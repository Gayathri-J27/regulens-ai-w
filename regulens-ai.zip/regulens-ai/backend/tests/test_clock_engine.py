"""Clock engine tests: unit + Hypothesis property tests (PART 7.6)."""
from datetime import date, datetime, timedelta, timezone

import pytest
from hypothesis import HealthCheck, given, settings, strategies as st

from app.engines.clock_engine import (ClockError, ClockEvent, ClockSpec, WorkCalendar, compute, compute_naive,
                                      count_countable, explain, local_date, walk_forward)

D0 = date(2026, 1, 5)  # a Monday
CAL = WorkCalendar.build(holidays={date(2026, 1, 26): "Republic Day", date(2026, 3, 4): "Holi",
                                   date(2026, 8, 15): "Independence Day"})


def ev(kind, d, **kw):
    return ClockEvent(kind, d, **kw)


# ----------------------------------------------------------------- unit
def test_walk_forward_working_skips_weekends_and_holidays():
    # 2026-01-23 (Fri) + 1 working day -> Tue 27 (26 is Republic Day, 24/25 weekend)
    assert walk_forward(date(2026, 1, 23), 1, CAL, "WORKING") == date(2026, 1, 27)
    assert walk_forward(D0, 5, CAL, "CALENDAR") == D0 + timedelta(days=5)
    assert walk_forward(D0, 0, CAL, "WORKING") == D0


def test_pause_resume_preserves_accrued_time():
    spec = ClockSpec(10, "CALENDAR")
    base = compute(spec, [ev("START", D0)], CAL, D0)
    paused = compute(spec, [ev("START", D0), ev("PAUSE", D0 + timedelta(3), pause_kind="INSTITUTION"),
                            ev("RESUME", D0 + timedelta(7))], CAL, D0 + timedelta(8))
    assert base.due_date == D0 + timedelta(10)
    assert paused.consumed == 3 + 1  # 3 days before pause, 1 day after resume
    assert paused.due_date == D0 + timedelta(14)  # shifted by exactly the 4 paused days


def test_paused_clock_has_no_due_date_but_projection():
    spec = ClockSpec(10, "CALENDAR")
    r = compute(spec, [ev("START", D0), ev("PAUSE", D0 + timedelta(2), pause_kind="INSTITUTION")], CAL, D0 + timedelta(5))
    assert r.state == "PAUSED_INSTITUTION" and r.due_date is None
    assert r.projected_due_if_resumed_today == D0 + timedelta(5 + 8)


def test_extension_moves_deadline():
    spec = ClockSpec(10, "WORKING")
    a = compute(spec, [ev("START", D0)], CAL, D0)
    b = compute(spec, [ev("START", D0), ev("EXTEND", D0 + timedelta(2), days=3)], CAL, D0)
    assert walk_forward(a.due_date, 3, CAL, "WORKING") == b.due_date


def test_holiday_change_triggers_recomputation():
    spec = ClockSpec(15, "WORKING")
    evs = [ev("START", date(2026, 1, 12))]
    before = compute(spec, evs, CAL, date(2026, 1, 12)).due_date
    cal2 = CAL.union(WorkCalendar.build(holidays={date(2026, 1, 20): "Regional holiday"}))
    after = compute(spec, evs, cal2, date(2026, 1, 12)).due_date
    assert after == walk_forward(before, 1, cal2, "WORKING")


def test_multiple_pauses_and_legal_hold_nesting():
    spec = ClockSpec(20, "CALENDAR")
    evs = [ev("START", D0), ev("PAUSE", D0 + timedelta(2), pause_kind="INSTITUTION"),
           ev("PAUSE", D0 + timedelta(4), pause_kind="LEGAL_HOLD"),
           ev("RESUME", D0 + timedelta(6), pause_kind="INSTITUTION"),
           ev("RESUME", D0 + timedelta(9), pause_kind="LEGAL_HOLD"),
           ev("PAUSE", D0 + timedelta(12), pause_kind="AICTE"), ev("RESUME", D0 + timedelta(13))]
    r = compute(spec, evs, CAL, D0 + timedelta(20))
    # excluded windows (2,9] and (12,13] -> 7 + 1 = 8 days
    assert r.due_date == D0 + timedelta(28)
    mid = compute(spec, evs[:4], CAL, D0 + timedelta(7))
    assert mid.state == "PAUSED_LEGAL_HOLD"  # still held even though the institution pause ended


def test_breach_and_stop_met():
    spec = ClockSpec(5, "CALENDAR")
    r = compute(spec, [ev("START", D0)], CAL, D0 + timedelta(9))
    assert r.state == "BREACHED" and r.breached and r.days_to_due == -4
    s = compute(spec, [ev("START", D0), ev("STOP_MET", D0 + timedelta(3))], CAL, D0 + timedelta(9))
    assert s.state == "STOPPED_MET" and s.met_on_time and s.consumed == 3


def test_revert_policies():
    spec = ClockSpec(10, "CALENDAR", revert_policy="RESUME")
    base = [ev("START", D0), ev("EXTEND", D0 + timedelta(1), days=2)]
    resume = compute(spec, base + [ev("REVERT", D0 + timedelta(4), policy="RESUME")], CAL, D0 + timedelta(4))
    restart = compute(spec, base + [ev("REVERT", D0 + timedelta(4), policy="RESTART")], CAL, D0 + timedelta(4))
    reset = compute(spec, base + [ev("REVERT", D0 + timedelta(4), policy="RESET_TO_STAGE_BUDGET", days=6)], CAL, D0 + timedelta(4))
    assert resume.due_date == D0 + timedelta(12)
    assert restart.due_date == D0 + timedelta(4 + 10)
    assert reset.due_date == D0 + timedelta(4 + 6 + 2)


def test_timezone_date_boundary():
    # 19:00 UTC on 1 Jan is 00:30 IST on 2 Jan
    assert local_date(datetime(2026, 1, 1, 19, 0, tzinfo=timezone.utc)) == date(2026, 1, 2)
    assert local_date(datetime(2026, 1, 1, 18, 29, tzinfo=timezone.utc)) == date(2026, 1, 1)
    spec = ClockSpec(3, "CALENDAR")
    r = compute(spec, [ClockEvent("START", datetime(2026, 1, 1, 19, 0, tzinfo=timezone.utc))], CAL, date(2026, 1, 2))
    assert r.due_date == date(2026, 1, 5)


def test_invalid_histories_rejected():
    with pytest.raises(ClockError):
        compute(ClockSpec(5), [ev("PAUSE", D0, pause_kind="AICTE")], CAL, D0)
    with pytest.raises(ClockError):
        ClockEvent("EXTEND", D0, days=0)
    with pytest.raises(ClockError):
        compute(ClockSpec(5), [ev("START", D0), ev("STOP_MET", D0), ev("EXTEND", D0, days=1)], CAL, D0)


def test_explain_is_deterministic_and_mentions_components():
    spec = ClockSpec(30, "WORKING")
    evs = [ev("START", date(2026, 1, 12)), ev("PAUSE", date(2026, 1, 20), pause_kind="INSTITUTION"),
           ev("RESUME", date(2026, 1, 26)), ev("EXTEND", date(2026, 2, 2), days=5, actor="RO")]
    r = compute(spec, evs, CAL, date(2026, 2, 3))
    e1 = explain(spec, r, "R-1 v1")
    e2 = explain(spec, compute(spec, evs, CAL, date(2026, 2, 3)), "R-1 v1")
    assert e1 == e2
    assert "30 working days were allocated" in e1["summary"]
    assert "Republic Day" not in e1["summary"]  # 26 Jan fell inside the institution pause, not a running window
    assert "while the institution responded" in e1["summary"]
    assert "1 extension" in e1["summary"]


# ----------------------------------------------------------------- property-based
@st.composite
def histories(draw):
    mode = draw(st.sampled_from(["WORKING", "CALENDAR"]))
    budget = draw(st.integers(0, 40))
    policy = draw(st.sampled_from(["RESUME", "RESTART", "RESET_TO_STAGE_BUDGET"]))
    start = D0 + timedelta(days=draw(st.integers(0, 60)))
    events = [ClockEvent("START", start)]
    d = start
    active: set[str] = set()
    for _ in range(draw(st.integers(0, 8))):
        d = d + timedelta(days=draw(st.integers(0, 9)))
        choice = draw(st.sampled_from(["PAUSE", "RESUME", "EXTEND", "REVERT"]))
        if choice == "PAUSE":
            k = draw(st.sampled_from(["INSTITUTION", "AICTE", "LEGAL_HOLD", "SOURCE"]))
            events.append(ClockEvent("PAUSE", d, pause_kind=k)); active.add(k)
        elif choice == "RESUME" and active:
            k = draw(st.sampled_from(sorted(active) + [None]))
            events.append(ClockEvent("RESUME", d, pause_kind=k))
            active = set() if k is None else active - {k}
        elif choice == "EXTEND":
            events.append(ClockEvent("EXTEND", d, days=draw(st.integers(1, 10))))
        elif choice == "REVERT":
            events.append(ClockEvent("REVERT", d, policy=draw(st.sampled_from(["RESUME", "RESTART", "RESET_TO_STAGE_BUDGET"])),
                                     days=draw(st.integers(0, 20)))); active = set()
    if draw(st.booleans()):
        d = d + timedelta(days=draw(st.integers(0, 15)))
        events.append(ClockEvent(draw(st.sampled_from(["STOP_MET", "STOP_WAIVED"])), d))
    today = d + timedelta(days=draw(st.integers(0, 30)))
    return ClockSpec(budget, mode, policy), events, today


@settings(max_examples=400, deadline=None, suppress_health_check=[HealthCheck.too_slow])
@given(histories())
def test_property_interval_engine_matches_day_by_day_reference(h):
    spec, events, today = h
    fast = compute(spec, events, CAL, today)
    ref = compute_naive(spec, events, CAL, today)
    assert fast.consumed == ref["consumed"]
    assert fast.effective_budget == ref["budget"]
    assert fast.due_date == ref["due_date"]


@settings(max_examples=200, deadline=None)
@given(histories())
def test_property_reproducible(h):
    spec, events, today = h
    assert compute(spec, events, CAL, today).to_dict() == compute(spec, list(events), CAL, today).to_dict()


@settings(max_examples=200, deadline=None)
@given(histories())
def test_property_incremental_prefixes_never_lose_accrued_time(h):
    """Replaying growing prefixes: consumption only drops on a resetting REVERT."""
    spec, events, today = h
    prev = None
    for k in range(1, len(events) + 1):
        day = events[k - 1].day
        r = compute(spec, events[:k], CAL, day)
        if prev is not None and events[k - 1].kind != "REVERT":
            assert r.consumed >= prev
        prev = r.consumed


@settings(max_examples=200, deadline=None)
@given(st.integers(0, 60), st.integers(1, 30), st.integers(1, 30))
def test_property_pause_shifts_due_by_countable_paused_days(budget, pause_at, length):
    spec = ClockSpec(budget, "WORKING")
    evs = [ClockEvent("START", D0), ClockEvent("PAUSE", D0 + timedelta(pause_at), pause_kind="INSTITUTION"),
           ClockEvent("RESUME", D0 + timedelta(pause_at + length))]
    plain = compute(spec, evs[:1], CAL, D0)
    paused = compute(spec, evs, CAL, D0 + timedelta(pause_at + length))
    if plain.due_date <= D0 + timedelta(pause_at):
        assert paused.due_date == plain.due_date  # deadline fell before the pause
    else:
        excluded = count_countable(D0 + timedelta(pause_at), D0 + timedelta(pause_at + length), CAL, "WORKING")
        assert count_countable(plain.due_date, paused.due_date, CAL, "WORKING") == excluded
