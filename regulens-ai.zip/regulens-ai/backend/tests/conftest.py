"""Integration tests run against a dedicated database (regulens_test) migrated with Alembic and seeded at reduced scale."""
import os
import sys
from pathlib import Path

import pytest

os.environ.setdefault("DATABASE_URL", "postgresql+psycopg://regulens:regulens@localhost:5432/regulens_test")
os.environ["RUN_SCHEDULER"] = "0"
os.environ["LOGIN_RATE_PER_MIN"] = "500"
os.environ.setdefault("STORAGE_DIR", str(Path(__file__).resolve().parents[2] / ".run" / "test-uploads"))
os.environ.setdefault("AUDIT_ANCHOR_DIR", str(Path(__file__).resolve().parents[2] / ".run" / "test-anchor"))
ROOT = Path(__file__).resolve().parents[2]


def _db_needed(items):
    return any("integration" in str(i.fspath) for i in items)


@pytest.fixture(scope="session")
def app_client():
    from alembic import command
    from alembic.config import Config
    from sqlalchemy import create_engine, text
    url = os.environ["DATABASE_URL"]
    eng = create_engine(url)
    with eng.begin() as c:  # fresh schema each session
        c.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public;"))
    eng.dispose()
    cfg = Config(str(ROOT / "backend" / "alembic.ini"))
    cfg.set_main_option("script_location", str(ROOT / "backend" / "migrations"))
    cfg.set_main_option("sqlalchemy.url", url)
    command.upgrade(cfg, "head")
    import subprocess
    if not (ROOT / "demo_docs" / "approval_letter_scanned.pdf").exists():
        subprocess.run([sys.executable, str(ROOT / "scripts" / "make_demo_docs.py")], check=True)
    from app.core.db import SessionLocal
    from app.services.seed import bootstrap, seed_demo_workload
    from app.services.synthetic import generate
    db = SessionLocal()
    bootstrap(db); db.commit()
    seed_demo_workload(db); db.commit()
    generate(db, None, seed=7, scale=0.15); db.commit()
    from app.services import escalation, intelligence
    escalation.sweep(db); intelligence.recompute_risk(db); db.commit()
    db.close()
    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as c:
        yield c
