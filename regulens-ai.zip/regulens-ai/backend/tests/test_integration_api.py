"""API integration tests on a real PostgreSQL database (no mocks)."""
import sys
from pathlib import Path

import pytest
from sqlalchemy import text

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
PW = "Demo@1234"


def tok(c, email):
    r = c.post("/api/auth/login", json={"email": email, "password": PW})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


def test_full_end_to_end_scenario(app_client):
    """PART 29: scenarios A–H (64 steps + two-person rule) through the real API."""
    import e2e_scenario
    log = e2e_scenario.run(app_client, verbose=False)
    assert len(log) == 65, log[-3:]


def test_login_lockout_and_logout(app_client):
    c = app_client
    for _ in range(5):
        assert c.post("/api/auth/login", json={"email": "auditor@regulens.demo", "password": "wrong"}).status_code == 401
    r = c.post("/api/auth/login", json={"email": "auditor@regulens.demo", "password": PW})
    assert r.status_code == 423  # locked after repeated failures
    from app.core.db import SessionLocal
    db = SessionLocal()
    db.execute(text("UPDATE users SET locked_until=NULL, failed_logins=0 WHERE email='auditor@regulens.demo'")); db.commit(); db.close()
    h = tok(c, "auditor@regulens.demo")
    assert c.get("/api/auth/me", headers=h).status_code == 200
    assert c.post("/api/auth/logout", headers=h).status_code == 200
    assert c.get("/api/auth/me", headers=h).status_code == 401
    assert c.get("/api/auth/me", headers={"Authorization": "Bearer forged"}).status_code == 401


def test_backend_enforces_permissions_not_ui(app_client):
    c = app_client
    p = tok(c, "principal@kaveri-demo.in")
    assert c.get("/api/dashboard", headers=p).status_code == 403
    assert c.post("/api/admin/audit/verify", headers=p).status_code == 403
    assert c.post("/api/admin/rules", headers=p, json={"rule_key": "x", "params": {}}).status_code == 403
    b = tok(c, "bureau@regulens.demo")
    assert c.post("/api/escalations/run-sweep", headers=b).status_code == 403


def test_institution_isolation_via_api_and_rls(app_client):
    c = app_client
    p = tok(c, "principal@kaveri-demo.in")
    me = c.get("/api/auth/me", headers=p).json()
    items = c.get("/api/ledger?view=all&page_size=200", headers=p).json()["items"]
    assert items and all(i["institution_id"] == me["institution_id"] for i in items)
    from app.core.db import SessionLocal
    db = SessionLocal()
    other = db.execute(text("SELECT id FROM obligations WHERE institution_id <> :i LIMIT 1"), {"i": me["institution_id"]}).scalar()
    assert c.get(f"/api/ledger/{other}", headers=p).status_code in (403, 404)
    # database-level RLS: with the scope set, foreign rows are invisible even to raw SQL
    db.execute(text("SELECT set_config('app.scope_institution', :v, false)"), {"v": str(me["institution_id"])})
    n_foreign = db.execute(text("SELECT count(*) FROM obligations WHERE institution_id <> :i"), {"i": me["institution_id"]}).scalar()
    db.execute(text("SELECT set_config('app.scope_institution', '', false)"))
    db.close()
    assert n_foreign == 0


def test_audit_log_is_append_only_in_database(app_client):
    from app.core.db import SessionLocal
    db = SessionLocal()
    for stmt in ("UPDATE audit_log SET reason='x' WHERE id=(SELECT min(id) FROM audit_log)", "DELETE FROM audit_log", "TRUNCATE audit_log"):
        with pytest.raises(Exception, match="append-only"):
            db.execute(text(stmt))
        db.rollback()
    db.close()


def test_scheduler_crash_recovery_no_miss_no_duplicate(app_client):
    from app.core.db import SessionLocal
    from app.services.benchmark import crash_recovery
    db = SessionLocal()
    r = crash_recovery(db, n=20)
    db.close()
    assert r["crashed_mid_run"] > 0 and r["missed_after_recovery"] == 0 and r["duplicate_notifications"] == 0


def test_notification_states_never_claim_unconfirmed_delivery(app_client):
    from app.core.db import SessionLocal
    from app.services.notifications import dispatch_due
    db = SessionLocal()
    dispatch_due(db, limit=3000); db.commit()
    bad = db.execute(text("SELECT count(*) FROM notifications n WHERE status='DELIVERED' AND NOT EXISTS "
                          "(SELECT 1 FROM delivery_log d WHERE d.notification_id=n.id AND d.outcome='DELIVERED')")).scalar()
    bounced_contacts = db.execute(text("SELECT count(*) FROM institution_contacts WHERE invalid")).scalar()
    db.close()
    assert bad == 0
    assert bounced_contacts > 0  # synthetic unreachable contacts were detected and flagged


def test_reports_export_csv_and_pdf_logged(app_client):
    c = app_client
    h = tok(c, "admin@regulens.demo")
    assert len(c.get("/api/reports", headers=h).json()) == 14
    for name in ("region_pendency", "overdue_obligations", "audit_verification", "institution_health"):
        assert c.get(f"/api/reports/{name}", headers=h).status_code == 200
    r = c.get("/api/reports/overdue_obligations?fmt=csv", headers=h)
    assert r.status_code == 200 and "Obligation" in r.text
    r = c.get("/api/reports/region_pendency?fmt=pdf", headers=h)
    assert r.status_code == 200 and r.content.startswith(b"%PDF")
    aud = c.get("/api/admin/audit?action=EXPORT", headers=tok(c, "auditor@regulens.demo")).json()
    assert aud["total"] >= 2


def test_upload_validation_and_malware_block(app_client):
    c = app_client
    h = tok(c, "ro.south@regulens.demo")
    r = c.post("/api/files", headers=h, files={"file": ("x.exe", b"MZ\x90\x00binary", "application/octet-stream")})
    assert r.status_code == 415
    eicar = b"%PDF-1.4\n" + b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
    r = c.post("/api/files", headers=h, files={"file": ("bad.pdf", eicar, "application/pdf")})
    assert r.status_code == 422 and "malware" in r.text


def test_magic_link_single_use_and_scoped(app_client):
    c = app_client
    h = tok(c, "ro.south@regulens.demo")
    o = c.get("/api/ledger?view=institution&state=OPEN&page_size=1&region_id=1", headers=h).json()["items"][0]
    link = c.post(f"/api/ledger/{o['id']}/do/magic-link", headers=h, json={}).json()["result"]["link"]
    token = link.rsplit("/", 1)[1]
    assert c.get(f"/api/m/{token}").json()["obligation"]["obl_no"] == o["obl_no"]
    pdf = (ROOT / "demo_docs" / "evidence_fire_noc.pdf").read_bytes()
    r = c.post(f"/api/m/{token}/evidence", files={"file": ("e.pdf", pdf, "application/pdf")})
    assert r.status_code == 200 and r.json()["receipt_no"].startswith("RCPT-")
    assert c.get(f"/api/m/{token}").status_code == 410  # single use
    assert c.get("/api/m/not-a-real-token").status_code == 404


def test_rule_versioning_two_person_and_pinning(app_client):
    c = app_client
    a1, a2 = tok(c, "admin@regulens.demo"), tok(c, "admin2@regulens.demo")
    r = c.post("/api/admin/rules", headers=a1, json={"rule_key": "deadline.EVC_SCHEDULING", "params": {"budget_days": 8, "day_mode": "WORKING", "revert_policy": "RESUME"}}).json()
    assert c.post(f"/api/admin/rules/{r['id']}/approve", headers=a2, json={}).status_code == 409  # preview required first
    assert c.post(f"/api/admin/rules/{r['id']}/preview", headers=a1).json()["status"] == "PREVIEWED"
    assert c.post(f"/api/admin/rules/{r['id']}/approve", headers=a1, json={}).status_code == 403
    out = c.post(f"/api/admin/rules/{r['id']}/approve", headers=a2, json={}).json()
    assert out["status"] == "EFFECTIVE"
    hb = c.post("/api/admin/rules", headers=a1, json={"rule_key": "deadline.EVC_SCHEDULING", "params": {}, "source_type": "HANDBOOK_CONFIRMED"})
    assert hb.status_code == 422  # cannot claim handbook confirmation without a verified citation


def test_simulator_uses_stored_records(app_client):
    c = app_client
    h = tok(c, "admin@regulens.demo")
    r = c.post("/api/simulator/run", headers=h, json={"rule_key": "deadline.SCRUTINY_COMPLETION", "params": {"budget_days": 5}}).json()
    assert r["obligations_replayed"] > 0 and r["deadlines_changed"] > 0 and "historical_backtest" in r


def test_dashboard_and_intelligence_endpoints(app_client):
    c = app_client
    h = tok(c, "admin@regulens.demo")
    d = c.get("/api/dashboard", headers=h).json()
    assert d["kpis"]["total_applications"] > 0 and d["source"]["applications"].startswith("materialized")
    assert c.get("/api/dashboard?officer_id=1", headers=h).json()["source"]["applications"] == "live query"
    assert c.get("/api/process-mining", headers=h).json()["applications"] > 0
    assert c.get("/api/capacity", headers=h).status_code == 200
    ro = tok(c, "ro.south@regulens.demo")
    t = c.get("/api/today", headers=ro).json()
    assert len(t["items"]) <= 10 and t["items"] == sorted(t["items"], key=lambda x: -x["priority"])
    imp = c.post("/api/impact", headers=h, json={}).json()
    assert "MODELLED ESTIMATE" in imp["label"]


def test_csv_import_preview_validation_cutover(app_client):
    c = app_client
    h = tok(c, "admin@regulens.demo")
    csv = ("institution_aicte_id,title,due_date,start_date\nDEMO-SR-0001,Submit hostel safety audit,2027-01-15,2026-10-01\n"
           "NOPE-1,Bad row,2027-01-01,\nDEMO-SR-0001,Submit hostel safety audit,2027-01-15,2026-10-01\nDEMO-SR-0001,Bad date,31/31/2027,\n")
    b = c.post("/api/admin/imports/csv", headers=h, data={"entity": "undertaking"}, files={"file": ("u.csv", csv.encode(), "text/csv")}).json()
    assert b["counts"] == {"received": 4, "valid": 1, "errors": 2, "duplicates": 1}
    sim = c.post(f"/api/admin/imports/{b['id']}/commit", headers=h, json={"dry_run": True}).json()
    assert sim["dry_run"] and sim["created"] == 1 and sim["batch"]["status"] == "STAGED"
    done = c.post(f"/api/admin/imports/{b['id']}/commit", headers=h, json={"dry_run": False}).json()
    assert done["batch"]["status"] == "COMMITTED"


def test_case_exceptions_hold_appeal_merge_withdraw(app_client):
    c = app_client
    ro, adm = tok(c, "ro.south@regulens.demo"), tok(c, "admin@regulens.demo")
    inst = c.get("/api/institutions?q=DEMO-SR-0001", headers=ro).json()["items"][0]["id"]
    new = lambda t: c.post("/api/applications", headers=ro, json={"institution_id": inst, "application_type": t}).json()
    a, b = new("NEW_COURSE"), new("NEW_COURSE")
    # court-ordered hold: requires the order, needs elevated authority, pauses every open obligation
    assert c.post(f"/api/applications/{a['id']}/exception", headers=ro, json={"kind": "LEGAL_HOLD", "reason": "stay"}).status_code == 403
    assert c.post(f"/api/applications/{a['id']}/exception", headers=adm, json={"kind": "LEGAL_HOLD", "reason": "stay"}).status_code == 422
    pdf = (ROOT / "demo_docs" / "evidence_fire_noc.pdf").read_bytes()
    fid = c.post("/api/files", headers=adm, data={"purpose": "court_order", "institution_id": str(inst)}, files={"file": ("order.pdf", pdf, "application/pdf")}).json()["id"]
    r = c.post(f"/api/applications/{a['id']}/exception", headers=adm, json={"kind": "LEGAL_HOLD", "reason": "High Court stay", "order_file_id": fid}).json()
    assert r["obligations_affected"] >= 1
    d = c.get(f"/api/applications/{a['id']}", headers=ro).json()
    assert d["status"] == "ON_HOLD" and d["stage_obligation"]["state"] == "PAUSED"
    ex = c.get(f"/api/clocks/{c.get('/api/ledger/' + str(d['stage_obligation']['id']), headers=ro).json()['clock_id']}/explain", headers=ro).json()
    assert ex["state"] == "PAUSED_LEGAL_HOLD"
    c.post(f"/api/applications/{a['id']}/exception", headers=adm, json={"kind": "LIFT_HOLD", "reason": "stay vacated"})
    assert c.get(f"/api/applications/{a['id']}", headers=ro).json()["status"] == "IN_PROGRESS"
    # appeal creates a child case
    ap = c.post(f"/api/applications/{a['id']}/exception", headers=ro, json={"kind": "APPEAL", "reason": "appeal filed"}).json()
    assert c.get(f"/api/applications/{ap['child_application_id']}", headers=ro).json()["parent_application_id"] == a["id"]
    # duplicate merged into primary; obligations de-duplicated, history kept
    m = c.post(f"/api/applications/{b['id']}/exception", headers=ro, json={"kind": "MERGED", "reason": "duplicate", "primary_application_id": a["id"]}).json()
    assert m["deduplicated"] >= 1
    bd = c.get(f"/api/applications/{b['id']}", headers=ro).json()
    assert bd["status"] == "MERGED" and all(o["state"] in ("MERGED", "MET", "WAIVED", "CANCELLED") for o in bd["obligations"])
    # withdrawal cancels open obligations and stops clocks
    w = c.post(f"/api/applications/{ap['child_application_id']}/exception", headers=ro, json={"kind": "WITHDRAWN", "reason": "institution withdrew"}).json()
    assert w["cancelled_obligations"] >= 1
    assert c.post(f"/api/applications/{a['id']}/exception", headers=ro, json={"kind": "WITHDRAWN", "reason": ""}).status_code == 422
