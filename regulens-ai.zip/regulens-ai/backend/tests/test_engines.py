"""Unit tests for the pure engines: workflow state machine, escalation resolver, audit chain, priority, risk,
EVC ranking and bounded extraction."""
from datetime import date, timedelta

import pytest
from hypothesis import given, settings, strategies as st

from app.engines import audit_chain as ac
from app.engines import extraction as ex
from app.engines import priority as pr
from app.engines import risk as rk
from app.engines import workflow as wf
from app.engines.escalation_resolver import DelegationView, PostView, escalation_target_post, resolve
from app.engines.evc_ranker import ExpertView, propose
from app.engines.ocr import find_expiry, parse_dates


# ------------------------------------------------------------------ workflow
def test_default_routes_are_valid():
    for code, (_, d) in wf.DEFAULT_ROUTES.items():
        assert wf.validate_definition(d) == [], code


def test_route_progression_and_validation():
    d = wf.DEFAULT_ROUTES["SCRUTINY_EVC"][1]
    assert wf.first_stage(d) == "SCRUTINY"
    with pytest.raises(wf.WorkflowError, match="scrutiny_remarks"):
        wf.plan_complete(d, "SCRUTINY", {}, {})
    assert wf.plan_complete(d, "SCRUTINY", {"scrutiny_remarks": "ok"}, {}).to_stage == "EVC"
    with pytest.raises(wf.WorkflowError, match="evc report"):
        wf.plan_complete(d, "EVC", {}, {"evc_report": False})
    assert wf.plan_complete(d, "EVC", {}, {"evc_report": True}).to_stage == "DECISION"
    assert wf.next_stage(d, "RESCRUTINY") == "EVC"  # re-scrutiny rejoins the main path


def test_decision_stage_is_human_only():
    d = wf.DEFAULT_ROUTES["EVC_ONLY"][1]
    with pytest.raises(wf.WorkflowError, match="competent authority"):
        wf.plan_complete(d, "DECISION", {}, {})
    with pytest.raises(wf.WorkflowError):
        wf.plan_decide(d, "DECISION", "APPROVED", "")
    assert wf.plan_decide(d, "DECISION", "REJECTED", "deficiencies uncured").kind == "DECIDE"


def test_return_and_revert_rules():
    d = wf.DEFAULT_ROUTES["SCRUTINY_EVC_SAC"][1]
    with pytest.raises(wf.WorkflowError, match="reason"):
        wf.plan_return(d, "SCRUTINY", " ")
    with pytest.raises(wf.WorkflowError, match="does not allow"):
        wf.plan_return(d, "SAC_SHC", "x")
    assert wf.plan_resubmit(d, "SCRUTINY").to_stage == "RESCRUTINY"
    with pytest.raises(wf.WorkflowError, match="not permitted"):
        wf.plan_revert(d, "EVC", "DECISION", "x")
    assert wf.plan_revert(d, "DECISION", "EVC", "panel re-visit").clock_policy == d["revert_policy"]


def test_invalid_route_definition_detected():
    bad = {"stages": [{"code": "A", "budget_days": 1}, {"code": "A", "budget_days": 1, "resubmit_to": "Z"}], "revert_policy": "SOMETIMES"}
    errs = wf.validate_definition(bad)
    assert any("duplicate" in e for e in errs) and any("decision" in e for e in errs) and any("revert_policy" in e for e in errs)


# ------------------------------------------------------------------ escalation resolver
POSTS = {
    1: PostView(1, 4, None, None, 100, "HQ"),
    2: PostView(2, 3, 10, 1, 200, "SR-HEAD"),
    3: PostView(3, 2, 10, 2, None, "SR-DD"),  # vacant
    4: PostView(4, 1, 10, 3, 400, "SR-DESK"),
    5: PostView(5, 2, 20, 2, 500, "SWR-DD"),   # nearest Region peer
    6: PostView(6, 2, 30, 2, 600, "ER-DD"),    # far Region peer
}
COORDS = {10: (13.08, 80.27), 20: (12.97, 77.59), 30: (22.57, 88.36)}
TODAY = date(2026, 10, 30)
ACTIVE = {100, 200, 400, 500, 600, 700}


def test_holder_and_delegate():
    assert resolve(4, TODAY, POSTS, [], ACTIVE, COORDS).recipient_id == 400
    dl = [DelegationView(4, 700, TODAY - timedelta(days=1), TODAY + timedelta(days=3))]
    r = resolve(4, TODAY, POSTS, dl, ACTIVE, COORDS)
    assert (r.recipient_id, r.via) == (700, "DELEGATE")
    expired = [DelegationView(4, 700, TODAY - timedelta(days=9), TODAY - timedelta(days=1))]
    assert resolve(4, TODAY, POSTS, expired, ACTIVE, COORDS).recipient_id == 400


def test_vacant_post_falls_back_to_nearest_region():
    r = resolve(3, TODAY, POSTS, [], ACTIVE, COORDS)
    assert (r.recipient_id, r.via) == (500, "NEAREST_REGION")  # Bengaluru is nearer to Chennai than Kolkata


def test_next_level_then_unroutable():
    r = resolve(3, TODAY, POSTS, [], ACTIVE - {500, 600}, COORDS)
    assert (r.recipient_id, r.via) == (200, "HOLDER")
    r2 = resolve(3, TODAY, POSTS, [], set(), COORDS)
    assert r2.recipient_id is None and r2.via == "UNROUTABLE"


def test_transfer_is_resolved_at_execution_time():
    moved = dict(POSTS)
    moved[4] = PostView(4, 1, 10, 3, 999, "SR-DESK")  # officer transferred; new holder 999
    assert resolve(4, TODAY, moved, [], ACTIVE | {999}, COORDS).recipient_id == 999


def test_escalation_target_levels():
    assert escalation_target_post(4, 1, POSTS) == 3
    assert escalation_target_post(4, 2, POSTS) == 2
    assert escalation_target_post(4, 9, POSTS) == 1  # capped at the top


# ------------------------------------------------------------------ audit chain
def _chain(n):
    rows, prev = [], ac.GENESIS
    for i in range(1, n + 1):
        e = {"id": i, "ts": f"2026-10-30T10:00:{i:02d}Z", "actor_id": 1, "actor_role": "R", "action": "A", "entity_type": "x",
             "entity_id": str(i), "before": None, "after": {"v": i}, "reason": None, "correlation_id": None}
        h = ac.entry_hash(prev, e)
        rows.append(e | {"prev_hash": prev, "hash": h})
        prev = h
    return rows


def test_canonical_json_is_order_independent():
    a = {"id": 1, "after": {"b": 1, "a": 2}, "before": None}
    b = {"before": None, "after": {"a": 2, "b": 1}, "id": 1}
    assert ac.canonical_json(a) == ac.canonical_json(b)


@settings(max_examples=60, deadline=None)
@given(st.integers(2, 40), st.data())
def test_any_single_alteration_is_detected_at_its_position(n, data):
    rows = _chain(n)
    assert ac.verify_chain(rows)["ok"]
    k = data.draw(st.integers(0, n - 1))
    rows[k] = rows[k] | {"after": {"v": -1}}
    res = ac.verify_chain(rows)
    assert not res["ok"] and res["first_broken_id"] == k + 1


def test_deletion_and_reordering_detected():
    rows = _chain(10)
    assert ac.verify_chain(rows[:4] + rows[5:])["first_broken_id"] == 6
    sw = rows[:]
    sw[2], sw[3] = sw[3], sw[2]
    assert not ac.verify_chain(sw)["ok"]


# ------------------------------------------------------------------ priority
def test_priority_handles_zero_negative_and_paused():
    w = {"w1": 10, "w2": 2, "w3": 3, "w4": 1.5}
    assert pr.urgency(None) == 0
    assert pr.urgency(0) == 2.0 and pr.urgency(-5) == 2.5 and pr.urgency(-500) == 5.0
    assert pr.urgency(1) == 1.0 and pr.urgency(10) == pytest.approx(0.1)
    overdue = pr.score(-3, 2, False, 10, w)["priority"]
    soon = pr.score(1, 2, False, 10, w)["priority"]
    later = pr.score(20, 2, False, 10, w)["priority"]
    assert overdue > soon > later
    assert pr.score(5, 1, True, 0, w)["priority"] > pr.score(5, 3, False, 0, w)["priority"]


# ------------------------------------------------------------------ risk
def test_risk_insufficient_data_and_shrinkage():
    th = {"medium": 0.3, "high": 0.6, "min_samples": 30, "shrinkage_k": 30}
    small = rk.build([("X", 1, 2, 0.5)] * 10)
    r = rk.estimate(small, otype="X", region_id=1, tier=2, start=date(2026, 10, 1), due=date(2026, 11, 1), today=date(2026, 10, 10), state="OPEN",
                    inst_miss_rate=None, inst_n=0, has_evidence=False, inst_response_ratio=None, officer_load=None, median_load=None, thresholds=th)
    assert r["level"] == "INSUFFICIENT_DATA" and r["probability"] is None
    hist = [("X", 1, 2, 0.5)] * 40 + [("X", 1, 2, 1.5)] * 40 + [("Y", 2, 1, 0.3)] * 100
    t = rk.build(hist)
    base = dict(otype="X", region_id=1, tier=2, start=date(2026, 10, 1), due=date(2026, 11, 1), state="OPEN", inst_miss_rate=None, inst_n=0,
                has_evidence=True, inst_response_ratio=None, officer_load=None, median_load=None, thresholds=th)
    early = rk.estimate(t, today=date(2026, 10, 2), **base)
    late = rk.estimate(t, today=date(2026, 10, 25), **base)
    assert 0 < early["probability"] < late["probability"] <= 0.99
    assert len(late["reasons"]) <= 3 and late["sample_size"] == 80
    sub = rk.estimate(t, today=date(2026, 10, 25), **(base | {"state": "SUBMITTED"}))
    assert sub["probability"] < late["probability"]


# ------------------------------------------------------------------ EVC
def _ex(i, **k):
    d = dict(id=i, name=f"E{i}", expertise=("ACADEMICS", "LABS"), region_id=1, lat=13.0, lon=80.2, monthly_cap=4, active=True,
             unavailable=frozenset(), coi=frozenset(), month_load=0)
    d.update(k)
    return ExpertView(**d)


def test_evc_filters_record_reasons_and_rank():
    vd = date(2026, 11, 10)
    experts = [_ex(1), _ex(2, coi=frozenset({77})), _ex(3, unavailable=frozenset({vd.isoformat()})), _ex(4, month_load=4),
               _ex(5, region_id=2), _ex(6, expertise=("CIVIL_INFRA",)), _ex(7, lat=13.5), _ex(8, month_load=3)]
    res = propose(experts, institution_id=77, institution_region=1, inst_coords=(13.0, 80.2), visit_date=vd,
                  required=["ACADEMICS", "CIVIL_INFRA"], weights={"panel_size": 3, "region_policy": "SAME_REGION_ONLY"})
    why = {x["expert_id"]: " ".join(x["reasons"]) for x in res["excluded"]}
    assert "conflict of interest" in why[2] and "unavailable" in why[3] and "cap" in why[4] and "Region policy" in why[5]
    assert len(res["panels"]) == 3
    assert all(not set(p["expert_ids"]) & {2, 3, 4, 5} for p in res["panels"])
    assert 6 in res["panels"][0]["expert_ids"]  # only expert covering CIVIL_INFRA -> best coverage


# ------------------------------------------------------------------ extraction
LETTER = ("Ref: F.No. 1 dated 01.10.2026\n1. The institution shall submit a valid Fire Safety No Objection Certificate within 30 days from the date of this letter.\n"
          "2. The Trust shall submit the registered lease deed on or before 31.03.2027.\n3. The institution undertakes to maintain the prescribed ratio.\n"
          "4. This letter is issued with approval.")


def test_local_extraction_with_source_verification():
    items = ex.local_extract(LETTER, None)
    ok, rej = ex.validate_and_verify(items, LETTER, date(2026, 10, 1))
    assert len(ok) == 3 and not rej
    fire = next(i for i in ok if "Fire" in i["source_sentence"])
    assert fire["due_date"] == date(2026, 10, 31) and fire["relative_days"] == 30
    lease = next(i for i in ok if "lease" in i["source_sentence"])
    assert lease["due_date"] == date(2027, 3, 31) and lease["responsible_role"] == "TRUST_SOCIETY"
    assert next(i for i in ok if "undertakes" in i["source_sentence"])["due_date"] is None  # never invented


def test_hallucinated_or_invented_items_are_rejected():
    fake = [{"kind": "UNDERTAKING", "title": "Build a stadium", "source_sentence": "The institution shall build a stadium by 2027.", "confidence": 0.9},
            {"kind": "CONDITION", "title": "Fire NOC", "confidence": 0.9,
             "source_sentence": "The institution shall submit a valid Fire Safety No Objection Certificate within 30 days from the date of this letter.",
             "due_date": "2026-12-25"},
            {"kind": "APPROVE_INSTITUTION", "title": "x", "source_sentence": "4. This letter is issued with approval.", "confidence": 1}]
    ok, rej = ex.validate_and_verify(fake, LETTER, date(2026, 10, 1))
    reasons = " | ".join(r["reason"] for r in rej)
    assert not ok and "not found" in reasons and "invented deadline" in reasons and "schema" in reasons


# ------------------------------------------------------------------ OCR date logic (text level)
def test_parse_dates_and_expiry_selection():
    assert [d for d, *_ in parse_dates("on 05.04.2027 and 3rd March 2026 and Jan 2, 2025")] == [date(2027, 4, 5), date(2026, 3, 3), date(2025, 1, 2)]
    r = find_expiry("Deed executed on 14.12.2017. This lease shall expire on 13 December 2026 unless renewed.")
    assert r["expiry"] == "2026-12-13" and r["issue"] == "2017-12-14"
    r2 = find_expiry("The lease is for a period of 9 years commencing from 01.01.2020.")
    assert r2["expiry"] == "2028-12-31"
    assert find_expiry("No dates at all")["expiry"] is None
