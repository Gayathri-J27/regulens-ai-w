"""widen applications.decision and extraction_jobs.text_method

Revision ID: 0005
Revises: 0004
"""
from alembic import op
import sqlalchemy as sa

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.alter_column("applications", "decision", type_=sa.String(40))
    op.alter_column("extraction_jobs", "text_method", type_=sa.String(120))


def downgrade() -> None:
    pass
