"""RLS policies: NULLIF so an empty scope setting never reaches the integer cast

Revision ID: 0003
Revises: 0002
"""
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None
TABLES = ["obligations", "evidence", "institutional_documents", "applications"]


def upgrade() -> None:
    for t in TABLES:
        op.execute(f"""
        DROP POLICY IF EXISTS {t}_institution_isolation ON {t};
        CREATE POLICY {t}_institution_isolation ON {t}
          USING (NULLIF(current_setting('app.scope_institution', true), '') IS NULL
                 OR institution_id = NULLIF(current_setting('app.scope_institution', true), '')::int);
        """)


def downgrade() -> None:
    pass
