"""audit append-only triggers, row-level security, partial indexes, dashboard materialised view

Revision ID: 0002
Revises: 0001
"""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

RLS_TABLES = ["obligations", "evidence", "institutional_documents", "applications"]


def upgrade() -> None:
    # --- tamper-evident audit: append-only enforced in the database itself
    op.execute("""
    CREATE OR REPLACE FUNCTION audit_log_block_mutation() RETURNS trigger AS $$
    BEGIN
      RAISE EXCEPTION 'audit_log is append-only: % is not permitted', TG_OP USING ERRCODE = 'insufficient_privilege';
    END; $$ LANGUAGE plpgsql;
    CREATE TRIGGER audit_log_no_update BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION audit_log_block_mutation();
    CREATE TRIGGER audit_log_no_truncate BEFORE TRUNCATE ON audit_log FOR EACH STATEMENT EXECUTE FUNCTION audit_log_block_mutation();
    CREATE TRIGGER audit_seals_no_update BEFORE UPDATE OR DELETE ON audit_seals FOR EACH ROW EXECUTE FUNCTION audit_log_block_mutation();
    REVOKE UPDATE, DELETE, TRUNCATE ON audit_log FROM PUBLIC;
    """)
    # --- row-level security: institution users only ever see their own institution's rows
    for t in RLS_TABLES:
        op.execute(f"""
        ALTER TABLE {t} ENABLE ROW LEVEL SECURITY;
        ALTER TABLE {t} FORCE ROW LEVEL SECURITY;
        CREATE POLICY {t}_institution_isolation ON {t}
          USING (coalesce(current_setting('app.scope_institution', true), '') = ''
                 OR institution_id = current_setting('app.scope_institution', true)::int);
        """)
    # --- partial indexes for open work (scale: 200k obligations)
    op.execute("CREATE INDEX IF NOT EXISTS ix_obl_open_assignee ON obligations (assigned_user_id, due_date) WHERE state IN ('OPEN','ACKNOWLEDGED','SUBMITTED','PAUSED')")
    op.execute("CREATE INDEX IF NOT EXISTS ix_obl_open_inst ON obligations (institution_id, due_date) WHERE state IN ('OPEN','ACKNOWLEDGED','SUBMITTED','PAUSED')")
    op.execute("CREATE INDEX IF NOT EXISTS ix_notif_queued ON notifications (next_attempt_at) WHERE status = 'QUEUED'")
    op.execute("CREATE INDEX IF NOT EXISTS ix_app_events_app_at ON application_events (application_id, at)")
    op.execute("CREATE INDEX IF NOT EXISTS ix_clocks_calendars ON clocks USING gin (calendar_ids)")
    # --- dashboard aggregate (refresh interval configured by rule dashboard.refresh)
    op.execute("""
    CREATE MATERIALIZED VIEW mv_app_rollup AS
      SELECT i.region_id, i.state, a.route_code, a.application_type, a.current_stage, a.status, a.priority, a.is_synthetic,
             count(*)::bigint AS n
      FROM applications a JOIN institutions i ON i.id = a.institution_id
      GROUP BY 1,2,3,4,5,6,7,8;
    CREATE UNIQUE INDEX mv_app_rollup_uq ON mv_app_rollup (region_id, state, route_code, application_type, current_stage, status, priority, is_synthetic);
    CREATE TABLE mv_refresh_log (name text PRIMARY KEY, refreshed_at timestamptz);
    INSERT INTO mv_refresh_log VALUES ('mv_app_rollup', now());
    """)


def downgrade() -> None:
    op.execute("DROP MATERIALIZED VIEW IF EXISTS mv_app_rollup; DROP TABLE IF EXISTS mv_refresh_log;")
    for t in RLS_TABLES:
        op.execute(f"DROP POLICY IF EXISTS {t}_institution_isolation ON {t}; ALTER TABLE {t} DISABLE ROW LEVEL SECURITY;")
    op.execute("DROP TRIGGER IF EXISTS audit_log_no_update ON audit_log; DROP TRIGGER IF EXISTS audit_log_no_truncate ON audit_log;"
               "DROP TRIGGER IF EXISTS audit_seals_no_update ON audit_seals;")
