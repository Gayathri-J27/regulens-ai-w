"""widen files.scan_engine for descriptive scanner labels

Revision ID: 0004
Revises: 0003
"""
from alembic import op
import sqlalchemy as sa

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.alter_column("files", "scan_engine", type_=sa.String(160))


def downgrade() -> None:
    op.alter_column("files", "scan_engine", type_=sa.String(60))
