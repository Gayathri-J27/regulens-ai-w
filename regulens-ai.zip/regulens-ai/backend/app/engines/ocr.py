"""Document text extraction + OCR + date finding.

Pipeline: PDF text layer (PyMuPDF) -> render -> OpenCV deskew/denoise -> PaddleOCR (if installed)
-> Tesseract fallback. Every result states which engine produced it.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, timedelta

import cv2
import numpy as np

try:
    import pymupdf as fitz
except ImportError:  # pragma: no cover
    import fitz  # type: ignore

try:
    import pytesseract
    _TESS = True
except ImportError:  # pragma: no cover
    _TESS = False

_PADDLE = None


def paddle():
    global _PADDLE
    if _PADDLE is None:
        try:
            from paddleocr import PaddleOCR  # type: ignore
            _PADDLE = PaddleOCR(use_angle_cls=True, lang="en", show_log=False)
        except Exception:  # noqa: BLE001 — optional heavy dependency
            _PADDLE = False
    return _PADDLE or None


def engines_available() -> dict:
    return {"pymupdf_text": True, "tesseract": _TESS, "paddleocr": paddle() is not None, "opencv": True}


# ---------------------------------------------------------------- image preprocessing
def deskew(gray: np.ndarray) -> tuple[np.ndarray, float]:
    thr = cv2.threshold(cv2.bitwise_not(gray), 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    coords = np.column_stack(np.where(thr > 0))
    if len(coords) < 50:
        return gray, 0.0
    angle = cv2.minAreaRect(coords.astype(np.float32))[-1]
    angle = -(90 + angle) if angle < -45 else -angle
    if angle > 45:
        angle -= 90
    if abs(angle) < 0.3 or abs(angle) > 15:
        return gray, 0.0
    h, w = gray.shape
    m = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
    return cv2.warpAffine(gray, m, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE), float(angle)


def preprocess(img: np.ndarray) -> tuple[np.ndarray, dict]:
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    den = cv2.fastNlMeansDenoising(gray, None, h=10, templateWindowSize=7, searchWindowSize=21)
    rot, angle = deskew(den)
    return rot, {"deskew_angle": round(angle, 2), "denoised": True}


@dataclass
class Word:
    text: str
    conf: float
    box: tuple[int, int, int, int]
    page: int


@dataclass
class PageText:
    page: int
    text: str
    words: list[Word] = field(default_factory=list)
    width: int = 0
    height: int = 0
    engine: str = ""


def _tesseract_words(img: np.ndarray, page: int, psm: int = 6) -> PageText:
    d = pytesseract.image_to_data(img, config=f"--psm {psm}", output_type=pytesseract.Output.DICT)
    words, lines, cur = [], [], {}
    for i, t in enumerate(d["text"]):
        if not t.strip():
            continue
        conf = float(d["conf"][i]) / 100 if float(d["conf"][i]) >= 0 else 0.0
        words.append(Word(t, conf, (d["left"][i], d["top"][i], d["width"][i], d["height"][i]), page))
        key = (d["block_num"][i], d["par_num"][i], d["line_num"][i])
        cur.setdefault(key, []).append(t)
    text = "\n".join(" ".join(v) for v in cur.values())
    return PageText(page, text, words, img.shape[1], img.shape[0], f"tesseract-psm{psm}")


def _paddle_words(img: np.ndarray, page: int) -> PageText:
    res = paddle().ocr(img, cls=True)
    words, lines = [], []
    for line in (res[0] or []):
        pts, (txt, conf) = line
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        words.append(Word(txt, float(conf), (int(min(xs)), int(min(ys)), int(max(xs) - min(xs)), int(max(ys) - min(ys))), page))
        lines.append(txt)
    return PageText(page, "\n".join(lines), words, img.shape[1], img.shape[0], "paddleocr")


def load_images(data: bytes, mime: str, dpi: int = 300) -> list[np.ndarray]:
    if mime == "application/pdf":
        doc = fitz.open(stream=data, filetype="pdf")
        out = []
        for p in doc:
            pix = p.get_pixmap(dpi=dpi)
            arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
            out.append(cv2.cvtColor(arr, cv2.COLOR_RGB2BGR if pix.n == 3 else cv2.COLOR_RGBA2BGR))
        return out
    arr = np.frombuffer(data, dtype=np.uint8)
    return [cv2.imdecode(arr, cv2.IMREAD_COLOR)]


def pdf_text_layer(data: bytes) -> list[str]:
    doc = fitz.open(stream=data, filetype="pdf")
    return [p.get_text() for p in doc]


def extract_text(data: bytes, mime: str) -> dict:
    """Text for approval letters: PDF text layer first, OCR fallback for scanned pages."""
    if mime == "application/pdf":
        pages = pdf_text_layer(data)
        if sum(len(p.strip()) for p in pages) >= 40 * max(1, len(pages)):
            return {"text": "\n".join(pages), "method": "PDF_TEXT_LAYER (PyMuPDF)", "pages": len(pages)}
    texts, engine = [], ""
    for i, img in enumerate(load_images(data, mime)):
        pre, _ = preprocess(img)
        if paddle():
            pt = _paddle_words(pre, i)
        elif _TESS:
            pt = _tesseract_words(pre, i)
        else:
            raise RuntimeError("No OCR engine available")
        texts.append(pt.text)
        engine = pt.engine
    return {"text": "\n".join(texts), "method": f"OCR ({engine}) after OpenCV deskew/denoise", "pages": len(texts)}


# ---------------------------------------------------------------- dates
MONTHS = "jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|january|february|march|april|june|july|august|september|october|november|december"
DATE_RES = [
    re.compile(r"\b(\d{1,2})[./-](\d{1,2})[./-](\d{4})\b"),
    re.compile(rf"\b(\d{{1,2}})(?:st|nd|rd|th)?\s+(?:of\s+)?({MONTHS})[a-z]*[,.]?\s+(\d{{4}})\b", re.I),
    re.compile(rf"\b({MONTHS})[a-z]*\.?\s+(\d{{1,2}})(?:st|nd|rd|th)?,?\s+(\d{{4}})\b", re.I),
    re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b"),
]
_MON = {m[:3]: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}


def parse_dates(text: str) -> list[tuple[date, int, int, str]]:
    """All dates in text (day-first, Indian convention) -> (date, start, end, raw)."""
    out = []
    for i, rx in enumerate(DATE_RES):
        for m in rx.finditer(text):
            try:
                g = m.groups()
                if i == 0:
                    d = date(int(g[2]), int(g[1]), int(g[0]))
                elif i == 1:
                    d = date(int(g[2]), _MON[g[1][:3].lower()], int(g[0]))
                elif i == 2:
                    d = date(int(g[2]), _MON[g[0][:3].lower()], int(g[1]))
                else:
                    d = date(int(g[0]), int(g[1]), int(g[2]))
            except (ValueError, KeyError):
                continue
            if 1990 <= d.year <= 2100:
                out.append((d, m.start(), m.end(), m.group(0)))
    out.sort(key=lambda t: t[1])
    dedup, last_end = [], -1
    for t in out:
        if t[1] >= last_end:
            dedup.append(t)
            last_end = t[2]
    return dedup


EXPIRY_CUES = re.compile(r"(expir|valid\s*(?:till|upto|up\s*to|until)|ending\s+on|period\s+ending|till|until|upto|up\s+to|terminat|renew(?:al)?\s+(?:on|by|before))", re.I)
ISSUE_CUES = re.compile(r"(issued|dated|executed|commenc|w\.?e\.?f|with effect from|from)", re.I)
TERM_RE = re.compile(r"(?:period|term)\s+of\s+(\d{1,3})\s*(?:\(\w+\)\s*)?years?\s+(?:commencing\s+)?(?:from|w\.e\.f\.?|with effect from)", re.I)


def find_expiry(text: str) -> dict:
    """Choose an expiry date with an explanation; never invents one."""
    ds = parse_dates(text)
    if not ds:
        return {"expiry": None, "issue": None, "reason": "no date found", "candidates": []}
    cands = []
    for d, s, e, raw in ds:
        ctx = text[max(0, s - 70):s].lower()
        score = 0.0
        if EXPIRY_CUES.search(ctx[-45:]):
            score += 0.6
        if ISSUE_CUES.search(ctx[-30:]):
            score -= 0.3
        cands.append({"date": d.isoformat(), "raw": raw, "offset": s, "cue_score": round(score, 2), "context": text[max(0, s - 60):e + 10]})
    best = max(cands, key=lambda c: (c["cue_score"], c["date"]))
    issue = None
    iss = [c for c in cands if c["cue_score"] < 0]
    if iss:
        issue = iss[0]["date"]
    derived = None
    m = TERM_RE.search(text)
    if m:
        after = [c for c in cands if c["offset"] > m.end() - 5]
        if after:
            start = date.fromisoformat(after[0]["date"])
            years = int(m.group(1))
            try:
                derived = (start.replace(year=start.year + years) - timedelta(days=1)).isoformat()
            except ValueError:
                derived = (start.replace(year=start.year + years, day=28)).isoformat()
            issue = issue or after[0]["date"]
    if best["cue_score"] > 0:
        return {"expiry": best["date"], "issue": issue, "raw": best["raw"], "reason": "date preceded by an expiry cue", "candidates": cands,
                "derived_from_term": derived}
    if derived:
        return {"expiry": derived, "issue": issue, "raw": None, "reason": f"derived from term of {m.group(1)} year(s) from {issue}",
                "candidates": cands, "derived_from_term": derived}
    return {"expiry": None, "issue": issue, "reason": "dates found but none is clearly an expiry date", "candidates": cands}


def ocr_document(data: bytes, mime: str) -> dict:
    """Lease/certificate OCR: two passes for agreement, word boxes for highlighting, confidence."""
    pages_primary, pages_secondary, prep = [], [], []
    text_layer = pdf_text_layer(data) if mime == "application/pdf" else None
    imgs = load_images(data, mime, dpi=200)
    for i, img in enumerate(imgs):
        pre, info = preprocess(img)
        prep.append(info)
        if paddle():
            pages_primary.append(_paddle_words(pre, i))
            pages_secondary.append(_tesseract_words(pre, i) if _TESS else None)
        else:
            pages_primary.append(_tesseract_words(pre, i, psm=6))
            pages_secondary.append(_tesseract_words(pre, i, psm=4))
    text = "\n".join(p.text for p in pages_primary)
    primary = find_expiry(text)
    # agreement source: independent engine if available, else the PDF text layer, else a second segmentation pass
    if text_layer and sum(len(t.strip()) for t in text_layer) > 40:
        sec_text, agree_src = "\n".join(text_layer), "pdf-text-layer"
    elif paddle() and pages_secondary[0] is not None:
        sec_text, agree_src = "\n".join(p.text for p in pages_secondary), "tesseract (independent engine)"
    else:
        sec_text, agree_src = "\n".join(p.text for p in pages_secondary if p), "tesseract-psm4 (second pass, same engine)"
    secondary = find_expiry(sec_text)
    agreement = bool(primary["expiry"]) and primary["expiry"] == secondary["expiry"]
    # word-level confidence + highlight boxes for the chosen date
    boxes, confs = [], []
    if primary.get("raw"):
        toks = [t for t in re.split(r"[\s,]+", primary["raw"]) if t]
        for p in pages_primary:
            for w in p.words:
                if any(tok.strip(".,") and tok.strip(".,") in w.text for tok in toks):
                    boxes.append({"page": p.page, "x": w.box[0] / p.width, "y": w.box[1] / p.height, "w": w.box[2] / p.width,
                                  "h": w.box[3] / p.height, "text": w.text, "conf": round(w.conf, 3)})
                    confs.append(w.conf)
    all_conf = [w.conf for p in pages_primary for w in p.words]
    page_conf = float(np.mean(all_conf)) if all_conf else 0.0
    date_conf = float(np.mean(confs)) if confs else page_conf
    if not primary["expiry"]:
        conf = min(0.4, page_conf * 0.5)
    else:
        cue = 1.0 if primary["reason"].startswith("date preceded") else 0.8
        conf = round(min(1.0, 0.6 * date_conf + 0.25 * cue + (0.15 if agreement else 0.0)), 3)
    if conf >= 0.9 and agreement:
        status = "VERIFIED_PENDING_CONFIRMATION"
    elif conf >= 0.6:
        status = "MANUAL_REVIEW"
    else:
        status = "MANUAL_REVIEW_UNREADABLE"
    return {"engine": pages_primary[0].engine if pages_primary else "none", "agreement_source": agree_src, "agreement": agreement,
            "secondary_expiry": secondary["expiry"], "expiry": primary["expiry"], "issue": primary.get("issue"),
            "reason": primary["reason"], "candidates": primary["candidates"][:12], "confidence": round(conf, 3),
            "page_confidence": round(page_conf, 3), "status": status, "highlights": boxes[:12], "preprocessing": prep,
            "text": text[:20000], "pages": len(imgs)}
