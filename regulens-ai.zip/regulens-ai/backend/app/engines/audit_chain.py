"""Hash-chain primitives (pure). hash = SHA256(prev_hash + canonical_json(entry))."""
from __future__ import annotations

import hashlib
import hmac
import json
from datetime import date, datetime, timezone
from typing import Any, Iterable

GENESIS = "0" * 64
HASHED_FIELDS = ("id", "ts", "actor_id", "actor_role", "action", "entity_type", "entity_id", "before", "after",
                 "reason", "correlation_id")


def _norm(v: Any) -> Any:
    if isinstance(v, datetime):
        if v.tzinfo is None:
            v = v.replace(tzinfo=timezone.utc)
        return v.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, dict):
        return {str(k): _norm(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_norm(x) for x in v]
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v


def canonical_json(entry: dict) -> str:
    """Deterministic serialisation: sorted keys, no whitespace, UTF-8, normalised timestamps."""
    body = {k: _norm(entry.get(k)) for k in HASHED_FIELDS}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def entry_hash(prev_hash: str, entry: dict) -> str:
    return hashlib.sha256((prev_hash + canonical_json(entry)).encode("utf-8")).hexdigest()


def verify_chain(rows: Iterable[dict], start_prev: str = GENESIS) -> dict:
    """Walk rows in id order. Returns ok flag, number checked and the first broken id."""
    prev = start_prev
    n = 0
    for r in rows:
        n += 1
        if r["prev_hash"] != prev:
            return {"ok": False, "checked": n, "first_broken_id": r["id"], "detail": "prev_hash link mismatch"}
        h = entry_hash(prev, r)
        if h != r["hash"]:
            return {"ok": False, "checked": n, "first_broken_id": r["id"], "detail": "content hash mismatch (record altered)"}
        prev = h
    return {"ok": True, "checked": n, "first_broken_id": None, "detail": None, "head": prev}


def sign_head(key: str, day: str, head_hash: str, last_id: int) -> str:
    msg = f"{day}|{last_id}|{head_hash}".encode()
    return hmac.new(key.encode(), msg, hashlib.sha256).hexdigest()
