"""Approval letter -> proposed obligations (bounded AI extraction).

Providers:
* ``anthropic`` — LLM structured extraction (only when ANTHROPIC_API_KEY is configured).
* ``local``     — deterministic rule-based sentence extractor. Labelled LOCAL_RULE_BASED; it is NOT an LLM.

Whatever the provider, every proposal must (1) pass strict schema validation and (2) quote a source
sentence that is found verbatim (whitespace-normalised) in the document text, or it is rejected.
Proposals are never obligations: only officer-confirmed items reach the Promise Ledger.
"""
from __future__ import annotations

import json
import re
from datetime import date, timedelta
from typing import Literal

import httpx
from pydantic import BaseModel, Field, ValidationError, field_validator

from app.engines.ocr import parse_dates

KINDS = ("UNDERTAKING", "CONDITION", "REQUIRED_DOCUMENT", "RENEWAL", "SUBMISSION_DEADLINE")


class ProposedItem(BaseModel):
    kind: Literal["UNDERTAKING", "CONDITION", "REQUIRED_DOCUMENT", "RENEWAL", "SUBMISSION_DEADLINE"]
    title: str = Field(min_length=3, max_length=300)
    source_sentence: str = Field(min_length=10)
    due_text: str | None = None
    due_date: date | None = None
    relative_days: int | None = Field(default=None, ge=0, le=3650)
    responsible_role: str = "INSTITUTION_PRINCIPAL"
    evidence_requirement: str | None = None
    confidence: float = Field(ge=0, le=1)

    @field_validator("responsible_role")
    @classmethod
    def _role(cls, v):
        allowed = {"INSTITUTION_PRINCIPAL", "INSTITUTION_COMPLIANCE", "TRUST_SOCIETY", "ACCOUNTS"}
        if v not in allowed:
            raise ValueError(f"responsible_role must be one of {sorted(allowed)}")
        return v


def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s.replace(" ", " ")).strip().lower()


def find_source(text: str, sentence: str) -> int | None:
    """Offset of the sentence in the normalised text, or None (=> proposal rejected)."""
    i = norm(text).find(norm(sentence))
    return i if i >= 0 else None


# ---------------------------------------------------------------- local rule-based extractor
OBLIG = re.compile(r"\b(shall|must|is required to|are required to|undertake[sn]?|undertaking|hereby directed|is directed to|"
                   r"should submit|to submit|to obtain|to renew|to furnish|to ensure|subject to the condition)\b", re.I)
REL = re.compile(r"within\s+(\d{1,3}|one|two|three|four|five|six|seven|eight|nine|ten|twelve|fifteen|thirty|sixty|ninety)\s*"
                 r"(?:\(\s*\d+\s*\)\s*)?(days?|weeks?|months?|years?)", re.I)
WORDNUM = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
           "twelve": 12, "fifteen": 15, "thirty": 30, "sixty": 60, "ninety": 90}
UNIT_DAYS = {"day": 1, "week": 7, "month": 30, "year": 365}


def split_sentences(text: str) -> list[str]:
    t = re.sub(r"[ \t]+", " ", text)
    t = re.sub(r"\n(?=\s*(\d+[.)]|\([a-z0-9]+\)|[a-z]\)|•|-)\s)", "\n\n", t)  # numbered clauses start sentences
    parts = re.split(r"(?<=[.;])\s+(?=[A-Z(0-9])|\n{2,}", t)
    out = []
    for p in parts:
        p = re.sub(r"\s*\n\s*", " ", p).strip()
        p = re.sub(r"^(\d+[.)]|\([a-z0-9]+\)|[a-z]\)|•|-)\s+", "", p)
        if len(p) >= 25:
            out.append(p)
    return out


def _kind(s: str) -> str:
    l = s.lower()
    if "renew" in l or "valid" in l and "lease" in l:
        return "RENEWAL"
    if "undertak" in l:
        return "UNDERTAKING"
    if re.search(r"submit|furnish|upload", l):
        return "REQUIRED_DOCUMENT" if re.search(r"certificate|deed|document|copy|report|affidavit|audit", l) else "SUBMISSION_DEADLINE"
    return "CONDITION"


def _role(s: str) -> str:
    l = s.lower()
    if "trust" in l or "society" in l:
        return "TRUST_SOCIETY"
    if "account" in l or "fee" in l and "audit" in l:
        return "ACCOUNTS"
    return "INSTITUTION_PRINCIPAL"


def _evidence(s: str) -> str | None:
    m = re.search(r"(?:submit|furnish|upload|obtain|produce)\s+(?:a\s+|the\s+|an\s+)?(.{8,140}?)(?:\s+(?:to|with|within|on or before|by|before|from|at)\b|[.;]|$)", s, re.I)
    return m.group(1).strip(" ,") if m else None


def _title(s: str, kind: str) -> str:
    ev = _evidence(s)
    if ev:
        return (("Renew " if kind == "RENEWAL" else "Submit ") + ev)[:160]
    words = re.sub(r"^(the\s+)?(institution|applicant|management|principal|trust|society)\s+(shall|must|is required to)\s+", "", s, flags=re.I)
    return words[:1].upper() + words[1:157] + ("…" if len(words) > 157 else "")


def local_extract(text: str, letter_date: date | None) -> list[dict]:
    items = []
    for s in split_sentences(text):
        if not OBLIG.search(s):
            continue
        kind = _kind(s)
        due_date, due_text, rel = None, None, None
        ds = parse_dates(s)
        for d, st, en, raw in ds:
            pre = s[max(0, st - 30):st].lower()
            if re.search(r"(on or before|by|before|not later than|till|until|upto|up to|expir|valid)", pre):
                due_date, due_text = d, s[max(0, st - 20):en].strip()
                break
        m = REL.search(s)
        if not due_date and m:
            n = m.group(1).lower()
            n = int(n) if n.isdigit() else WORDNUM[n]
            rel = n * UNIT_DAYS[m.group(2).lower().rstrip("s")]
            due_text = m.group(0)  # resolved against the letter date by validate_and_verify, never here
        conf = 0.45 + (0.2 if OBLIG.search(s).group(0).lower() in ("shall", "must", "undertake", "undertakes", "is required to") else 0.1)
        conf += 0.2 if (due_date or rel) else 0.0
        conf += 0.1 if _evidence(s) else 0.0
        items.append({"kind": kind, "title": _title(s, kind), "source_sentence": s, "due_text": due_text,
                      "due_date": due_date.isoformat() if due_date else None, "relative_days": rel,
                      "responsible_role": _role(s), "evidence_requirement": _evidence(s), "confidence": round(min(conf, 0.95), 2)})
    return items


# ---------------------------------------------------------------- LLM adapter
PROMPT = """You extract proposed post-approval obligations from an AICTE approval letter.
Return ONLY a JSON array. Each element: {"kind": one of %s, "title": short imperative title,
"source_sentence": the exact sentence copied verbatim from the letter, "due_text": the deadline phrase or null,
"due_date": "YYYY-MM-DD" only if an explicit calendar date appears in that sentence else null,
"relative_days": integer days if the sentence says "within N days/months" else null,
"responsible_role": one of INSTITUTION_PRINCIPAL, INSTITUTION_COMPLIANCE, TRUST_SOCIETY, ACCOUNTS,
"evidence_requirement": what document proves compliance or null, "confidence": 0..1}.
Never invent deadlines, never decide approval or compliance. If unsure, omit the item.
LETTER:
""" % (", ".join(KINDS),)


def llm_extract(text: str, api_key: str, model: str) -> list[dict]:
    r = httpx.post("https://api.anthropic.com/v1/messages", timeout=90,
                   headers={"x-api-key": api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                   json={"model": model, "max_tokens": 4000, "messages": [{"role": "user", "content": PROMPT + text[:60000]}]})
    r.raise_for_status()
    body = "".join(b.get("text", "") for b in r.json().get("content", []))
    m = re.search(r"\[.*\]", body, re.S)
    return json.loads(m.group(0)) if m else []


# ---------------------------------------------------------------- validation gate
def validate_and_verify(raw_items: list[dict], text: str, letter_date: date | None) -> tuple[list[dict], list[dict]]:
    ok, rejected = [], []
    seen = set()
    for raw in raw_items:
        try:
            item = ProposedItem.model_validate(raw)
        except ValidationError as e:
            rejected.append({"item": raw, "reason": "schema: " + "; ".join(x["msg"] for x in e.errors())[:300]})
            continue
        off = find_source(text, item.source_sentence)
        if off is None:
            rejected.append({"item": raw, "reason": "source sentence not found in the document text"})
            continue
        rel_ok = (item.relative_days is not None and letter_date is not None
                  and item.due_date == letter_date + timedelta(days=item.relative_days))
        if item.due_date and not rel_ok and not any(d == item.due_date for d, *_ in parse_dates(item.source_sentence)):
            rejected.append({"item": raw, "reason": "due date not present in the quoted sentence (possible invented deadline)"})
            continue
        key = norm(item.source_sentence)
        if key in seen:
            continue
        seen.add(key)
        d = item.model_dump()
        if not d["due_date"] and d["relative_days"] is not None and letter_date:
            d["due_date"] = letter_date + timedelta(days=d["relative_days"])
        d["source_offset"] = off
        ok.append(d)
    return ok, rejected
