"""ReguLens deterministic Clock Engine.

Pure module: no database, no LLM, no wall-clock reads except via an explicit ``today`` argument.

Day-counting semantics (documented in ARCHITECTURE.md and asserted by tests)
-------------------------------------------------------------------------------
* All instants are converted to the Asia/Kolkata local date before counting.
* A clock started on local date S consumes budget on the countable dates d > S.
* A date d is *running* iff, after applying every event whose local date is < d, the clock
  is started, not stopped and has no active pause.  Consequently a PAUSE on date P still
  counts P, and a RESUME on date R does not count R (excluded window is (P, R]).
* Countable = every date (CALENDAR mode) or every non-weekend, non-holiday date (WORKING mode).
* due_date = the date on which cumulative consumption since the last reset reaches the
  current budget (base budget + approved extensions).  While paused the due date is
  undetermined; ``projected_due_if_resumed_today`` is supplied instead.
* EXTEND adds days to the budget.  REVERT applies a revert policy:
    RESUME                -> accrued consumption is kept.
    RESTART               -> consumption reset to 0, budget reset to the original budget.
    RESET_TO_STAGE_BUDGET -> consumption reset to 0, budget = event.days (stage budget) + extensions.
  A REVERT also lifts any active pause (the work is back with AICTE).
* Pauses nest by kind (e.g. a LEGAL_HOLD on top of an institution pause); the clock runs only
  when no pause kind is active.

``compute`` (interval arithmetic, used in production) and ``compute_naive`` (day-by-day
reference simulation) are independent implementations; property tests assert they agree.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta
from enum import Enum
from typing import Iterable, Sequence
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
ONE = timedelta(days=1)


class ClockState(str, Enum):
    RUNNING = "RUNNING"
    PAUSED_INSTITUTION = "PAUSED_INSTITUTION"
    PAUSED_AICTE = "PAUSED_AICTE"
    PAUSED_LEGAL_HOLD = "PAUSED_LEGAL_HOLD"
    PAUSED_SOURCE = "PAUSED_SOURCE"
    STOPPED_MET = "STOPPED_MET"
    STOPPED_WAIVED = "STOPPED_WAIVED"
    BREACHED = "BREACHED"


PAUSE_KINDS = ("INSTITUTION", "AICTE", "LEGAL_HOLD", "SOURCE")
_PAUSE_PRECEDENCE = {"LEGAL_HOLD": 0, "SOURCE": 1, "INSTITUTION": 2, "AICTE": 3}
REVERT_POLICIES = ("RESTART", "RESUME", "RESET_TO_STAGE_BUDGET")
EVENT_KINDS = ("START", "PAUSE", "RESUME", "EXTEND", "REVERT", "STOP_MET", "STOP_WAIVED")


class ClockError(ValueError):
    pass


def local_date(at: datetime | date) -> date:
    if isinstance(at, datetime):
        if at.tzinfo is None:  # naive datetimes are interpreted as IST wall-clock
            return at.date()
        return at.astimezone(IST).date()
    return at


@dataclass(frozen=True)
class WorkCalendar:
    weekend_days: frozenset[int] = frozenset({5, 6})  # Mon=0 .. Sun=6
    holidays: tuple[tuple[date, str], ...] = ()
    name: str = "default"

    @property
    def holiday_map(self) -> dict[date, str]:
        return dict(self.holidays)

    @staticmethod
    def build(weekend_days: Iterable[int] = (5, 6), holidays: dict[date, str] | None = None, name: str = "cal") -> "WorkCalendar":
        hol = tuple(sorted((holidays or {}).items()))
        return WorkCalendar(frozenset(weekend_days), hol, name)

    def union(self, other: "WorkCalendar") -> "WorkCalendar":
        merged = self.holiday_map
        for d, n in other.holidays:
            merged.setdefault(d, n)
        return WorkCalendar(self.weekend_days | other.weekend_days, tuple(sorted(merged.items())), f"{self.name}+{other.name}")

    def is_countable(self, d: date, mode: str) -> bool:
        if mode == "CALENDAR":
            return True
        if d.weekday() in self.weekend_days:
            return False
        return d not in self._hset

    @property
    def _hset(self) -> frozenset[date]:  # cached lazily
        cache = self.__dict__.get("_hs")
        if cache is None:
            cache = frozenset(d for d, _ in self.holidays)
            object.__setattr__(self, "_hs", cache)
        return cache


@dataclass(frozen=True)
class ClockSpec:
    budget_days: int
    day_mode: str = "WORKING"  # WORKING | CALENDAR
    revert_policy: str = "RESUME"
    label: str = ""

    def __post_init__(self):
        if self.budget_days < 0:
            raise ClockError("budget must be >= 0")
        if self.day_mode not in ("WORKING", "CALENDAR"):
            raise ClockError(f"bad day_mode {self.day_mode}")
        if self.revert_policy not in REVERT_POLICIES:
            raise ClockError(f"bad revert policy {self.revert_policy}")


@dataclass(frozen=True)
class ClockEvent:
    kind: str
    at: datetime | date
    days: int | None = None
    pause_kind: str | None = None
    policy: str | None = None
    actor: str | None = None
    reason: str | None = None

    def __post_init__(self):
        if self.kind not in EVENT_KINDS:
            raise ClockError(f"unknown event kind {self.kind}")
        if self.kind == "PAUSE" and self.pause_kind not in PAUSE_KINDS:
            raise ClockError("PAUSE needs pause_kind in " + ",".join(PAUSE_KINDS))
        if self.kind == "EXTEND" and (self.days is None or self.days <= 0):
            raise ClockError("EXTEND needs positive days")

    @property
    def day(self) -> date:
        return local_date(self.at)


# --------------------------------------------------------------------------- primitives
def count_countable(a: date, b: date, cal: WorkCalendar, mode: str) -> int:
    """Countable dates in the half-open window (a, b]."""
    if b <= a:
        return 0
    if mode == "CALENDAR":
        return (b - a).days
    n, d = 0, a + ONE
    while d <= b:
        if cal.is_countable(d, mode):
            n += 1
        d += ONE
    return n


def walk_forward(start: date, remaining: int, cal: WorkCalendar, mode: str = "WORKING") -> date:
    """due = walk_forward(started_at, remaining_budget, calendar): the date on which the
    ``remaining``-th countable date after ``start`` falls."""
    if remaining <= 0:
        return start
    if mode == "CALENDAR":
        return start + timedelta(days=remaining)
    d, n = start, 0
    while n < remaining:
        d += ONE
        if cal.is_countable(d, mode):
            n += 1
    return d


# --------------------------------------------------------------------------- result
@dataclass
class ClockResult:
    state: str
    started_on: date | None
    base_budget: int
    effective_budget: int
    day_mode: str
    consumed: int
    remaining: int
    due_date: date | None
    projected_due_if_resumed_today: date | None
    active_pauses: list[str]
    pauses: list[dict] = field(default_factory=list)
    extensions: list[dict] = field(default_factory=list)
    reverts: list[dict] = field(default_factory=list)
    holidays_excluded: list[dict] = field(default_factory=list)
    weekend_days_excluded: int = 0
    stopped_on: date | None = None
    stop_kind: str | None = None
    met_on_time: bool | None = None
    breached: bool = False
    days_to_due: int | None = None
    as_of: date | None = None

    def to_dict(self) -> dict:
        d = asdict(self)
        for k, v in list(d.items()):
            if isinstance(v, date):
                d[k] = v.isoformat()
        return d


# --------------------------------------------------------------------------- production implementation
def _sorted(events: Sequence[ClockEvent]) -> list[ClockEvent]:
    # stable sort by local date only; same-day events keep their recorded (sequence) order
    return sorted(events, key=lambda e: e.day)


def compute(spec: ClockSpec, events: Sequence[ClockEvent], cal: WorkCalendar, today: date) -> ClockResult:
    """Interval-arithmetic clock reconstruction from history (production path)."""
    evs = _sorted(events)
    if not evs or evs[0].kind != "START":
        raise ClockError("clock history must begin with START")
    mode = spec.day_mode
    start = evs[0].day
    budget = spec.budget_days
    ext_total = 0
    segments: list[list] = [[start, None]]  # running segments since the last reset: [open_date, close_date|None]
    active: dict[str, date] = {}  # pause kind -> since
    pauses: list[dict] = []
    extensions: list[dict] = []
    reverts: list[dict] = []
    stopped_on: date | None = None
    stop_kind: str | None = None

    def running() -> bool:
        return stopped_on is None and not active

    for e in evs[1:]:
        d = e.day
        if stopped_on is not None:
            raise ClockError(f"event {e.kind} after clock stopped")
        if e.kind == "START":
            raise ClockError("duplicate START")
        if e.kind == "PAUSE":
            if e.pause_kind in active:
                continue  # idempotent
            if running():
                segments[-1][1] = d
            active[e.pause_kind] = d
        elif e.kind == "RESUME":
            kinds = [e.pause_kind] if e.pause_kind else list(active)
            closed = False
            for k in kinds:
                if k in active:
                    pauses.append({"kind": k, "start": active.pop(k), "end": d, "reason": e.reason})
                    closed = True
            if closed and not active:
                segments.append([d, None])
        elif e.kind == "EXTEND":
            budget += e.days
            ext_total += e.days
            extensions.append({"days": e.days, "on": d, "actor": e.actor, "reason": e.reason})
        elif e.kind == "REVERT":
            policy = e.policy or spec.revert_policy
            for k in list(active):
                pauses.append({"kind": k, "start": active.pop(k), "end": d, "reason": "lifted by revert"})
            if policy == "RESUME":
                if segments[-1][1] is not None:
                    segments.append([d, None])
            else:
                if segments[-1][1] is None:
                    segments[-1][1] = d
                segments = [[d, None]]
                if policy == "RESTART":
                    budget = spec.budget_days
                    ext_total = 0
                else:  # RESET_TO_STAGE_BUDGET
                    budget = (e.days if e.days is not None else spec.budget_days) + ext_total
            reverts.append({"policy": policy, "on": d, "reason": e.reason})
        elif e.kind in ("STOP_MET", "STOP_WAIVED"):
            if active:
                for k in list(active):
                    pauses.append({"kind": k, "start": active.pop(k), "end": d, "reason": "closed at stop"})
                segments.append([d, None])  # due date projected as if it had continued from stop
                frozen_consumed = sum(count_countable(a, b if b else d, cal, mode) for a, b in segments[:-1])
            else:
                frozen_consumed = sum(count_countable(a, (b if b is not None else d), cal, mode) for a, b in segments)
            stopped_on, stop_kind = d, e.kind
            stop_consumed = frozen_consumed

    # consumption so far
    horizon = today if stopped_on is None else stopped_on
    if stopped_on is not None:
        consumed = stop_consumed
    else:
        consumed = 0
        for a, b in segments:
            end = b if b is not None else max(a, horizon)
            consumed += count_countable(a, min(end, max(a, horizon)), cal, mode)

    # due date: walk the segments (open segment extends indefinitely)
    due: date | None = None
    cum = 0
    for a, b in segments:
        if b is None:
            due = walk_forward(a, budget - cum, cal, mode)
            break
        c = count_countable(a, b, cal, mode)
        if cum + c >= budget:
            due = walk_forward(a, budget - cum, cal, mode)
            break
        cum += c
    projected = None
    if due is None:  # paused and budget not yet exhausted
        projected = walk_forward(today, budget - cum, cal, mode)

    remaining = budget - consumed
    breached = False
    if stopped_on is None:
        if due is not None and today > due:
            breached = True
        elif due is None and remaining < 0:
            breached = True
    met_on_time = None
    if stopped_on is not None and due is not None:
        met_on_time = stopped_on <= due

    if stopped_on is not None:
        state = ClockState.STOPPED_MET.value if stop_kind == "STOP_MET" else ClockState.STOPPED_WAIVED.value
    elif active:
        k = min(active, key=lambda x: _PAUSE_PRECEDENCE[x])
        state = f"PAUSED_{k}"
    elif breached:
        state = ClockState.BREACHED.value
    else:
        state = ClockState.RUNNING.value

    # explanation data: holidays / weekends skipped inside running windows up to due (or horizon)
    hol_map = cal.holiday_map
    hol_excl: list[dict] = []
    wk = 0
    if mode == "WORKING":
        limit = due or horizon
        for a, b in segments:
            end = b if b is not None else limit
            dd = a + ONE
            while dd <= end:
                if dd.weekday() in cal.weekend_days:
                    wk += 1
                elif dd in hol_map:
                    hol_excl.append({"date": dd.isoformat(), "name": hol_map[dd]})
                dd += ONE

    for p in pauses:
        p["calendar_days"] = (p["end"] - p["start"]).days
        p["countable_days"] = count_countable(p["start"], p["end"], cal, mode)
    open_pauses = [{"kind": k, "start": s, "end": None, "calendar_days": (today - s).days,
                    "countable_days": count_countable(s, today, cal, mode), "reason": None} for k, s in active.items()]

    def ser(lst):
        out = []
        for x in lst:
            out.append({k: (v.isoformat() if isinstance(v, date) else v) for k, v in x.items()})
        return out

    return ClockResult(
        state=state, started_on=start, base_budget=spec.budget_days, effective_budget=budget, day_mode=mode,
        consumed=consumed, remaining=remaining, due_date=due, projected_due_if_resumed_today=projected,
        active_pauses=sorted(active), pauses=ser(pauses + open_pauses), extensions=ser(extensions),
        reverts=ser(reverts), holidays_excluded=hol_excl, weekend_days_excluded=wk, stopped_on=stopped_on,
        stop_kind=stop_kind, met_on_time=met_on_time, breached=breached,
        days_to_due=((due - today).days if due else None), as_of=today,
    )


# --------------------------------------------------------------------------- reference implementation
def compute_naive(spec: ClockSpec, events: Sequence[ClockEvent], cal: WorkCalendar, today: date) -> dict:
    """Day-by-day simulation used only to cross-check ``compute`` in tests and the benchmark.

    Deliberately written without interval arithmetic: it walks every date, applying events dated
    the previous day, and records cumulative consumption since the last reset.
    """
    evs = _sorted(events)
    start = evs[0].day
    by_day: dict[date, list[ClockEvent]] = {}
    for e in evs[1:]:
        by_day.setdefault(e.day, []).append(e)
    last_event_day = evs[-1].day
    total_ext = sum(e.days or 0 for e in evs if e.kind in ("EXTEND", "REVERT"))
    horizon_end = max(today, last_event_day) + timedelta(days=(spec.budget_days + total_ext) * 3 + 60)

    budget, ext_total = spec.budget_days, 0
    active: set[str] = set()
    stopped = False
    counter = 0
    real = 0
    reset_day = start
    hist: list[tuple[date, int]] = []
    d = start
    while d < horizon_end:
        for e in by_day.get(d, []):
            if e.kind == "PAUSE":
                active.add(e.pause_kind)
            elif e.kind == "RESUME":
                if e.pause_kind:
                    active.discard(e.pause_kind)
                else:
                    active.clear()
            elif e.kind == "EXTEND":
                budget += e.days
                ext_total += e.days
            elif e.kind == "REVERT":
                policy = e.policy or spec.revert_policy
                active.clear()
                if policy != "RESUME":
                    counter, real, hist, reset_day = 0, 0, [], d
                    if policy == "RESTART":
                        budget, ext_total = spec.budget_days, 0
                    else:
                        budget = (e.days if e.days is not None else spec.budget_days) + ext_total
            elif e.kind in ("STOP_MET", "STOP_WAIVED"):
                stopped = True
                active.clear()
        nd = d + ONE
        if not active and cal.is_countable(nd, spec.day_mode):
            counter += 1
            hist.append((nd, counter))
            if not stopped and nd <= today:
                real += 1
        d = nd
        if d > last_event_day and d >= today and counter >= budget:
            break
        if d > last_event_day and active:
            break
    if budget <= 0:
        due = reset_day
    else:
        due = next((day for day, c in hist if c >= budget), None)
    return {"consumed": real, "due_date": due, "budget": budget}


# --------------------------------------------------------------------------- explain()
def _plural(n: int, word: str) -> str:
    return f"{n} {word}{'' if n == 1 else 's'}"


def explain(spec: ClockSpec, result: ClockResult, source_rule: str | None = None, audit_verified: bool | None = None) -> dict:
    """Deterministic, template-based human explanation. No LLM involvement."""
    unit = "working day" if spec.day_mode == "WORKING" else "calendar day"
    lines: list[str] = []
    lines.append(f"{_plural(spec.budget_days, unit)} were allocated"
                 + (f" under {source_rule}" if source_rule else "") + f", starting {result.started_on:%d %b %Y}.")
    if spec.day_mode == "WORKING":
        h = len(result.holidays_excluded)
        names = ", ".join(f"{x['name']} ({x['date']})" for x in result.holidays_excluded[:6])
        lines.append(f"{_plural(result.weekend_days_excluded, 'weekend day')} and {_plural(h, 'holiday')} were excluded"
                     + (f": {names}" + (" …" if h > 6 else "") if h else "") + ".")
    closed = [p for p in result.pauses if p.get("end")]
    open_ = [p for p in result.pauses if not p.get("end")]
    who = {"INSTITUTION": "while the institution responded", "AICTE": "on AICTE's side",
           "LEGAL_HOLD": "under a legal hold", "SOURCE": "while the source system was unavailable"}
    for p in closed:
        lines.append(f"The clock was paused for {_plural(p['calendar_days'], 'day')} ({p['countable_days']} countable) "
                     f"{who.get(p['kind'], '')}, from {p['start']} to {p['end']}.")
    for p in open_:
        lines.append(f"The clock is currently paused {who.get(p['kind'], '')} since {p['start']} "
                     f"({_plural(p['calendar_days'], 'day')} so far); this time does not count against the deadline.")
    if result.extensions:
        tot = sum(x["days"] for x in result.extensions)
        lines.append(f"{_plural(len(result.extensions), 'extension')} totalling {_plural(tot, unit)} "
                     f"{'was' if len(result.extensions) == 1 else 'were'} approved"
                     + "".join(f"; {x['days']} on {x['on']} by {x['actor'] or 'authorised officer'}" for x in result.extensions) + ".")
    for r in result.reverts:
        txt = {"RESUME": "accrued time was kept", "RESTART": "the clock restarted with its original budget",
               "RESET_TO_STAGE_BUDGET": "the budget was reset to the stage budget"}[r["policy"]]
        lines.append(f"On {r['on']} the case was reverted ({r['policy']}): {txt}.")
    lines.append(f"{_plural(result.consumed, unit)} have been consumed; {_plural(max(result.remaining, 0), unit)} remain"
                 + (f" (overrun by {abs(result.remaining)})" if result.remaining < 0 else "") + ".")
    if result.stopped_on:
        verdict = "on time" if result.met_on_time else "after the deadline"
        lines.append(f"The obligation was {'met' if result.stop_kind == 'STOP_MET' else 'waived'} on {result.stopped_on}"
                     + (f", {verdict}" if result.stop_kind == "STOP_MET" and result.met_on_time is not None else "") + ".")
    if result.due_date:
        lines.append(f"The current due date is {result.due_date:%d %b %Y}"
                     + (f" — BREACHED {abs(result.days_to_due)} day(s) ago." if result.breached and result.days_to_due is not None and result.days_to_due < 0
                        else (f" ({result.days_to_due} day(s) from today)." if result.days_to_due is not None and not result.stopped_on else ".")))
    elif result.projected_due_if_resumed_today:
        lines.append(f"No due date while paused; if resumed today it would be {result.projected_due_if_resumed_today:%d %b %Y}.")
    if audit_verified is not None:
        lines.append("Clock history audit chain: " + ("verified intact." if audit_verified else "VERIFICATION FAILED."))
    return {
        "summary": " ".join(lines),
        "lines": lines,
        "original_budget": spec.budget_days,
        "effective_budget": result.effective_budget,
        "start_date": result.started_on.isoformat() if result.started_on else None,
        "day_mode": spec.day_mode,
        "holidays_excluded": result.holidays_excluded,
        "weekend_days_excluded": result.weekend_days_excluded,
        "pause_intervals": result.pauses,
        "extensions": result.extensions,
        "reverts": result.reverts,
        "remaining": result.remaining,
        "due_date": result.due_date.isoformat() if result.due_date else None,
        "state": result.state,
        "source_rule": source_rule,
        "audit_verified": audit_verified,
    }
