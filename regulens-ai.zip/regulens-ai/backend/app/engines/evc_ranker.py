"""EVC panel proposal (pure): hard filters with recorded reasons, then weighted ranking."""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass
from datetime import date


@dataclass(frozen=True)
class ExpertView:
    id: int
    name: str
    expertise: tuple[str, ...]
    region_id: int
    lat: float
    lon: float
    monthly_cap: int
    active: bool
    unavailable: frozenset[str]
    coi: frozenset[int]
    month_load: int  # visits already assigned in the visit month


def km(a, b) -> float:
    (la1, lo1), (la2, lo2) = a, b
    p = math.pi / 180
    h = 0.5 - math.cos((la2 - la1) * p) / 2 + math.cos(la1 * p) * math.cos(la2 * p) * (1 - math.cos((lo2 - lo1) * p)) / 2
    return 12742 * math.asin(math.sqrt(h))


def propose(experts: list[ExpertView], *, institution_id: int, institution_region: int, inst_coords: tuple[float, float],
            visit_date: date, required: list[str], weights: dict, n_panels: int = 3) -> dict:
    size = int(weights.get("panel_size", 3))
    policy = weights.get("region_policy", "SAME_REGION_ONLY")
    max_km = float(weights.get("max_distance_km", 1200))
    excluded, eligible = [], []
    for e in experts:
        reasons = []
        if not e.active:
            reasons.append("inactive")
        if visit_date.isoformat() in e.unavailable:
            reasons.append(f"unavailable on {visit_date.isoformat()}")
        if institution_id in e.coi:
            reasons.append("declared conflict of interest with this institution")
        if policy == "SAME_REGION_ONLY" and e.region_id != institution_region:
            reasons.append("Region policy: expert must belong to the institution's Region")
        if policy == "OTHER_REGION_ONLY" and e.region_id == institution_region:
            reasons.append("Region policy: expert must be from another Region")
        if e.month_load >= e.monthly_cap:
            reasons.append(f"monthly visit cap reached ({e.month_load}/{e.monthly_cap})")
        dist = km((e.lat, e.lon), inst_coords)
        if dist > max_km and not reasons:
            reasons.append(f"travel distance {dist:.0f} km exceeds {max_km:.0f} km")
        if reasons:
            excluded.append({"expert_id": e.id, "name": e.name, "reasons": reasons, "coi": institution_id in e.coi})
            continue
        travel = max(0.0, 1 - dist / max_km)
        workload = 1 - e.month_load / max(e.monthly_cap, 1)
        req = set(required)
        match = len(req & set(e.expertise)) / len(req) if req else 1.0
        score = weights.get("travel", 0.35) * travel + weights.get("workload", 0.3) * workload + weights.get("expertise", 0.35) * match
        eligible.append({"expert_id": e.id, "name": e.name, "expertise": list(e.expertise), "distance_km": round(dist),
                         "month_load": e.month_load, "monthly_cap": e.monthly_cap, "score": round(score, 4),
                         "components": {"travel": round(travel, 3), "workload": round(workload, 3), "expertise": round(match, 3)}})
    eligible.sort(key=lambda x: (-x["score"], x["expert_id"]))
    panels = []
    pool = eligible[:9]
    if len(pool) >= size:
        combos = []
        for c in itertools.combinations(pool, size):
            covered = set().union(*[set(x["expertise"]) for x in c]) & set(required)
            coverage = len(covered) / len(required) if required else 1.0
            pscore = sum(x["score"] for x in c) / size + 0.25 * coverage
            combos.append((round(pscore, 4), coverage, c))
        combos.sort(key=lambda t: (-t[0], [x["expert_id"] for x in t[2]]))
        for pscore, coverage, c in combos[:n_panels]:
            panels.append({"panel_score": pscore, "expertise_coverage": round(coverage, 3), "expert_ids": [x["expert_id"] for x in c],
                           "members": list(c),
                           "explanation": f"Mean member score {sum(x['score'] for x in c) / size:.3f} "
                                          f"+ coverage bonus {0.25 * coverage:.3f} ({coverage:.0%} of required expertise: {', '.join(required) or 'none'})."})
    return {"visit_date": visit_date.isoformat(), "required_expertise": required, "weights": weights,
            "panels": panels, "eligible": eligible, "excluded": excluded,
            "insufficient": len(panels) == 0,
            "note": None if panels else f"Fewer than {size} eligible experts — adjust date, policy or expert pool."}
