"""Escalation recipient resolver (pure, resolved at execution time).

Order of resolution for a target post:
  1. Active delegate (leave delegation covering the date)        -> DELEGATE
  2. Active post holder                                          -> HOLDER
  3. Vacant -> same-level post in the nearest Region with a holder/delegate -> NEAREST_REGION
  4. Next organisational level (parent post), repeat              -> NEXT_LEVEL
  5. Nothing found                                                -> UNROUTABLE (alert administrator)
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date


@dataclass(frozen=True)
class PostView:
    id: int
    level: int
    region_id: int | None
    parent_id: int | None
    holder_id: int | None
    code: str = ""


@dataclass(frozen=True)
class DelegationView:
    post_id: int
    delegate_id: int
    starts_on: date
    ends_on: date
    revoked: bool = False


@dataclass
class Resolution:
    recipient_id: int | None
    post_id: int | None
    via: str
    path: list[dict] = field(default_factory=list)


def _distance(a: tuple[float, float], b: tuple[float, float]) -> float:
    (la1, lo1), (la2, lo2) = a, b
    p = math.pi / 180
    h = 0.5 - math.cos((la2 - la1) * p) / 2 + math.cos(la1 * p) * math.cos(la2 * p) * (1 - math.cos((lo2 - lo1) * p)) / 2
    return 12742 * math.asin(math.sqrt(h))


def _occupant(post: PostView, on: date, delegations: list[DelegationView], active_users: set[int]) -> tuple[int | None, str]:
    for d in delegations:
        if d.post_id == post.id and not d.revoked and d.starts_on <= on <= d.ends_on and d.delegate_id in active_users:
            return d.delegate_id, "DELEGATE"
    if post.holder_id and post.holder_id in active_users:
        return post.holder_id, "HOLDER"
    return None, "VACANT"


def resolve(start_post_id: int, on: date, posts: dict[int, PostView], delegations: list[DelegationView],
            active_users: set[int], region_coords: dict[int, tuple[float, float]], exclude: set[int] | None = None) -> Resolution:
    exclude = exclude or set()
    path: list[dict] = []
    post = posts.get(start_post_id)
    seen: set[int] = set()
    while post and post.id not in seen:
        seen.add(post.id)
        uid, how = _occupant(post, on, delegations, active_users)
        path.append({"post": post.code or post.id, "level": post.level, "result": how, "user": uid})
        if uid and uid not in exclude:
            return Resolution(uid, post.id, how, path)
        # vacant (or only the excluded person): try the same level in the nearest Region
        if post.region_id is not None and post.region_id in region_coords:
            here = region_coords[post.region_id]
            peers = sorted((p for p in posts.values() if p.level == post.level and p.region_id not in (None, post.region_id)
                            and p.region_id in region_coords),
                           key=lambda p: (_distance(here, region_coords[p.region_id]), p.id))
            for p in peers:
                uid2, how2 = _occupant(p, on, delegations, active_users)
                if uid2 and uid2 not in exclude:
                    path.append({"post": p.code or p.id, "level": p.level, "result": f"NEAREST_REGION/{how2}", "user": uid2})
                    return Resolution(uid2, p.id, "NEAREST_REGION", path)
        path.append({"post": post.code or post.id, "result": "NEXT_LEVEL"})
        post = posts.get(post.parent_id) if post.parent_id else None
    path.append({"result": "UNROUTABLE"})
    return Resolution(None, None, "UNROUTABLE", path)


def escalation_target_post(assigned_post_id: int | None, level: int, posts: dict[int, PostView]) -> int | None:
    """Level n escalates n steps up the organisational hierarchy from the assigned post."""
    p = posts.get(assigned_post_id) if assigned_post_id else None
    for _ in range(level):
        if not p or not p.parent_id:
            break
        p = posts.get(p.parent_id)
    return p.id if p else None
