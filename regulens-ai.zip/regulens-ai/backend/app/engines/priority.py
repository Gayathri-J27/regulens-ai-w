"""Today's 10 priority formula (pure, visible, configurable).

priority = w1 * urgency + w2 * tier_score + w3 * statutory_flag + w4 * ageing

urgency    = 1 / max(days_to_breach, 0.5)                     for days_to_breach > 0
           = 2 + min(days_overdue, 30) / 10                    for due today or overdue (bounded, never divides by 0)
tier_score = (4 - tier) / 3                                    tier 1 -> 1.0, tier 3 -> 0.33
ageing     = min(age_days / 90, 1)
An authorised officer's recorded override replaces the computed value.
"""
from __future__ import annotations


def urgency(days_to_breach: int | None) -> float:
    if days_to_breach is None:
        return 0.0  # paused: nothing is running against anyone
    if days_to_breach > 0:
        return 1.0 / max(days_to_breach, 0.5)
    return 2.0 + min(-days_to_breach, 30) / 10.0


def score(days_to_breach: int | None, tier: int, statutory: bool, age_days: int, w: dict) -> dict:
    u = urgency(days_to_breach)
    t = (4 - min(max(tier, 1), 3)) / 3
    a = min(max(age_days, 0) / 90, 1.0)
    parts = {"urgency": round(w.get("w1", 10) * u, 3), "tier": round(w.get("w2", 2) * t, 3),
             "statutory": round(w.get("w3", 3) * (1 if statutory else 0), 3), "ageing": round(w.get("w4", 1.5) * a, 3)}
    return {"priority": round(sum(parts.values()), 3), "components": parts,
            "inputs": {"days_to_breach": days_to_breach, "urgency": round(u, 3), "tier_score": round(t, 3), "ageing": round(a, 3)}}


def why(days_to_breach: int | None, statutory: bool, tier: int, otype: str) -> str:
    bits = []
    if days_to_breach is None:
        bits.append("clock paused")
    elif days_to_breach < 0:
        bits.append(f"overdue by {-days_to_breach} day(s)")
    elif days_to_breach == 0:
        bits.append("due today")
    elif days_to_breach <= 3:
        bits.append(f"due in {days_to_breach} day(s)")
    if statutory:
        bits.append("statutory obligation")
    if tier == 1:
        bits.append("tier-1 institution")
    return "; ".join(bits) or f"{otype.replace('_', ' ').lower()} in progress"


def next_action(otype: str, state: str, party: str) -> str:
    if state == "SUBMITTED":
        return "Verify or reject the submitted evidence"
    if otype == "EVC_SCHEDULING":
        return "Propose and approve an EVC panel"
    if otype == "EVC_REPORT":
        return "Obtain and upload the EVC report"
    if otype in ("SCRUTINY_COMPLETION", "STAGE_COMPLETION"):
        return "Complete the stage or return the application with reasons"
    if party == "INSTITUTION":
        return "Nudge the institution or record assisted handling"
    return "Review and act on the obligation"
