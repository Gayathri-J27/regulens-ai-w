"""Route state machine (pure). Routes are data (route_templates.definition), not code.

definition = {
  "stages": [{"code": "SCRUTINY", "name": ..., "budget_days": 15, "day_mode": "WORKING",
              "responsible_role": "BUREAU_OFFICER", "required_fields": ["scrutiny_remarks"],
              "requires": {"evc_report": false}, "returnable": true, "resubmit_to": "RESCRUTINY",
              "entry_only_via_resubmit": false, "decision": false, "revert_budget_days": 7}, ...],
  "revert_policy": "RESUME",            # applied to the stage clock on resubmission / revert
  "revert_targets": {"EVC": ["SCRUTINY"], ...}
}
"""
from __future__ import annotations

from dataclasses import dataclass


class WorkflowError(ValueError):
    pass


@dataclass(frozen=True)
class Transition:
    kind: str  # COMPLETE | RETURN | RESUBMIT | REVERT | DECIDE
    from_stage: str
    to_stage: str | None
    clock_policy: str | None = None
    note: str = ""


def stage(defn: dict, code: str) -> dict:
    for s in defn["stages"]:
        if s["code"] == code:
            return s
    raise WorkflowError(f"stage {code} not in route")


def main_path(defn: dict) -> list[str]:
    return [s["code"] for s in defn["stages"] if not s.get("entry_only_via_resubmit")]


def first_stage(defn: dict) -> str:
    return main_path(defn)[0]


def next_stage(defn: dict, current: str) -> str | None:
    s = stage(defn, current)
    if s.get("next"):
        return s["next"]
    path = main_path(defn)
    if current in path:
        i = path.index(current)
        return path[i + 1] if i + 1 < len(path) else None
    raise WorkflowError(f"{current} has no successor")


def plan_complete(defn: dict, current: str, fields: dict, facts: dict) -> Transition:
    s = stage(defn, current)
    if s.get("decision"):
        raise WorkflowError("The decision stage is completed only by a recorded decision of the competent authority.")
    missing = [f for f in s.get("required_fields", []) if not str(fields.get(f, "")).strip()]
    if missing:
        raise WorkflowError(f"Required field(s) missing for {current}: {', '.join(missing)}")
    for cond, need in (s.get("requires") or {}).items():
        if need and not facts.get(cond):
            raise WorkflowError(f"Condition not satisfied for completing {current}: {cond.replace('_', ' ')}")
    return Transition("COMPLETE", current, next_stage(defn, current))


def plan_return(defn: dict, current: str, reason: str) -> Transition:
    s = stage(defn, current)
    if not s.get("returnable", False):
        raise WorkflowError(f"Stage {current} does not allow return to the institution.")
    if not reason or not reason.strip():
        raise WorkflowError("A return reason is mandatory.")
    return Transition("RETURN", current, current, None, reason)


def plan_resubmit(defn: dict, current: str) -> Transition:
    s = stage(defn, current)
    return Transition("RESUBMIT", current, s.get("resubmit_to") or current, defn.get("revert_policy", "RESUME"))


def plan_revert(defn: dict, current: str, target: str, reason: str) -> Transition:
    allowed = (defn.get("revert_targets") or {}).get(current, [])
    if target not in allowed:
        raise WorkflowError(f"Revert from {current} to {target} is not permitted by this route (allowed: {allowed or 'none'}).")
    if not reason or not reason.strip():
        raise WorkflowError("A revert reason is mandatory.")
    return Transition("REVERT", current, target, defn.get("revert_policy", "RESUME"), reason)


def plan_decide(defn: dict, current: str, decision: str, note: str) -> Transition:
    s = stage(defn, current)
    if not s.get("decision"):
        raise WorkflowError("Application is not at the decision stage.")
    if decision not in ("APPROVED", "REJECTED", "APPROVED_WITH_CONDITIONS"):
        raise WorkflowError("decision must be APPROVED, APPROVED_WITH_CONDITIONS or REJECTED")
    if not note or not note.strip():
        raise WorkflowError("A decision note is mandatory.")
    return Transition("DECIDE", current, None, None, note)


def validate_definition(defn: dict) -> list[str]:
    errs = []
    codes = [s.get("code") for s in defn.get("stages", [])]
    if not codes:
        errs.append("route has no stages")
    if len(codes) != len(set(codes)):
        errs.append("duplicate stage codes")
    if not any(s.get("decision") for s in defn.get("stages", [])):
        errs.append("route must end in a human decision stage")
    for s in defn.get("stages", []):
        if s.get("resubmit_to") and s["resubmit_to"] not in codes:
            errs.append(f"{s['code']}.resubmit_to unknown")
        if s.get("next") and s["next"] not in codes:
            errs.append(f"{s['code']}.next unknown")
    for src, tgts in (defn.get("revert_targets") or {}).items():
        for t in tgts:
            if t not in codes or src not in codes:
                errs.append(f"revert {src}->{t} references unknown stage")
    if defn.get("revert_policy", "RESUME") not in ("RESUME", "RESTART", "RESET_TO_STAGE_BUDGET"):
        errs.append("bad revert_policy")
    return errs


def _s(code, name, budget, role, **kw):
    d = {"code": code, "name": name, "budget_days": budget, "day_mode": "WORKING", "responsible_role": role}
    d.update(kw)
    return d


SCRUTINY = _s("SCRUTINY", "Scrutiny", 15, "BUREAU_OFFICER", required_fields=["scrutiny_remarks"], returnable=True,
              resubmit_to="RESCRUTINY", revert_budget_days=7)
RESCRUTINY = _s("RESCRUTINY", "Re-scrutiny", 7, "BUREAU_OFFICER", required_fields=["scrutiny_remarks"], returnable=True,
                resubmit_to="RESCRUTINY", entry_only_via_resubmit=True, revert_budget_days=5)
EVC = _s("EVC", "Expert Visit Committee", 20, "REGIONAL_OFFICER", requires={"evc_report": True}, returnable=True,
         revert_budget_days=10)
SAC = _s("SAC_SHC", "SAC / SHC", 10, "REGIONAL_OFFICER", required_fields=["committee_recommendation"], returnable=False,
         revert_budget_days=5)
DECISION = _s("DECISION", "Decision by competent authority", 7, "COMPETENT_AUTHORITY", decision=True)


def _route(stages, reverts, policy="RESUME"):
    import copy
    st = copy.deepcopy(stages)
    codes = [s["code"] for s in st]
    if "RESCRUTINY" in codes:  # re-scrutiny continues on the same path as scrutiny
        nxt = codes[codes.index("RESCRUTINY") + 1]
        for s in st:
            if s["code"] == "RESCRUTINY":
                s["next"] = nxt
    return {"stages": st, "revert_policy": policy, "revert_targets": reverts}


DEFAULT_ROUTES = {
    "SCRUTINY_ONLY": ("Only Scrutiny", _route([SCRUTINY, RESCRUTINY, DECISION], {"DECISION": ["SCRUTINY"]})),
    "SCRUTINY_EVC": ("Scrutiny + EVC", _route([SCRUTINY, RESCRUTINY, EVC, DECISION], {"EVC": ["SCRUTINY"], "DECISION": ["EVC", "SCRUTINY"]})),
    "EVC_SAC": ("EVC + SAC/SHC", _route([EVC, SAC, DECISION], {"SAC_SHC": ["EVC"], "DECISION": ["SAC_SHC", "EVC"]}, "RESET_TO_STAGE_BUDGET")),
    "EVC_ONLY": ("Only EVC", _route([EVC, DECISION], {"DECISION": ["EVC"]})),
    "SCRUTINY_EVC_SAC": ("Scrutiny + EVC + SAC/SHC", _route([SCRUTINY, RESCRUTINY, EVC, SAC, DECISION],
                                                            {"EVC": ["SCRUTINY"], "SAC_SHC": ["EVC"], "DECISION": ["SAC_SHC", "EVC", "SCRUTINY"]})),
    "SCRUTINY_SAC": ("Scrutiny + SAC/SHC", _route([SCRUTINY, RESCRUTINY, SAC, DECISION], {"SAC_SHC": ["SCRUTINY"], "DECISION": ["SAC_SHC"]}, "RESTART")),
}
