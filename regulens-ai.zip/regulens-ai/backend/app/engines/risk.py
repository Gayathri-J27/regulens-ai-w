"""Breach forecast (pure, explainable).

Base probability: empirical survival of the completion ratio r = duration / budget among *closed*
historical obligations of the same segment (type, Region, institution tier):

    P(miss | not done at elapsed ratio e) = S(1) / S(e)      with S(x) = P(r > x)

Segments with n < min_samples are shrunk towards the parent (type-only) estimate, and that towards the
global estimate:  p = (n * p_seg + k * p_parent) / (n + k).  With fewer than min_samples globally the
engine returns INSUFFICIENT_DATA rather than inventing confidence.

Modifiers are explicit odds multipliers, each reported as a reason with its contribution.
"""
from __future__ import annotations

import bisect
import math
from dataclasses import dataclass
from datetime import date, timedelta


@dataclass
class Survival:
    ratios: list[float]  # sorted

    @property
    def n(self) -> int:
        return len(self.ratios)

    def S(self, x: float) -> float:
        if not self.ratios:
            return 1.0
        i = bisect.bisect_right(self.ratios, x)
        return (len(self.ratios) - i) / len(self.ratios)

    def p_miss(self, elapsed_ratio: float) -> float:
        se = self.S(min(elapsed_ratio, 0.999))
        if se <= 0:
            return 0.0  # nobody historically took this long without finishing
        return min(1.0, self.S(1.0) / se)


def build(rows: list[tuple[str, int, int, float]]) -> dict:
    """rows: (type, region_id, tier, ratio) for closed obligations. Returns survival tables per level."""
    seg, typ, glob = {}, {}, []
    for t, reg, tier, r in rows:
        seg.setdefault((t, reg, tier), []).append(r)
        typ.setdefault(t, []).append(r)
        glob.append(r)
    return {"seg": {k: Survival(sorted(v)) for k, v in seg.items()},
            "type": {k: Survival(sorted(v)) for k, v in typ.items()},
            "global": Survival(sorted(glob))}


def _odds(p):
    p = min(max(p, 0.02), 0.98)  # empirical base rates are kept away from certainty so modifiers stay meaningful
    return p / (1 - p)


def _prob(o):
    return o / (1 + o)


def estimate(tables: dict, *, otype: str, region_id: int, tier: int, start: date, due: date, today: date, state: str,
             inst_miss_rate: float | None, inst_n: int, has_evidence: bool, inst_response_ratio: float | None,
             officer_load: int | None, median_load: float | None, thresholds: dict) -> dict:
    k = float(thresholds.get("shrinkage_k", 30))
    min_n = int(thresholds.get("min_samples", 30))
    g: Survival = tables["global"]
    if g.n < min_n:
        return {"level": "INSUFFICIENT_DATA", "probability": None, "sample_size": g.n, "segment": "global", "reasons": [
            {"reason": f"Only {g.n} closed obligations in history (< {min_n}); no forecast is made.", "effect": 0}]}
    budget = max((due - start).days, 1)
    elapsed = max((today - start).days, 0) / budget
    s_seg = tables["seg"].get((otype, region_id, tier))
    s_type = tables["type"].get(otype)
    p_g = g.p_miss(elapsed)
    if s_type and s_type.n:
        p_t = (s_type.n * s_type.p_miss(elapsed) + k * p_g) / (s_type.n + k)
        n_t = s_type.n
    else:
        p_t, n_t = p_g, 0
    if s_seg and s_seg.n:
        p = (s_seg.n * s_seg.p_miss(elapsed) + k * p_t) / (s_seg.n + k)
        segment, n = f"{otype} / region {region_id} / tier {tier}", s_seg.n
    else:
        p, segment, n = p_t, f"{otype} (all regions)" if n_t else "global", n_t or g.n
    reasons = [{"reason": f"Historical: {p:.0%} of similar obligations ({segment}, n={n}) still open at {elapsed:.0%} of their time missed the deadline.",
                "effect": round(p, 3), "kind": "base"}]
    odds = _odds(p)
    mods = []
    days_left = (due - today).days
    if days_left < 0:
        odds = _odds(0.99)
        mods.append(("Deadline already passed", 3.0))
    if inst_miss_rate is not None and inst_n >= 3:
        f = 1 + 2.0 * (inst_miss_rate - 0.2)
        if abs(f - 1) > 0.05:
            mods.append((f"Institution missed {inst_miss_rate:.0%} of its last {inst_n} deadlines", f))
    if state in ("OPEN",) and not has_evidence and elapsed > 0.6:
        mods.append(("No acknowledgement or evidence yet with most of the time used", 1.6))
    if state == "SUBMITTED":
        mods.append(("Evidence already submitted — awaiting verification", 0.35))
    if state == "ACKNOWLEDGED":
        mods.append(("Requirement acknowledged by the institution", 0.85))
    if inst_response_ratio is not None and inst_response_ratio > 1.0:
        mods.append((f"Institution's past responses took {inst_response_ratio:.1f}× the allowed time on average", min(1 + (inst_response_ratio - 1), 2.5)))
    if officer_load and median_load and officer_load > 1.5 * median_load:
        f = min(officer_load / median_load / 1.5, 2.0)
        mods.append((f"Assigned officer carries {officer_load} open items (median {median_load:.0f})", f))
    if 0 <= days_left <= 3 and state == "OPEN":
        mods.append((f"Only {days_left} day(s) left", 1.4))
    for why, f in mods:
        before = _prob(odds)
        odds *= f
        reasons.append({"reason": why, "effect": round(_prob(odds) - before, 3), "kind": "modifier"})
    prob = round(min(max(_prob(odds), 0.01), 0.99), 3)  # an empirical model never claims certainty
    level = "HIGH" if prob >= thresholds.get("high", 0.6) else ("MEDIUM" if prob >= thresholds.get("medium", 0.3) else "LOW")
    top = sorted(reasons, key=lambda r: -abs(r["effect"]))[:3]
    lead = 14 if level == "HIGH" else (7 if level == "MEDIUM" else 3)
    suggested = max(today, due - timedelta(days=lead))
    return {"level": level, "probability": prob, "sample_size": n, "segment": segment, "reasons": top,
            "all_reasons": reasons, "suggested_reminder": suggested.isoformat(), "elapsed_ratio": round(elapsed, 3)}
