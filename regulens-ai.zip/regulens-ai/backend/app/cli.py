"""ReguLens command line: python -m app.cli <command>

  bootstrap            reference data + demo accounts (idempotent)
  synthetic [--scale]  reset bulk synthetic data and regenerate it (fixed seed)
  reset-synthetic      remove bulk synthetic data only
  sweep                run escalation + overdue + EVC delay sweeps and dispatch notifications once
  benchmark [--out]    run the benchmark harness and write a scorecard (JSON + Markdown)
  worker               run the durable scheduler loop in the foreground
  verify-audit         verify the audit hash chain
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from app.core.db import SessionLocal


def main(argv=None):
    ap = argparse.ArgumentParser(prog="regulens")
    ap.add_argument("cmd")
    ap.add_argument("--scale", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=20261030)
    ap.add_argument("--out", default=str(Path(__file__).resolve().parents[2] / "docs" / "benchmark"))
    a = ap.parse_args(argv)
    db = SessionLocal()
    try:
        if a.cmd == "bootstrap":
            from app.services.seed import bootstrap
            print(bootstrap(db))
            db.commit()
        elif a.cmd in ("synthetic", "reset-synthetic"):
            from app.services.seed import bootstrap
            from app.services.synthetic import generate, reset
            bootstrap(db)
            db.commit()
            print("reset:", reset(db, None))
            db.commit()
            if a.cmd == "synthetic":
                print("generated:", json.dumps(generate(db, None, seed=a.seed, scale=a.scale), default=str))
                db.commit()
        elif a.cmd == "sweep":
            from app.services import escalation, evc, intelligence, notifications
            from app.workers.scheduler import overdue_notices
            print("escalation:", escalation.sweep(db)); db.commit()
            print("overdue:", overdue_notices(db)); db.commit()
            print("evc delayed:", evc.delay_sweep(db)); db.commit()
            print("risk:", intelligence.recompute_risk(db)); db.commit()
            for _ in range(10):
                s = notifications.dispatch_due(db, limit=5000)
                db.commit()
                if not s["processed"]:
                    break
            print("dispatch:", s)
        elif a.cmd == "benchmark":
            from app.services.benchmark import run_benchmark
            sc = run_benchmark(db)
            db.commit()
            out = Path(a.out)
            out.mkdir(parents=True, exist_ok=True)
            (out / "scorecard.json").write_text(json.dumps(sc, indent=2, default=str))
            (out / "scorecard.md").write_text(to_markdown(sc))
            print(to_markdown(sc))
        elif a.cmd == "worker":
            import time
            from app.workers.scheduler import tick
            print("scheduler running; Ctrl+C to stop")
            while True:
                print(tick(), flush=True)
                time.sleep(15)
        elif a.cmd == "verify-audit":
            from app.services.audit import verify
            v = verify(db, "ON_DEMAND")
            db.commit()
            print({"ok": v.ok, "checked": v.checked, "first_broken_id": v.first_broken_id, "detail": v.detail})
            sys.exit(0 if v.ok else 1)
        else:
            print(__doc__)
            sys.exit(2)
    finally:
        db.close()


def to_markdown(sc: dict) -> str:
    L = [f"# ReguLens AI — benchmark scorecard", "", f"Run at {sc['ran_at']} · {sc['environment']} · {sc['duration_s']} s", ""]
    def sect(title, d, keys=None):
        L.append(f"## {title}")
        L.append("")
        L.append("| Metric | Value |")
        L.append("|---|---|")
        for k, v in d.items():
            if keys and k not in keys or isinstance(v, (list, dict)):
                continue
            L.append(f"| {k.replace('_', ' ')} | {v} |")
        L.append("")
    sect("1. Workflow accuracy", sc["workflow_accuracy"])
    sect("2. Alert timeliness", sc["alert_timeliness"])
    sect("3. Deadline reliability", sc["deadline_reliability"])
    sect("3b. Scheduler crash recovery", sc["scheduler_crash_recovery"])
    sect("4. Pending-case visibility", sc["pending_case_visibility"])
    sect("5. Manual follow-up reduction", sc["manual_followup_reduction"])
    sect("6. Audit completeness", sc["audit_completeness"])
    sect("Permission matrix", sc["permission_matrix"])
    L.append("## Targets (measured, not asserted)")
    L.append("")
    for k, v in sc["targets"].items():
        L.append(f"- {k.replace('_', ' ')}: **{'MET' if v else 'NOT MET'}**")
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    main()
