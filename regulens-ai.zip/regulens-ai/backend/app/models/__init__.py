"""SQLAlchemy 2 models for ReguLens AI.

One shared schema: every module (ledger, workflow, EVC, notifications, escalation,
analytics, audit) reads and writes these same tables.
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from sqlalchemy import (BigInteger, Boolean, Date, DateTime, Float, ForeignKey, Index, Integer, String, Text,
                        UniqueConstraint, text)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


TS = DateTime(timezone=True)


# --------------------------------------------------------------------------- organisation
class Region(Base):
    __tablename__ = "regions"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(16), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    hq_city: Mapped[str] = mapped_column(String(80))
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    states: Mapped[list] = mapped_column(JSONB, default=list)
    holiday_calendar_id: Mapped[int | None] = mapped_column(ForeignKey("holiday_calendars.id"))


class Post(Base):
    """An organisational post (seat). Escalation resolves to whoever holds / covers it *at execution time*."""
    __tablename__ = "posts"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    title: Mapped[str] = mapped_column(String(160))
    level: Mapped[int] = mapped_column(Integer)  # 1=desk officer .. 4=head office
    region_id: Mapped[int | None] = mapped_column(ForeignKey("regions.id"))
    parent_post_id: Mapped[int | None] = mapped_column(ForeignKey("posts.id"))
    holder_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", use_alter=True))
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160))
    password_hash: Mapped[str] = mapped_column(String(200))
    role: Mapped[str] = mapped_column(String(40), index=True)
    region_id: Mapped[int | None] = mapped_column(ForeignKey("regions.id"))
    institution_id: Mapped[int | None] = mapped_column(ForeignKey("institutions.id", use_alter=True))
    post_id: Mapped[int | None] = mapped_column(ForeignKey("posts.id", use_alter=True))
    phone: Mapped[str | None] = mapped_column(String(32))
    preferred_language: Mapped[str] = mapped_column(String(5), default="en")
    totp_secret: Mapped[str | None] = mapped_column(String(64))
    totp_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    failed_logins: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(TS)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    reset_token_hash: Mapped[str | None] = mapped_column(String(128))
    reset_token_expires: Mapped[datetime | None] = mapped_column(TS)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class UserSession(Base):
    __tablename__ = "user_sessions"
    id: Mapped[int] = mapped_column(primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(TS)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)
    mfa_passed: Mapped[bool] = mapped_column(Boolean, default=True)
    ip: Mapped[str | None] = mapped_column(String(64))


class Delegation(Base):
    __tablename__ = "delegations"
    id: Mapped[int] = mapped_column(primary_key=True)
    post_id: Mapped[int] = mapped_column(ForeignKey("posts.id"), index=True)
    delegate_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    starts_on: Mapped[date] = mapped_column(Date)
    ends_on: Mapped[date] = mapped_column(Date)
    reason: Mapped[str] = mapped_column(String(200))
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)


# --------------------------------------------------------------------------- calendars
class HolidayCalendar(Base):
    __tablename__ = "holiday_calendars"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(160))
    scope: Mapped[str] = mapped_column(String(20))  # AICTE_NATIONAL | AICTE_REGION | STATE
    state: Mapped[str | None] = mapped_column(String(60))
    weekend_days: Mapped[list] = mapped_column(JSONB, default=lambda: [5, 6])  # Mon=0 .. Sun=6
    version: Mapped[int] = mapped_column(Integer, default=1)


class Holiday(Base):
    __tablename__ = "holidays"
    __table_args__ = (UniqueConstraint("calendar_id", "day"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    calendar_id: Mapped[int] = mapped_column(ForeignKey("holiday_calendars.id"), index=True)
    day: Mapped[date] = mapped_column(Date)
    name: Mapped[str] = mapped_column(String(160))


# --------------------------------------------------------------------------- institutions
class Institution(Base):
    __tablename__ = "institutions"
    id: Mapped[int] = mapped_column(primary_key=True)
    aicte_id: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(240), index=True)
    region_id: Mapped[int] = mapped_column(ForeignKey("regions.id"), index=True)
    state: Mapped[str] = mapped_column(String(60), index=True)
    district: Mapped[str | None] = mapped_column(String(80))
    tier: Mapped[int] = mapped_column(Integer, default=2)  # 1 = highest priority/visibility, 3 = lowest
    address: Mapped[str | None] = mapped_column(Text)
    lat: Mapped[float | None] = mapped_column(Float)
    lon: Mapped[float | None] = mapped_column(Float)
    preferred_language: Mapped[str] = mapped_column(String(5), default="en")
    digest_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    responsiveness: Mapped[float] = mapped_column(Float, default=1.0)  # synthetic generator parameter only
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    contacts: Mapped[list["InstitutionContact"]] = relationship(back_populates="institution")


class InstitutionContact(Base):
    __tablename__ = "institution_contacts"
    id: Mapped[int] = mapped_column(primary_key=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institutions.id"), index=True)
    role: Mapped[str] = mapped_column(String(30))  # PRINCIPAL | COMPLIANCE | TRUST_REP | ACCOUNTS
    name: Mapped[str] = mapped_column(String(160))
    email: Mapped[str | None] = mapped_column(String(200))
    phone: Mapped[str | None] = mapped_column(String(32))
    verified: Mapped[bool] = mapped_column(Boolean, default=False)
    invalid: Mapped[bool] = mapped_column(Boolean, default=False)
    invalid_reason: Mapped[str | None] = mapped_column(String(200))
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    institution: Mapped[Institution] = relationship(back_populates="contacts")


# --------------------------------------------------------------------------- rules & config
class Rule(Base):
    """Rules-as-code. Every configurable parameter is a versioned rule row.

    status: DRAFT -> PREVIEWED -> APPROVED (two-person) -> EFFECTIVE -> SUPERSEDED / RETIRED
    """
    __tablename__ = "rules"
    __table_args__ = (UniqueConstraint("rule_key", "version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    rule_key: Mapped[str] = mapped_column(String(80), index=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    rule_type: Mapped[str] = mapped_column(String(40))  # DEADLINE | REMINDER | ESCALATION | ROUTE | PRIORITY | RISK | EVC | RETENTION | NOTIFICATION
    condition: Mapped[dict] = mapped_column(JSONB, default=dict)
    action: Mapped[dict] = mapped_column(JSONB, default=dict)
    params: Mapped[dict] = mapped_column(JSONB, default=dict)
    effective_from: Mapped[date | None] = mapped_column(Date)
    effective_to: Mapped[date | None] = mapped_column(Date)
    source_type: Mapped[str] = mapped_column(String(30), default="CONFIGURABLE_PARAMETER")
    aph_edition: Mapped[str | None] = mapped_column(String(40))
    section: Mapped[str | None] = mapped_column(String(40))
    page: Mapped[str | None] = mapped_column(String(20))
    citation: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="DRAFT", index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False)
    impact_preview: Mapped[dict | None] = mapped_column(JSONB)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    approved_at: Mapped[datetime | None] = mapped_column(TS)


class RouteTemplate(Base):
    """Configurable workflow state machine definition (one row per version)."""
    __tablename__ = "route_templates"
    __table_args__ = (UniqueConstraint("code", "version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), index=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    name: Mapped[str] = mapped_column(String(160))
    description: Mapped[str] = mapped_column(Text, default="")
    definition: Mapped[dict] = mapped_column(JSONB)  # {stages:[...], revert_policy, return_allowed_from:[...]}
    source_type: Mapped[str] = mapped_column(String(30), default="CONFIGURABLE_PARAMETER")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class ConfigVersion(Base):
    """Snapshot of effective configuration; applications pin the version current at their creation."""
    __tablename__ = "config_versions"
    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    reason: Mapped[str] = mapped_column(String(200))
    rule_ids: Mapped[list] = mapped_column(JSONB)  # effective rule row ids at this version


# --------------------------------------------------------------------------- applications & workflow
class Application(Base):
    __tablename__ = "applications"
    id: Mapped[int] = mapped_column(primary_key=True)
    app_no: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institutions.id"), index=True)
    application_type: Mapped[str] = mapped_column(String(60), index=True)
    academic_year: Mapped[str] = mapped_column(String(10), default="2026-27")
    route_template_id: Mapped[int] = mapped_column(ForeignKey("route_templates.id"))
    route_code: Mapped[str] = mapped_column(String(40), index=True)
    current_stage: Mapped[str] = mapped_column(String(40), index=True)
    status: Mapped[str] = mapped_column(String(20), default="IN_PROGRESS", index=True)
    # IN_PROGRESS | RETURNED | AWAITING_DECISION | APPROVED | REJECTED | WITHDRAWN | MERGED | ON_HOLD
    assigned_officer_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True)
    stage_entered_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    stage_clock_id: Mapped[int | None] = mapped_column(ForeignKey("clocks.id", use_alter=True))
    institution_clock_id: Mapped[int | None] = mapped_column(ForeignKey("clocks.id", use_alter=True))
    parent_application_id: Mapped[int | None] = mapped_column(ForeignKey("applications.id"))
    merged_into_id: Mapped[int | None] = mapped_column(ForeignKey("applications.id"))
    config_version_id: Mapped[int | None] = mapped_column(ForeignKey("config_versions.id"))
    priority: Mapped[str] = mapped_column(String(10), default="NORMAL")
    decision: Mapped[str | None] = mapped_column(String(40))
    decision_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    decision_at: Mapped[datetime | None] = mapped_column(TS)
    decision_note: Mapped[str | None] = mapped_column(Text)
    ground_truth_route: Mapped[str | None] = mapped_column(String(40))  # synthetic benchmark only
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow, onupdate=utcnow)
    institution: Mapped[Institution] = relationship()


class ApplicationEvent(Base):
    """Movement history -> also the event log used by process mining."""
    __tablename__ = "application_events"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    application_id: Mapped[int] = mapped_column(ForeignKey("applications.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(30), index=True)
    from_stage: Mapped[str | None] = mapped_column(String(40))
    to_stage: Mapped[str | None] = mapped_column(String(40))
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    reason: Mapped[str | None] = mapped_column(Text)
    reason_code: Mapped[str | None] = mapped_column(String(40), index=True)
    payload: Mapped[dict] = mapped_column(JSONB, default=dict)
    at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)


# --------------------------------------------------------------------------- clocks
class Clock(Base):
    __tablename__ = "clocks"
    id: Mapped[int] = mapped_column(primary_key=True)
    owner_side: Mapped[str] = mapped_column(String(12))  # AICTE | INSTITUTION
    label: Mapped[str] = mapped_column(String(160))
    budget_days: Mapped[int] = mapped_column(Integer)
    day_mode: Mapped[str] = mapped_column(String(10))  # WORKING | CALENDAR
    calendar_ids: Mapped[list] = mapped_column(JSONB, default=list)
    revert_policy: Mapped[str] = mapped_column(String(30), default="RESUME")
    state: Mapped[str] = mapped_column(String(24), default="RUNNING", index=True)
    started_at: Mapped[datetime] = mapped_column(TS)
    due_date: Mapped[date | None] = mapped_column(Date, index=True)  # derived from clock_events; cache only
    source_rule_id: Mapped[int | None] = mapped_column(ForeignKey("rules.id"))
    application_id: Mapped[int | None] = mapped_column(ForeignKey("applications.id"), index=True)
    computed_at: Mapped[datetime | None] = mapped_column(TS)


class ClockEvent(Base):
    __tablename__ = "clock_events"
    __table_args__ = (UniqueConstraint("clock_id", "seq"),)
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    clock_id: Mapped[int] = mapped_column(ForeignKey("clocks.id"), index=True)
    seq: Mapped[int] = mapped_column(Integer)
    kind: Mapped[str] = mapped_column(String(20))  # START PAUSE RESUME EXTEND REVERT STOP_MET STOP_WAIVED
    pause_kind: Mapped[str | None] = mapped_column(String(24))
    at: Mapped[datetime] = mapped_column(TS)
    days: Mapped[int | None] = mapped_column(Integer)
    policy: Mapped[str | None] = mapped_column(String(30))
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    reason: Mapped[str | None] = mapped_column(Text)


# --------------------------------------------------------------------------- files
class StoredFile(Base):
    __tablename__ = "files"
    id: Mapped[int] = mapped_column(primary_key=True)
    storage_key: Mapped[str] = mapped_column(String(300), unique=True)
    filename: Mapped[str] = mapped_column(String(240))
    mime: Mapped[str] = mapped_column(String(80))
    size: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    scan_status: Mapped[str] = mapped_column(String(20))  # CLEAN | INFECTED | ERROR
    scan_engine: Mapped[str] = mapped_column(String(160))
    institution_id: Mapped[int | None] = mapped_column(ForeignKey("institutions.id"), index=True)
    uploaded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    purpose: Mapped[str] = mapped_column(String(40))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


# --------------------------------------------------------------------------- promise ledger
class Obligation(Base):
    __tablename__ = "obligations"
    id: Mapped[int] = mapped_column(primary_key=True)
    obl_no: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institutions.id"), index=True)
    application_id: Mapped[int | None] = mapped_column(ForeignKey("applications.id"), index=True)
    obligation_type: Mapped[str] = mapped_column(String(40), index=True)
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[str] = mapped_column(Text, default="")
    responsible_role: Mapped[str] = mapped_column(String(40))
    responsible_party: Mapped[str] = mapped_column(String(12))  # AICTE | INSTITUTION
    assigned_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True)
    assigned_post_id: Mapped[int | None] = mapped_column(ForeignKey("posts.id"))
    source_event: Mapped[str] = mapped_column(String(60))
    source_rule_id: Mapped[int | None] = mapped_column(ForeignKey("rules.id"))
    source_document_id: Mapped[int | None] = mapped_column(ForeignKey("files.id"))
    source_text: Mapped[str | None] = mapped_column(Text)
    evidence_requirements: Mapped[list] = mapped_column(JSONB, default=list)
    start_date: Mapped[date] = mapped_column(Date)
    due_date: Mapped[date | None] = mapped_column(Date, index=True)
    clock_id: Mapped[int | None] = mapped_column(ForeignKey("clocks.id"))
    state: Mapped[str] = mapped_column(String(20), default="OPEN", index=True)
    # OPEN ACKNOWLEDGED SUBMITTED PAUSED MET WAIVED CANCELLED MERGED  (OVERDUE derived: open & due < today)
    priority: Mapped[str] = mapped_column(String(10), default="NORMAL")
    priority_override: Mapped[float | None] = mapped_column(Float)
    priority_override_reason: Mapped[str | None] = mapped_column(Text)
    statutory_flag: Mapped[bool] = mapped_column(Boolean, default=False)
    verification_status: Mapped[str] = mapped_column(String(30), default="NOT_SUBMITTED")
    escalation_level: Mapped[int] = mapped_column(Integer, default=0)
    acknowledged_at: Mapped[datetime | None] = mapped_column(TS)
    completed_at: Mapped[datetime | None] = mapped_column(TS)
    closure_note: Mapped[str | None] = mapped_column(Text)
    closed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    merged_into_id: Mapped[int | None] = mapped_column(ForeignKey("obligations.id"))
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(TS, default=utcnow, onupdate=utcnow)
    institution: Mapped[Institution] = relationship()


Index("ix_obligations_open_due", Obligation.due_date,
      postgresql_where=text("state IN ('OPEN','ACKNOWLEDGED','SUBMITTED','PAUSED')"))


class Evidence(Base):
    __tablename__ = "evidence"
    id: Mapped[int] = mapped_column(primary_key=True)
    receipt_no: Mapped[str] = mapped_column(String(40), unique=True)
    obligation_id: Mapped[int] = mapped_column(ForeignKey("obligations.id"), index=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institutions.id"), index=True)
    file_id: Mapped[int | None] = mapped_column(ForeignKey("files.id"))
    channel: Mapped[str] = mapped_column(String(20))  # PORTAL | MAGIC_LINK | ASSISTED | OFFLINE
    note: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(40), default="RECEIVED_PENDING_VERIFICATION")
    ocr_status: Mapped[str] = mapped_column(String(20), default="QUEUED")
    ocr_text: Mapped[str | None] = mapped_column(Text)
    submitted_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    submitted_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(TS)
    review_reason: Mapped[str | None] = mapped_column(Text)


class InstitutionalDocument(Base):
    __tablename__ = "institutional_documents"
    id: Mapped[int] = mapped_column(primary_key=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institutions.id"), index=True)
    doc_type: Mapped[str] = mapped_column(String(60))  # LEASE_DEED | FIRE_SAFETY | BUILDING_STABILITY | ...
    issue_date: Mapped[date | None] = mapped_column(Date)
    expiry_date: Mapped[date | None] = mapped_column(Date, index=True)
    file_id: Mapped[int | None] = mapped_column(ForeignKey("files.id"))
    ocr_text: Mapped[str | None] = mapped_column(Text)
    ocr_result: Mapped[dict | None] = mapped_column(JSONB)
    extraction_confidence: Mapped[float | None] = mapped_column(Float)
    ocr_status: Mapped[str] = mapped_column(String(40), default="PENDING")
    verification_status: Mapped[str] = mapped_column(String(20), default="PENDING")  # PENDING CONFIRMED CORRECTED REJECTED
    verified_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    verified_at: Mapped[datetime | None] = mapped_column(TS)
    obligation_id: Mapped[int | None] = mapped_column(ForeignKey("obligations.id"))
    previous_document_id: Mapped[int | None] = mapped_column(ForeignKey("institutional_documents.id"))
    is_current: Mapped[bool] = mapped_column(Boolean, default=True)
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    uploaded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class ExtractionJob(Base):
    __tablename__ = "extraction_jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    file_id: Mapped[int] = mapped_column(ForeignKey("files.id"))
    application_id: Mapped[int | None] = mapped_column(ForeignKey("applications.id"))
    institution_id: Mapped[int] = mapped_column(ForeignKey("institutions.id"), index=True)
    letter_date: Mapped[date | None] = mapped_column(Date)
    text_method: Mapped[str] = mapped_column(String(120))
    extractor: Mapped[str] = mapped_column(String(60))
    status: Mapped[str] = mapped_column(String(20), default="REVIEW")
    full_text: Mapped[str] = mapped_column(Text, default="")
    rejected_count: Mapped[int] = mapped_column(Integer, default=0)
    log: Mapped[list] = mapped_column(JSONB, default=list)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class ExtractionItem(Base):
    __tablename__ = "extraction_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    job_id: Mapped[int] = mapped_column(ForeignKey("extraction_jobs.id"), index=True)
    kind: Mapped[str] = mapped_column(String(30))
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[str] = mapped_column(Text, default="")
    source_sentence: Mapped[str] = mapped_column(Text)
    source_offset: Mapped[int | None] = mapped_column(Integer)
    due_text: Mapped[str | None] = mapped_column(String(120))
    due_date: Mapped[date | None] = mapped_column(Date)
    responsible_role: Mapped[str] = mapped_column(String(40), default="INSTITUTION_PRINCIPAL")
    evidence_requirement: Mapped[str | None] = mapped_column(Text)
    obligation_type: Mapped[str] = mapped_column(String(40), default="APPROVAL_UNDERTAKING")
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    status: Mapped[str] = mapped_column(String(20), default="PROPOSED")  # PROPOSED ACCEPTED REJECTED
    edited: Mapped[bool] = mapped_column(Boolean, default=False)
    obligation_id: Mapped[int | None] = mapped_column(ForeignKey("obligations.id"))
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    reject_reason: Mapped[str | None] = mapped_column(Text)


# --------------------------------------------------------------------------- EVC
class Expert(Base):
    __tablename__ = "experts"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160))
    expertise: Mapped[list] = mapped_column(JSONB, default=list)
    region_id: Mapped[int] = mapped_column(ForeignKey("regions.id"))
    city: Mapped[str] = mapped_column(String(80))
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    monthly_cap: Mapped[int] = mapped_column(Integer, default=4)
    unavailable_dates: Mapped[list] = mapped_column(JSONB, default=list)  # ISO dates
    coi_institution_ids: Mapped[list] = mapped_column(JSONB, default=list)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)


class EvcVisit(Base):
    __tablename__ = "evc_visits"
    id: Mapped[int] = mapped_column(primary_key=True)
    application_id: Mapped[int] = mapped_column(ForeignKey("applications.id"), index=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institutions.id"), index=True)
    status: Mapped[str] = mapped_column(String(20), default="QUEUED", index=True)
    required_expertise: Mapped[list] = mapped_column(JSONB, default=list)
    proposal: Mapped[dict | None] = mapped_column(JSONB)
    panel_expert_ids: Mapped[list] = mapped_column(JSONB, default=list)
    proposed_date: Mapped[date | None] = mapped_column(Date)
    scheduled_date: Mapped[date | None] = mapped_column(Date)
    visited_at: Mapped[datetime | None] = mapped_column(TS)
    report_file_id: Mapped[int | None] = mapped_column(ForeignKey("files.id"))
    report_received_at: Mapped[datetime | None] = mapped_column(TS)
    findings: Mapped[list] = mapped_column(JSONB, default=list)
    override_reason: Mapped[str | None] = mapped_column(Text)
    delayed_reason: Mapped[str | None] = mapped_column(Text)
    schedule_obligation_id: Mapped[int | None] = mapped_column(ForeignKey("obligations.id"))
    report_obligation_id: Mapped[int | None] = mapped_column(ForeignKey("obligations.id"))
    reschedule_count: Mapped[int] = mapped_column(Integer, default=0)
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class EvcAssignment(Base):
    __tablename__ = "evc_assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    visit_id: Mapped[int] = mapped_column(ForeignKey("evc_visits.id"), index=True)
    expert_id: Mapped[int] = mapped_column(ForeignKey("experts.id"), index=True)
    visit_date: Mapped[date] = mapped_column(Date, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


# --------------------------------------------------------------------------- notifications
class NotificationTemplate(Base):
    __tablename__ = "notification_templates"
    __table_args__ = (UniqueConstraint("key", "language", "version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(60), index=True)
    language: Mapped[str] = mapped_column(String(5))
    version: Mapped[int] = mapped_column(Integer, default=1)
    subject: Mapped[str] = mapped_column(String(240))
    body: Mapped[str] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    translation_source: Mapped[str] = mapped_column(String(40), default="HUMAN_AUTHORED")


class Notification(Base):
    __tablename__ = "notifications"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(String(160), unique=True)
    recipient_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True)
    recipient_contact_id: Mapped[int | None] = mapped_column(ForeignKey("institution_contacts.id"))
    institution_id: Mapped[int | None] = mapped_column(ForeignKey("institutions.id"), index=True)
    channel: Mapped[str] = mapped_column(String(12))  # IN_APP EMAIL SMS WHATSAPP
    address: Mapped[str | None] = mapped_column(String(200))
    template_key: Mapped[str] = mapped_column(String(60), index=True)
    template_version: Mapped[int] = mapped_column(Integer, default=1)
    language: Mapped[str] = mapped_column(String(5), default="en")
    subject: Mapped[str] = mapped_column(String(240))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(12), default="QUEUED", index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    next_attempt_at: Mapped[datetime | None] = mapped_column(TS, index=True)
    entity_type: Mapped[str | None] = mapped_column(String(30))
    entity_id: Mapped[int | None] = mapped_column(Integer)
    provider: Mapped[str | None] = mapped_column(String(40))
    error: Mapped[str | None] = mapped_column(Text)
    fallback_of_id: Mapped[int | None] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)
    sent_at: Mapped[datetime | None] = mapped_column(TS)
    delivered_at: Mapped[datetime | None] = mapped_column(TS)
    read_at: Mapped[datetime | None] = mapped_column(TS)
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)


class DeliveryLog(Base):
    """Local development delivery store (captured email / SMS log / WhatsApp preview)."""
    __tablename__ = "delivery_log"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    notification_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("notifications.id"), index=True)
    channel: Mapped[str] = mapped_column(String(12))
    provider: Mapped[str] = mapped_column(String(40))
    address: Mapped[str | None] = mapped_column(String(200))
    payload: Mapped[dict] = mapped_column(JSONB)
    outcome: Mapped[str] = mapped_column(String(20))
    at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class Escalation(Base):
    __tablename__ = "escalations"
    id: Mapped[int] = mapped_column(primary_key=True)
    obligation_id: Mapped[int] = mapped_column(ForeignKey("obligations.id"), index=True)
    level: Mapped[int] = mapped_column(Integer)
    previous_recipient_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    new_recipient_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), index=True)
    target_post_id: Mapped[int | None] = mapped_column(ForeignKey("posts.id"))
    resolution_path: Mapped[list] = mapped_column(JSONB, default=list)
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="OPEN", index=True)  # OPEN ACKNOWLEDGED CLOSED UNROUTABLE
    notification_id: Mapped[int | None] = mapped_column(BigInteger)
    triggered_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    closed_at: Mapped[datetime | None] = mapped_column(TS)
    closure_note: Mapped[str | None] = mapped_column(Text)


class MagicLink(Base):
    __tablename__ = "magic_links"
    id: Mapped[int] = mapped_column(primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True)
    obligation_id: Mapped[int] = mapped_column(ForeignKey("obligations.id"))
    contact_id: Mapped[int | None] = mapped_column(ForeignKey("institution_contacts.id"))
    expires_at: Mapped[datetime] = mapped_column(TS)
    used_at: Mapped[datetime | None] = mapped_column(TS)
    opened_count: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


# --------------------------------------------------------------------------- scheduler
class ScheduledAction(Base):
    """Durable PostgreSQL-backed queue. Claimed with FOR UPDATE SKIP LOCKED; leased; idempotent."""
    __tablename__ = "scheduled_actions"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(String(160), unique=True)
    action_type: Mapped[str] = mapped_column(String(40), index=True)
    entity_type: Mapped[str | None] = mapped_column(String(30))
    entity_id: Mapped[int | None] = mapped_column(Integer)
    payload: Mapped[dict] = mapped_column(JSONB, default=dict)
    run_at: Mapped[datetime] = mapped_column(TS, index=True)
    status: Mapped[str] = mapped_column(String(12), default="PENDING", index=True)  # PENDING RUNNING DONE FAILED CANCELLED
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    locked_by: Mapped[str | None] = mapped_column(String(60))
    lease_expires_at: Mapped[datetime | None] = mapped_column(TS)
    last_error: Mapped[str | None] = mapped_column(Text)
    done_at: Mapped[datetime | None] = mapped_column(TS)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


Index("ix_sched_pending", ScheduledAction.run_at, postgresql_where=text("status IN ('PENDING','RUNNING')"))


# --------------------------------------------------------------------------- audit
class AuditLog(Base):
    """Append-only, hash-chained. UPDATE/DELETE/TRUNCATE blocked by DB triggers (see migration)."""
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    ts: Mapped[datetime] = mapped_column(TS, index=True)
    actor_id: Mapped[int | None] = mapped_column(Integer, index=True)
    actor_role: Mapped[str | None] = mapped_column(String(40))
    action: Mapped[str] = mapped_column(String(60), index=True)
    entity_type: Mapped[str] = mapped_column(String(40), index=True)
    entity_id: Mapped[str | None] = mapped_column(String(60), index=True)
    before: Mapped[dict | None] = mapped_column(JSONB)
    after: Mapped[dict | None] = mapped_column(JSONB)
    reason: Mapped[str | None] = mapped_column(Text)
    correlation_id: Mapped[str | None] = mapped_column(String(64))
    prev_hash: Mapped[str] = mapped_column(String(64))
    hash: Mapped[str] = mapped_column(String(64), unique=True)


class AuditDemoLog(Base):
    """ISOLATED copy used only by the tamper demonstration. Never contains production records."""
    __tablename__ = "audit_demo_log"
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    ts: Mapped[datetime] = mapped_column(TS)
    actor_id: Mapped[int | None] = mapped_column(Integer)
    actor_role: Mapped[str | None] = mapped_column(String(40))
    action: Mapped[str] = mapped_column(String(60))
    entity_type: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[str | None] = mapped_column(String(60))
    before: Mapped[dict | None] = mapped_column(JSONB)
    after: Mapped[dict | None] = mapped_column(JSONB)
    reason: Mapped[str | None] = mapped_column(Text)
    correlation_id: Mapped[str | None] = mapped_column(String(64))
    prev_hash: Mapped[str] = mapped_column(String(64))
    hash: Mapped[str] = mapped_column(String(64))


class AuditSeal(Base):
    __tablename__ = "audit_seals"
    id: Mapped[int] = mapped_column(primary_key=True)
    day: Mapped[date] = mapped_column(Date, unique=True)
    first_audit_id: Mapped[int] = mapped_column(BigInteger)
    last_audit_id: Mapped[int] = mapped_column(BigInteger)
    entry_count: Mapped[int] = mapped_column(Integer)
    head_hash: Mapped[str] = mapped_column(String(64))
    signature: Mapped[str] = mapped_column(String(128))
    anchored: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class AuditVerification(Base):
    __tablename__ = "audit_verifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    ran_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    trigger: Mapped[str] = mapped_column(String(20))  # HOURLY | ON_DEMAND | DEMO
    target: Mapped[str] = mapped_column(String(20), default="MAIN")
    ok: Mapped[bool] = mapped_column(Boolean)
    checked: Mapped[int] = mapped_column(Integer)
    first_broken_id: Mapped[int | None] = mapped_column(BigInteger)
    detail: Mapped[str | None] = mapped_column(Text)
    seals_checked: Mapped[int] = mapped_column(Integer, default=0)
    duration_ms: Mapped[float] = mapped_column(Float, default=0)
    run_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))


# --------------------------------------------------------------------------- integration / misc
class ImportBatch(Base):
    __tablename__ = "import_batches"
    id: Mapped[int] = mapped_column(primary_key=True)
    adapter: Mapped[str] = mapped_column(String(20))  # CSV | API | SYNTHETIC
    entity: Mapped[str] = mapped_column(String(30))
    filename: Mapped[str | None] = mapped_column(String(240))
    status: Mapped[str] = mapped_column(String(20), default="STAGED")  # STAGED COMMITTED FAILED CANCELLED
    staged_rows: Mapped[list] = mapped_column(JSONB, default=list)
    errors: Mapped[list] = mapped_column(JSONB, default=list)
    duplicates: Mapped[list] = mapped_column(JSONB, default=list)
    counts: Mapped[dict] = mapped_column(JSONB, default=dict)
    dry_run: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    committed_at: Mapped[datetime | None] = mapped_column(TS)


class RiskScore(Base):
    __tablename__ = "risk_scores"
    obligation_id: Mapped[int] = mapped_column(ForeignKey("obligations.id"), primary_key=True)
    probability: Mapped[float | None] = mapped_column(Float)
    level: Mapped[str] = mapped_column(String(20))  # LOW MEDIUM HIGH INSUFFICIENT_DATA
    reasons: Mapped[list] = mapped_column(JSONB, default=list)
    sample_size: Mapped[int] = mapped_column(Integer)
    segment: Mapped[str] = mapped_column(String(120))
    suggested_reminder: Mapped[date | None] = mapped_column(Date)
    computed_at: Mapped[datetime] = mapped_column(TS, default=utcnow)


class BenchmarkRun(Base):
    __tablename__ = "benchmark_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    ran_at: Mapped[datetime] = mapped_column(TS, default=utcnow)
    scorecard: Mapped[dict] = mapped_column(JSONB)
