"""Durable PostgreSQL-backed scheduler.

* Actions live in ``scheduled_actions`` with a unique idempotency key.
* Workers claim due actions with ``FOR UPDATE SKIP LOCKED`` and take a lease.
* A crashed worker's lease expires and the action is re-claimed (recovery); handlers are idempotent
  (notification idempotency keys), so a re-run never duplicates messages.
* Periodic jobs are materialised as keyed actions (e.g. ``sweep:escalation:2026-10-30``), so each
  runs exactly once per period even with several workers.
"""
from __future__ import annotations

import logging
import os
import socket
import threading
import traceback
from datetime import timedelta

from sqlalchemy import select, text, update
from sqlalchemy.dialects.postgresql import insert

from app.core.config import settings
from app.core.db import SessionLocal
from app.core.security import now
from app.models import Evidence, InstitutionalDocument, Obligation, Rule, ScheduledAction

log = logging.getLogger("regulens.scheduler")
WORKER_ID = f"{socket.gethostname()}-{os.getpid()}"


def ensure_periodic(db) -> None:
    from app.services.clocks import today_ist
    from app.services.config import get_params
    t = now()
    d = today_ist()
    hour = t.strftime("%Y%m%d%H")
    refresh = int(get_params(db, "dashboard.refresh").get("refresh_minutes", 10))
    slot = (t.hour * 60 + t.minute) // max(refresh, 1)
    jobs = [
        (f"dispatch:{t.strftime('%Y%m%d%H%M')}", "DISPATCH", t),
        (f"sweep:escalation:{d}", "ESCALATION_SWEEP", t),
        (f"sweep:overdue:{d}", "OVERDUE_NOTICES", t),
        (f"sweep:evc:{d}", "EVC_DELAY_SWEEP", t),
        (f"sweep:rules:{d}", "PUBLISH_RULES", t),
        (f"risk:{d}", "RISK_RECALC", t),
        (f"audit_verify:{hour}", "AUDIT_VERIFY", t),
        (f"audit_seal:{d - timedelta(days=1)}", "AUDIT_SEAL", t),
        (f"digest:{d}", "DIGEST", t.replace(hour=12, minute=30, second=0, microsecond=0)),  # 18:00 IST
        (f"mv_refresh:{d}:{slot}", "MV_REFRESH", t),
        (f"retention:{d}", "RETENTION_PURGE", t),
    ]
    for key, typ, run in jobs:
        db.execute(insert(ScheduledAction).values(idempotency_key=key, action_type=typ, payload={}, run_at=run, status="PENDING",
                                                  attempts=0, created_at=t).on_conflict_do_nothing(index_elements=["idempotency_key"]))


def recover_expired_leases(db) -> int:
    r = db.execute(update(ScheduledAction).where(ScheduledAction.status == "RUNNING", ScheduledAction.lease_expires_at < now())
                   .values(status="PENDING", locked_by=None, last_error="lease expired — worker presumed crashed; re-queued"))
    return r.rowcount or 0


def claim(db, limit: int = 50, worker: str = WORKER_ID) -> list[int]:
    rows = db.execute(select(ScheduledAction).where(ScheduledAction.status == "PENDING", ScheduledAction.run_at <= now())
                      .order_by(ScheduledAction.run_at).limit(limit).with_for_update(skip_locked=True)).scalars().all()
    for a in rows:
        a.status, a.locked_by, a.attempts = "RUNNING", worker, a.attempts + 1
        a.lease_expires_at = now() + timedelta(seconds=settings.lease_seconds)
    return [a.id for a in rows]


def handle(db, a: ScheduledAction) -> str:
    from app.services import audit as audit_svc
    from app.services import documents, escalation, evc, intelligence, ledger, notifications
    from app.services.clocks import today_ist
    from app.services.config import publish_if_due
    t = today_ist()
    if a.action_type == "REMINDER":
        o = db.get(Obligation, a.entity_id)
        if not o or o.state not in ledger.OPEN or not o.due_date or o.due_date.isoformat() != a.payload.get("due"):
            return "stale (obligation closed, paused or re-dated)"
        days = (o.due_date - t).days
        ctx = ledger.ctx_for(db, o)
        tpl = "document_expiring" if o.obligation_type in ("LEASE_RENEWAL", "DOCUMENT_RENEWAL") else "deadline_upcoming"
        if tpl == "document_expiring":
            ctx |= {"doc_type": o.title.split("(")[0].replace("Renew", "").strip()}
        suffix = f"{a.payload.get('offset')}:{o.due_date.isoformat()}"
        from app.models import Institution, User
        if o.responsible_party == "INSTITUTION":
            notifications.notify_institution(db, db.get(Institution, o.institution_id), tpl, ctx, entity=("obligation", o.id), key_suffix=suffix, urgent=days <= 3)
        if o.assigned_user_id:
            notifications.notify_user(db, db.get(User, o.assigned_user_id), tpl, ctx, entity=("obligation", o.id), key_suffix=suffix,
                                      channels=["IN_APP"])
        return f"reminder for {o.obl_no} ({days} day(s) left)"
    if a.action_type == "DISPATCH":
        s = notifications.dispatch_due(db)
        return str(s)
    if a.action_type == "ESCALATION_SWEEP":
        return str(escalation.sweep(db))
    if a.action_type == "OVERDUE_NOTICES":
        return str(overdue_notices(db))
    if a.action_type == "EVC_DELAY_SWEEP":
        return f"{evc.delay_sweep(db)} visit(s) marked delayed"
    if a.action_type == "PUBLISH_RULES":
        n = 0
        for r in db.execute(select(Rule).where(Rule.status == "APPROVED")).scalars():
            n += publish_if_due(db, None, r)
        return f"{n} approved rule(s) became effective"
    if a.action_type == "RISK_RECALC":
        return str(intelligence.recompute_risk(db))
    if a.action_type == "AUDIT_VERIFY":
        v = audit_svc.verify(db, "HOURLY")
        return f"ok={v.ok} checked={v.checked}"
    if a.action_type == "AUDIT_SEAL":
        day = t - timedelta(days=1)
        s = audit_svc.seal_day(db, day)
        return f"sealed {day}: {s.entry_count if s else 0} entries"
    if a.action_type == "DIGEST":
        return f"{notifications.run_digests(db)} digest(s)"
    if a.action_type == "MV_REFRESH":
        intelligence.refresh_mv(db)
        return "mv_app_rollup refreshed"
    if a.action_type == "RETENTION_PURGE":
        return str(retention_purge(db))
    if a.action_type == "OCR_EVIDENCE":
        ev = db.get(Evidence, a.entity_id)
        if ev and ev.ocr_status == "QUEUED":
            documents.ocr_evidence(db, ev)
        return f"evidence {a.entity_id} OCR {ev.ocr_status if ev else 'missing'}"
    return "unknown action type"


def retention_purge(db) -> dict:
    """Apply rule retention.policy: delete expired sessions and old delivery logs/notifications; log the deletion.
    The audit trail itself is never purged by this job (audit_years is enforced by archival, see SECURITY_AND_PRIVACY.md)."""
    from app.services.audit import audit
    from app.services.config import get_params
    p = get_params(db, "retention.policy")
    s_days, n_days = int(p.get("session_days", 30)), int(p.get("notification_days", 730))
    r1 = db.execute(text("DELETE FROM user_sessions WHERE (revoked OR expires_at < now()) AND created_at < now() - make_interval(days => :d)"), {"d": s_days}).rowcount
    r2 = db.execute(text("DELETE FROM delivery_log WHERE at < now() - make_interval(days => :d)"), {"d": n_days}).rowcount
    r3 = db.execute(text("DELETE FROM notifications WHERE created_at < now() - make_interval(days => :d) AND status IN ('DELIVERED','FAILED','BOUNCED','SENT') "
                         "AND NOT EXISTS (SELECT 1 FROM delivery_log d WHERE d.notification_id = notifications.id)"), {"d": n_days}).rowcount
    res = {"sessions_deleted": r1, "delivery_logs_deleted": r2, "notifications_deleted": r3, "policy": p}
    audit(db, None, "RETENTION_PURGE", "system", "retention", None, res)
    return res


def overdue_notices(db) -> dict:
    from app.models import Institution, User
    from app.services import ledger, notifications
    from app.services.clocks import today_ist
    from app.services.config import get_params
    t = today_ist()
    every = int(get_params(db, "reminder.offsets").get("overdue_every_days", 3))
    n = 0
    for o in db.execute(select(Obligation).where(Obligation.state.in_(ledger.OPEN), Obligation.due_date < t)).scalars():
        over = (t - o.due_date).days
        if over != 1 and over % every:
            continue
        ctx = ledger.ctx_for(db, o)
        if o.responsible_party == "INSTITUTION":
            notifications.notify_institution(db, db.get(Institution, o.institution_id), "deadline_overdue", ctx, entity=("obligation", o.id),
                                             key_suffix=f"od{over}", urgent=True)
        if o.assigned_user_id:
            notifications.notify_user(db, db.get(User, o.assigned_user_id), "deadline_overdue", ctx, entity=("obligation", o.id),
                                      key_suffix=f"od{over}", channels=["IN_APP"])
        n += 1
    return {"overdue_notices": n}


def run_action(action_id: int, crash_before_commit: bool = False) -> None:
    db = SessionLocal()
    try:
        a = db.get(ScheduledAction, action_id)
        if not a or a.status != "RUNNING":
            return
        try:
            res = handle(db, a)
            if crash_before_commit:
                raise SystemExit("simulated worker crash")
            a.status, a.done_at, a.last_error = "DONE", now(), None
            a.payload = {**(a.payload or {}), "result": res[:500]}
            db.commit()
        except SystemExit:
            db.rollback()
            raise
        except Exception as e:  # noqa: BLE001
            db.rollback()
            a = db.get(ScheduledAction, action_id)
            a.last_error = traceback.format_exc()[-1500:]
            a.status = "FAILED" if a.attempts >= 5 else "PENDING"
            a.run_at = now() + timedelta(minutes=2 ** a.attempts)
            a.locked_by = None
            db.commit()
            log.exception("action %s failed: %s", action_id, e)
    finally:
        db.close()


def tick(worker: str = WORKER_ID) -> dict:
    db = SessionLocal()
    try:
        ensure_periodic(db)
        rec = recover_expired_leases(db)
        ids = claim(db, worker=worker)
        db.commit()
    finally:
        db.close()
    for i in ids:
        run_action(i)
    return {"recovered": rec, "ran": len(ids)}


class SchedulerThread(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True, name="regulens-scheduler")
        self.stop = threading.Event()

    def run(self):
        log.info("scheduler %s started (tick %ss)", WORKER_ID, settings.scheduler_tick_seconds)
        while not self.stop.is_set():
            try:
                tick()
            except Exception:  # noqa: BLE001
                log.exception("scheduler tick failed")
            self.stop.wait(settings.scheduler_tick_seconds)
