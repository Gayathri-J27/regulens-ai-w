"""Authentication: bcrypt password hashing, opaque server-side sessions, lockout, optional TOTP,
rate limiting and signed download URLs."""
from __future__ import annotations

import hashlib
import hmac
import secrets
import threading
import time
from collections import defaultdict, deque
from contextvars import ContextVar
from datetime import datetime, timedelta, timezone

import bcrypt
from fastapi import Depends, Header, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.db import get_db
from app.core.permissions import has_perm
from app.models import User, UserSession

correlation_id: ContextVar[str | None] = ContextVar("correlation_id", default=None)


def now() -> datetime:
    return datetime.now(timezone.utc)


def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt(rounds=10)).decode()


def verify_password(pw: str, h: str) -> bool:
    try:
        return bcrypt.checkpw(pw.encode(), h.encode())
    except ValueError:
        return False


def sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def new_token() -> str:
    return secrets.token_urlsafe(32)


# ---------------------------------------------------------------- rate limiting (process-local sliding window)
_buckets: dict[str, deque] = defaultdict(deque)
_lock = threading.Lock()


def rate_limit(bucket: str, per_minute: int) -> None:
    t = time.monotonic()
    with _lock:
        q = _buckets[bucket]
        while q and t - q[0] > 60:
            q.popleft()
        if len(q) >= per_minute:
            raise HTTPException(429, "Too many requests — please wait a minute and retry.")
        q.append(t)


# ---------------------------------------------------------------- sessions
def create_session(db: Session, user: User, ip: str | None, mfa_passed: bool) -> str:
    tok = new_token()
    db.add(UserSession(token_hash=sha(tok), user_id=user.id, expires_at=now() + timedelta(minutes=settings.session_ttl_minutes),
                       mfa_passed=mfa_passed, ip=ip))
    return tok


def _load_session(db: Session, token: str) -> tuple[UserSession, User]:
    s = db.execute(select(UserSession).where(UserSession.token_hash == sha(token))).scalar_one_or_none()
    if not s or s.revoked:
        raise HTTPException(401, "Session invalid — please sign in again.")
    t = now()
    if s.expires_at < t:
        raise HTTPException(401, "Session expired — please sign in again.")
    if (t - s.last_seen_at) > timedelta(minutes=settings.session_idle_minutes):
        s.revoked = True
        db.commit()
        raise HTTPException(401, "Session timed out due to inactivity.")
    user = db.get(User, s.user_id)
    if not user or not user.is_active:
        raise HTTPException(401, "Account disabled.")
    if (t - s.last_seen_at) > timedelta(seconds=60):
        s.last_seen_at = t
        db.commit()
    return s, user


def _token_from(request: Request, authorization: str | None) -> str:
    if authorization and authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    raise HTTPException(401, "Not authenticated")


def current_session(request: Request, authorization: str | None = Header(default=None), db: Session = Depends(get_db)):
    return _load_session(db, _token_from(request, authorization))


def current_user(sess=Depends(current_session), db: Session = Depends(get_db)) -> User:
    s, user = sess
    if not s.mfa_passed:
        raise HTTPException(401, "Second factor required")
    from app.core.permissions import INSTITUTION_ROLES
    if user.role in INSTITUTION_ROLES and user.institution_id:
        # PostgreSQL RLS (defence in depth): session-level GUC, reset when the connection is returned (get_db)
        from sqlalchemy import text
        db.execute(text("SELECT set_config('app.scope_institution', :v, false)"), {"v": str(user.institution_id)})
        db.info["rls"] = True
    return user


def require(perm: str):
    """FastAPI dependency: 403 unless the user's role grants ``perm``. Enforced server-side."""
    def dep(user: User = Depends(current_user)) -> User:
        if not has_perm(user.role, perm):
            raise HTTPException(403, f"Your role ({user.role}) is not permitted to perform '{perm}'.")
        return user
    return dep


# ---------------------------------------------------------------- signed URLs
def sign_url(file_id: int, user_id: int, ttl: int | None = None) -> str:
    exp = int(time.time()) + (ttl or settings.signed_url_ttl_seconds)
    msg = f"{file_id}:{user_id}:{exp}"
    sig = hmac.new(settings.secret_key.encode(), msg.encode(), hashlib.sha256).hexdigest()[:40]
    return f"/api/files/{file_id}/download?u={user_id}&exp={exp}&sig={sig}"


def check_signed(file_id: int, user_id: int, exp: int, sig: str) -> bool:
    if exp < time.time():
        return False
    msg = f"{file_id}:{user_id}:{exp}"
    good = hmac.new(settings.secret_key.encode(), msg.encode(), hashlib.sha256).hexdigest()[:40]
    return hmac.compare_digest(good, sig)
