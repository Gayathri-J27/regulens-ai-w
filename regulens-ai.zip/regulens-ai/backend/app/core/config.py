"""Central configuration, loaded from environment variables (see .env.example)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]


def _env(name: str, default: str | None = None) -> str | None:
    return os.environ.get(name, default)


@dataclass(frozen=True)
class Settings:
    database_url: str = field(default_factory=lambda: _env(
        "DATABASE_URL", "postgresql+psycopg://regulens:regulens@localhost:5432/regulens"))
    secret_key: str = field(default_factory=lambda: _env("SECRET_KEY", "dev-only-change-me-0123456789abcdef"))
    audit_signing_key: str = field(default_factory=lambda: _env("AUDIT_SIGNING_KEY", "dev-audit-signing-key-change-me"))
    environment: str = field(default_factory=lambda: _env("ENVIRONMENT", "development"))
    timezone: str = "Asia/Kolkata"

    # sessions / auth
    session_ttl_minutes: int = field(default_factory=lambda: int(_env("SESSION_TTL_MINUTES", "480")))
    session_idle_minutes: int = field(default_factory=lambda: int(_env("SESSION_IDLE_MINUTES", "60")))
    max_failed_logins: int = 5
    lockout_minutes: int = 15

    # storage
    storage_backend: str = field(default_factory=lambda: _env("STORAGE_BACKEND", "local"))  # local | s3
    storage_dir: Path = field(default_factory=lambda: Path(_env("STORAGE_DIR", str(BASE_DIR.parent / "uploads"))))
    s3_endpoint: str | None = field(default_factory=lambda: _env("S3_ENDPOINT"))
    s3_bucket: str = field(default_factory=lambda: _env("S3_BUCKET", "regulens"))
    s3_access_key: str | None = field(default_factory=lambda: _env("S3_ACCESS_KEY"))
    s3_secret_key: str | None = field(default_factory=lambda: _env("S3_SECRET_KEY"))
    max_upload_mb: int = field(default_factory=lambda: int(_env("MAX_UPLOAD_MB", "15")))
    signed_url_ttl_seconds: int = 300

    # audit trust anchor (separate append-only store)
    anchor_dir: Path = field(default_factory=lambda: Path(_env("AUDIT_ANCHOR_DIR", str(BASE_DIR.parent / "infra" / "audit-anchor"))))

    # malware scanning
    clamd_host: str | None = field(default_factory=lambda: _env("CLAMD_HOST"))
    clamd_port: int = field(default_factory=lambda: int(_env("CLAMD_PORT", "3310")))

    # LLM provider for approval-letter extraction (optional)
    llm_provider: str = field(default_factory=lambda: _env("LLM_PROVIDER", "local"))  # local | anthropic
    anthropic_api_key: str | None = field(default_factory=lambda: _env("ANTHROPIC_API_KEY"))
    anthropic_model: str = field(default_factory=lambda: _env("ANTHROPIC_MODEL", "claude-sonnet-5-5"))

    # notifications
    smtp_host: str | None = field(default_factory=lambda: _env("SMTP_HOST"))
    smtp_port: int = field(default_factory=lambda: int(_env("SMTP_PORT", "25")))
    smtp_from: str = field(default_factory=lambda: _env("SMTP_FROM", "noreply@regulens.local"))
    sms_provider: str = field(default_factory=lambda: _env("SMS_PROVIDER", "devlog"))
    whatsapp_provider: str = field(default_factory=lambda: _env("WHATSAPP_PROVIDER", "devpreview"))

    # scheduler
    run_scheduler: bool = field(default_factory=lambda: _env("RUN_SCHEDULER", "1") == "1")
    scheduler_tick_seconds: int = field(default_factory=lambda: int(_env("SCHEDULER_TICK_SECONDS", "15")))
    lease_seconds: int = 120

    # rate limits (requests per minute)
    login_rate_per_min: int = field(default_factory=lambda: int(_env("LOGIN_RATE_PER_MIN", "30")))
    magic_link_rate_per_min: int = 20

    frontend_origin: str = field(default_factory=lambda: _env("FRONTEND_ORIGIN", "http://localhost:5173"))
    public_base_url: str = field(default_factory=lambda: _env("PUBLIC_BASE_URL", "http://localhost:5173"))


settings = Settings()
settings.storage_dir.mkdir(parents=True, exist_ok=True)
settings.anchor_dir.mkdir(parents=True, exist_ok=True)
