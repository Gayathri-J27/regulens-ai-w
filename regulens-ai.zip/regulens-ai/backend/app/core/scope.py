"""Row-level data scope: Region, institution and committee restrictions.

Applied in every list/detail query (defence in depth with PostgreSQL RLS policies set in
the initial migration for institution-scoped tables).
"""
from __future__ import annotations

from fastapi import HTTPException
from sqlalchemy import select, text
from sqlalchemy.orm import Session

from app.core.permissions import INSTITUTION_ROLES, NATIONAL_ROLES
from app.models import Application, EvcAssignment, EvcVisit, Expert, Institution, Obligation, User


def is_national(user: User) -> bool:
    return user.role in NATIONAL_ROLES


def apply_rls(db: Session, user: User) -> None:
    """Set the per-transaction GUC read by the RLS policies (institution isolation)."""
    if user.role in INSTITUTION_ROLES and user.institution_id:
        db.execute(text("SELECT set_config('app.scope_institution', :v, true)"), {"v": str(user.institution_id)})


def scope_institutions(q, user: User, inst_model=Institution):
    if user.role in INSTITUTION_ROLES:
        return q.where(inst_model.id == (user.institution_id or -1))
    if is_national(user) or user.region_id is None:
        return q
    return q.where(inst_model.region_id == user.region_id)


def scope_by_institution_col(q, user: User, col, db: Session | None = None):
    """Filter any query having an institution_id column by the user's data scope."""
    if user.role in INSTITUTION_ROLES:
        return q.where(col == (user.institution_id or -1))
    if user.role == "COMMITTEE_MEMBER":
        sub = (select(EvcVisit.institution_id).join(EvcAssignment, EvcAssignment.visit_id == EvcVisit.id)
               .join(Expert, Expert.id == EvcAssignment.expert_id).where(Expert.user_id == user.id))
        return q.where(col.in_(sub))
    if is_national(user) or user.region_id is None:
        return q
    return q.where(col.in_(select(Institution.id).where(Institution.region_id == user.region_id)))


def assert_institution_access(db: Session, user: User, institution_id: int) -> Institution:
    inst = db.get(Institution, institution_id)
    if not inst:
        raise HTTPException(404, "Institution not found")
    if user.role in INSTITUTION_ROLES:
        if user.institution_id != institution_id:
            raise HTTPException(403, "You can only access your own institution's records.")
    elif user.role == "COMMITTEE_MEMBER":
        ok = db.execute(select(EvcVisit.id).join(EvcAssignment, EvcAssignment.visit_id == EvcVisit.id)
                        .join(Expert, Expert.id == EvcAssignment.expert_id)
                        .where(Expert.user_id == user.id, EvcVisit.institution_id == institution_id)).first()
        if not ok:
            raise HTTPException(403, "Committee members can only access institutions on their assigned EVC visits.")
    elif not is_national(user) and user.region_id and inst.region_id != user.region_id:
        raise HTTPException(403, "This record belongs to another Region.")
    return inst


def get_application_scoped(db: Session, user: User, app_id: int) -> Application:
    a = db.get(Application, app_id)
    if not a:
        raise HTTPException(404, "Application not found")
    assert_institution_access(db, user, a.institution_id)
    return a


def get_obligation_scoped(db: Session, user: User, obl_id: int) -> Obligation:
    o = db.get(Obligation, obl_id)
    if not o:
        raise HTTPException(404, "Obligation not found")
    assert_institution_access(db, user, o.institution_id)
    return o
