"""Role -> permission matrix. Enforced server-side by ``require(...)`` dependencies.

Data scope (row-level) is enforced separately by ``app.core.scope``.
"""
from __future__ import annotations

ROLES = {
    "SUPER_ADMIN": "Super Administrator",
    "AICTE_ADMIN": "AICTE Administrator",
    "REGIONAL_OFFICER": "Regional Officer",
    "BUREAU_OFFICER": "Bureau Officer",
    "COMMITTEE_MEMBER": "Committee Member",
    "COMPETENT_AUTHORITY": "Competent Authority",
    "INSTITUTION_PRINCIPAL": "Institution Principal/Director",
    "INSTITUTION_COMPLIANCE": "Institution Compliance Officer",
    "AUDIT_OFFICER": "Audit Officer",
}
OFFICER_ROLES = {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER", "BUREAU_OFFICER", "COMMITTEE_MEMBER",
                 "COMPETENT_AUTHORITY", "AUDIT_OFFICER"}
INSTITUTION_ROLES = {"INSTITUTION_PRINCIPAL", "INSTITUTION_COMPLIANCE"}
NATIONAL_ROLES = {"SUPER_ADMIN", "AICTE_ADMIN", "COMPETENT_AUTHORITY", "AUDIT_OFFICER"}

P = {
    # dashboards & reading
    "dashboard.view": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER", "BUREAU_OFFICER", "COMPETENT_AUTHORITY", "AUDIT_OFFICER", "COMMITTEE_MEMBER"},
    "application.view": OFFICER_ROLES | INSTITUTION_ROLES,
    "application.create": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER", "BUREAU_OFFICER"},
    "application.assign": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER"},
    "workflow.transition": {"REGIONAL_OFFICER", "BUREAU_OFFICER", "AICTE_ADMIN", "SUPER_ADMIN"},
    "workflow.return": {"REGIONAL_OFFICER", "BUREAU_OFFICER"},
    "workflow.revert": {"REGIONAL_OFFICER", "AICTE_ADMIN"},
    "workflow.decide": {"COMPETENT_AUTHORITY"},  # statutory decision: humans with authority only
    "workflow.resubmit": INSTITUTION_ROLES | {"REGIONAL_OFFICER", "BUREAU_OFFICER"},  # officers only for assisted resubmission
    "exception.record": {"REGIONAL_OFFICER", "AICTE_ADMIN", "COMPETENT_AUTHORITY"},
    "exception.legal_hold": {"AICTE_ADMIN", "COMPETENT_AUTHORITY"},
    # ledger
    "ledger.view": OFFICER_ROLES | INSTITUTION_ROLES,
    "ledger.create": {"REGIONAL_OFFICER", "BUREAU_OFFICER", "AICTE_ADMIN", "COMPETENT_AUTHORITY"},
    "ledger.edit": {"REGIONAL_OFFICER", "BUREAU_OFFICER", "AICTE_ADMIN"},
    "ledger.assign": {"REGIONAL_OFFICER", "AICTE_ADMIN"},
    "ledger.verify": {"REGIONAL_OFFICER", "BUREAU_OFFICER"},
    "ledger.extend": {"REGIONAL_OFFICER", "AICTE_ADMIN", "COMPETENT_AUTHORITY"},
    "ledger.pause": {"REGIONAL_OFFICER", "AICTE_ADMIN"},
    "ledger.close": {"REGIONAL_OFFICER", "AICTE_ADMIN"},
    "ledger.reopen": {"AICTE_ADMIN", "COMPETENT_AUTHORITY"},
    "ledger.priority_override": {"REGIONAL_OFFICER", "BUREAU_OFFICER", "AICTE_ADMIN"},
    "ledger.assisted": {"REGIONAL_OFFICER", "BUREAU_OFFICER"},
    "ledger.export": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER", "AUDIT_OFFICER", "COMPETENT_AUTHORITY"},
    # institution side
    "institution.acknowledge": INSTITUTION_ROLES,
    "evidence.submit": INSTITUTION_ROLES,
    "institution.manage": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER"},
    "magiclink.issue": {"REGIONAL_OFFICER", "BUREAU_OFFICER", "AICTE_ADMIN"},
    # documents
    "document.upload": INSTITUTION_ROLES | {"REGIONAL_OFFICER", "BUREAU_OFFICER"},
    "document.verify": {"REGIONAL_OFFICER", "BUREAU_OFFICER"},
    "extraction.upload": {"REGIONAL_OFFICER", "BUREAU_OFFICER", "COMPETENT_AUTHORITY"},
    "extraction.review": {"REGIONAL_OFFICER", "BUREAU_OFFICER", "COMPETENT_AUTHORITY"},
    # EVC
    "evc.view": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER", "BUREAU_OFFICER", "COMMITTEE_MEMBER", "COMPETENT_AUTHORITY", "AUDIT_OFFICER"},
    "evc.schedule": {"REGIONAL_OFFICER", "AICTE_ADMIN"},
    "evc.coi_override": {"AICTE_ADMIN"},
    "evc.report": {"COMMITTEE_MEMBER", "REGIONAL_OFFICER"},
    "evc.confirm_findings": {"REGIONAL_OFFICER", "COMPETENT_AUTHORITY"},
    "expert.manage": {"AICTE_ADMIN", "SUPER_ADMIN"},
    # notifications / escalation
    "notification.view_all": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER", "AUDIT_OFFICER"},
    "notification.nudge": {"REGIONAL_OFFICER", "BUREAU_OFFICER", "AICTE_ADMIN"},
    "escalation.view": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER", "BUREAU_OFFICER", "COMPETENT_AUTHORITY", "AUDIT_OFFICER"},
    "escalation.act": {"REGIONAL_OFFICER", "BUREAU_OFFICER", "AICTE_ADMIN", "COMPETENT_AUTHORITY"},
    # intelligence
    "analytics.view": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER", "BUREAU_OFFICER", "COMPETENT_AUTHORITY", "AUDIT_OFFICER"},
    "today.view": {"REGIONAL_OFFICER", "BUREAU_OFFICER", "COMMITTEE_MEMBER", "COMPETENT_AUTHORITY", "AICTE_ADMIN"},
    "report.view": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER", "BUREAU_OFFICER", "COMPETENT_AUTHORITY", "AUDIT_OFFICER"},
    "report.export": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER", "COMPETENT_AUTHORITY", "AUDIT_OFFICER"},
    # config / admin
    "rule.view": {"SUPER_ADMIN", "AICTE_ADMIN", "AUDIT_OFFICER", "COMPETENT_AUTHORITY", "REGIONAL_OFFICER"},
    "rule.edit": {"SUPER_ADMIN", "AICTE_ADMIN"},
    "rule.approve": {"SUPER_ADMIN", "AICTE_ADMIN", "COMPETENT_AUTHORITY"},
    "rule.simulate": {"SUPER_ADMIN", "AICTE_ADMIN"},
    "calendar.edit": {"SUPER_ADMIN", "AICTE_ADMIN"},
    "user.manage": {"SUPER_ADMIN"},
    "post.manage": {"SUPER_ADMIN", "AICTE_ADMIN"},
    "delegation.manage": {"SUPER_ADMIN", "AICTE_ADMIN", "REGIONAL_OFFICER"},
    "template.edit": {"SUPER_ADMIN", "AICTE_ADMIN"},
    "import.run": {"SUPER_ADMIN", "AICTE_ADMIN"},
    "synthetic.manage": {"SUPER_ADMIN"},
    "benchmark.run": {"SUPER_ADMIN", "AICTE_ADMIN"},
    # audit
    "audit.view": {"AUDIT_OFFICER", "SUPER_ADMIN"},
    "audit.verify": {"AUDIT_OFFICER", "SUPER_ADMIN"},
    "audit.tamper_demo": {"AUDIT_OFFICER", "SUPER_ADMIN"},
}


def has_perm(role: str, perm: str) -> bool:
    return role in P.get(perm, set())


def perms_for(role: str) -> list[str]:
    return sorted(k for k, v in P.items() if role in v)


# Sidebar modules visible per role (frontend reads this; backend still enforces each API).
MODULES = {
    "overview": "dashboard.view", "applications": "application.view", "workflow": "workflow.transition",
    "ledger": "ledger.view", "today": "today.view", "evc": "evc.view", "undertakings": "ledger.view",
    "compliance": "ledger.view", "documents": "document.upload", "notifications": None, "escalations": "escalation.view",
    "process_mining": "analytics.view", "forecast": "analytics.view", "reports": "report.view", "audit": "audit.view",
    "simulator": "rule.simulate", "admin": "rule.view", "settings": None, "portal": "evidence.submit",
}


def modules_for(role: str) -> list[str]:
    out = []
    for m, p in MODULES.items():
        if p is None or has_perm(role, p):
            if role in INSTITUTION_ROLES and m in {"workflow", "undertakings", "compliance", "ledger", "documents"}:
                continue
            out.append(m)
    if role in INSTITUTION_ROLES:
        out = [m for m in out if m in {"portal", "applications", "notifications", "settings"}]
    return out
