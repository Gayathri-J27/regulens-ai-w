"""EVC, approval-letter extraction, document validity, notifications and escalations."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.permissions import INSTITUTION_ROLES, has_perm
from app.core.scope import assert_institution_access, get_application_scoped, is_national, scope_by_institution_col
from app.core.security import current_user, now, require, sign_url
from app.models import (DeliveryLog, Escalation, EvcVisit, Expert, ExtractionItem, ExtractionJob, Institution, InstitutionalDocument,
                        Notification, Obligation, StoredFile, User)
from app.services import documents, evc, ledger
from app.services.audit import audit
from app.services.files import store_upload
from app.api.deps import body_date, page_params, paginate

router = APIRouter(prefix="/api", tags=["operations"])


# ---------------------------------------------------------------- EVC
@router.get("/evc/visits")
def evc_list(status: str | None = None, region_id: int | None = None, pg=Depends(page_params), user: User = Depends(require("evc.view")),
             db: Session = Depends(get_db)):
    q = scope_by_institution_col(select(EvcVisit).join(Institution, Institution.id == EvcVisit.institution_id), user, EvcVisit.institution_id)
    if status:
        q = q.where(EvcVisit.status == status)
    if region_id:
        q = q.where(Institution.region_id == region_id)
    out = paginate(db, q.order_by(EvcVisit.status, EvcVisit.id.desc()), *pg, lambda v: evc.visit_view(db, v))
    cq = scope_by_institution_col(select(EvcVisit.status, func.count()).join(Institution, Institution.id == EvcVisit.institution_id), user, EvcVisit.institution_id)
    if region_id:
        cq = cq.where(Institution.region_id == region_id)
    out["by_status"] = dict(db.execute(cq.group_by(EvcVisit.status)).all())
    return out


def _visit(db, user, vid) -> EvcVisit:
    v = db.get(EvcVisit, vid)
    if not v:
        raise HTTPException(404)
    assert_institution_access(db, user, v.institution_id)
    return v


@router.get("/evc/visits/{vid:int}")
def evc_get(vid: int, user: User = Depends(require("evc.view")), db: Session = Depends(get_db)):
    v = _visit(db, user, vid)
    d = evc.visit_view(db, v)
    if v.report_file_id:
        d["report_url"] = sign_url(v.report_file_id, user.id)
    return d


class ProposeIn(BaseModel):
    visit_date: str


class ScheduleIn(BaseModel):
    expert_ids: list[int]
    visit_date: str
    override_reason: str | None = None
    reschedule: bool = False


@router.post("/evc/visits/{vid:int}/propose")
def evc_propose(vid: int, body: ProposeIn, user: User = Depends(require("evc.schedule")), db: Session = Depends(get_db)):
    v = _visit(db, user, vid)
    res = evc.propose_panel(db, user, v, body_date(body.visit_date))
    db.commit()
    return res


@router.post("/evc/visits/{vid:int}/schedule")
def evc_schedule(vid: int, body: ScheduleIn, user: User = Depends(require("evc.schedule")), db: Session = Depends(get_db)):
    v = _visit(db, user, vid)
    evc.schedule(db, user, v, body.expert_ids, body_date(body.visit_date), body.override_reason, body.reschedule)
    db.commit()
    return evc.visit_view(db, v)


@router.post("/evc/visits/{vid:int}/visited")
def evc_visited(vid: int, user: User = Depends(require("evc.report")), db: Session = Depends(get_db)):
    v = _visit(db, user, vid)
    evc.record_visit(db, user, v)
    db.commit()
    return evc.visit_view(db, v)


@router.post("/evc/visits/{vid:int}/report")
async def evc_report(vid: int, findings: str = Form("[]"), file: UploadFile | None = File(None), user: User = Depends(require("evc.report")),
                     db: Session = Depends(get_db)):
    import json
    v = _visit(db, user, vid)
    try:
        fl = json.loads(findings)
        assert isinstance(fl, list)
    except (ValueError, AssertionError):
        raise HTTPException(422, "findings must be a JSON list")
    f = await store_upload(db, user, file, "evc_report", v.institution_id) if file and file.filename else None
    evc.submit_report(db, user, v, f, fl)
    db.commit()
    return evc.visit_view(db, v)


class ConfirmIn(BaseModel):
    decisions: list[dict]


@router.post("/evc/visits/{vid:int}/confirm-findings")
def evc_confirm(vid: int, body: ConfirmIn, user: User = Depends(require("evc.confirm_findings")), db: Session = Depends(get_db)):
    v = _visit(db, user, vid)
    res = evc.confirm_findings(db, user, v, body.decisions)
    db.commit()
    return res


class DelayIn(BaseModel):
    reason: str


@router.post("/evc/visits/{vid:int}/delay")
def evc_delay(vid: int, body: DelayIn, user: User = Depends(require("evc.schedule")), db: Session = Depends(get_db)):
    v = _visit(db, user, vid)
    evc.mark_delayed(db, user, v, body.reason)
    db.commit()
    return evc.visit_view(db, v)


@router.get("/experts")
def experts(region_id: int | None = None, pg=Depends(page_params), user: User = Depends(require("evc.view")), db: Session = Depends(get_db)):
    q = select(Expert)
    if region_id:
        q = q.where(Expert.region_id == region_id)
    elif not is_national(user) and user.region_id:
        q = q.where(Expert.region_id == user.region_id)
    return paginate(db, q.order_by(Expert.name), *pg, lambda e: {
        "id": e.id, "name": e.name, "expertise": e.expertise, "region_id": e.region_id, "city": e.city, "monthly_cap": e.monthly_cap,
        "is_active": e.is_active, "coi_count": len(e.coi_institution_ids or []), "unavailable_dates": e.unavailable_dates,
        "is_synthetic": e.is_synthetic})


class ExpertIn(BaseModel):
    name: str
    expertise: list[str]
    region_id: int
    city: str
    lat: float
    lon: float
    monthly_cap: int = 4
    unavailable_dates: list[str] = []
    coi_institution_ids: list[int] = []
    is_active: bool = True


@router.post("/experts")
def add_expert(body: ExpertIn, user: User = Depends(require("expert.manage")), db: Session = Depends(get_db)):
    e = Expert(**body.model_dump())
    db.add(e)
    db.flush()
    audit(db, user, "EXPERT_ADDED", "expert", e.id, None, body.model_dump())
    db.commit()
    return {"id": e.id}


@router.patch("/experts/{eid:int}")
def update_expert(eid: int, body: ExpertIn, user: User = Depends(require("expert.manage")), db: Session = Depends(get_db)):
    e = db.get(Expert, eid)
    if not e:
        raise HTTPException(404)
    before = {"unavailable_dates": e.unavailable_dates, "coi": e.coi_institution_ids, "active": e.is_active, "cap": e.monthly_cap}
    for k, v in body.model_dump().items():
        setattr(e, k, v)
    audit(db, user, "EXPERT_UPDATED", "expert", e.id, before, body.model_dump())
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- approval letter extraction
@router.post("/extraction/jobs")
async def extraction_upload(institution_id: int = Form(...), application_id: int | None = Form(None), letter_date: str | None = Form(None),
                            file: UploadFile = File(...), user: User = Depends(require("extraction.upload")), db: Session = Depends(get_db)):
    assert_institution_access(db, user, institution_id)
    if application_id:
        a = get_application_scoped(db, user, application_id)
        if a.institution_id != institution_id:
            raise HTTPException(422, "Application belongs to a different institution.")
    f = await store_upload(db, user, file, "approval_letter", institution_id)
    if f.mime != "application/pdf":
        raise HTTPException(415, "Approval letters must be PDF.")
    job = documents.run_extraction(db, user, f, institution_id, application_id, body_date(letter_date))
    db.commit()
    return job_view(db, job, user)


def job_view(db: Session, job: ExtractionJob, user: User) -> dict:
    items = db.execute(select(ExtractionItem).where(ExtractionItem.job_id == job.id).order_by(ExtractionItem.source_offset.nulls_last(), ExtractionItem.id)).scalars().all()
    inst = db.get(Institution, job.institution_id)
    return {"id": job.id, "institution_id": job.institution_id, "institution": inst.name, "application_id": job.application_id,
            "letter_date": job.letter_date.isoformat() if job.letter_date else None, "text_method": job.text_method, "extractor": job.extractor,
            "status": job.status, "rejected_count": job.rejected_count, "log": job.log, "full_text": job.full_text,
            "file_url": sign_url(job.file_id, user.id), "created_at": job.created_at.isoformat(),
            "items": [{"id": i.id, "kind": i.kind, "title": i.title, "description": i.description, "source_sentence": i.source_sentence,
                       "source_offset": i.source_offset, "due_text": i.due_text, "due_date": i.due_date.isoformat() if i.due_date else None,
                       "responsible_role": i.responsible_role, "evidence_requirement": i.evidence_requirement, "obligation_type": i.obligation_type,
                       "confidence": i.confidence, "status": i.status, "edited": i.edited, "obligation_id": i.obligation_id,
                       "reject_reason": i.reject_reason} for i in items]}


@router.get("/extraction/jobs")
def extraction_jobs(pg=Depends(page_params), user: User = Depends(require("extraction.review")), db: Session = Depends(get_db)):
    q = scope_by_institution_col(select(ExtractionJob), user, ExtractionJob.institution_id).order_by(ExtractionJob.id.desc())
    return paginate(db, q, *pg, lambda j: {"id": j.id, "institution_id": j.institution_id, "status": j.status, "extractor": j.extractor,
                                           "created_at": j.created_at.isoformat(), "letter_date": j.letter_date.isoformat() if j.letter_date else None,
                                           "items": db.execute(select(func.count()).where(ExtractionItem.job_id == j.id)).scalar_one()})


@router.get("/extraction/jobs/{jid:int}")
def extraction_job(jid: int, user: User = Depends(require("extraction.review")), db: Session = Depends(get_db)):
    j = db.get(ExtractionJob, jid)
    if not j:
        raise HTTPException(404)
    assert_institution_access(db, user, j.institution_id)
    return job_view(db, j, user)


class ItemReviewIn(BaseModel):
    action: str
    edits: dict | None = None
    reason: str | None = None


@router.post("/extraction/items/{iid:int}/review")
def extraction_review(iid: int, body: ItemReviewIn, user: User = Depends(require("extraction.review")), db: Session = Depends(get_db)):
    it = db.get(ExtractionItem, iid)
    if not it:
        raise HTTPException(404)
    j = db.get(ExtractionJob, it.job_id)
    assert_institution_access(db, user, j.institution_id)
    documents.review_item(db, user, it, body.action, body.edits, body.reason)
    db.commit()
    return job_view(db, j, user)


@router.post("/extraction/jobs/{jid:int}/items")
def extraction_manual(jid: int, body: dict, user: User = Depends(require("extraction.review")), db: Session = Depends(get_db)):
    j = db.get(ExtractionJob, jid)
    if not j:
        raise HTTPException(404)
    assert_institution_access(db, user, j.institution_id)
    if not body.get("title"):
        raise HTTPException(422, "title required")
    documents.manual_item(db, user, j, body)
    db.commit()
    return job_view(db, j, user)


# ---------------------------------------------------------------- document validity
@router.get("/documents")
def doc_list(validity: str | None = None, doc_type: str | None = None, verification: str | None = None, institution_id: int | None = None,
             region_id: int | None = None, pg=Depends(page_params), user: User = Depends(current_user), db: Session = Depends(get_db)):
    from datetime import timedelta
    from app.services.clocks import today_ist
    if not (has_perm(user.role, "document.upload") or has_perm(user.role, "report.view")):
        raise HTTPException(403)
    t = today_ist()
    q = scope_by_institution_col(select(InstitutionalDocument).join(Institution, Institution.id == InstitutionalDocument.institution_id), user,
                                 InstitutionalDocument.institution_id)
    if validity == "EXPIRED":
        q = q.where(InstitutionalDocument.expiry_date < t, InstitutionalDocument.is_current.is_(True))
    elif validity == "EXPIRING":
        q = q.where(InstitutionalDocument.expiry_date >= t, InstitutionalDocument.expiry_date <= t + timedelta(days=90), InstitutionalDocument.is_current.is_(True))
    elif validity == "PENDING":
        q = q.where(InstitutionalDocument.verification_status == "PENDING")
    if doc_type:
        q = q.where(InstitutionalDocument.doc_type == doc_type)
    if verification:
        q = q.where(InstitutionalDocument.verification_status == verification)
    if institution_id:
        q = q.where(InstitutionalDocument.institution_id == institution_id)
    if region_id:
        q = q.where(Institution.region_id == region_id)
    return paginate(db, q.order_by(InstitutionalDocument.verification_status.desc(), InstitutionalDocument.expiry_date.asc().nulls_first()), *pg,
                    lambda d: documents.document_view(db, d))


@router.post("/documents")
async def doc_upload(institution_id: int = Form(...), doc_type: str = Form(...), previous_document_id: int | None = Form(None),
                     file: UploadFile = File(...), user: User = Depends(require("document.upload")), db: Session = Depends(get_db)):
    if user.role in INSTITUTION_ROLES:
        institution_id = user.institution_id
    assert_institution_access(db, user, institution_id)
    f = await store_upload(db, user, file, "document", institution_id)
    d = documents.upload_document(db, user, f, institution_id, doc_type, previous_document_id)
    db.commit()
    return documents.document_view(db, d) | {"file_url": sign_url(f.id, user.id)}


@router.get("/documents/{did:int}")
def doc_get(did: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    d = db.get(InstitutionalDocument, did)
    if not d:
        raise HTTPException(404)
    assert_institution_access(db, user, d.institution_id)
    hist = []
    p = d
    while p and p.previous_document_id:
        p = db.get(InstitutionalDocument, p.previous_document_id)
        if p:
            hist.append(documents.document_view(db, p))
    return documents.document_view(db, d) | {"file_url": sign_url(d.file_id, user.id) if d.file_id else None, "renewal_history": hist,
                                            "ocr_text": (d.ocr_text or "")[:8000]}


class DocConfirmIn(BaseModel):
    expiry_date: str
    issue_date: str | None = None
    note: str | None = None
    reject: bool = False


@router.post("/documents/{did:int}/confirm")
def doc_confirm(did: int, body: DocConfirmIn, user: User = Depends(require("document.verify")), db: Session = Depends(get_db)):
    d = db.get(InstitutionalDocument, did)
    if not d:
        raise HTTPException(404)
    assert_institution_access(db, user, d.institution_id)
    if body.reject:
        documents.reject_document(db, user, d, body.note or "")
    else:
        documents.confirm_document(db, user, d, body_date(body.expiry_date), body_date(body.issue_date), body.note)
    db.commit()
    return documents.document_view(db, d)


# ---------------------------------------------------------------- notifications
@router.get("/notifications")
def my_notifications(unread: bool = False, channel: str | None = None, pg=Depends(page_params), user: User = Depends(current_user),
                     db: Session = Depends(get_db)):
    q = select(Notification).where(Notification.recipient_user_id == user.id, Notification.channel == (channel or "IN_APP"))
    if unread:
        q = q.where(Notification.read_at.is_(None))
    out = paginate(db, q.order_by(Notification.id.desc()), *pg, notif_view)
    out["unread"] = db.execute(select(func.count()).where(Notification.recipient_user_id == user.id, Notification.channel == "IN_APP",
                                                          Notification.read_at.is_(None))).scalar_one()
    return out


def notif_view(n: Notification) -> dict:
    return {"id": n.id, "channel": n.channel, "address": n.address, "template_key": n.template_key, "template_version": n.template_version,
            "language": n.language, "subject": n.subject, "body": n.body, "status": n.status, "attempts": n.attempts, "provider": n.provider,
            "error": n.error, "entity_type": n.entity_type, "entity_id": n.entity_id, "created_at": n.created_at.isoformat(),
            "sent_at": n.sent_at.isoformat() if n.sent_at else None, "delivered_at": n.delivered_at.isoformat() if n.delivered_at else None,
            "read_at": n.read_at.isoformat() if n.read_at else None, "fallback_of_id": n.fallback_of_id, "institution_id": n.institution_id}


@router.post("/notifications/{nid:int}/read")
def mark_read(nid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    n = db.get(Notification, nid)
    if not n or n.recipient_user_id != user.id:
        raise HTTPException(404)
    n.read_at = n.read_at or now()
    db.commit()
    return {"ok": True}


@router.post("/notifications/read-all")
def read_all(user: User = Depends(current_user), db: Session = Depends(get_db)):
    from sqlalchemy import update
    db.execute(update(Notification).where(Notification.recipient_user_id == user.id, Notification.read_at.is_(None)).values(read_at=now()))
    db.commit()
    return {"ok": True}


@router.get("/notifications/all")
def all_notifications(status: str | None = None, channel: str | None = None, template_key: str | None = None, institution_id: int | None = None,
                      pg=Depends(page_params), user: User = Depends(require("notification.view_all")), db: Session = Depends(get_db)):
    q = select(Notification)
    if not is_national(user) and user.region_id:
        q = q.outerjoin(Institution, Institution.id == Notification.institution_id).where(
            or_(Institution.region_id == user.region_id, Notification.recipient_user_id == user.id))
    for col, v in ((Notification.status, status), (Notification.channel, channel), (Notification.template_key, template_key),
                   (Notification.institution_id, institution_id)):
        if v:
            q = q.where(col == v)
    out = paginate(db, q.order_by(Notification.id.desc()), *pg, notif_view)
    out["by_status"] = dict(db.execute(select(Notification.status, func.count()).group_by(Notification.status)).all())
    return out


@router.get("/notifications/{nid:int}/deliveries")
def deliveries(nid: int, user: User = Depends(require("notification.view_all")), db: Session = Depends(get_db)):
    return [{"id": d.id, "channel": d.channel, "provider": d.provider, "address": d.address, "outcome": d.outcome, "payload": d.payload,
             "at": d.at.isoformat()} for d in db.execute(select(DeliveryLog).where(DeliveryLog.notification_id == nid).order_by(DeliveryLog.id)).scalars()]


@router.post("/notifications/dispatch")
def dispatch_now(user: User = Depends(require("notification.nudge")), db: Session = Depends(get_db)):
    from app.services.notifications import dispatch_due
    s = dispatch_due(db)
    db.commit()
    return s


class ReceiptIn(BaseModel):
    notification_id: int
    status: str
    detail: str = ""


@router.post("/notifications/webhook/{provider}")
def provider_receipt(provider: str, body: ReceiptIn, user: User = Depends(require("template.edit")), db: Session = Depends(get_db)):
    """Delivery-receipt webhook (provider DLR). Authenticated here; production would verify the provider signature."""
    from app.services.notifications import apply_receipt
    n = apply_receipt(db, body.notification_id, body.status, body.detail)
    db.commit()
    return notif_view(n) if n else {}


# ---------------------------------------------------------------- escalations
@router.get("/escalations")
def esc_list(status: str | None = None, mine: bool = False, level: int | None = None, pg=Depends(page_params),
             user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not (has_perm(user.role, "escalation.view") or user.role == "COMMITTEE_MEMBER"):
        raise HTTPException(403)
    q = scope_by_institution_col(select(Escalation).join(Obligation, Obligation.id == Escalation.obligation_id), user, Obligation.institution_id)
    if mine or not has_perm(user.role, "escalation.view"):
        q = q.where(Escalation.new_recipient_id == user.id)
    if status:
        q = q.where(Escalation.status == status)
    if level:
        q = q.where(Escalation.level == level)
    names = {}

    def view(e: Escalation):
        o = db.get(Obligation, e.obligation_id)
        for uid in (e.previous_recipient_id, e.new_recipient_id):
            if uid and uid not in names:
                u = db.get(User, uid)
                names[uid] = u.full_name if u else str(uid)
        return {"id": e.id, "obligation_id": e.obligation_id, "obl_no": o.obl_no, "title": o.title, "institution": o.institution.name,
                "level": e.level, "previous": names.get(e.previous_recipient_id), "new_recipient": names.get(e.new_recipient_id),
                "new_recipient_id": e.new_recipient_id, "reason": e.reason, "status": e.status, "path": e.resolution_path,
                "triggered_at": e.triggered_at.isoformat(), "closed_at": e.closed_at.isoformat() if e.closed_at else None,
                "closure_note": e.closure_note, "notification_id": e.notification_id, "due_date": o.due_date.isoformat() if o.due_date else None}
    out = paginate(db, q.order_by(Escalation.id.desc()), *pg, view)
    out["by_status"] = dict(db.execute(scope_by_institution_col(select(Escalation.status, func.count()).join(Obligation, Obligation.id == Escalation.obligation_id),
                                                                user, Obligation.institution_id).group_by(Escalation.status)).all())
    return out


class EscActIn(BaseModel):
    action: str  # acknowledge | close
    note: str = ""


@router.post("/escalations/{eid:int}")
def esc_act(eid: int, body: EscActIn, user: User = Depends(require("escalation.act")), db: Session = Depends(get_db)):
    e = db.get(Escalation, eid)
    if not e:
        raise HTTPException(404)
    o = db.get(Obligation, e.obligation_id)
    assert_institution_access(db, user, o.institution_id)
    if body.action == "acknowledge":
        e.status = "ACKNOWLEDGED"
    elif body.action == "close":
        if not body.note:
            raise HTTPException(422, "Closure note required.")
        e.status, e.closed_at, e.closure_note = "CLOSED", now(), body.note
    else:
        raise HTTPException(422, "action must be acknowledge or close")
    audit(db, user, f"ESCALATION_{body.action.upper()}", "escalation", e.id, None, {"status": e.status}, body.note or None)
    db.commit()
    return {"status": e.status}


@router.post("/escalations/run-sweep")
def esc_sweep(user: User = Depends(require("rule.edit")), db: Session = Depends(get_db)):
    from app.services.escalation import sweep
    res = sweep(db)
    audit(db, user, "ESCALATION_SWEEP_RUN", "system", "escalation", None, res)
    db.commit()
    return res
