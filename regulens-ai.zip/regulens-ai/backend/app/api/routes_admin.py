"""Administration: rules/config versioning, routes, calendars, users, posts, delegations, templates, imports,
synthetic data, benchmark and the audit trail."""
from __future__ import annotations

import json
from datetime import date

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, EmailStr
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.permissions import P, ROLES
from app.core.security import current_user, hash_password, require
from app.engines import workflow as wf
from app.models import (AuditLog, AuditSeal, AuditVerification, BenchmarkRun, ConfigVersion, Delegation, Holiday, HolidayCalendar,
                        ImportBatch, NotificationTemplate, Post, Region, RouteTemplate, Rule, User)
from app.services import config as cfg
from app.services import imports
from app.services.audit import audit, seal_day, snapshot, tamper_demo, verify
from app.services.clocks import recompute_for_calendar, today_ist
from app.api.deps import body_date, page_params, paginate

router = APIRouter(prefix="/api/admin", tags=["admin"])


def rule_view(r: Rule) -> dict:
    return {"id": r.id, "rule_key": r.rule_key, "version": r.version, "name": r.name, "description": r.description, "rule_type": r.rule_type,
            "condition": r.condition, "action": r.action, "params": r.params,
            "effective_from": r.effective_from.isoformat() if r.effective_from else None,
            "effective_to": r.effective_to.isoformat() if r.effective_to else None, "source_type": r.source_type, "aph_edition": r.aph_edition,
            "section": r.section, "page": r.page, "citation": r.citation, "status": r.status, "is_active": r.is_active,
            "impact_preview": r.impact_preview, "created_by": r.created_by, "approved_by": r.approved_by,
            "created_at": r.created_at.isoformat(), "approved_at": r.approved_at.isoformat() if r.approved_at else None}


# ---------------------------------------------------------------- rules
@router.get("/rules")
def rules(status: str | None = None, rule_key: str | None = None, user: User = Depends(require("rule.view")), db: Session = Depends(get_db)):
    q = select(Rule)
    if status:
        q = q.where(Rule.status == status)
    if rule_key:
        q = q.where(Rule.rule_key == rule_key)
    return [rule_view(r) for r in db.execute(q.order_by(Rule.rule_key, Rule.version.desc())).scalars()]


class RuleIn(BaseModel):
    rule_key: str
    name: str | None = None
    description: str | None = None
    rule_type: str | None = None
    condition: dict | None = None
    action: dict | None = None
    params: dict
    effective_from: str | None = None
    effective_to: str | None = None
    source_type: str = "CONFIGURABLE_PARAMETER"
    aph_edition: str | None = None
    section: str | None = None
    page: str | None = None
    citation: str | None = None


def _rule_data(body: RuleIn) -> dict:
    d = body.model_dump()
    d["effective_from"] = body_date(body.effective_from) or date.today()
    d["effective_to"] = body_date(body.effective_to)
    if body.source_type not in ("HANDBOOK_CONFIRMED", "CONFIGURABLE_PARAMETER"):
        raise HTTPException(422, "source_type must be HANDBOOK_CONFIRMED or CONFIGURABLE_PARAMETER")
    return d


@router.post("/rules")
def rule_draft(body: RuleIn, user: User = Depends(require("rule.edit")), db: Session = Depends(get_db)):
    r = cfg.create_draft(db, user, _rule_data(body))
    db.commit()
    return rule_view(r)


@router.patch("/rules/{rid:int}")
def rule_edit(rid: int, body: RuleIn, user: User = Depends(require("rule.edit")), db: Session = Depends(get_db)):
    r = db.get(Rule, rid)
    if not r:
        raise HTTPException(404)
    cfg.update_draft(db, user, r, _rule_data(body))
    db.commit()
    return rule_view(r)


@router.post("/rules/{rid:int}/preview")
def rule_preview(rid: int, user: User = Depends(require("rule.edit")), db: Session = Depends(get_db)):
    from app.services.simulator import simulate
    r = db.get(Rule, rid)
    if not r:
        raise HTTPException(404)
    try:
        impact = simulate(db, r.rule_key, r.params)
    except HTTPException:
        impact = {"note": "No replay available for this rule type; impact limited to new cases after the effective date.",
                  "obligations_affected": 0}
    cfg.record_preview(db, user, r, impact)
    db.commit()
    return rule_view(r)


class ApproveIn(BaseModel):
    note: str | None = None


@router.post("/rules/{rid:int}/approve")
def rule_approve(rid: int, body: ApproveIn, user: User = Depends(require("rule.approve")), db: Session = Depends(get_db)):
    r = db.get(Rule, rid)
    if not r:
        raise HTTPException(404)
    cfg.approve(db, user, r, body.note)
    db.commit()
    return rule_view(r)


class ActiveIn(BaseModel):
    active: bool
    reason: str


@router.post("/rules/{rid:int}/active")
def rule_active(rid: int, body: ActiveIn, user: User = Depends(require("rule.approve")), db: Session = Depends(get_db)):
    r = db.get(Rule, rid)
    if not r:
        raise HTTPException(404)
    cfg.set_active(db, user, r, body.active, body.reason)
    db.commit()
    return rule_view(r)


@router.get("/config-versions")
def config_versions(user: User = Depends(require("rule.view")), db: Session = Depends(get_db)):
    return [{"id": c.id, "created_at": c.created_at.isoformat(), "reason": c.reason, "rules": len(c.rule_ids)}
            for c in db.execute(select(ConfigVersion).order_by(ConfigVersion.id.desc()).limit(50)).scalars()]


# ---------------------------------------------------------------- routes
@router.get("/routes")
def routes(user: User = Depends(require("rule.view")), db: Session = Depends(get_db)):
    return [{"id": r.id, "code": r.code, "version": r.version, "name": r.name, "definition": r.definition, "is_active": r.is_active,
             "source_type": r.source_type} for r in db.execute(select(RouteTemplate).order_by(RouteTemplate.code, RouteTemplate.version.desc())).scalars()]


class RouteIn(BaseModel):
    code: str
    name: str
    definition: dict


@router.post("/routes")
def route_new_version(body: RouteIn, user: User = Depends(require("rule.edit")), db: Session = Depends(get_db)):
    errs = wf.validate_definition(body.definition)
    if errs:
        raise HTTPException(422, "; ".join(errs))
    latest = db.execute(select(RouteTemplate).where(RouteTemplate.code == body.code).order_by(RouteTemplate.version.desc()).limit(1)).scalar_one_or_none()
    if latest:
        latest.is_active = False
    r = RouteTemplate(code=body.code, version=(latest.version + 1) if latest else 1, name=body.name, definition=body.definition)
    db.add(r)
    db.flush()
    audit(db, user, "ROUTE_VERSION_PUBLISHED", "route_template", r.id, {"previous_version": latest.version if latest else None}, body.model_dump(),
          "existing applications keep their pinned route version")
    db.commit()
    return {"id": r.id, "version": r.version}


# ---------------------------------------------------------------- calendars
@router.get("/calendars")
def calendars(user: User = Depends(current_user), db: Session = Depends(get_db)):
    cals = db.execute(select(HolidayCalendar).order_by(HolidayCalendar.scope, HolidayCalendar.code)).scalars().all()
    hol = db.execute(select(Holiday).order_by(Holiday.day)).scalars().all()
    by = {}
    for h in hol:
        by.setdefault(h.calendar_id, []).append({"id": h.id, "day": h.day.isoformat(), "name": h.name})
    return [{"id": c.id, "code": c.code, "name": c.name, "scope": c.scope, "state": c.state, "weekend_days": c.weekend_days, "version": c.version,
             "holidays": by.get(c.id, [])} for c in cals]


class HolidayIn(BaseModel):
    day: str
    name: str
    reason: str = "calendar update"


@router.post("/calendars/{cid:int}/holidays")
def add_holiday(cid: int, body: HolidayIn, user: User = Depends(require("calendar.edit")), db: Session = Depends(get_db)):
    c = db.get(HolidayCalendar, cid)
    if not c:
        raise HTTPException(404)
    d = body_date(body.day)
    if db.execute(select(Holiday.id).where(Holiday.calendar_id == cid, Holiday.day == d)).first():
        raise HTTPException(409, "Holiday already exists on this date.")
    db.add(Holiday(calendar_id=cid, day=d, name=body.name))
    c.version += 1
    db.flush()
    audit(db, user, "HOLIDAY_ADDED", "holiday_calendar", cid, None, {"day": d.isoformat(), "name": body.name, "calendar_version": c.version}, body.reason)
    res = recompute_for_calendar(db, cid, user, f"holiday {d} added")
    db.commit()
    return res


@router.delete("/calendars/{cid:int}/holidays/{hid:int}")
def del_holiday(cid: int, hid: int, user: User = Depends(require("calendar.edit")), db: Session = Depends(get_db)):
    h = db.get(Holiday, hid)
    if not h or h.calendar_id != cid:
        raise HTTPException(404)
    c = db.get(HolidayCalendar, cid)
    info = {"day": h.day.isoformat(), "name": h.name}
    db.delete(h)
    c.version += 1
    db.flush()
    audit(db, user, "HOLIDAY_REMOVED", "holiday_calendar", cid, info, {"calendar_version": c.version})
    res = recompute_for_calendar(db, cid, user, f"holiday {info['day']} removed")
    db.commit()
    return res


# ---------------------------------------------------------------- users / posts / delegations
@router.get("/users")
def users(q: str | None = None, role: str | None = None, synthetic: str | None = None, pg=Depends(page_params),
          user: User = Depends(require("user.manage")), db: Session = Depends(get_db)):
    s = select(User)
    if q:
        s = s.where(or_(User.full_name.ilike(f"%{q}%"), User.email.ilike(f"%{q}%")))
    if role:
        s = s.where(User.role == role)
    if synthetic == "0":
        s = s.where(User.is_synthetic.is_(False))
    return paginate(db, s.order_by(User.is_synthetic, User.id), *pg, lambda u: {
        "id": u.id, "email": u.email, "full_name": u.full_name, "role": u.role, "region_id": u.region_id, "institution_id": u.institution_id,
        "post_id": u.post_id, "is_active": u.is_active, "totp_enabled": u.totp_enabled, "locked": bool(u.locked_until),
        "is_synthetic": u.is_synthetic})


class UserIn(BaseModel):
    email: EmailStr
    full_name: str
    role: str
    region_id: int | None = None
    institution_id: int | None = None
    password: str
    phone: str | None = None


@router.post("/users")
def create_user(body: UserIn, user: User = Depends(require("user.manage")), db: Session = Depends(get_db)):
    if body.role not in ROLES:
        raise HTTPException(422, "unknown role")
    if db.execute(select(User.id).where(User.email == body.email.lower())).first():
        raise HTTPException(409, "Email already registered")
    if body.role.startswith("INSTITUTION") and not body.institution_id:
        raise HTTPException(422, "Institution users need an institution.")
    u = User(email=body.email.lower(), full_name=body.full_name, role=body.role, region_id=body.region_id, institution_id=body.institution_id,
             password_hash=hash_password(body.password), phone=body.phone)
    db.add(u)
    db.flush()
    audit(db, user, "USER_CREATED", "user", u.id, None, snapshot(u))
    db.commit()
    return {"id": u.id}


class UserPatch(BaseModel):
    role: str | None = None
    region_id: int | None = None
    is_active: bool | None = None
    unlock: bool = False
    post_id: int | None = None


@router.patch("/users/{uid:int}")
def patch_user(uid: int, body: UserPatch, user: User = Depends(require("user.manage")), db: Session = Depends(get_db)):
    u = db.get(User, uid)
    if not u:
        raise HTTPException(404)
    before = snapshot(u)
    if body.role:
        if body.role not in ROLES:
            raise HTTPException(422)
        u.role = body.role
    if body.region_id is not None:
        u.region_id = body.region_id
    if body.is_active is not None:
        u.is_active = body.is_active
    if body.unlock:
        u.locked_until, u.failed_logins = None, 0
    if body.post_id is not None:  # officer transfer: post holder changes; escalations resolve to the new holder at execution time
        if u.post_id:
            old = db.get(Post, u.post_id)
            if old and old.holder_user_id == u.id:
                old.holder_user_id = None
        p = db.get(Post, body.post_id)
        if not p:
            raise HTTPException(404, "post")
        if p.holder_user_id and p.holder_user_id != u.id:
            prev = db.get(User, p.holder_user_id)
            prev.post_id = None
        p.holder_user_id, u.post_id = u.id, p.id
    audit(db, user, "USER_UPDATED", "user", u.id, before, snapshot(u))
    db.commit()
    return {"ok": True}


@router.get("/roles")
def roles(user: User = Depends(require("rule.view"))):
    return {"roles": ROLES, "matrix": {perm: sorted(rs) for perm, rs in P.items()}}


@router.get("/posts")
def posts(region_id: int | None = None, user: User = Depends(require("rule.view")), db: Session = Depends(get_db)):
    q = select(Post)
    if region_id:
        q = q.where(Post.region_id == region_id)
    names = {u.id: u.full_name for u in db.execute(select(User).where(User.post_id.is_not(None))).scalars()}
    t = today_ist()
    dels = db.execute(select(Delegation).where(Delegation.revoked.is_(False), Delegation.ends_on >= t)).scalars().all()
    dmap = {}
    for d in dels:
        dmap.setdefault(d.post_id, []).append({"id": d.id, "delegate_user_id": d.delegate_user_id, "starts_on": d.starts_on.isoformat(),
                                               "ends_on": d.ends_on.isoformat(), "reason": d.reason, "active_now": d.starts_on <= t <= d.ends_on})
    return [{"id": p.id, "code": p.code, "title": p.title, "level": p.level, "region_id": p.region_id, "parent_post_id": p.parent_post_id,
             "holder_user_id": p.holder_user_id, "holder": names.get(p.holder_user_id), "vacant": p.holder_user_id is None,
             "delegations": dmap.get(p.id, [])} for p in db.execute(q.order_by(Post.level.desc(), Post.code)).scalars()]


class PostVacateIn(BaseModel):
    reason: str


@router.post("/posts/{pid:int}/vacate")
def vacate(pid: int, body: PostVacateIn, user: User = Depends(require("post.manage")), db: Session = Depends(get_db)):
    p = db.get(Post, pid)
    if not p:
        raise HTTPException(404)
    before = {"holder_user_id": p.holder_user_id}
    if p.holder_user_id:
        u = db.get(User, p.holder_user_id)
        u.post_id = None
    p.holder_user_id = None
    audit(db, user, "POST_VACATED", "post", p.id, before, {"holder_user_id": None}, body.reason)
    db.commit()
    return {"ok": True}


class DelegationIn(BaseModel):
    post_id: int
    delegate_user_id: int
    starts_on: str
    ends_on: str
    reason: str


@router.post("/delegations")
def add_delegation(body: DelegationIn, user: User = Depends(require("delegation.manage")), db: Session = Depends(get_db)):
    s, e = body_date(body.starts_on), body_date(body.ends_on)
    if e < s:
        raise HTTPException(422, "ends_on before starts_on")
    p = db.get(Post, body.post_id)
    if not p:
        raise HTTPException(404, "post")
    if user.role == "REGIONAL_OFFICER" and p.region_id != user.region_id:
        raise HTTPException(403, "Regional officers manage delegations in their own Region.")
    d = Delegation(post_id=body.post_id, delegate_user_id=body.delegate_user_id, starts_on=s, ends_on=e, reason=body.reason, created_by=user.id)
    db.add(d)
    db.flush()
    audit(db, user, "DELEGATION_CREATED", "delegation", d.id, None, body.model_dump())
    db.commit()
    return {"id": d.id}


@router.post("/delegations/{did:int}/revoke")
def revoke_delegation(did: int, user: User = Depends(require("delegation.manage")), db: Session = Depends(get_db)):
    d = db.get(Delegation, did)
    if not d:
        raise HTTPException(404)
    d.revoked = True
    audit(db, user, "DELEGATION_REVOKED", "delegation", d.id)
    db.commit()
    return {"ok": True}


@router.get("/resolve-escalation/{post_id:int}")
def resolve_preview(post_id: int, user: User = Depends(require("rule.view")), db: Session = Depends(get_db)):
    from app.services.escalation import OrgSnapshot
    r = OrgSnapshot(db).resolve(post_id, today_ist())
    u = db.get(User, r.recipient_id) if r.recipient_id else None
    return {"recipient_id": r.recipient_id, "recipient": u.full_name if u else None, "via": r.via, "path": r.path}


# ---------------------------------------------------------------- notification templates
@router.get("/templates")
def templates(user: User = Depends(require("rule.view")), db: Session = Depends(get_db)):
    return [{"id": t.id, "key": t.key, "language": t.language, "version": t.version, "subject": t.subject, "body": t.body, "is_active": t.is_active,
             "translation_source": t.translation_source} for t in db.execute(select(NotificationTemplate).order_by(NotificationTemplate.key,
                                                                                                                    NotificationTemplate.language,
                                                                                                                    NotificationTemplate.version.desc())).scalars()]


class TemplateIn(BaseModel):
    key: str
    language: str
    subject: str
    body: str
    translation_source: str = "HUMAN_AUTHORED"


@router.post("/templates")
def template_version(body: TemplateIn, user: User = Depends(require("template.edit")), db: Session = Depends(get_db)):
    if body.language not in ("en", "hi", "mr", "ta"):
        raise HTTPException(422, "language must be en, hi, mr or ta")
    cur = db.execute(select(NotificationTemplate).where(NotificationTemplate.key == body.key, NotificationTemplate.language == body.language)
                     .order_by(NotificationTemplate.version.desc()).limit(1)).scalar_one_or_none()
    if cur:
        cur.is_active = False
    t = NotificationTemplate(key=body.key, language=body.language, version=(cur.version + 1) if cur else 1, subject=body.subject, body=body.body,
                             translation_source=body.translation_source)
    db.add(t)
    db.flush()
    audit(db, user, "TEMPLATE_VERSIONED", "notification_template", t.id, {"version": cur.version if cur else None}, body.model_dump())
    db.commit()
    return {"id": t.id, "version": t.version}


# ---------------------------------------------------------------- imports
@router.post("/imports/csv")
async def import_csv(entity: str = Form(...), file: UploadFile = File(...), user: User = Depends(require("import.run")), db: Session = Depends(get_db)):
    data = await file.read()
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(413, "CSV too large")
    rows = imports.parse_csv(data)
    b = imports.stage(db, user, "CSV", entity, rows, file.filename)
    db.commit()
    return batch_view(b)


@router.post("/integration/v1/{entity}")
def import_api(entity: str, body: dict, user: User = Depends(require("import.run")), db: Session = Depends(get_db)):
    recs = body.get("records")
    if not isinstance(recs, list):
        raise HTTPException(422, "records must be a list")
    b = imports.stage(db, user, "API", entity, [{k: str(v) if v is not None else "" for k, v in r.items()} for r in recs], body.get("source_system"))
    db.commit()
    return batch_view(b)


@router.get("/integration/openapi.json")
def import_contract(user: User = Depends(current_user)):
    return imports.OPENAPI_CONTRACT


@router.get("/imports/template/{entity}")
def import_template(entity: str, user: User = Depends(require("import.run"))):
    from fastapi.responses import Response
    spec = imports.CANONICAL.get(entity)
    if not spec:
        raise HTTPException(404)
    return Response(",".join(spec["required"] + spec["optional"]) + "\n", media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{entity}-template.csv"'})


def batch_view(b: ImportBatch) -> dict:
    return {"id": b.id, "adapter": b.adapter, "entity": b.entity, "filename": b.filename, "status": b.status, "counts": b.counts,
            "errors": b.errors[:200], "duplicates": b.duplicates[:200], "preview": b.staged_rows[:20],
            "created_at": b.created_at.isoformat(), "committed_at": b.committed_at.isoformat() if b.committed_at else None}


@router.get("/imports")
def import_history(user: User = Depends(require("import.run")), db: Session = Depends(get_db)):
    return [batch_view(b) for b in db.execute(select(ImportBatch).order_by(ImportBatch.id.desc()).limit(50)).scalars()]


class CommitIn(BaseModel):
    dry_run: bool = True


@router.post("/imports/{bid:int}/commit")
def import_commit(bid: int, body: CommitIn, user: User = Depends(require("import.run")), db: Session = Depends(get_db)):
    b = db.get(ImportBatch, bid)
    if not b:
        raise HTTPException(404)
    res = imports.commit(db, user, b, body.dry_run)
    db.commit()
    return res | {"batch": batch_view(b)}


# ---------------------------------------------------------------- synthetic data & benchmark
class SynthIn(BaseModel):
    confirm: str = ""
    scale: float = 1.0
    seed: int = 20261030


@router.get("/synthetic/status")
def synth_status(user: User = Depends(require("synthetic.manage")), db: Session = Depends(get_db)):
    from app.services.synthetic import status
    return status(db)


@router.post("/synthetic/regenerate")
def synth_regen(body: SynthIn, user: User = Depends(require("synthetic.manage")), db: Session = Depends(get_db)):
    if body.confirm != "REGENERATE SYNTHETIC DATA":
        raise HTTPException(422, "Type 'REGENERATE SYNTHETIC DATA' to confirm. Only records flagged synthetic are removed; real records are untouched.")
    from app.services.synthetic import generate, reset
    r = reset(db, user)
    g = generate(db, user, seed=body.seed, scale=body.scale)
    db.commit()
    return {"reset": r, "generated": g}


@router.post("/benchmark/run")
def bench_run(user: User = Depends(require("benchmark.run")), db: Session = Depends(get_db)):
    from app.services.benchmark import run_benchmark
    sc = run_benchmark(db, user)
    db.commit()
    return sc


@router.get("/benchmark/runs")
def bench_runs(user: User = Depends(require("benchmark.run")), db: Session = Depends(get_db)):
    return [{"id": b.id, "ran_at": b.ran_at.isoformat(), "scorecard": b.scorecard}
            for b in db.execute(select(BenchmarkRun).order_by(BenchmarkRun.id.desc()).limit(10)).scalars()]


# ---------------------------------------------------------------- audit
@router.get("/audit")
def audit_list(entity_type: str | None = None, entity_id: str | None = None, action: str | None = None, actor_id: int | None = None,
               pg=Depends(page_params), user: User = Depends(require("audit.view")), db: Session = Depends(get_db)):
    q = select(AuditLog)
    for col, v in ((AuditLog.entity_type, entity_type), (AuditLog.entity_id, entity_id), (AuditLog.actor_id, actor_id)):
        if v:
            q = q.where(col == v)
    if action:
        q = q.where(AuditLog.action.ilike(f"%{action}%"))
    names = {}

    def view(a: AuditLog):
        if a.actor_id and a.actor_id not in names:
            u = db.get(User, a.actor_id)
            names[a.actor_id] = u.full_name if u else str(a.actor_id)
        return {"id": a.id, "ts": a.ts.isoformat(), "actor_id": a.actor_id, "actor": names.get(a.actor_id, "system"), "actor_role": a.actor_role,
                "action": a.action, "entity_type": a.entity_type, "entity_id": a.entity_id, "before": a.before, "after": a.after,
                "reason": a.reason, "correlation_id": a.correlation_id, "prev_hash": a.prev_hash, "hash": a.hash}
    out = paginate(db, q.order_by(AuditLog.id.desc()), *pg, view)
    last = db.execute(select(AuditVerification).where(AuditVerification.target == "MAIN").order_by(AuditVerification.id.desc()).limit(1)).scalar_one_or_none()
    out["last_verification"] = {"ok": last.ok, "ran_at": last.ran_at.isoformat(), "checked": last.checked, "first_broken_id": last.first_broken_id,
                                "trigger": last.trigger} if last else None
    out["seals"] = [{"day": s.day.isoformat(), "last_audit_id": s.last_audit_id, "entries": s.entry_count, "head_hash": s.head_hash,
                     "signature": s.signature[:24] + "…", "anchored": s.anchored}
                    for s in db.execute(select(AuditSeal).order_by(AuditSeal.day.desc()).limit(14)).scalars()]
    return out


@router.post("/audit/verify")
def audit_verify(user: User = Depends(require("audit.verify")), db: Session = Depends(get_db)):
    v = verify(db, "ON_DEMAND", user)
    audit(db, user, "AUDIT_CHAIN_VERIFIED", "audit_log", None, None, {"ok": v.ok, "checked": v.checked, "first_broken_id": v.first_broken_id})
    db.commit()
    return {"ok": v.ok, "checked": v.checked, "first_broken_id": v.first_broken_id, "detail": v.detail, "seals_checked": v.seals_checked,
            "duration_ms": v.duration_ms}


@router.post("/audit/seal")
def audit_seal(user: User = Depends(require("audit.verify")), db: Session = Depends(get_db)):
    from datetime import timedelta
    s = seal_day(db, today_ist() - timedelta(days=1))
    db.commit()
    return {"sealed": bool(s), "day": s.day.isoformat() if s else None, "entries": s.entry_count if s else 0}


@router.post("/audit/tamper-demo")
def audit_tamper(user: User = Depends(require("audit.tamper_demo")), db: Session = Depends(get_db)):
    res = tamper_demo(db, user)
    db.commit()
    return res


@router.post("/audit/try-modify/{aid:int}")
def audit_try_modify(aid: int, user: User = Depends(require("audit.tamper_demo")), db: Session = Depends(get_db)):
    """Shows the production table refuses modification (database trigger). Nothing is changed."""
    from sqlalchemy import text
    try:
        db.execute(text("UPDATE audit_log SET reason = 'tamper attempt' WHERE id = :i"), {"i": aid})
        db.rollback()
        return {"blocked": False}
    except Exception as e:  # noqa: BLE001
        db.rollback()
        msg = str(getattr(e, "orig", e)).split("\n")[0]
        audit(db, user, "AUDIT_MODIFY_ATTEMPT_BLOCKED", "audit_log", aid, None, {"db_error": msg})
        db.commit()
        return {"blocked": True, "database_said": msg}
