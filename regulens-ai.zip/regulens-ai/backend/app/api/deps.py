from __future__ import annotations

from datetime import date
from typing import Any

from fastapi import Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.security import current_user, require
from app.models import User


def page_params(page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=200)) -> tuple[int, int]:
    return page, page_size


def paginate(db: Session, q, page: int, size: int, mapper) -> dict:
    total = db.execute(select(func.count()).select_from(q.order_by(None).subquery())).scalar_one()
    rows = db.execute(q.limit(size).offset((page - 1) * size)).scalars().all()
    return {"total": total, "page": page, "page_size": size, "pages": (total + size - 1) // size, "items": [mapper(r) for r in rows]}


def clean(d: dict) -> dict:
    return {k: v for k, v in d.items() if v not in (None, "")}


def body_date(v: Any) -> date | None:
    if v in (None, ""):
        return None
    try:
        return date.fromisoformat(str(v)[:10])
    except ValueError:
        raise HTTPException(422, f"Invalid date: {v}")
