from __future__ import annotations

import secrets
from datetime import timedelta

import pyotp
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, EmailStr
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.db import get_db
from app.core.permissions import OFFICER_ROLES, ROLES, modules_for, perms_for
from app.core.security import (create_session, current_session, current_user, hash_password, now, rate_limit, sha,
                               verify_password)
from app.models import Institution, Region, User
from app.services.audit import audit
from app.services.notifications import notify_user

router = APIRouter(prefix="/api/auth", tags=["auth"])


class LoginIn(BaseModel):
    email: EmailStr
    password: str


def me_payload(db: Session, u: User) -> dict:
    inst = db.get(Institution, u.institution_id) if u.institution_id else None
    reg = db.get(Region, u.region_id) if u.region_id else None
    return {"id": u.id, "email": u.email, "full_name": u.full_name, "role": u.role, "role_label": ROLES[u.role],
            "region_id": u.region_id, "region": reg.name if reg else None, "institution_id": u.institution_id,
            "institution": inst.name if inst else None, "preferred_language": u.preferred_language, "totp_enabled": u.totp_enabled,
            "permissions": perms_for(u.role), "modules": modules_for(u.role), "post_id": u.post_id}


@router.post("/login")
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)):
    ip = request.client.host if request.client else "?"
    rate_limit(f"login:{ip}", settings.login_rate_per_min)
    u = db.execute(select(User).where(User.email == body.email.lower())).scalar_one_or_none()
    if u and u.locked_until and u.locked_until > now():
        raise HTTPException(423, f"Account locked after repeated failures. Try again after {u.locked_until:%H:%M} UTC.")
    if not u or not u.is_active or not verify_password(body.password, u.password_hash):
        if u:
            u.failed_logins += 1
            if u.failed_logins >= settings.max_failed_logins:
                u.locked_until = now() + timedelta(minutes=settings.lockout_minutes)
                audit(db, None, "ACCOUNT_LOCKED", "user", u.id, None, {"failed_logins": u.failed_logins})
            db.commit()
        raise HTTPException(401, "Invalid email or password.")
    u.failed_logins, u.locked_until = 0, None
    need_mfa = u.totp_enabled and u.role in OFFICER_ROLES
    tok = create_session(db, u, ip, mfa_passed=not need_mfa)
    audit(db, u, "LOGIN", "user", u.id, None, {"ip": ip, "mfa_pending": need_mfa})
    db.commit()
    return {"token": tok, "mfa_required": need_mfa, "user": None if need_mfa else me_payload(db, u)}


class TotpIn(BaseModel):
    code: str


@router.post("/totp/verify")
def totp_verify(body: TotpIn, sess=Depends(current_session), db: Session = Depends(get_db)):
    s, u = sess
    if not u.totp_secret or not pyotp.TOTP(u.totp_secret).verify(body.code, valid_window=1):
        raise HTTPException(401, "Invalid authentication code.")
    s.mfa_passed = True
    audit(db, u, "MFA_PASSED", "user", u.id)
    db.commit()
    return {"user": me_payload(db, u)}


@router.post("/totp/setup")
def totp_setup(user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.role not in OFFICER_ROLES:
        raise HTTPException(403, "TOTP is offered to officer accounts.")
    user.totp_secret = pyotp.random_base32()
    db.commit()
    return {"secret": user.totp_secret, "otpauth_uri": pyotp.TOTP(user.totp_secret).provisioning_uri(user.email, issuer_name="ReguLens AI")}


@router.post("/totp/enable")
def totp_enable(body: TotpIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not user.totp_secret or not pyotp.TOTP(user.totp_secret).verify(body.code, valid_window=1):
        raise HTTPException(422, "Code does not match; scan the secret again.")
    user.totp_enabled = True
    audit(db, user, "TOTP_ENABLED", "user", user.id)
    db.commit()
    return {"totp_enabled": True}


@router.post("/totp/disable")
def totp_disable(body: TotpIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.totp_enabled and not pyotp.TOTP(user.totp_secret).verify(body.code, valid_window=1):
        raise HTTPException(422, "Code does not match.")
    user.totp_enabled, user.totp_secret = False, None
    audit(db, user, "TOTP_DISABLED", "user", user.id)
    db.commit()
    return {"totp_enabled": False}


@router.post("/logout")
def logout(sess=Depends(current_session), db: Session = Depends(get_db)):
    s, u = sess
    s.revoked = True
    audit(db, u, "LOGOUT", "user", u.id)
    db.commit()
    return {"ok": True}


@router.get("/me")
def me(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return me_payload(db, user)


class ResetReq(BaseModel):
    email: EmailStr


@router.post("/password-reset/request")
def reset_request(body: ResetReq, request: Request, db: Session = Depends(get_db)):
    rate_limit(f"reset:{request.client.host if request.client else '?'}", 5)
    u = db.execute(select(User).where(User.email == body.email.lower())).scalar_one_or_none()
    if u and u.is_active:
        code = f"{secrets.randbelow(10**6):06d}"
        u.reset_token_hash, u.reset_token_expires = sha(f"{u.id}:{code}"), now() + timedelta(minutes=15)
        notify_user(db, u, "password_reset", {"code": code}, entity=("user", u.id), key_suffix=sha(code)[:8], channels=["EMAIL"])
        audit(db, None, "PASSWORD_RESET_REQUESTED", "user", u.id)
        db.commit()
    # identical response either way (no account enumeration). Demo: the code is in the dev mailbox (Notifications → delivery log).
    return {"ok": True, "message": "If the account exists, a reset code has been sent to its registered email."}


class ResetConfirm(BaseModel):
    email: EmailStr
    code: str
    new_password: str


@router.post("/password-reset/confirm")
def reset_confirm(body: ResetConfirm, db: Session = Depends(get_db)):
    u = db.execute(select(User).where(User.email == body.email.lower())).scalar_one_or_none()
    if not u or not u.reset_token_hash or u.reset_token_expires < now() or u.reset_token_hash != sha(f"{u.id}:{body.code}"):
        raise HTTPException(400, "Invalid or expired code.")
    if len(body.new_password) < 10 or body.new_password.isalpha() or body.new_password.isdigit():
        raise HTTPException(422, "Password must be at least 10 characters and mix letters with numbers/symbols.")
    u.password_hash, u.reset_token_hash, u.failed_logins, u.locked_until = hash_password(body.new_password), None, 0, None
    audit(db, None, "PASSWORD_RESET_COMPLETED", "user", u.id)
    db.commit()
    return {"ok": True}


@router.get("/demo-accounts")
def demo_accounts(db: Session = Depends(get_db)):
    """Role-appropriate demo access for the login page (only in non-production environments)."""
    if settings.environment == "production":
        raise HTTPException(404)
    rows = db.execute(select(User).where(User.is_synthetic.is_(False)).order_by(User.id)).scalars().all()
    return [{"email": u.email, "name": u.full_name, "role": u.role, "role_label": ROLES[u.role]} for u in rows]
