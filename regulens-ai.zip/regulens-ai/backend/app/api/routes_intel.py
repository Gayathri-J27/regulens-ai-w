"""Dashboards, Today's 10, breach forecast, capacity, process mining, simulator, reports, impact calculator."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.security import current_user, require
from app.models import User
from app.services import intelligence, reports, simulator
from app.services.audit import audit

router = APIRouter(prefix="/api", tags=["intelligence"])


def _f(request: Request) -> dict:
    return {k: v for k, v in request.query_params.items() if v not in ("", None)}


@router.get("/dashboard")
def dashboard(request: Request, user: User = Depends(require("dashboard.view")), db: Session = Depends(get_db)):
    return intelligence.dashboard(db, user, _f(request))


@router.get("/today")
def today(user: User = Depends(require("today.view")), db: Session = Depends(get_db)):
    return intelligence.today10(db, user)


@router.get("/forecast")
def forecast(request: Request, page: int = 1, user: User = Depends(require("analytics.view")), db: Session = Depends(get_db)):
    f = {k: v for k, v in _f(request).items() if k != "page"}
    return intelligence.forecast_list(db, user, f, limit=50, offset=(page - 1) * 50)


@router.post("/forecast/recompute")
def forecast_recompute(user: User = Depends(require("analytics.view")), db: Session = Depends(get_db)):
    res = intelligence.recompute_risk(db)
    audit(db, user, "RISK_RECOMPUTED", "system", "risk", None, res)
    db.commit()
    return res


@router.get("/capacity")
def capacity(request: Request, user: User = Depends(require("analytics.view")), db: Session = Depends(get_db)):
    return intelligence.capacity(db, user, _f(request))


@router.get("/process-mining")
def process_mining(request: Request, user: User = Depends(require("analytics.view")), db: Session = Depends(get_db)):
    return intelligence.process_mining(db, user, _f(request))


class SimIn(BaseModel):
    rule_key: str
    params: dict
    include_closed: bool = True


@router.post("/simulator/run")
def sim_run(body: SimIn, user: User = Depends(require("rule.simulate")), db: Session = Depends(get_db)):
    res = simulator.simulate(db, body.rule_key, body.params, body.include_closed)
    audit(db, user, "RULE_SIMULATED", "rule", body.rule_key, None, {"params": body.params, "affected": res.get("obligations_affected")})
    db.commit()
    return res


@router.get("/reports")
def report_catalog(user: User = Depends(require("report.view"))):
    return [{"name": k, "title": v} for k, v in reports.REPORTS.items()]


@router.get("/reports/{name}")
def report(name: str, request: Request, fmt: str = "json", user: User = Depends(require("report.view")), db: Session = Depends(get_db)):
    f = {k: v for k, v in _f(request).items() if k != "fmt"}
    rep = reports.build(db, user, name, f)
    if fmt == "json":
        rep["rows"] = rep["rows"][:500]
        rep["truncated"] = len(rep["rows"]) == 500
        return rep
    from app.core.permissions import has_perm
    if not has_perm(user.role, "report.export"):
        raise HTTPException(403, "Your role may view but not export reports.")
    audit(db, user, "EXPORT", "report", name, None, {"format": fmt, "rows": len(rep["rows"]), "filters": f})
    db.commit()
    if fmt == "csv":
        return Response(reports.to_csv(rep), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{name}.csv"'})
    if fmt == "pdf":
        return Response(reports.to_pdf(rep, f"{user.full_name} ({user.role})"), media_type="application/pdf",
                        headers={"Content-Disposition": f'attachment; filename="{name}.pdf"'})
    raise HTTPException(422, "fmt must be json, csv or pdf")


class ImpactIn(BaseModel):
    obligations: int = 18000
    reminders_per_obligation: float = 3
    minutes_per_followup: float = 12
    status_checks_per_obligation: float = 4
    minutes_per_status_check: float = 6
    automated_followup_pct: float = 85
    institutions: int = 2000
    baseline_miss_rate_pct: float | None = None


@router.post("/impact")
def impact(body: ImpactIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Transparent model — every output is a formula of the stated inputs (modelled estimate, not measured AICTE results)."""
    def run(auto_pct, mins_fu, mins_check):
        followups = body.obligations * body.reminders_per_obligation
        auto = followups * auto_pct / 100
        checks_saved = body.obligations * body.status_checks_per_obligation * (auto_pct / 100)
        hours = (auto * mins_fu + checks_saved * mins_check) / 60
        return {"manual_followups_baseline": round(followups), "followups_automated": round(auto),
                "manual_followups_remaining": round(followups - auto), "officer_hours_saved": round(hours, 1),
                "fte_equivalent": round(hours / 1600, 2)}
    base = run(body.automated_followup_pct, body.minutes_per_followup, body.minutes_per_status_check)
    low = run(max(body.automated_followup_pct - 20, 0), body.minutes_per_followup * 0.6, body.minutes_per_status_check * 0.6)
    high = run(min(body.automated_followup_pct + 10, 100), body.minutes_per_followup * 1.3, body.minutes_per_status_check * 1.3)
    # deadline-miss reduction only where back-testing supports it: compare historical late rate (stored records)
    from sqlalchemy import func, select
    from app.models import Obligation
    late, total = db.execute(select(func.count().filter(func.date(Obligation.completed_at) > Obligation.due_date), func.count())
                             .where(Obligation.state == "MET", Obligation.due_date.is_not(None))).one()
    hist_rate = round(100 * late / total, 1) if total else None
    return {"label": "MODELLED ESTIMATE — based on the stated assumptions; not measured AICTE production results.",
            "inputs": body.model_dump(),
            "formulas": {"manual_followups_baseline": "obligations × reminders_per_obligation",
                         "followups_automated": "baseline × automated_followup_pct",
                         "officer_hours_saved": "(automated × minutes_per_followup + obligations × status_checks × automated_pct × minutes_per_check) / 60",
                         "fte_equivalent": "hours / 1,600 working hours per year"},
            "scenarios": {"low": low, "base": base, "high": high},
            "sensitivity": {"low": "automation −20 pts, minutes ×0.6", "high": "automation +10 pts, minutes ×1.3"},
            "deadline_miss": {"historical_late_rate_pct": hist_rate, "sample": total,
                              "note": "A miss-reduction estimate needs a before/after back-test against real AICTE history; with synthetic "
                                      "history only the observed late rate is reported, no reduction is claimed."}}
