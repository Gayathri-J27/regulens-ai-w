"""Institutions, applications/workflow, Promise Ledger, evidence, files, institution portal and magic links."""
from __future__ import annotations

import io
from datetime import date

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.db import get_db
from app.core.permissions import INSTITUTION_ROLES, has_perm
from app.core.scope import (assert_institution_access, get_application_scoped, get_obligation_scoped, scope_by_institution_col,
                            scope_institutions)
from app.core.security import check_signed, current_user, now, rate_limit, require, sign_url
from app.models import (Application, Evidence, Institution, InstitutionalDocument, InstitutionContact, Obligation, RiskScore,
                        StoredFile, User)
from app.services import ledger, workflow
from app.services.audit import audit, snapshot
from app.services.clocks import today_ist
from app.services.config import OBLIGATION_TYPES
from app.services.files import read, store_upload
from app.api.deps import body_date, clean, page_params, paginate

router = APIRouter(prefix="/api", tags=["core"])


# ---------------------------------------------------------------- reference
@router.get("/meta")
def meta(user: User = Depends(current_user), db: Session = Depends(get_db)):
    from app.models import Region, RouteTemplate
    from app.services.workflow import APP_TYPES, REASON_CODES
    return {"regions": [{"id": r.id, "code": r.code, "name": r.name, "states": r.states} for r in db.execute(select(Region).order_by(Region.id)).scalars()],
            "routes": [{"code": r.code, "name": r.name, "version": r.version} for r in db.execute(select(RouteTemplate).where(RouteTemplate.is_active.is_(True))).scalars()],
            "application_types": APP_TYPES, "obligation_types": OBLIGATION_TYPES, "reason_codes": REASON_CODES,
            "stages": ["SCRUTINY", "RESCRUTINY", "EVC", "SAC_SHC", "DECISION"],
            "officers": [{"id": u.id, "name": u.full_name, "role": u.role, "region_id": u.region_id} for u in db.execute(
                select(User).where(User.role.in_(["REGIONAL_OFFICER", "BUREAU_OFFICER"]), User.is_active.is_(True))
                .order_by(User.is_synthetic, User.full_name).limit(400)).scalars()] if user.role not in INSTITUTION_ROLES else []}


# ---------------------------------------------------------------- institutions
class InstitutionIn(BaseModel):
    aicte_id: str
    name: str
    region_id: int
    state: str
    district: str | None = None
    tier: int = Field(2, ge=1, le=3)
    address: str | None = None
    preferred_language: str = "en"
    digest_enabled: bool = False
    is_synthetic: bool = True
    principal_name: str | None = None
    principal_email: str | None = None
    principal_phone: str | None = None


@router.get("/institutions")
def list_institutions(q: str | None = None, region_id: int | None = None, state: str | None = None, synthetic: str | None = None,
                      pg=Depends(page_params), user: User = Depends(require("application.view")), db: Session = Depends(get_db)):
    stmt = scope_institutions(select(Institution), user)
    if q:
        stmt = stmt.where(or_(Institution.name.ilike(f"%{q}%"), Institution.aicte_id.ilike(f"%{q}%")))
    if region_id:
        stmt = stmt.where(Institution.region_id == region_id)
    if state:
        stmt = stmt.where(Institution.state == state)
    if synthetic == "0":
        stmt = stmt.where(Institution.is_synthetic.is_(False))
    return paginate(db, stmt.order_by(Institution.name), *pg, lambda i: {
        "id": i.id, "aicte_id": i.aicte_id, "name": i.name, "region_id": i.region_id, "state": i.state, "tier": i.tier,
        "district": i.district, "is_synthetic": i.is_synthetic, "preferred_language": i.preferred_language})


@router.post("/institutions")
def create_institution(body: InstitutionIn, user: User = Depends(require("institution.manage")), db: Session = Depends(get_db)):
    if db.execute(select(Institution.id).where(Institution.aicte_id == body.aicte_id)).first():
        raise HTTPException(409, "An institution with this AICTE ID already exists.")
    if user.role == "REGIONAL_OFFICER" and user.region_id != body.region_id:
        raise HTTPException(403, "Regional officers register institutions in their own Region only.")
    i = Institution(**body.model_dump(exclude={"principal_name", "principal_email", "principal_phone"}))
    db.add(i)
    db.flush()
    if body.principal_email or body.principal_phone:
        db.add(InstitutionContact(institution_id=i.id, role="PRINCIPAL", name=body.principal_name or "Principal",
                                  email=body.principal_email, phone=body.principal_phone, verified=False))
    audit(db, user, "INSTITUTION_REGISTERED", "institution", i.id, None, snapshot(i))
    db.commit()
    return {"id": i.id}


@router.get("/institutions/{iid:int}")
def get_institution(iid: int, user: User = Depends(require("application.view")), db: Session = Depends(get_db)):
    i = assert_institution_access(db, user, iid)
    contacts = db.execute(select(InstitutionContact).where(InstitutionContact.institution_id == iid)).scalars().all()
    return {"id": i.id, "aicte_id": i.aicte_id, "name": i.name, "region_id": i.region_id, "state": i.state, "district": i.district,
            "tier": i.tier, "address": i.address, "preferred_language": i.preferred_language, "digest_enabled": i.digest_enabled,
            "is_synthetic": i.is_synthetic,
            "contacts": [{"id": c.id, "role": c.role, "name": c.name, "email": c.email, "phone": c.phone, "verified": c.verified,
                          "invalid": c.invalid, "invalid_reason": c.invalid_reason} for c in contacts],
            "health": health_card(db, i)}


class ContactIn(BaseModel):
    role: str
    name: str
    email: str | None = None
    phone: str | None = None
    verified: bool = False


@router.post("/institutions/{iid:int}/contacts")
def add_contact(iid: int, body: ContactIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    assert_institution_access(db, user, iid)
    if not (has_perm(user.role, "institution.manage") or user.role == "INSTITUTION_PRINCIPAL"):
        raise HTTPException(403, "Not permitted to manage contacts.")
    if body.role not in ("PRINCIPAL", "COMPLIANCE", "TRUST_REP", "ACCOUNTS"):
        raise HTTPException(422, "role must be PRINCIPAL, COMPLIANCE, TRUST_REP or ACCOUNTS")
    c = InstitutionContact(institution_id=iid, **body.model_dump())
    db.add(c)
    db.flush()
    audit(db, user, "CONTACT_ADDED", "institution", iid, None, {"contact_id": c.id, "role": c.role})
    db.commit()
    return {"id": c.id}


@router.patch("/institutions/{iid:int}/contacts/{cid:int}")
def update_contact(iid: int, cid: int, body: ContactIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    assert_institution_access(db, user, iid)
    c = db.get(InstitutionContact, cid)
    if not c or c.institution_id != iid:
        raise HTTPException(404)
    before = snapshot(c)
    for k, v in body.model_dump().items():
        setattr(c, k, v)
    c.invalid, c.invalid_reason = False, None
    audit(db, user, "CONTACT_UPDATED", "institution_contact", cid, before, snapshot(c))
    db.commit()
    return {"ok": True}


def health_card(db: Session, i: Institution) -> dict:
    t = today_ist()
    # the health card describes what the institution itself owes (AICTE-side stage work is excluded)
    rows = db.execute(select(Obligation.state, Obligation.due_date, Obligation.completed_at, Obligation.responsible_party)
                      .where(Obligation.institution_id == i.id, Obligation.responsible_party == "INSTITUTION")).all()
    open_ = [r for r in rows if r[0] in ledger.OPEN or r[0] == "PAUSED"]
    met = [r for r in rows if r[0] == "MET" and r[3] == "INSTITUTION"]
    ontime = [r for r in met if r[2] and r[1] and r[2].date() <= r[1]]
    docs = db.execute(select(InstitutionalDocument).where(InstitutionalDocument.institution_id == i.id, InstitutionalDocument.is_current.is_(True))).scalars().all()
    contacts = db.execute(select(InstitutionContact).where(InstitutionContact.institution_id == i.id)).scalars().all()
    return {"open_obligations": len(open_), "completed_obligations": len([r for r in rows if r[0] == "MET"]),
            "upcoming_30d": len([r for r in open_ if r[1] and t <= r[1] <= date.fromordinal(t.toordinal() + 30)]),
            "overdue": len([r for r in open_ if r[1] and r[1] < t and r[0] != "PAUSED"]),
            "on_time_rate": round(len(ontime) / len(met), 3) if met else None, "on_time_sample": len(met),
            "documents": [{"doc_type": d.doc_type, "expiry_date": d.expiry_date.isoformat() if d.expiry_date else None,
                           "days": (d.expiry_date - t).days if d.expiry_date else None} for d in docs],
            "contact_health": {"total": len(contacts), "verified": sum(c.verified for c in contacts), "invalid": sum(c.invalid for c in contacts)}}


# ---------------------------------------------------------------- applications & workflow
class AppIn(BaseModel):
    institution_id: int
    application_type: str
    route_code: str | None = None
    assigned_officer_id: int | None = None
    academic_year: str = "2026-27"
    priority: str = "NORMAL"


@router.get("/applications")
def list_applications(q: str | None = None, status: str | None = None, stage: str | None = None, route_code: str | None = None,
                      region_id: int | None = None, application_type: str | None = None, officer_id: int | None = None,
                      mine: bool = False, synthetic: str | None = None, pg=Depends(page_params),
                      user: User = Depends(require("application.view")), db: Session = Depends(get_db)):
    stmt = scope_by_institution_col(select(Application).join(Institution, Institution.id == Application.institution_id), user,
                                    Application.institution_id)
    for col, v in ((Application.status, status), (Application.current_stage, stage), (Application.route_code, route_code),
                   (Institution.region_id, region_id), (Application.application_type, application_type),
                   (Application.assigned_officer_id, officer_id)):
        if v:
            stmt = stmt.where(col == v)
    if mine:
        stmt = stmt.where(Application.assigned_officer_id == user.id)
    if synthetic == "0":
        stmt = stmt.where(Application.is_synthetic.is_(False))
    if q:
        stmt = stmt.where(or_(Application.app_no.ilike(f"%{q}%"), Institution.name.ilike(f"%{q}%")))
    return paginate(db, stmt.order_by(Application.created_at.desc()), *pg, lambda a: workflow.app_view(db, a))


@router.post("/applications")
def create_application(body: AppIn, user: User = Depends(require("application.create")), db: Session = Depends(get_db)):
    assert_institution_access(db, user, body.institution_id)
    a = workflow.register(db, user, **body.model_dump())
    db.commit()
    return workflow.app_view(db, a, detail=True)


@router.get("/applications/{aid:int}")
def get_application(aid: int, user: User = Depends(require("application.view")), db: Session = Depends(get_db)):
    return workflow.app_view(db, get_application_scoped(db, user, aid), detail=True)


class FieldsIn(BaseModel):
    fields: dict = {}


class ReasonIn(BaseModel):
    reason: str = ""
    reason_code: str | None = None
    response_days: int | None = None


class RevertIn(BaseModel):
    target: str
    reason: str


class DecideIn(BaseModel):
    decision: str
    note: str


class AssignIn(BaseModel):
    officer_id: int
    reason: str = ""


@router.post("/applications/{aid:int}/complete-stage")
def complete_stage(aid: int, body: FieldsIn, user: User = Depends(require("workflow.transition")), db: Session = Depends(get_db)):
    a = get_application_scoped(db, user, aid)
    workflow.complete_stage(db, user, a, body.fields)
    db.commit()
    return workflow.app_view(db, a, detail=True)


@router.post("/applications/{aid:int}/return")
def return_app(aid: int, body: ReasonIn, user: User = Depends(require("workflow.return")), db: Session = Depends(get_db)):
    a = get_application_scoped(db, user, aid)
    workflow.return_to_institution(db, user, a, body.reason, body.reason_code or "OTHER", body.response_days)
    db.commit()
    return workflow.app_view(db, a, detail=True)


@router.post("/applications/{aid:int}/resubmit")
def resubmit(aid: int, body: ReasonIn, user: User = Depends(require("workflow.resubmit")), db: Session = Depends(get_db)):
    a = get_application_scoped(db, user, aid)
    workflow.resubmit(db, user, a, body.reason)
    db.commit()
    return workflow.app_view(db, a, detail=True)


@router.post("/applications/{aid:int}/revert")
def revert(aid: int, body: RevertIn, user: User = Depends(require("workflow.revert")), db: Session = Depends(get_db)):
    a = get_application_scoped(db, user, aid)
    workflow.revert(db, user, a, body.target, body.reason)
    db.commit()
    return workflow.app_view(db, a, detail=True)


@router.post("/applications/{aid:int}/decide")
def decide(aid: int, body: DecideIn, user: User = Depends(require("workflow.decide")), db: Session = Depends(get_db)):
    a = get_application_scoped(db, user, aid)
    workflow.decide(db, user, a, body.decision, body.note)
    db.commit()
    return workflow.app_view(db, a, detail=True)


@router.post("/applications/{aid:int}/assign")
def assign_app(aid: int, body: AssignIn, user: User = Depends(require("application.assign")), db: Session = Depends(get_db)):
    a = get_application_scoped(db, user, aid)
    workflow.assign(db, user, a, body.officer_id, body.reason)
    db.commit()
    return workflow.app_view(db, a, detail=True)


class ExceptionIn(BaseModel):
    kind: str  # WITHDRAWN | MERGED | APPEAL | LEGAL_HOLD | LIFT_HOLD
    reason: str
    primary_application_id: int | None = None
    order_file_id: int | None = None


@router.post("/applications/{aid:int}/exception")
def record_exception(aid: int, body: ExceptionIn, user: User = Depends(require("exception.record")), db: Session = Depends(get_db)):
    a = get_application_scoped(db, user, aid)
    if not body.reason.strip():
        raise HTTPException(422, "A reason is required for every exception.")
    if body.kind in ("LEGAL_HOLD", "LIFT_HOLD") and not has_perm(user.role, "exception.legal_hold"):
        raise HTTPException(403, "Court-ordered holds are placed/lifted by the AICTE Administrator or Competent Authority.")
    if body.kind == "WITHDRAWN":
        res = workflow.withdraw(db, user, a, body.reason)
    elif body.kind == "MERGED":
        res = workflow.merge(db, user, a, body.primary_application_id or 0, body.reason)
    elif body.kind == "APPEAL":
        child = workflow.appeal(db, user, a, body.reason)
        res = {"child_application_id": child.id, "child_app_no": child.app_no}
    elif body.kind in ("LEGAL_HOLD", "LIFT_HOLD"):
        res = workflow.legal_hold(db, user, a, body.reason, body.order_file_id, lift=body.kind == "LIFT_HOLD")
    else:
        raise HTTPException(422, "kind must be WITHDRAWN, MERGED, APPEAL, LEGAL_HOLD or LIFT_HOLD")
    db.commit()
    return res


# ---------------------------------------------------------------- Promise Ledger
LEDGER_VIEWS = {"all", "mine", "upcoming", "overdue", "completed", "paused", "verification", "institution"}


@router.get("/ledger")
def list_ledger(view: str = "all", q: str | None = None, region_id: int | None = None, institution_id: int | None = None,
                officer_id: int | None = None, obligation_type: str | None = None, state: str | None = None,
                due_from: str | None = None, due_to: str | None = None, synthetic: str | None = None, application_id: int | None = None,
                sort: str = "due", pg=Depends(page_params), user: User = Depends(require("ledger.view")), db: Session = Depends(get_db)):
    if view not in LEDGER_VIEWS:
        raise HTTPException(422, f"view must be one of {sorted(LEDGER_VIEWS)}")
    t = today_ist()
    stmt = scope_by_institution_col(select(Obligation).join(Institution, Institution.id == Obligation.institution_id), user, Obligation.institution_id)
    open_states = list(ledger.OPEN)
    if view == "mine":
        stmt = stmt.where(Obligation.assigned_user_id == user.id, Obligation.state.in_(open_states + ["PAUSED"]))
    elif view == "upcoming":
        stmt = stmt.where(Obligation.state.in_(open_states), Obligation.due_date >= t, Obligation.due_date <= date.fromordinal(t.toordinal() + 30))
    elif view == "overdue":
        stmt = stmt.where(Obligation.state.in_(open_states), Obligation.due_date < t)
    elif view == "completed":
        stmt = stmt.where(Obligation.state.in_(ledger.CLOSED))
    elif view == "paused":
        stmt = stmt.where(Obligation.state == "PAUSED")
    elif view == "verification":
        stmt = stmt.where(Obligation.state == "SUBMITTED")
    elif view == "institution":
        stmt = stmt.where(Obligation.responsible_party == "INSTITUTION")
    for col, v in ((Institution.region_id, region_id), (Obligation.institution_id, institution_id), (Obligation.assigned_user_id, officer_id),
                   (Obligation.obligation_type, obligation_type), (Obligation.state, state), (Obligation.application_id, application_id)):
        if v:
            stmt = stmt.where(col == v)
    if due_from:
        stmt = stmt.where(Obligation.due_date >= body_date(due_from))
    if due_to:
        stmt = stmt.where(Obligation.due_date <= body_date(due_to))
    if synthetic == "0":
        stmt = stmt.where(Obligation.is_synthetic.is_(False))
    if q:
        stmt = stmt.where(or_(Obligation.title.ilike(f"%{q}%"), Obligation.obl_no.ilike(f"%{q}%"), Institution.name.ilike(f"%{q}%")))
    order = {"due": Obligation.due_date.asc().nulls_last(), "recent": Obligation.created_at.desc(), "updated": Obligation.updated_at.desc()}.get(sort)
    return paginate(db, stmt.order_by(order, Obligation.id), *pg, lambda o: ledger.obligation_view(db, o))


@router.get("/ledger/export")
def export_ledger(view: str = "all", fmt: str = "csv", region_id: int | None = None, obligation_type: str | None = None,
                  user: User = Depends(require("ledger.export")), db: Session = Depends(get_db)):
    from app.services.reports import to_csv
    res = list_ledger(view=view, region_id=region_id, obligation_type=obligation_type, pg=(1, 200), user=user, db=db, q=None,
                      institution_id=None, officer_id=None, state=None, due_from=None, due_to=None, synthetic=None, application_id=None, sort="due")
    stmt_total = res["total"]
    rows = []
    page = 1
    while True:
        chunk = list_ledger(view=view, region_id=region_id, obligation_type=obligation_type, pg=(page, 200), user=user, db=db, q=None,
                            institution_id=None, officer_id=None, state=None, due_from=None, due_to=None, synthetic=None, application_id=None, sort="due")
        rows += chunk["items"]
        if page >= chunk["pages"] or len(rows) >= 20000:
            break
        page += 1
    cols = ["obl_no", "institution", "obligation_type", "title", "responsible_party", "display_state", "due_date", "days_remaining",
            "verification_status", "escalation_level", "is_synthetic"]
    rep = {"title": f"Promise Ledger ({view})", "generated": today_ist().isoformat(), "columns": cols, "rows": [[r[c] for c in cols] for r in rows],
           "filters": {"view": view, "region_id": region_id, "obligation_type": obligation_type}}
    audit(db, user, "EXPORT", "ledger", view, None, {"rows": len(rows), "total": stmt_total, "format": fmt})
    db.commit()
    return Response(to_csv(rep), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="ledger-{view}.csv"'})


class ObligationIn(BaseModel):
    institution_id: int
    obligation_type: str
    title: str
    description: str = ""
    application_id: int | None = None
    responsible_role: str | None = None
    assigned_user_id: int | None = None
    evidence_requirements: list[str] = []
    start_date: str | None = None
    due_date: str | None = None
    budget_days: int | None = None
    day_mode: str | None = None
    priority: str = "NORMAL"


@router.post("/ledger")
def create_ledger(body: ObligationIn, user: User = Depends(require("ledger.create")), db: Session = Depends(get_db)):
    assert_institution_access(db, user, body.institution_id)
    if not body.title.strip():
        raise HTTPException(422, "Title is required.")
    o = ledger.create_obligation(db, user, institution_id=body.institution_id, obligation_type=body.obligation_type, title=body.title,
                                 description=body.description, application_id=body.application_id, responsible_role=body.responsible_role,
                                 assigned_user_id=body.assigned_user_id, evidence_requirements=body.evidence_requirements,
                                 start_date=body_date(body.start_date), due_date=body_date(body.due_date), budget_days=body.budget_days,
                                 day_mode=body.day_mode, priority=body.priority, source_event="OFFICER_CREATED")
    db.commit()
    return ledger.obligation_view(db, o, detail=True)


@router.get("/ledger/{oid:int}")
def get_ledger(oid: int, user: User = Depends(require("ledger.view")), db: Session = Depends(get_db)):
    o = get_obligation_scoped(db, user, oid)
    d = ledger.obligation_view(db, o, detail=True)
    d["evidence"] = [{"id": e.id, "receipt_no": e.receipt_no, "channel": e.channel, "status": e.status, "note": e.note, "file_id": e.file_id,
                      "submitted_at": e.submitted_at.isoformat(), "reviewed_at": e.reviewed_at.isoformat() if e.reviewed_at else None,
                      "review_reason": e.review_reason, "ocr_status": e.ocr_status, "ocr_excerpt": (e.ocr_text or "")[:600],
                      "download": sign_url(e.file_id, user.id) if e.file_id else None}
                     for e in db.execute(select(Evidence).where(Evidence.obligation_id == oid).order_by(Evidence.id.desc())).scalars()]
    from app.models import AuditLog, Escalation, RiskScore
    d["history"] = [{"id": a.id, "ts": a.ts.isoformat(), "action": a.action, "actor_id": a.actor_id, "actor_role": a.actor_role, "reason": a.reason,
                     "hash": a.hash[:16]} for a in db.execute(select(AuditLog).where(
                         or_(((AuditLog.entity_type == "obligation") & (AuditLog.entity_id == str(oid))),
                             ((AuditLog.entity_type == "clock") & (AuditLog.entity_id == str(o.clock_id)))))
                         .order_by(AuditLog.id)).scalars()]
    d["escalations"] = [{"id": e.id, "level": e.level, "new_recipient_id": e.new_recipient_id, "status": e.status, "reason": e.reason,
                         "triggered_at": e.triggered_at.isoformat(), "path": e.resolution_path}
                        for e in db.execute(select(Escalation).where(Escalation.obligation_id == oid).order_by(Escalation.id)).scalars()]
    r = db.get(RiskScore, oid)
    d["risk"] = {"level": r.level, "probability": r.probability, "reasons": r.reasons, "sample_size": r.sample_size, "segment": r.segment,
                 "computed_at": r.computed_at.isoformat()} if r else None
    if o.source_document_id and user.role not in INSTITUTION_ROLES:
        d["source_document_url"] = sign_url(o.source_document_id, user.id)
    if o.source_rule_id:
        from app.models import Rule
        rule = db.get(Rule, o.source_rule_id)
        d["source_rule"] = {"id": rule.id, "rule_key": rule.rule_key, "version": rule.version, "name": rule.name, "source_type": rule.source_type,
                            "citation": rule.citation, "params": rule.params} if rule else None
    d["can"] = {p: has_perm(user.role, p) for p in ("ledger.edit", "ledger.assign", "ledger.verify", "ledger.extend", "ledger.pause",
                                                     "ledger.close", "ledger.reopen", "ledger.priority_override", "ledger.assisted",
                                                     "magiclink.issue", "institution.acknowledge", "evidence.submit", "notification.nudge")}
    return d


class EditIn(BaseModel):
    changes: dict
    reason: str = ""


class ActionIn(BaseModel):
    reason: str = ""
    days: int | None = None
    kind: str | None = None
    outcome: str | None = None
    user_id: int | None = None
    value: float | None = None
    contact_id: int | None = None


@router.patch("/ledger/{oid:int}")
def edit_ledger(oid: int, body: EditIn, user: User = Depends(require("ledger.edit")), db: Session = Depends(get_db)):
    o = get_obligation_scoped(db, user, oid)
    ledger.edit(db, user, o, body.changes, body.reason)
    db.commit()
    return ledger.obligation_view(db, o, detail=True)


@router.post("/ledger/{oid:int}/do/{action}")
def ledger_action(oid: int, action: str, body: ActionIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    o = get_obligation_scoped(db, user, oid)
    perm = {"acknowledge": "institution.acknowledge", "extend": "ledger.extend", "pause": "ledger.pause", "resume": "ledger.pause",
            "close": "ledger.close", "reopen": "ledger.reopen", "assign": "ledger.assign", "priority": "ledger.priority_override",
            "magic-link": "magiclink.issue", "nudge": "notification.nudge"}.get(action)
    if not perm:
        raise HTTPException(404, "Unknown action")
    if not has_perm(user.role, perm):
        raise HTTPException(403, f"Your role ({user.role}) is not permitted to perform '{perm}'.")
    res: dict = {}
    if action == "acknowledge":
        ledger.acknowledge(db, user, o)
    elif action == "extend":
        res = ledger.extend(db, user, o, body.days or 0, body.reason)
    elif action == "pause":
        res = ledger.pause(db, user, o, body.kind or "AICTE", body.reason or "paused by officer")
    elif action == "resume":
        res = ledger.resume(db, user, o, body.reason or "resumed by officer", body.kind)
    elif action == "close":
        ledger.close(db, user, o, body.outcome or "MET", body.reason)
    elif action == "reopen":
        ledger.reopen(db, user, o, body.reason, body.days or 15)
    elif action == "assign":
        ledger.assign(db, user, o, body.user_id or 0, body.reason)
    elif action == "priority":
        ledger.override_priority(db, user, o, body.value, body.reason)
    elif action == "magic-link":
        res = {"link": ledger.issue_magic_link(db, user, o, body.contact_id), "note": "Sent through the notification engine; shown here for the demo."}
    elif action == "nudge":
        res = nudge(db, user, o)
    db.commit()
    return {"obligation": ledger.obligation_view(db, o, detail=True), "result": res}


def nudge(db: Session, user: User, o: Obligation) -> dict:
    from app.services.notifications import notify_institution, notify_user
    r = db.get(RiskScore, o.id)
    why = (r.reasons[0]["reason"] if r and r.reasons else "deadline approaching")[:160]
    ctx = ledger.ctx_for(db, o, risk=(r.level if r else "elevated").lower(), why=why)
    key = f"nudge-{now().strftime('%Y%m%d%H%M%S')}"
    if o.responsible_party == "INSTITUTION":
        ids = notify_institution(db, db.get(Institution, o.institution_id), "nudge", ctx, entity=("obligation", o.id), key_suffix=key)
    else:
        ids = notify_user(db, db.get(User, o.assigned_user_id) if o.assigned_user_id else None, "nudge", ctx, entity=("obligation", o.id),
                          key_suffix=key, institution_id=o.institution_id)
    audit(db, user, "NUDGE_SENT", "obligation", o.id, None, {"notification_ids": ids})
    return {"notifications_created": len(ids), "notification_ids": ids}


@router.post("/ledger/{oid:int}/assisted")
async def ledger_assisted(oid: int, kind: str = Form(...), note: str = Form(...), file: UploadFile | None = File(None),
                          user: User = Depends(require("ledger.assisted")), db: Session = Depends(get_db)):
    o = get_obligation_scoped(db, user, oid)
    f = await store_upload(db, user, file, "assisted", o.institution_id) if file and file.filename else None
    res = ledger.record_assisted(db, user, o, kind, note, f)
    db.commit()
    return res


@router.post("/ledger/{oid:int}/evidence")
async def submit_evidence(oid: int, file: UploadFile = File(...), note: str = Form(""), user: User = Depends(require("evidence.submit")),
                          db: Session = Depends(get_db)):
    o = get_obligation_scoped(db, user, oid)
    if o.responsible_party != "INSTITUTION":
        raise HTTPException(409, "Evidence is submitted against institution-side obligations.")
    f = await store_upload(db, user, file, "evidence", o.institution_id)
    ev = ledger.submit_evidence(db, user, o, f, "PORTAL", note or None)
    db.commit()
    return {"receipt_no": ev.receipt_no, "evidence_id": ev.id, "status": ev.status, "sha256": f.sha256, "scan": f.scan_engine,
            "submitted_at": ev.submitted_at.isoformat()}


class ReviewIn(BaseModel):
    accept: bool
    reason: str | None = None


@router.post("/evidence/{eid:int}/review")
def review_evidence(eid: int, body: ReviewIn, user: User = Depends(require("ledger.verify")), db: Session = Depends(get_db)):
    ev = db.get(Evidence, eid)
    if not ev:
        raise HTTPException(404)
    get_obligation_scoped(db, user, ev.obligation_id)
    ledger.review_evidence(db, user, ev, body.accept, body.reason)
    db.commit()
    return {"status": ev.status}


@router.get("/clocks/{cid:int}/explain")
def clock_explain(cid: int, user: User = Depends(require("ledger.view")), db: Session = Depends(get_db)):
    from app.models import Clock
    from app.services.clocks import explain_clock
    c = db.get(Clock, cid)
    if not c:
        raise HTTPException(404)
    o = db.execute(select(Obligation).where(Obligation.clock_id == cid)).scalar_one_or_none()
    if o:
        get_obligation_scoped(db, user, o.id)
    return explain_clock(db, c)


# ---------------------------------------------------------------- files
@router.post("/files")
async def upload_file(purpose: str = Form("general"), institution_id: int | None = Form(None), file: UploadFile = File(...),
                      user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.role in INSTITUTION_ROLES:
        institution_id = user.institution_id
    elif institution_id:
        assert_institution_access(db, user, institution_id)
    f = await store_upload(db, user, file, purpose, institution_id)
    db.commit()
    return {"id": f.id, "sha256": f.sha256, "size": f.size, "mime": f.mime, "scan": f.scan_engine, "url": sign_url(f.id, user.id)}


@router.get("/files/{fid:int}/link")
def file_link(fid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    f = db.get(StoredFile, fid)
    if not f:
        raise HTTPException(404)
    if f.institution_id:
        assert_institution_access(db, user, f.institution_id)
    elif user.role in INSTITUTION_ROLES:
        raise HTTPException(403)
    return {"url": sign_url(f.id, user.id), "filename": f.filename, "mime": f.mime}


@router.get("/files/{fid:int}/download")
def download(fid: int, u: int, exp: int, sig: str, inline: bool = True, db: Session = Depends(get_db)):
    if not check_signed(fid, u, exp, sig):
        raise HTTPException(403, "Link invalid or expired.")
    f = db.get(StoredFile, fid)
    if not f:
        raise HTTPException(404)
    return Response(read(f), media_type=f.mime, headers={
        "Content-Disposition": f'{"inline" if inline else "attachment"}; filename="{f.filename}"', "X-Content-Type-Options": "nosniff",
        "Cache-Control": "private, no-store"})


# ---------------------------------------------------------------- institution portal
@router.get("/portal/summary")
def portal_summary(user: User = Depends(require("evidence.submit")), db: Session = Depends(get_db)):
    i = db.get(Institution, user.institution_id)
    obls = db.execute(select(Obligation).where(Obligation.institution_id == i.id, Obligation.responsible_party == "INSTITUTION")
                      .order_by(Obligation.due_date.asc().nulls_last())).scalars().all()
    apps = db.execute(select(Application).where(Application.institution_id == i.id).order_by(Application.created_at.desc())).scalars().all()
    evs = db.execute(select(Evidence).where(Evidence.institution_id == i.id).order_by(Evidence.id.desc()).limit(30)).scalars().all()
    docs = db.execute(select(InstitutionalDocument).where(InstitutionalDocument.institution_id == i.id).order_by(InstitutionalDocument.id.desc())).scalars().all()
    from app.services.documents import document_view
    return {"institution": {"id": i.id, "name": i.name, "aicte_id": i.aicte_id, "is_synthetic": i.is_synthetic},
            "health": health_card(db, i), "obligations": [ledger.obligation_view(db, o) for o in obls],
            "applications": [workflow.app_view(db, a) for a in apps],
            "receipts": [{"receipt_no": e.receipt_no, "obligation_id": e.obligation_id, "status": e.status, "submitted_at": e.submitted_at.isoformat(),
                          "review_reason": e.review_reason} for e in evs],
            "documents": [document_view(db, d) for d in docs]}


@router.get("/m/{token}")
def magic_open(token: str, request: Request, db: Session = Depends(get_db)):
    rate_limit(f"magic:{request.client.host if request.client else '?'}", settings.magic_link_rate_per_min)
    ml, o = ledger.resolve_magic_link(db, token)
    db.commit()
    i = db.get(Institution, o.institution_id)
    return {"obligation": {"obl_no": o.obl_no, "title": o.title, "description": o.description, "due_date": o.due_date.isoformat() if o.due_date else None,
                           "state": o.state, "evidence_requirements": o.evidence_requirements, "institution": i.name},
            "expires_at": ml.expires_at.isoformat(), "single_use": True}


@router.post("/m/{token}/acknowledge")
def magic_ack(token: str, request: Request, db: Session = Depends(get_db)):
    rate_limit(f"magic:{request.client.host if request.client else '?'}", settings.magic_link_rate_per_min)
    ml, o = ledger.resolve_magic_link(db, token)
    if o.state == "OPEN":
        o.state, o.acknowledged_at = "ACKNOWLEDGED", now()
        audit(db, None, "OBLIGATION_ACKNOWLEDGED", "obligation", o.id, None, {"via": "MAGIC_LINK", "magic_link_id": ml.id})
    db.commit()
    return {"state": o.state}


@router.post("/m/{token}/evidence")
async def magic_evidence(token: str, request: Request, file: UploadFile = File(...), note: str = Form(""), db: Session = Depends(get_db)):
    rate_limit(f"magic:{request.client.host if request.client else '?'}", settings.magic_link_rate_per_min)
    ml, o = ledger.resolve_magic_link(db, token, consume=True)  # single use: consumed by the submission
    if o.state == "OPEN":
        o.state, o.acknowledged_at = "ACKNOWLEDGED", now()
    f = await store_upload(db, None, file, "evidence", o.institution_id)
    ev = ledger.submit_evidence(db, None, o, f, "MAGIC_LINK", note or None)
    audit(db, None, "MAGIC_LINK_USED", "obligation", o.id, None, {"magic_link_id": ml.id, "receipt": ev.receipt_no})
    db.commit()
    return {"receipt_no": ev.receipt_no, "status": ev.status, "sha256": f.sha256}
