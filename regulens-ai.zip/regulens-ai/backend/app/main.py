"""ReguLens AI — FastAPI application (modular monolith)."""
from __future__ import annotations

import json
import logging
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text

from app.api import auth, routes_admin, routes_core, routes_intel, routes_ops
from app.core.config import settings
from app.core.db import SessionLocal, engine
from app.core.security import correlation_id


class JsonFormatter(logging.Formatter):
    def format(self, r):
        d = {"ts": self.formatTime(r), "level": r.levelname, "logger": r.name, "msg": r.getMessage(), "cid": correlation_id.get()}
        if r.exc_info:
            d["exc"] = self.formatException(r.exc_info)[-2000:]
        return json.dumps(d)


h = logging.StreamHandler()
h.setFormatter(JsonFormatter())
logging.basicConfig(level=logging.INFO, handlers=[h], force=True)
log = logging.getLogger("regulens")

app = FastAPI(title="ReguLens AI API", version="1.0.0",
              description="Evidence-Driven Regulatory Intelligence for AICTE — prototype API. Not connected to AICTE production systems.")
app.add_middleware(CORSMiddleware, allow_origins=[settings.frontend_origin, "http://localhost:4173", "http://127.0.0.1:5173"],
                   allow_credentials=False, allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def request_context(request: Request, call_next):
    cid = request.headers.get("X-Request-ID") or uuid.uuid4().hex[:16]
    tok = correlation_id.set(cid)
    t0 = time.perf_counter()
    try:
        resp = await call_next(request)
    except Exception:
        log.exception("unhandled error on %s %s", request.method, request.url.path)
        resp = JSONResponse({"detail": "Internal error. Reference: " + cid}, status_code=500)
    finally:
        correlation_id.reset(tok)
    ms = (time.perf_counter() - t0) * 1000
    resp.headers["X-Request-ID"] = cid
    resp.headers["X-Response-Time-ms"] = f"{ms:.1f}"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "SAMEORIGIN"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'self'" if request.url.path.startswith("/api/") and \
        not request.url.path.endswith("/download") else resp.headers.get("Content-Security-Policy", "")
    if request.url.path.startswith("/api/"):
        log.info(json.dumps({"method": request.method, "path": request.url.path, "status": resp.status_code, "ms": round(ms, 1), "cid": cid}))
    return resp


for r in (auth.router, routes_core.router, routes_ops.router, routes_intel.router, routes_admin.router):
    app.include_router(r)


@app.get("/api/health")
def health():
    with engine.connect() as c:
        c.execute(text("SELECT 1"))
    from app.engines.ocr import engines_available
    return {"status": "ok", "database": "ok", "environment": settings.environment, "scheduler": settings.run_scheduler,
            "ocr_engines": engines_available(), "llm_provider": settings.llm_provider if settings.anthropic_api_key else "local (no API key)",
            "malware_scanner": "clamav" if settings.clamd_host else "local-signature-scanner (dev fallback)",
            "storage": settings.storage_backend}


_sched = None


@app.on_event("startup")
def startup():
    global _sched
    from app.services.seed import bootstrap, seed_demo_workload
    db = SessionLocal()
    try:
        bootstrap(db)
        db.commit()
        seed_demo_workload(db)
        db.commit()
    finally:
        db.close()
    if settings.run_scheduler:
        from app.workers.scheduler import SchedulerThread
        _sched = SchedulerThread()
        _sched.start()


@app.on_event("shutdown")
def shutdown():
    if _sched:
        _sched.stop.set()
