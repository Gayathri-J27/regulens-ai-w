"""Escalation service: real overdue conditions -> level -> recipient resolved at execution time."""
from __future__ import annotations

from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import now
from app.engines.escalation_resolver import DelegationView, PostView, escalation_target_post, resolve
from app.models import Delegation, Escalation, Institution, Obligation, Post, Region, User
from app.services.audit import audit
from app.services.clocks import today_ist
from app.services.config import get_params
from app.services.notifications import notify_role, notify_user

OPEN_STATES = ("OPEN", "ACKNOWLEDGED", "SUBMITTED")


class OrgSnapshot:
    def __init__(self, db: Session):
        self.posts = {p.id: PostView(p.id, p.level, p.region_id, p.parent_post_id, p.holder_user_id, p.code)
                      for p in db.execute(select(Post)).scalars()}
        self.delegations = [DelegationView(d.post_id, d.delegate_user_id, d.starts_on, d.ends_on, d.revoked)
                            for d in db.execute(select(Delegation)).scalars()]
        self.active = set(db.execute(select(User.id).where(User.is_active.is_(True))).scalars())
        self.coords = {r.id: (r.lat, r.lon) for r in db.execute(select(Region)).scalars()}

    def resolve(self, post_id: int, on: date, exclude: set[int] | None = None):
        return resolve(post_id, on, self.posts, self.delegations, self.active, self.coords, exclude)


def officer_for_institution(db: Session, inst: Institution | None) -> User | None:
    """Current desk officer for an institution's Region (level-1 regional post), resolved now."""
    if not inst:
        return None
    post = db.execute(select(Post).where(Post.region_id == inst.region_id, Post.level == 1).order_by(Post.id).limit(1)).scalar_one_or_none()
    if not post:
        return None
    r = OrgSnapshot(db).resolve(post.id, today_ist())
    return db.get(User, r.recipient_id) if r.recipient_id else None


def assigned_post_for(db: Session, o: Obligation) -> int | None:
    if o.assigned_post_id:
        return o.assigned_post_id
    if o.assigned_user_id:
        u = db.get(User, o.assigned_user_id)
        if u and u.post_id:
            return u.post_id
    inst = db.get(Institution, o.institution_id)
    p = db.execute(select(Post.id).where(Post.region_id == inst.region_id, Post.level == 1).limit(1)).scalar_one_or_none()
    return p


def escalate(db: Session, o: Obligation, level: int, reason: str, org: OrgSnapshot | None = None,
             actor: User | None = None) -> Escalation:
    org = org or OrgSnapshot(db)
    start_post = assigned_post_for(db, o)
    target = escalation_target_post(start_post, level, org.posts) if start_post else None
    prev = o.assigned_user_id
    res = org.resolve(target, today_ist(), exclude={prev} if prev else None) if target else None
    inst = db.get(Institution, o.institution_id)
    esc = Escalation(obligation_id=o.id, level=level, previous_recipient_id=prev,
                     new_recipient_id=res.recipient_id if res else None, target_post_id=target,
                     resolution_path=res.path if res else [{"result": "NO_ASSIGNED_POST"}], reason=reason,
                     status="OPEN" if res and res.recipient_id else "UNROUTABLE")
    db.add(esc)
    db.flush()
    o.escalation_level = max(o.escalation_level, level)
    days_over = (today_ist() - o.due_date).days if o.due_date else 0
    prev_user = db.get(User, prev) if prev else None
    ctx = {"level": level, "title": o.title, "obl_no": o.obl_no, "institution": inst.name if inst else "", "days": days_over,
           "previous": prev_user.full_name if prev_user else "unassigned"}
    if esc.new_recipient_id:
        ids = notify_user(db, db.get(User, esc.new_recipient_id), "escalation", ctx, entity=("escalation", esc.id), key_suffix=f"L{level}",
                          institution_id=o.institution_id)
        esc.notification_id = ids[0] if ids else None
    else:
        notify_role(db, "SUPER_ADMIN", "escalation", ctx | {"title": "UNROUTABLE — " + o.title},
                    entity=("escalation", esc.id), key_suffix=f"L{level}")
        notify_role(db, "AICTE_ADMIN", "escalation", ctx | {"title": "UNROUTABLE — " + o.title},
                    entity=("escalation", esc.id), key_suffix=f"L{level}")
    audit(db, actor, "ESCALATION_TRIGGERED", "obligation", o.id, None,
          {"escalation_id": esc.id, "level": level, "previous_recipient": prev, "new_recipient": esc.new_recipient_id,
           "via": res.via if res else "NONE", "path": esc.resolution_path}, reason)
    return esc


def sweep(db: Session, limit: int | None = None) -> dict:
    """Daily: escalate every overdue open obligation to the level its days-overdue warrant."""
    levels = sorted(get_params(db, "escalation.timeline").get("levels", []), key=lambda x: x["level"])
    t = today_ist()
    q = select(Obligation).where(Obligation.state.in_(OPEN_STATES), Obligation.due_date < t, Obligation.merged_into_id.is_(None))
    org = OrgSnapshot(db)
    made = 0
    for o in db.execute(q.limit(limit) if limit else q).scalars():
        over = (t - o.due_date).days
        want = max([l["level"] for l in levels if over >= l["days_overdue"]], default=0)
        for lvl in range(o.escalation_level + 1, want + 1):
            escalate(db, o, lvl, f"Overdue by {over} day(s); escalation timeline level {lvl} reached.", org)
            made += 1
    return {"escalations_created": made, "as_of": t.isoformat()}


def close_for_obligation(db: Session, o: Obligation, note: str) -> None:
    for e in db.execute(select(Escalation).where(Escalation.obligation_id == o.id, Escalation.status.in_(["OPEN", "ACKNOWLEDGED", "UNROUTABLE"]))).scalars():
        e.status, e.closed_at, e.closure_note = "CLOSED", now(), note
