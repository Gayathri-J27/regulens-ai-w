"""Promise Ledger: the single source of truth for every time-bound action.

Creating an obligation = ledger row + clock + reminder schedule + notifications + audit entry, in one
transaction, so it appears everywhere (institution view, officer views, deadlines, escalation) at once.
"""
from __future__ import annotations

import secrets
from datetime import date, datetime, time, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from app.core.permissions import INSTITUTION_ROLES
from app.core.security import now, sha
from app.models import (Clock, Evidence, Institution, MagicLink, Obligation, ScheduledAction, StoredFile, User)
from app.services.audit import audit, snapshot
from app.services.clocks import add_event, calendars_for_institution, create_clock, explain_clock, today_ist
from app.services.config import INSTITUTION_SIDE, OBLIGATION_TYPES, STATUTORY_TYPES, get_params, get_rule
from app.services.escalation import close_for_obligation, officer_for_institution
from app.services.notifications import notify_institution, notify_user

IST = timezone(timedelta(hours=5, minutes=30))
OPEN = ("OPEN", "ACKNOWLEDGED", "SUBMITTED")
CLOSED = ("MET", "WAIVED", "CANCELLED", "MERGED")


def _ist_dt(d: date) -> datetime:
    return datetime.combine(d, time(10, 0), tzinfo=IST)


def next_obl_no(db: Session, prefix: str = "OBL") -> str:
    n = db.execute(select(func.count(Obligation.id))).scalar_one() + 1
    return f"{prefix}-{today_ist():%y}-{n:06d}-{secrets.token_hex(2).upper()}"


def create_obligation(db: Session, actor: User | None, *, institution_id: int, obligation_type: str, title: str,
                      description: str = "", application_id: int | None = None, responsible_role: str | None = None,
                      assigned_user_id: int | None = None, assigned_post_id: int | None = None,
                      source_event: str = "MANUAL", source_document_id: int | None = None, source_text: str | None = None,
                      evidence_requirements: list | None = None, start_date: date | None = None,
                      due_date: date | None = None, budget_days: int | None = None, day_mode: str | None = None,
                      priority: str = "NORMAL", statutory: bool | None = None, notify: bool = True,
                      rule_key: str | None = None, rule_params: dict | None = None, source_rule_id: int | None = None,
                      started_at: datetime | None = None, owner_side: str | None = None) -> Obligation:
    if obligation_type not in OBLIGATION_TYPES:
        raise HTTPException(422, f"Unknown obligation type {obligation_type}")
    inst = db.get(Institution, institution_id)
    if not inst:
        raise HTTPException(404, "Institution not found")
    rk = rule_key or f"deadline.{obligation_type}"
    rule = get_rule(db, rk)
    params = rule_params or (dict(rule.params) if rule else get_params(db, rk))
    start = start_date or today_ist()
    st_at = started_at or (_ist_dt(start) if start_date else now())
    mode = day_mode or params.get("day_mode", "CALENDAR")
    if due_date is not None:
        # an explicit due date (e.g. from a confirmed approval letter) becomes a calendar-day budget
        if due_date < start:
            raise HTTPException(422, "Due date cannot be before the start date.")
        mode, budget = "CALENDAR", (due_date - start).days
    else:
        budget = budget_days if budget_days is not None else int(params.get("budget_days", 15))
    party = owner_side or ("INSTITUTION" if obligation_type in INSTITUTION_SIDE else "AICTE")
    if assigned_user_id is None and party == "AICTE" and actor and actor.role not in INSTITUTION_ROLES:
        assigned_user_id = actor.id
    if assigned_user_id is None:
        off = officer_for_institution(db, inst)
        assigned_user_id = off.id if off else None
    if assigned_post_id is None and assigned_user_id:
        u = db.get(User, assigned_user_id)
        assigned_post_id = u.post_id if u else None
    clock = create_clock(db, owner_side=party, label=title[:150], budget_days=budget, day_mode=mode,
                         calendar_ids=calendars_for_institution(db, inst), started_at=st_at,
                         revert_policy=params.get("revert_policy", "RESUME"), source_rule_id=source_rule_id or (rule.id if rule else None),
                         application_id=application_id, actor=actor)
    o = Obligation(obl_no=next_obl_no(db), institution_id=institution_id, application_id=application_id,
                   obligation_type=obligation_type, title=title, description=description,
                   responsible_role=responsible_role or ("INSTITUTION_PRINCIPAL" if party == "INSTITUTION" else "REGIONAL_OFFICER"),
                   responsible_party=party, assigned_user_id=assigned_user_id, assigned_post_id=assigned_post_id,
                   source_event=source_event, source_rule_id=source_rule_id or (rule.id if rule else None),
                   source_document_id=source_document_id, source_text=source_text,
                   evidence_requirements=evidence_requirements or [], start_date=start, due_date=clock.due_date,
                   clock_id=clock.id, state="OPEN", priority=priority,
                   statutory_flag=statutory if statutory is not None else obligation_type in STATUTORY_TYPES,
                   verification_status="NOT_SUBMITTED" if party == "INSTITUTION" else "NOT_APPLICABLE",
                   created_by=actor.id if actor else None)
    db.add(o)
    db.flush()
    audit(db, actor, "OBLIGATION_CREATED", "obligation", o.id, None, snapshot(o))
    schedule_reminders(db, o)
    if notify:
        ctx = ctx_for(db, o)
        if party == "INSTITUTION":
            notify_institution(db, inst, "undertaking_created", ctx, entity=("obligation", o.id), key_suffix="new")
        if o.assigned_user_id and party == "AICTE":
            notify_user(db, db.get(User, o.assigned_user_id), "undertaking_created", ctx, entity=("obligation", o.id), key_suffix="new")
    return o


def ctx_for(db: Session, o: Obligation, **extra) -> dict:
    inst = db.get(Institution, o.institution_id)
    days = (o.due_date - today_ist()).days if o.due_date else ""
    return {"title": o.title, "obl_no": o.obl_no, "due": o.due_date.strftime("%d %b %Y") if o.due_date else "paused",
            "days": abs(days) if days != "" else "", "institution": inst.name if inst else "",
            "evidence": ", ".join(o.evidence_requirements) if o.evidence_requirements else "as specified", **extra}


def schedule_reminders(db: Session, o: Obligation) -> int:
    """Durable reminder actions keyed by (obligation, due date, offset): idempotent; stale ones are skipped."""
    if not o.due_date:
        return 0
    p = get_params(db, "reminder.offsets")
    offsets = p.get("document_days_before") if o.obligation_type in ("LEASE_RENEWAL", "DOCUMENT_RENEWAL") else p.get("days_before", [7, 3, 1])
    offsets = list(offsets) + ([0] if p.get("on_due", True) else [])
    n = 0
    for off in offsets:
        d = o.due_date - timedelta(days=off)
        if d < today_ist():
            continue
        run = _ist_dt(d).replace(hour=9)
        res = db.execute(insert(ScheduledAction).values(
            idempotency_key=f"rem:{o.id}:{o.due_date.isoformat()}:{off}", action_type="REMINDER", entity_type="obligation",
            entity_id=o.id, payload={"due": o.due_date.isoformat(), "offset": off}, run_at=run, status="PENDING",
            attempts=0, created_at=now()).on_conflict_do_nothing(index_elements=["idempotency_key"]))
        n += res.rowcount or 0
    return n


# ---------------------------------------------------------------- state transitions
def _require_open(o: Obligation):
    if o.state not in OPEN and o.state != "PAUSED":
        raise HTTPException(409, f"Obligation is {o.state}; this action needs an open obligation.")


def acknowledge(db: Session, actor: User, o: Obligation, via: str = "PORTAL") -> Obligation:
    if o.responsible_party != "INSTITUTION":
        raise HTTPException(409, "Only institution-side obligations are acknowledged by institutions.")
    if o.state != "OPEN":
        raise HTTPException(409, f"Obligation is {o.state}; only OPEN obligations can be acknowledged.")
    before = snapshot(o)
    o.state, o.acknowledged_at = "ACKNOWLEDGED", now()
    audit(db, actor, "OBLIGATION_ACKNOWLEDGED", "obligation", o.id, before, snapshot(o), f"via {via}")
    return o


def submit_evidence(db: Session, actor: User | None, o: Obligation, file: StoredFile | None, channel: str,
                    note: str | None = None) -> Evidence:
    _require_open(o)
    if o.state == "PAUSED":
        raise HTTPException(409, "Obligation is paused; evidence can be submitted once it resumes.")
    receipt = f"RCPT-{today_ist():%Y%m%d}-{secrets.token_hex(4).upper()}"
    ev = Evidence(receipt_no=receipt, obligation_id=o.id, institution_id=o.institution_id, file_id=file.id if file else None,
                  channel=channel, note=note, status="RECEIVED_PENDING_VERIFICATION",
                  ocr_status="QUEUED" if file else "NOT_APPLICABLE", submitted_by=actor.id if actor else None)
    db.add(ev)
    db.flush()
    before = snapshot(o)
    o.state, o.verification_status = "SUBMITTED", "PENDING_VERIFICATION"
    audit(db, actor, "EVIDENCE_SUBMITTED", "obligation", o.id, before, snapshot(o) | {"receipt": receipt, "channel": channel})
    if file:
        db.execute(insert(ScheduledAction).values(idempotency_key=f"ocr:evidence:{ev.id}", action_type="OCR_EVIDENCE",
                                                  entity_type="evidence", entity_id=ev.id, payload={}, run_at=now(),
                                                  status="PENDING", attempts=0, created_at=now())
                   .on_conflict_do_nothing(index_elements=["idempotency_key"]))
    officer = db.get(User, o.assigned_user_id) if o.assigned_user_id else None
    notify_user(db, officer, "evidence_submitted", ctx_for(db, o, receipt=receipt), entity=("evidence", ev.id), key_suffix="sub",
                institution_id=o.institution_id)
    return ev


def review_evidence(db: Session, actor: User, ev: Evidence, accept: bool, reason: str | None) -> Evidence:
    if ev.status != "RECEIVED_PENDING_VERIFICATION":
        raise HTTPException(409, f"Evidence already {ev.status}.")
    if not accept and not (reason and reason.strip()):
        raise HTTPException(422, "A reason is mandatory when rejecting evidence.")
    o = db.get(Obligation, ev.obligation_id)
    before = snapshot(o)
    ev.status = "VERIFIED" if accept else "REJECTED"
    ev.reviewed_by, ev.reviewed_at, ev.review_reason = actor.id, now(), reason
    inst = db.get(Institution, o.institution_id)
    if accept:
        o.verification_status = "VERIFIED"
        _close(db, actor, o, "MET", f"Evidence {ev.receipt_no} verified")
        notify_institution(db, inst, "evidence_verified", ctx_for(db, o, receipt=ev.receipt_no), entity=("evidence", ev.id), key_suffix="ok")
    else:
        o.state, o.verification_status = "ACKNOWLEDGED", "REJECTED"
        notify_institution(db, inst, "evidence_rejected", ctx_for(db, o, receipt=ev.receipt_no, reason=reason),
                           entity=("evidence", ev.id), key_suffix="rej")
    audit(db, actor, "EVIDENCE_VERIFIED" if accept else "EVIDENCE_REJECTED", "obligation", o.id, before, snapshot(o) | {"receipt": ev.receipt_no}, reason)
    return ev


def _close(db: Session, actor: User | None, o: Obligation, state: str, note: str) -> None:
    clock = db.get(Clock, o.clock_id) if o.clock_id else None
    if clock and clock.state not in ("STOPPED_MET", "STOPPED_WAIVED"):
        if clock.state.startswith("PAUSED"):
            add_event(db, clock, "RESUME", actor=actor, reason="closing obligation")
        add_event(db, clock, "STOP_MET" if state == "MET" else "STOP_WAIVED", actor=actor, reason=note)
    o.state, o.completed_at, o.closure_note = state, now(), note
    o.closed_by = actor.id if actor else None
    close_for_obligation(db, o, f"obligation {state}: {note}")


def close(db: Session, actor: User, o: Obligation, outcome: str, note: str) -> Obligation:
    if outcome not in ("MET", "WAIVED", "CANCELLED"):
        raise HTTPException(422, "outcome must be MET, WAIVED or CANCELLED")
    if not note or not note.strip():
        raise HTTPException(422, "A closure note is mandatory.")
    if o.state in CLOSED:
        raise HTTPException(409, "Already closed.")
    if outcome == "MET" and o.responsible_party == "INSTITUTION" and o.verification_status != "VERIFIED":
        raise HTTPException(409, "Institution obligations close as MET only through evidence verification (or assisted evidence).")
    before = snapshot(o)
    _close(db, actor, o, outcome, note)
    audit(db, actor, f"OBLIGATION_{outcome}", "obligation", o.id, before, snapshot(o), note)
    return o


def reopen(db: Session, actor: User, o: Obligation, reason: str, extra_days: int) -> Obligation:
    if o.state not in CLOSED:
        raise HTTPException(409, "Only closed obligations can be reopened.")
    if not reason:
        raise HTTPException(422, "Reason required.")
    before = snapshot(o)
    inst = db.get(Institution, o.institution_id)
    old = db.get(Clock, o.clock_id)
    clock = create_clock(db, owner_side=o.responsible_party, label=f"{o.title[:120]} (reopened)", budget_days=max(extra_days, 1),
                         day_mode=old.day_mode if old else "CALENDAR", calendar_ids=calendars_for_institution(db, inst),
                         started_at=now(), source_rule_id=o.source_rule_id, application_id=o.application_id, actor=actor)
    o.clock_id, o.due_date, o.state, o.completed_at, o.closure_note = clock.id, clock.due_date, "OPEN", None, None
    o.verification_status = "NOT_SUBMITTED" if o.responsible_party == "INSTITUTION" else "NOT_APPLICABLE"
    o.escalation_level = 0
    audit(db, actor, "OBLIGATION_REOPENED", "obligation", o.id, before, snapshot(o) | {"previous_clock_id": old.id if old else None}, reason)
    schedule_reminders(db, o)
    return o


def extend(db: Session, actor: User, o: Obligation, days: int, reason: str) -> dict:
    _require_open(o)
    if days <= 0 or not reason:
        raise HTTPException(422, "Positive days and a reason are required for an extension.")
    before = snapshot(o)
    res = add_event(db, db.get(Clock, o.clock_id), "EXTEND", days=days, actor=actor, reason=reason)
    audit(db, actor, "OBLIGATION_EXTENDED", "obligation", o.id, before, snapshot(o), reason)
    schedule_reminders(db, o)
    return res


def pause(db: Session, actor: User | None, o: Obligation, kind: str, reason: str) -> dict:
    _require_open(o)
    before = snapshot(o)
    res = add_event(db, db.get(Clock, o.clock_id), "PAUSE", pause_kind=kind, actor=actor, reason=reason)
    o.state = "PAUSED"
    audit(db, actor, "OBLIGATION_PAUSED", "obligation", o.id, before, snapshot(o) | {"pause_kind": kind}, reason)
    return res


def resume(db: Session, actor: User | None, o: Obligation, reason: str, kind: str | None = None) -> dict:
    if o.state != "PAUSED":
        raise HTTPException(409, "Obligation is not paused.")
    before = snapshot(o)
    clock = db.get(Clock, o.clock_id)
    res = add_event(db, clock, "RESUME", pause_kind=kind, actor=actor, reason=reason)
    if not res["state"].startswith("PAUSED"):
        has_ev = db.execute(select(Evidence.id).where(Evidence.obligation_id == o.id,
                                                       Evidence.status == "RECEIVED_PENDING_VERIFICATION")).first()
        o.state = "SUBMITTED" if has_ev else ("ACKNOWLEDGED" if o.acknowledged_at else "OPEN")
        schedule_reminders(db, o)
    audit(db, actor, "OBLIGATION_RESUMED", "obligation", o.id, before, snapshot(o), reason)
    return res


EDITABLE = {"title", "description", "evidence_requirements", "priority", "responsible_role"}


def edit(db: Session, actor: User, o: Obligation, data: dict, reason: str) -> Obligation:
    bad = set(data) - EDITABLE
    if bad:
        raise HTTPException(422, f"Not editable: {', '.join(sorted(bad))}. Deadlines change only via extension/clock events.")
    before = snapshot(o)
    for k, v in data.items():
        setattr(o, k, v)
    audit(db, actor, "OBLIGATION_EDITED", "obligation", o.id, before, snapshot(o), reason)
    return o


def assign(db: Session, actor: User, o: Obligation, user_id: int, reason: str) -> Obligation:
    u = db.get(User, user_id)
    if not u or u.role in INSTITUTION_ROLES:
        raise HTTPException(422, "Assignee must be an active officer.")
    before = snapshot(o)
    o.assigned_user_id, o.assigned_post_id = u.id, u.post_id
    audit(db, actor, "OBLIGATION_ASSIGNED", "obligation", o.id, before, snapshot(o), reason)
    notify_user(db, u, "undertaking_created", ctx_for(db, o), entity=("obligation", o.id), key_suffix=f"asg{u.id}")
    return o


def override_priority(db: Session, actor: User, o: Obligation, value: float | None, reason: str) -> Obligation:
    if not reason:
        raise HTTPException(422, "A reason is required to override priority.")
    before = snapshot(o)
    o.priority_override, o.priority_override_reason = value, reason
    audit(db, actor, "PRIORITY_OVERRIDE", "obligation", o.id, before, snapshot(o), reason)
    return o


def record_assisted(db: Session, actor: User, o: Obligation, kind: str, note: str, file: StoredFile | None) -> dict:
    """Tier 3 assisted handling: OFFLINE_EVIDENCE | ASSISTED_SUBMISSION | NON_RESPONSE | CONTACT_FAILURE."""
    if not note:
        raise HTTPException(422, "Supporting notes are required.")
    if kind in ("OFFLINE_EVIDENCE", "ASSISTED_SUBMISSION"):
        ev = submit_evidence(db, actor, o, file, "OFFLINE" if kind == "OFFLINE_EVIDENCE" else "ASSISTED", note)
        return {"evidence_id": ev.id, "receipt_no": ev.receipt_no}
    if kind not in ("NON_RESPONSE", "CONTACT_FAILURE"):
        raise HTTPException(422, "Unknown assisted action")
    audit(db, actor, f"ASSISTED_{kind}", "obligation", o.id, None, {"note": note, "file_id": file.id if file else None}, note)
    if kind == "CONTACT_FAILURE":
        from app.models import InstitutionContact
        for c in db.execute(select(InstitutionContact).where(InstitutionContact.institution_id == o.institution_id)).scalars():
            if not c.verified:
                c.invalid, c.invalid_reason = True, f"officer-recorded contact failure: {note[:120]}"
    return {"recorded": kind}


# ---------------------------------------------------------------- magic links (Tier 2)
def issue_magic_link(db: Session, actor: User, o: Obligation, contact_id: int | None) -> str:
    if o.responsible_party != "INSTITUTION":
        raise HTTPException(409, "Magic links are for institution-side obligations.")
    tok = secrets.token_urlsafe(32)
    ml = MagicLink(token_hash=sha(tok), obligation_id=o.id, contact_id=contact_id, expires_at=now() + timedelta(days=7),
                   created_by=actor.id)
    db.add(ml)
    db.flush()
    from app.core.config import settings
    link = f"{settings.public_base_url}/m/{tok}"
    inst = db.get(Institution, o.institution_id)
    notify_institution(db, inst, "magic_link", ctx_for(db, o, link=link), entity=("magic_link", ml.id), key_suffix="ml")
    audit(db, actor, "MAGIC_LINK_ISSUED", "obligation", o.id, None, {"magic_link_id": ml.id, "expires_at": ml.expires_at.isoformat()})
    return link


def resolve_magic_link(db: Session, token: str, consume: bool = False) -> tuple[MagicLink, Obligation]:
    ml = db.execute(select(MagicLink).where(MagicLink.token_hash == sha(token))).scalar_one_or_none()
    if not ml:
        raise HTTPException(404, "Link not recognised.")
    if ml.expires_at < now():
        raise HTTPException(410, "This link has expired. Please ask your AICTE officer for a new one.")
    if ml.used_at:
        raise HTTPException(410, "This link has already been used. Each link is single-use.")
    ml.opened_count += 1
    if consume:
        ml.used_at = now()
    return ml, db.get(Obligation, ml.obligation_id)


def obligation_view(db: Session, o: Obligation, detail: bool = False) -> dict:
    t = today_ist()
    overdue = o.state in OPEN and o.due_date is not None and o.due_date < t
    inst = o.institution if o.institution else db.get(Institution, o.institution_id)
    d = {"id": o.id, "obl_no": o.obl_no, "institution_id": o.institution_id, "institution": inst.name if inst else None,
         "institution_synthetic": inst.is_synthetic if inst else False, "application_id": o.application_id,
         "obligation_type": o.obligation_type, "type_label": OBLIGATION_TYPES.get(o.obligation_type, o.obligation_type),
         "title": o.title, "responsible_party": o.responsible_party, "responsible_role": o.responsible_role,
         "assigned_user_id": o.assigned_user_id, "state": o.state, "display_state": "OVERDUE" if overdue else o.state,
         "due_date": o.due_date.isoformat() if o.due_date else None, "start_date": o.start_date.isoformat(),
         "days_remaining": (o.due_date - t).days if o.due_date else None, "priority": o.priority,
         "verification_status": o.verification_status, "statutory": o.statutory_flag, "escalation_level": o.escalation_level,
         "is_synthetic": o.is_synthetic, "region_id": inst.region_id if inst else None}
    if detail:
        u = db.get(User, o.assigned_user_id) if o.assigned_user_id else None
        d |= {"description": o.description, "source_event": o.source_event, "source_rule_id": o.source_rule_id,
              "source_document_id": o.source_document_id, "source_text": o.source_text,
              "evidence_requirements": o.evidence_requirements, "clock_id": o.clock_id,
              "assigned_user": u.full_name if u else None, "assigned_post_id": o.assigned_post_id,
              "created_at": o.created_at.isoformat(), "updated_at": o.updated_at.isoformat() if o.updated_at else None,
              "completed_at": o.completed_at.isoformat() if o.completed_at else None, "closure_note": o.closure_note,
              "priority_override": o.priority_override, "priority_override_reason": o.priority_override_reason,
              "acknowledged_at": o.acknowledged_at.isoformat() if o.acknowledged_at else None,
              "merged_into_id": o.merged_into_id}
        d["clock"] = explain_clock(db, db.get(Clock, o.clock_id)) if o.clock_id else None
    return d
