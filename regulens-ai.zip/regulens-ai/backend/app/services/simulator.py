"""Rule Simulator: replay a proposed parameter against stored records with the real clock engine."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import timedelta

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.engines.clock_engine import ClockEvent as EE
from app.engines.clock_engine import ClockSpec, compute
from app.models import Application, Clock, ClockEvent, Institution, Obligation, Rule
from app.services.clocks import CalendarCache, today_ist
from app.services.config import get_params, get_rule
from app.services.ledger import OPEN

SUPPORTED = ("deadline.*", "escalation.timeline", "route.assignment", "risk.thresholds")


def _events_by_clock(db: Session, clock_ids: list[int]) -> dict[int, list]:
    out = defaultdict(list)
    for i in range(0, len(clock_ids), 5000):
        for e in db.execute(select(ClockEvent).where(ClockEvent.clock_id.in_(clock_ids[i:i + 5000])).order_by(ClockEvent.clock_id, ClockEvent.seq)).scalars():
            out[e.clock_id].append(EE(e.kind, e.at, days=e.days, pause_kind=e.pause_kind, policy=e.policy))
    return out


def simulate(db: Session, rule_key: str, proposed: dict, include_closed: bool = True, max_rows: int = 20000) -> dict:
    t = today_ist()
    if rule_key.startswith("deadline."):
        return _deadline(db, rule_key, proposed, include_closed, max_rows, t)
    if rule_key == "escalation.timeline":
        return _escalation(db, proposed, t)
    if rule_key == "route.assignment":
        return _routes(db, proposed)
    if rule_key == "risk.thresholds":
        from app.models import RiskScore
        rows = db.execute(select(RiskScore.level, RiskScore.probability)).all()
        cur = Counter(l for l, _ in rows)
        new = Counter("INSUFFICIENT_DATA" if p is None else ("HIGH" if p >= proposed.get("high", 0.6) else "MEDIUM" if p >= proposed.get("medium", 0.3) else "LOW")
                      for _, p in rows)
        return {"rule_key": rule_key, "cases_affected": sum(abs(new[k] - cur[k]) for k in set(new) | set(cur)) // 2,
                "current": dict(cur), "proposed": dict(new), "method": "re-banding stored risk probabilities"}
    raise HTTPException(422, f"Simulation supports {', '.join(SUPPORTED)}")


def _deadline(db, rule_key, proposed, include_closed, max_rows, t):
    otype = rule_key.split(".", 1)[1]
    cur = get_params(db, rule_key)
    new_budget = int(proposed.get("budget_days", cur.get("budget_days", 15)))
    new_mode = proposed.get("day_mode", cur.get("day_mode", "WORKING"))
    rule_ids = list(db.execute(select(Rule.id).where(Rule.rule_key == rule_key)).scalars())
    states = list(OPEN) + ["PAUSED"] + (["MET"] if include_closed else [])
    q = (select(Obligation, Clock).join(Clock, Clock.id == Obligation.clock_id)
         .where(Obligation.obligation_type == otype, Obligation.state.in_(states), Obligation.source_rule_id.in_(rule_ids or [0]))
         .limit(max_rows))
    rows = db.execute(q).all()
    if not rows:  # stage obligations use route budgets; fall back to all obligations of the type
        rows = db.execute(select(Obligation, Clock).join(Clock, Clock.id == Obligation.clock_id)
                          .where(Obligation.obligation_type == otype, Obligation.state.in_(states)).limit(max_rows)).all()
    evs = _events_by_clock(db, [c.id for _, c in rows])
    cache = CalendarCache(db)
    changed = 0
    new_breach_open, new_breach_hist, saved_hist = 0, 0, 0
    wl_before, wl_after = Counter(), Counter()
    cases = set()
    sample = []
    delta_days = []
    for o, c in rows:
        cal = cache.get(c.calendar_ids)
        base_budget = c.budget_days
        rel = new_budget if c.source_rule_id in rule_ids or not rule_ids else base_budget + (new_budget - cur.get("budget_days", base_budget))
        old = compute(ClockSpec(c.budget_days, c.day_mode, c.revert_policy), evs[c.id], cal, t)
        nw = compute(ClockSpec(max(rel, 0), new_mode, c.revert_policy), evs[c.id], cal, t)
        if old.due_date != nw.due_date:
            changed += 1
            if o.application_id:
                cases.add(o.application_id)
            if old.due_date and nw.due_date:
                delta_days.append((nw.due_date - old.due_date).days)
            if len(sample) < 25:
                sample.append({"obl_no": o.obl_no, "state": o.state, "old_due": old.due_date.isoformat() if old.due_date else None,
                               "new_due": nw.due_date.isoformat() if nw.due_date else None})
        if o.state in OPEN:
            if old.due_date and old.due_date >= t and nw.due_date and nw.due_date < t:
                new_breach_open += 1
            if old.due_date and t <= old.due_date < t + timedelta(days=14):
                wl_before[o.assigned_user_id] += 1
            if nw.due_date and t <= nw.due_date < t + timedelta(days=14):
                wl_after[o.assigned_user_id] += 1
        elif o.state == "MET" and o.completed_at:
            done = o.completed_at.date()
            was_late = old.due_date and done > old.due_date
            now_late = nw.due_date and done > nw.due_date
            if now_late and not was_late:
                new_breach_hist += 1
            if was_late and not now_late:
                saved_hist += 1
    return {"rule_key": rule_key, "current": cur, "proposed": {"budget_days": new_budget, "day_mode": new_mode},
            "obligations_replayed": len(rows), "obligations_affected": changed, "deadlines_changed": changed,
            "cases_affected": len(cases), "stage_changes": 0,
            "potential_additional_breaches_open": new_breach_open,
            "historical_backtest": {"would_have_been_late": new_breach_hist, "would_have_been_on_time": saved_hist},
            "mean_due_shift_days": round(sum(delta_days) / len(delta_days), 2) if delta_days else 0,
            "workload_14d": {"before": sum(wl_before.values()), "after": sum(wl_after.values()),
                             "officers_with_change": sum(1 for k in set(wl_before) | set(wl_after) if wl_before[k] != wl_after[k])},
            "sample": sample, "method": "clock histories replayed with the production clock engine"}


def _escalation(db, proposed, t):
    cur = get_params(db, "escalation.timeline")["levels"]
    new = proposed.get("levels", cur)
    rows = db.execute(select(Obligation.due_date, Obligation.assigned_user_id).where(Obligation.state.in_(OPEN), Obligation.due_date < t)).all()

    def lvl(over, levels):
        return max([l["level"] for l in levels if over >= l["days_overdue"]], default=0)
    a, b = Counter(), Counter()
    diff = 0
    for due, _ in rows:
        over = (t - due).days
        la, lb = lvl(over, cur), lvl(over, new)
        a[la] += 1
        b[lb] += 1
        diff += la != lb
    return {"rule_key": "escalation.timeline", "obligations_replayed": len(rows), "obligations_affected": diff,
            "current_levels": dict(a), "proposed_levels": dict(b), "deadlines_changed": 0, "stage_changes": 0,
            "method": "overdue obligations re-levelled against the proposed timeline"}


def _routes(db, proposed):
    cur = get_params(db, "route.assignment")["map"]
    new = proposed.get("map", cur)
    rows = db.execute(select(Application.application_type, Application.status, Application.route_code)).all()
    moved = Counter()
    live = 0
    for typ, st, route in rows:
        if cur.get(typ) != new.get(typ):
            moved[(typ, cur.get(typ), new.get(typ))] += 1
            if st in ("IN_PROGRESS", "RETURNED", "AWAITING_DECISION"):
                live += 1
    return {"rule_key": "route.assignment", "obligations_replayed": len(rows), "cases_affected": sum(moved.values()),
            "stage_changes": sum(moved.values()), "live_cases_pinned": live,
            "note": "Existing cases keep their pinned configuration version; only new applications would take the new route.",
            "changes": [{"type": k[0], "from": k[1], "to": k[2], "applications": v} for k, v in moved.items()], "deadlines_changed": 0,
            "obligations_affected": 0, "method": "route rule re-applied to stored applications"}
