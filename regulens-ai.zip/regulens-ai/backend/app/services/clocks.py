"""Bridge between persisted clock histories and the pure clock engine.

A clock's due date is *always* re-derived from its event history (``recompute``); the stored
``due_date`` columns are caches refreshed after every event or calendar change.
"""
from __future__ import annotations

from datetime import date, datetime
from functools import lru_cache

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.security import now
from app.engines.clock_engine import ClockEvent as EngineEvent
from app.engines.clock_engine import ClockSpec, WorkCalendar, compute, explain, local_date
from app.models import Clock, ClockEvent, Holiday, HolidayCalendar, Institution, Obligation, Region, Rule, User
from app.services.audit import audit


def today_ist() -> date:
    return local_date(now())


# ---------------------------------------------------------------- calendars
def load_calendar(db: Session, calendar_ids: list[int]) -> WorkCalendar:
    cal = WorkCalendar.build((5, 6), {}, "none")
    if not calendar_ids:
        return cal
    cals = db.execute(select(HolidayCalendar).where(HolidayCalendar.id.in_(calendar_ids))).scalars().all()
    hol = db.execute(select(Holiday).where(Holiday.calendar_id.in_(calendar_ids))).scalars().all()
    weekend = set()
    for c in cals:
        weekend |= set(c.weekend_days or [5, 6])
    return WorkCalendar.build(weekend or (5, 6), {h.day: h.name for h in hol}, "+".join(c.code for c in cals))


class CalendarCache:
    """Per-request cache used by bulk recomputation (synthetic generation, holiday changes)."""

    def __init__(self, db: Session):
        self.db = db
        self._c: dict[tuple, WorkCalendar] = {}

    def get(self, ids: list[int]) -> WorkCalendar:
        k = tuple(sorted(ids or []))
        if k not in self._c:
            self._c[k] = load_calendar(self.db, list(k))
        return self._c[k]


def calendars_for_institution(db: Session, institution: Institution) -> list[int]:
    """AICTE Regional calendar (+ national) and the institution's state calendar."""
    ids: list[int] = []
    nat = db.execute(select(HolidayCalendar.id).where(HolidayCalendar.scope == "AICTE_NATIONAL")).scalar_one_or_none()
    if nat:
        ids.append(nat)
    reg = db.get(Region, institution.region_id)
    if reg and reg.holiday_calendar_id:
        ids.append(reg.holiday_calendar_id)
    st = db.execute(select(HolidayCalendar.id).where(HolidayCalendar.scope == "STATE", HolidayCalendar.state == institution.state)).scalar_one_or_none()
    if st:
        ids.append(st)
    return ids


# ---------------------------------------------------------------- clock lifecycle
def _events(db: Session, clock: Clock) -> list[ClockEvent]:
    return db.execute(select(ClockEvent).where(ClockEvent.clock_id == clock.id).order_by(ClockEvent.seq)).scalars().all()


def _to_engine(evs: list[ClockEvent], names: dict[int, str] | None = None) -> list[EngineEvent]:
    return [EngineEvent(e.kind, e.at, days=e.days, pause_kind=e.pause_kind, policy=e.policy,
                        actor=(names or {}).get(e.actor_id, str(e.actor_id)) if e.actor_id else None, reason=e.reason) for e in evs]


def spec_of(clock: Clock) -> ClockSpec:
    return ClockSpec(clock.budget_days, clock.day_mode, clock.revert_policy, clock.label)


def create_clock(db: Session, *, owner_side: str, label: str, budget_days: int, day_mode: str, calendar_ids: list[int],
                 started_at: datetime, revert_policy: str = "RESUME", source_rule_id: int | None = None,
                 application_id: int | None = None, actor: User | None = None, cache: CalendarCache | None = None) -> Clock:
    c = Clock(owner_side=owner_side, label=label, budget_days=budget_days, day_mode=day_mode, calendar_ids=calendar_ids,
              revert_policy=revert_policy, started_at=started_at, source_rule_id=source_rule_id, application_id=application_id)
    db.add(c)
    db.flush()
    db.add(ClockEvent(clock_id=c.id, seq=1, kind="START", at=started_at, actor_id=actor.id if actor else None,
                      reason="clock started"))
    db.flush()
    recompute(db, c, cache=cache)
    return c


def add_event(db: Session, clock: Clock, kind: str, *, at: datetime | None = None, days: int | None = None,
              pause_kind: str | None = None, policy: str | None = None, actor: User | None = None,
              reason: str | None = None) -> dict:
    """Append an event (history is never rewritten) and re-derive the due date."""
    at = at or now()
    # validate against the engine before persisting
    evs = _events(db, clock)
    candidate = _to_engine(evs) + [EngineEvent(kind, at, days=days, pause_kind=pause_kind, policy=policy)]
    compute(spec_of(clock), candidate, load_calendar(db, clock.calendar_ids), today_ist())
    seq = (evs[-1].seq if evs else 0) + 1
    db.add(ClockEvent(clock_id=clock.id, seq=seq, kind=kind, at=at, days=days, pause_kind=pause_kind, policy=policy,
                      actor_id=actor.id if actor else None, reason=reason))
    db.flush()
    res = recompute(db, clock)
    audit(db, actor, f"CLOCK_{kind}", "clock", clock.id, None,
          {"kind": kind, "days": days, "pause_kind": pause_kind, "policy": policy, "due_date": res.get("due_date"),
           "state": res["state"]}, reason)
    return res


def recompute(db: Session, clock: Clock, today: date | None = None, cache: CalendarCache | None = None) -> dict:
    cal = cache.get(clock.calendar_ids) if cache else load_calendar(db, clock.calendar_ids)
    r = compute(spec_of(clock), _to_engine(_events(db, clock)), cal, today or today_ist())
    clock.state = r.state
    clock.due_date = r.due_date
    clock.computed_at = now()
    for o in db.execute(select(Obligation).where(Obligation.clock_id == clock.id)).scalars():
        o.due_date = r.due_date  # None while paused (no deadline runs against anyone)
    return r.to_dict()


def explain_clock(db: Session, clock: Clock) -> dict:
    from app.services.audit import _iter_rows  # local import: avoid cycle
    cal = load_calendar(db, clock.calendar_ids)
    spec = spec_of(clock)
    evs = _events(db, clock)
    ids = {e.actor_id for e in evs if e.actor_id}
    names = {u.id: u.full_name for u in db.execute(select(User).where(User.id.in_(ids))).scalars()} if ids else {}
    res = compute(spec, _to_engine(evs, names), cal, today_ist())
    rule = db.get(Rule, clock.source_rule_id) if clock.source_rule_id else None
    rule_label = f"{rule.rule_key} v{rule.version} ({rule.source_type})" if rule else None
    # audit status for this clock's own entries: every CLOCK_* entry must still match its hash
    from app.engines.audit_chain import entry_hash
    from app.models import AuditLog
    rows = db.execute(select(AuditLog).where(AuditLog.entity_type == "clock", AuditLog.entity_id == str(clock.id))).scalars().all()
    ok = all(entry_hash(r.prev_hash, {
        "id": r.id, "ts": r.ts, "actor_id": r.actor_id, "actor_role": r.actor_role, "action": r.action,
        "entity_type": r.entity_type, "entity_id": r.entity_id, "before": r.before, "after": r.after, "reason": r.reason,
        "correlation_id": r.correlation_id}) == r.hash for r in rows) if rows else None
    out = explain(spec, res, rule_label, ok)
    out["calendar"] = cal.name
    out["history"] = [{"seq": e.seq, "kind": e.kind, "at": e.at.isoformat(), "days": e.days, "pause_kind": e.pause_kind,
                       "policy": e.policy, "reason": e.reason, "actor_id": e.actor_id} for e in _events(db, clock)]
    out["owner_side"] = clock.owner_side
    out["label"] = clock.label
    out["result"] = res.to_dict()
    out["source_rule_id"] = clock.source_rule_id
    return out


def recompute_for_calendar(db: Session, calendar_id: int, actor: User | None, reason: str) -> dict:
    """Holiday-calendar change -> recompute every non-stopped clock using that calendar."""
    cache = CalendarCache(db)
    changed, total = [], 0
    clocks = db.execute(select(Clock).where(Clock.calendar_ids.contains([calendar_id]),
                                            Clock.state.notin_(["STOPPED_MET", "STOPPED_WAIVED"]))).scalars().all()
    for c in clocks:
        total += 1
        before = c.due_date
        recompute(db, c, cache=cache)
        if c.due_date != before:
            changed.append({"clock_id": c.id, "before": before.isoformat() if before else None,
                            "after": c.due_date.isoformat() if c.due_date else None})
    audit(db, actor, "CALENDAR_RECOMPUTE", "holiday_calendar", calendar_id, None,
          {"clocks_checked": total, "due_dates_changed": len(changed), "sample": changed[:20]}, reason)
    return {"clocks_checked": total, "due_dates_changed": len(changed), "changes": changed[:200]}


def recompute_all_open(db: Session) -> int:
    cache = CalendarCache(db)
    n = 0
    for c in db.execute(select(Clock).where(Clock.state.notin_(["STOPPED_MET", "STOPPED_WAIVED"]))).scalars():
        recompute(db, c, cache=cache)
        n += 1
    return n
