"""Benchmark harness for the six evaluation criteria. Every number is measured from stored records or a controlled
run in this environment; nothing is asserted without a test behind it."""
from __future__ import annotations

import random
import statistics
import time
from collections import Counter
from datetime import timedelta

from sqlalchemy import func, select, text
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from app.core.security import now
from app.engines.clock_engine import ClockEvent as EE
from app.engines.clock_engine import ClockSpec, compute, compute_naive
from app.engines.workflow import stage as wf_stage
from app.models import (Application, AuditLog, BenchmarkRun, Clock, ClockEvent, Notification, Obligation, RouteTemplate,
                        ScheduledAction, User)
from app.services.audit import tamper_demo, verify
from app.services.clocks import CalendarCache, today_ist
from app.services.config import get_params


def _pct(v, p):
    if not v:
        return None
    v = sorted(v)
    return round(v[min(len(v) - 1, int(p / 100 * (len(v) - 1) + 0.5))], 3)


def workflow_accuracy(db: Session) -> dict:
    rmap = get_params(db, "route.assignment")["map"]
    rows = db.execute(select(Application.application_type, Application.route_code, Application.ground_truth_route, Application.current_stage,
                             Application.route_template_id).where(Application.ground_truth_route.is_not(None))).all()
    defs = {r.id: r.definition for r in db.execute(select(RouteTemplate)).scalars()}
    engine_ok = sum(1 for at, rc, gt, *_ in rows if rmap.get(at) == gt)
    planted = {i for i, (at, rc, gt, *_) in enumerate(rows) if rc != gt}
    flagged = {i for i, (at, rc, gt, *_) in enumerate(rows) if rc != rmap.get(at)}
    tp = len(planted & flagged)
    stage_valid = 0
    for at, rc, gt, stg, rt in rows:
        try:
            wf_stage(defs[rt], stg)
            stage_valid += 1
        except Exception:  # noqa: BLE001
            pass
    return {"applications_with_ground_truth": len(rows),
            "route_assignment_accuracy": round(engine_ok / len(rows), 4) if rows else None,
            "planted_misroutes": len(planted), "misroutes_flagged": len(flagged), "misroute_recall": round(tp / len(planted), 4) if planted else None,
            "misroute_precision": round(tp / len(flagged), 4) if flagged else None,
            "current_stage_valid_for_route": round(stage_valid / len(rows), 4) if rows else None}


def alert_timeliness(db: Session) -> dict:
    """Controlled run: enqueue reminders due now, run the scheduler + dispatcher, measure due -> delivered delay."""
    from app.workers.scheduler import claim, run_action
    from app.services.notifications import dispatch_due
    obls = db.execute(select(Obligation).where(Obligation.state == "OPEN", Obligation.due_date >= today_ist(), Obligation.is_synthetic.is_(True))
                      .limit(200)).scalars().all()
    tag = now().strftime("%Y%m%d%H%M%S")
    t0 = now()
    for o in obls:
        db.execute(insert(ScheduledAction).values(idempotency_key=f"bench-rem:{tag}:{o.id}", action_type="REMINDER", entity_type="obligation",
                                                  entity_id=o.id, payload={"due": o.due_date.isoformat(), "offset": f"bench{tag}"}, run_at=t0,
                                                  status="PENDING", attempts=0, created_at=t0))
    db.commit()
    start = time.perf_counter()
    ids = []
    while True:
        batch = claim(db, limit=100, worker="bench")
        db.commit()
        if not batch:
            break
        ids += batch
        for i in batch:
            run_action(i)
    for _ in range(5):
        dispatch_due(db, limit=2000)
        db.commit()
    elapsed = time.perf_counter() - start
    ns = db.execute(select(Notification).where(Notification.idempotency_key.like(f"%:bench{tag}:%"))).scalars().all()
    delays = [(n.delivered_at - t0).total_seconds() for n in ns if n.delivered_at]
    sent_only = sum(1 for n in ns if n.status == "SENT")
    return {"reminders_scheduled": len(obls), "actions_run": len(ids), "notifications_created": len(ns),
            "delivered": len(delays), "sent_awaiting_receipt": sent_only,
            "p50_due_to_delivered_s": _pct(delays, 50), "p95_due_to_delivered_s": _pct(delays, 95), "wall_clock_s": round(elapsed, 2),
            "note": "Measured in this environment with local channel adapters; SMS delivery receipts arrive on a later dispatcher pass."}


def deadline_reliability(db: Session, sample: int = 1500) -> dict:
    t = today_ist()
    cids = [r[0] for r in db.execute(select(Clock.id).order_by(func.random()).limit(sample)).all()]
    evs = {}
    for e in db.execute(select(ClockEvent).where(ClockEvent.clock_id.in_(cids)).order_by(ClockEvent.clock_id, ClockEvent.seq)).scalars():
        evs.setdefault(e.clock_id, []).append(EE(e.kind, e.at, days=e.days, pause_kind=e.pause_kind, policy=e.policy))
    cache = CalendarCache(db)
    agree = stored_agree = 0
    mism = []
    for c in db.execute(select(Clock).where(Clock.id.in_(cids))).scalars():
        cal = cache.get(c.calendar_ids)
        spec = ClockSpec(c.budget_days, c.day_mode, c.revert_policy)
        a = compute(spec, evs[c.id], cal, t)
        b = compute_naive(spec, evs[c.id], cal, t)
        if a.due_date == b["due_date"] and a.consumed == b["consumed"]:
            agree += 1
        elif len(mism) < 5:
            mism.append(c.id)
        if c.due_date == a.due_date or c.state.startswith("STOPPED"):
            stored_agree += 1
    due = db.execute(select(func.count()).where(ScheduledAction.action_type == "REMINDER", ScheduledAction.run_at <= now() - timedelta(minutes=5))).scalar_one()
    missed = db.execute(select(func.count()).where(ScheduledAction.action_type == "REMINDER", ScheduledAction.run_at <= now() - timedelta(minutes=5),
                                                   ScheduledAction.status.in_(["PENDING", "FAILED"]))).scalar_one()
    return {"clocks_sampled": len(cids), "engine_vs_reference_agreement": round(agree / len(cids), 4) if cids else None,
            "stored_due_date_matches_recomputation": round(stored_agree / len(cids), 4) if cids else None, "mismatch_examples": mism,
            "reminders_due": due, "reminders_missed": missed, "missed_per_100k": round(missed / due * 100000, 2) if due else 0.0}


def crash_recovery(db: Session, n: int = 60) -> dict:
    """Worker A claims actions and 'crashes' mid-run (rolled back). Leases expire; worker B recovers and completes them."""
    from app.workers.scheduler import claim, recover_expired_leases, run_action
    obls = db.execute(select(Obligation).where(Obligation.state == "OPEN", Obligation.due_date >= today_ist()).limit(n)).scalars().all()
    tag = "crash" + now().strftime("%H%M%S%f")
    t0 = now()
    for o in obls:
        db.execute(insert(ScheduledAction).values(idempotency_key=f"bench-crash:{tag}:{o.id}", action_type="REMINDER", entity_type="obligation",
                                                  entity_id=o.id, payload={"due": o.due_date.isoformat(), "offset": tag}, run_at=t0, status="PENDING",
                                                  attempts=0, created_at=t0))
    db.commit()
    keys = [f"bench-crash:{tag}:{o.id}" for o in obls]
    a_ids = []
    while True:
        b = claim(db, limit=200, worker="worker-A")
        db.commit()
        if not b:
            break
        a_ids += b
    crashed = 0
    for i in a_ids[: len(a_ids) // 2]:
        try:
            run_action(i, crash_before_commit=True)
        except SystemExit:
            crashed += 1
    for i in a_ids[len(a_ids) // 2:]:
        run_action(i)  # half completed before the "crash"
    db.execute(text("UPDATE scheduled_actions SET lease_expires_at = now() - interval '1 second' WHERE idempotency_key = ANY(:k) AND status='RUNNING'"),
               {"k": keys})
    rec = recover_expired_leases(db)
    db.commit()
    while True:
        b = claim(db, limit=200, worker="worker-B")
        db.commit()
        if not b:
            break
        for i in b:
            run_action(i)
    # replay already-DONE actions once more to prove idempotency of handlers
    for i in a_ids[len(a_ids) // 2:]:
        db.execute(text("UPDATE scheduled_actions SET status='RUNNING' WHERE id=:i"), {"i": i})
        db.commit()
        run_action(i)
    done = db.execute(select(func.count()).where(ScheduledAction.idempotency_key.in_(keys), ScheduledAction.status == "DONE")).scalar_one()
    notif = db.execute(select(Notification.idempotency_key).where(Notification.idempotency_key.like(f"%:{tag}:%"))).scalars().all()
    logical = Counter(k for k in notif)
    dup = sum(v - 1 for v in logical.values() if v > 1)
    expected_per_action = Counter(k.split(":")[2] for k in notif)  # obligation id per notification
    return {"actions": len(obls), "claimed_by_A": len(a_ids), "crashed_mid_run": crashed, "leases_recovered": rec, "completed": done,
            "missed_after_recovery": len(obls) - done, "notifications": len(notif), "duplicate_notifications": dup,
            "obligations_with_notifications": len(expected_per_action)}


def visibility(db: Session) -> dict:
    from app.services.intelligence import recompute_risk
    t0 = time.perf_counter()
    r = recompute_risk(db)
    t1 = time.perf_counter()
    from app.models import RiskScore
    top = db.execute(select(RiskScore.obligation_id).order_by(RiskScore.probability.desc().nulls_last()).limit(10)).scalars().all()
    t2 = time.perf_counter()
    planted = set(db.execute(select(Obligation.id).where(Obligation.source_event == "SYNTHETIC:PLANTED_LATE", Obligation.state.in_(["OPEN", "ACKNOWLEDGED"]))).scalars())
    overdue = set(db.execute(select(Obligation.id).where(Obligation.state.in_(["OPEN", "ACKNOWLEDGED", "SUBMITTED"]), Obligation.due_date < today_ist())).scalars())
    hi = set(db.execute(select(RiskScore.obligation_id).where(RiskScore.level == "HIGH")).scalars())
    return {"risk_recompute_s": round(t1 - t0, 2), "top10_query_ms": round((t2 - t1) * 1000, 1), "obligations_scored": r["scored"],
            "history_samples": r["history_samples"], "planted_late_obligations": len(planted),
            "planted_late_flagged_overdue": round(len(planted & overdue) / len(planted), 4) if planted else None,
            "planted_late_rated_high": round(len(planted & hi) / len(planted), 4) if planted else None, "top10": top}


def followup_reduction(db: Session) -> dict:
    p = get_params(db, "reminder.offsets")
    per = len(p.get("days_before", [])) + (1 if p.get("on_due") else 0)
    open_n = db.execute(select(func.count()).where(Obligation.state.in_(["OPEN", "ACKNOWLEDGED", "SUBMITTED", "PAUSED"]))).scalar_one()
    sys_gen = db.execute(select(func.count()).where(Notification.template_key.in_(["deadline_upcoming", "deadline_overdue", "document_expiring",
                                                                                     "escalation", "nudge", "undertaking_created", "evidence_submitted"]))).scalar_one()
    manual = db.execute(select(func.count()).where(AuditLog.action.like("ASSISTED_%"))).scalar_one()
    sched = db.execute(select(func.count()).where(ScheduledAction.action_type == "REMINDER")).scalar_one()
    baseline = open_n * per
    return {"open_obligations": open_n, "follow_ups_per_obligation_policy": per, "baseline_manual_followups": baseline,
            "system_scheduled_reminders": sched, "system_generated_notifications": sys_gen, "officer_manual_followups_recorded": manual,
            "automated_share": round(sched / (sched + manual), 4) if sched + manual else None,
            "note": "Baseline assumes each open obligation needs the configured reminder schedule by hand; see the impact calculator for hours."}


def audit_completeness(db: Session) -> dict:
    real = db.execute(select(Obligation.id).where(Obligation.is_synthetic.is_(False))).scalars().all()
    covered = set(int(x) for x in db.execute(select(AuditLog.entity_id).where(AuditLog.action == "OBLIGATION_CREATED")).scalars() if x)
    ev_total = db.execute(select(func.count()).select_from(ClockEvent).join(Clock, Clock.id == ClockEvent.clock_id).join(
        Obligation, Obligation.clock_id == Clock.id).where(Obligation.is_synthetic.is_(False), ClockEvent.kind != "START")).scalar_one()
    ev_aud = db.execute(select(func.count()).where(AuditLog.action.like("CLOCK_%"))).scalar_one()
    t0 = time.perf_counter()
    v = verify(db, "BENCHMARK")
    t1 = time.perf_counter()
    bench_user = db.execute(select(User).where(User.role == "AUDIT_OFFICER")).scalars().first()
    td = tamper_demo(db, bench_user)
    t2 = time.perf_counter()
    return {"non_synthetic_obligations": len(real), "with_creation_audit": len(set(real) & covered),
            "obligation_audit_coverage": round(len(set(real) & covered) / len(real), 4) if real else None,
            "clock_events_after_start": ev_total, "clock_audit_entries": ev_aud,
            "clock_event_audit_coverage": round(min(ev_aud, ev_total) / ev_total, 4) if ev_total else None,
            "chain_entries_verified": v.checked, "chain_ok": v.ok, "verify_s": round(t1 - t0, 2),
            "tamper_detected": td["detected"], "tamper_first_broken_id": td["verification_after"]["first_broken_id"],
            "tamper_detect_s": round(t2 - t1, 3)}


def permission_matrix(db: Session) -> dict:
    from fastapi.testclient import TestClient
    from app.main import app
    from app.services.seed import DEMO_PASSWORD
    c = TestClient(app)
    toks = {}
    for email in ["superadmin@regulens.demo", "admin@regulens.demo", "ro.south@regulens.demo", "ro.west@regulens.demo", "bureau@regulens.demo",
                  "committee@regulens.demo", "authority@regulens.demo", "principal@kaveri-demo.in", "compliance@kaveri-demo.in", "auditor@regulens.demo"]:
        r = c.post("/api/auth/login", json={"email": email, "password": DEMO_PASSWORD})
        if r.status_code == 200:
            toks[email] = r.json()["token"]
    sr_app = db.execute(text("SELECT a.id FROM applications a JOIN institutions i ON i.id=a.institution_id JOIN regions r ON r.id=i.region_id "
                             "WHERE r.code='SR' ORDER BY a.id LIMIT 1")).scalar()
    other_obl = db.execute(text("SELECT o.id FROM obligations o JOIN institutions i ON i.id=o.institution_id WHERE i.aicte_id <> 'DEMO-SR-0001' "
                                "ORDER BY o.id LIMIT 1")).scalar()
    probes = [  # (who, method, path, expected_allowed)
        ("principal@kaveri-demo.in", "GET", f"/api/ledger/{other_obl}", False),
        ("compliance@kaveri-demo.in", "GET", f"/api/ledger/{other_obl}", False),
        ("ro.west@regulens.demo", "GET", f"/api/applications/{sr_app}", False),
        ("ro.south@regulens.demo", "GET", f"/api/applications/{sr_app}", True),
        ("principal@kaveri-demo.in", "GET", "/api/admin/audit", False),
        ("auditor@regulens.demo", "GET", "/api/admin/audit", True),
        ("bureau@regulens.demo", "POST", f"/api/applications/{sr_app}/decide", False),
        ("ro.south@regulens.demo", "POST", "/api/admin/rules", False),
        ("committee@regulens.demo", "GET", "/api/dashboard", True),
        ("committee@regulens.demo", "GET", "/api/admin/users", False),
        ("principal@kaveri-demo.in", "GET", "/api/dashboard", False),
        ("auditor@regulens.demo", "POST", "/api/admin/synthetic/regenerate", False),
        ("admin@regulens.demo", "GET", "/api/admin/users", False),
        ("superadmin@regulens.demo", "GET", "/api/admin/users", True),
        ("principal@kaveri-demo.in", "GET", "/api/ledger?view=all&page_size=200", True),
        ("committee@regulens.demo", "GET", f"/api/applications/{sr_app}", None),
    ]
    results, leaks, wrong = [], 0, 0
    for who, m, path, expect in probes:
        if who not in toks:
            continue
        r = c.request(m, path, headers={"Authorization": f"Bearer {toks[who]}"}, json={} if m == "POST" else None)
        allowed = r.status_code < 400 or r.status_code == 422  # 422 = authorised but invalid body
        if who == "principal@kaveri-demo.in" and path.startswith("/api/ledger?"):
            inst = db.execute(text("SELECT id FROM institutions WHERE aicte_id='DEMO-SR-0001'")).scalar()
            foreign = [x for x in r.json().get("items", []) if x["institution_id"] != inst]
            if foreign:
                leaks += 1
        if expect is False and allowed:
            leaks += 1
        if expect is not None and allowed != expect:
            wrong += 1
        results.append({"user": who, "method": m, "path": path.split("?")[0], "status": r.status_code, "expected_allowed": expect, "allowed": allowed})
    for tok in toks.values():
        c.post("/api/auth/logout", headers={"Authorization": f"Bearer {tok}"})
    return {"probes": len(results), "unauthorised_data_leaks": leaks, "unexpected_results": wrong, "results": results}


def run_benchmark(db: Session, actor: User | None = None) -> dict:
    t0 = time.perf_counter()
    sc = {"ran_at": now().isoformat(), "environment": "local prototype (single host, local channel adapters)"}
    sc["workflow_accuracy"] = workflow_accuracy(db)
    sc["deadline_reliability"] = deadline_reliability(db)
    db.commit()
    sc["alert_timeliness"] = alert_timeliness(db)
    sc["scheduler_crash_recovery"] = crash_recovery(db)
    sc["pending_case_visibility"] = visibility(db)
    db.commit()
    sc["manual_followup_reduction"] = followup_reduction(db)
    sc["audit_completeness"] = audit_completeness(db)
    db.commit()
    sc["permission_matrix"] = permission_matrix(db)
    cr = sc["scheduler_crash_recovery"]
    sc["targets"] = {"zero_missed_scheduled_actions": cr["missed_after_recovery"] == 0 and sc["deadline_reliability"]["reminders_missed"] == 0,
                     "zero_duplicate_notifications": cr["duplicate_notifications"] == 0,
                     "zero_unauthorised_data_leaks": sc["permission_matrix"]["unauthorised_data_leaks"] == 0}
    sc["duration_s"] = round(time.perf_counter() - t0, 1)
    db.add(BenchmarkRun(scorecard=sc))
    from app.services.audit import audit
    audit(db, actor, "BENCHMARK_RUN", "system", "benchmark", None, {"targets": sc["targets"], "duration_s": sc["duration_s"]})
    return sc
