"""Reproducible synthetic data generator (fixed seed). Every record is flagged is_synthetic and named as fictional.

Target: 8 Regions, 2,000 institutions, 6,000 applications over 6 route types, ~18,000 obligations, 120 officers on
4 organisational levels, varied institutional response times, 12% non-responding institutions.
Planted faults (ground truth for the benchmark): 300 late obligations, 200 incorrect stage routings, 150 expired leases,
and two process bottlenecks (Northern Region re-scrutiny, Eastern Region EVC).
"""
from __future__ import annotations

import math
import random
from collections import Counter, defaultdict
from datetime import date, datetime, time, timedelta, timezone

from sqlalchemy import func, insert, select, text
from sqlalchemy.orm import Session

from app.core.security import hash_password, now
from app.engines.clock_engine import ClockEvent as EE
from app.engines.clock_engine import ClockSpec, compute, walk_forward
from app.engines.workflow import DEFAULT_ROUTES, main_path
from app.models import (Application, ApplicationEvent, Clock, ClockEvent, Delegation, EvcAssignment, EvcVisit, Expert, Institution,
                        InstitutionalDocument, InstitutionContact, Obligation, Post, Region, RouteTemplate, Rule, User)
from app.services.audit import audit
from app.services.clocks import CalendarCache, calendars_for_institution, today_ist
from app.services.config import get_params

IST = timezone(timedelta(hours=5, minutes=30))
FIRST = ["Aditya", "Bhavana", "Chitra", "Deepak", "Esha", "Farhan", "Gita", "Harish", "Isha", "Jayant", "Kavya", "Lokesh", "Madhu",
         "Nikhil", "Oviya", "Pranav", "Rekha", "Sanjay", "Tanvi", "Uday", "Varsha", "Yash", "Zoya", "Arjun", "Meena", "Suresh"]
LAST = ["Sharma", "Iyer", "Reddy", "Nair", "Patil", "Banerjee", "Singh", "Gupta", "Menon", "Rao", "Kulkarni", "Das", "Joshi", "Khan",
        "Pillai", "Verma", "Mehta", "Bose", "Chauhan", "Krishnan"]
INST_WORDS = ["Institute of Technology", "College of Engineering", "School of Management", "Polytechnic", "Institute of Pharmacy",
              "College of Architecture", "Engineering College", "Institute of Science & Technology"]
PLACES = ["Sundarpur", "Navgaon", "Rajnagar", "Shantipur", "Kalyanpur", "Ramgarh", "Devpur", "Chandanagar", "Hiranagar", "Suryapuram",
          "Vidyanagar", "Kamalpur", "Ganeshpur", "Lakshmipuram", "Mohanpur", "Anandpur", "Krishnapur", "Sitapur", "Madhavnagar"]
APP_TYPE_WEIGHTS = [("EXTENSION_OF_APPROVAL", 40), ("INCREASE_IN_INTAKE", 15), ("NEW_COURSE", 15), ("NEW_INSTITUTION", 10),
                    ("CHANGE_OF_SITE", 8), ("CLOSURE", 6), ("CONVERSION", 6)]
REASONS = [("MISSING_EVIDENCE", 30), ("INCOMPLETE_DOCUMENTATION", 25), ("LAND_DOCUMENT_ISSUE", 12), ("FACULTY_SHORTFALL", 12),
           ("INFRASTRUCTURE_DEFICIENCY", 9), ("FEE_MISMATCH", 6), ("AFFIDAVIT_FORMAT", 6)]
STAGE_SPEED = {"SCRUTINY": 0.85, "RESCRUTINY": 0.8, "EVC": 0.9, "SAC_SHC": 0.8, "DECISION": 0.7}


def _w(rng, pairs):
    return rng.choices([p for p, _ in pairs], weights=[w for _, w in pairs])[0]


def _dt(d: date, hour=10) -> datetime:
    return datetime.combine(d, time(hour, 0), tzinfo=IST)


def status(db: Session) -> dict:
    c = lambda m: db.execute(select(func.count()).select_from(m).where(m.is_synthetic.is_(True))).scalar_one()
    return {"institutions": c(Institution), "applications": c(Application), "obligations": c(Obligation), "officers": c(User),
            "experts": c(Expert), "evc_visits": c(EvcVisit), "documents": c(InstitutionalDocument),
            "planted": {"late_obligations": db.execute(select(func.count()).where(Obligation.source_event == "SYNTHETIC:PLANTED_LATE")).scalar_one(),
                        "misrouted_applications": db.execute(select(func.count()).where(Application.is_synthetic.is_(True),
                                                                                         Application.ground_truth_route.is_not(None),
                                                                                         Application.route_code != Application.ground_truth_route)).scalar_one(),
                        "expired_leases": db.execute(select(func.count()).where(InstitutionalDocument.is_synthetic.is_(True),
                                                                                 InstitutionalDocument.doc_type == "LEASE_DEED",
                                                                                 InstitutionalDocument.expiry_date < today_ist())).scalar_one()}}


def reset(db: Session, actor: User | None) -> dict:
    """Delete only bulk-generated synthetic records (DEMO-* institutions and real/user records are kept)."""
    inst_ids = "SELECT id FROM institutions WHERE is_synthetic AND aicte_id LIKE 'SYN-%'"
    stmts = [
        f"DELETE FROM risk_scores WHERE obligation_id IN (SELECT id FROM obligations WHERE institution_id IN ({inst_ids}))",
        f"DELETE FROM delivery_log WHERE notification_id IN (SELECT id FROM notifications WHERE institution_id IN ({inst_ids}))",
        f"DELETE FROM notifications WHERE institution_id IN ({inst_ids}) OR (entity_type='obligation' AND entity_id IN (SELECT id FROM obligations WHERE institution_id IN ({inst_ids})))",
        "DELETE FROM delivery_log WHERE notification_id IN (SELECT id FROM notifications WHERE recipient_user_id IN (SELECT id FROM users WHERE is_synthetic))",
        "DELETE FROM notifications WHERE recipient_user_id IN (SELECT id FROM users WHERE is_synthetic)",
        f"DELETE FROM escalations WHERE obligation_id IN (SELECT id FROM obligations WHERE institution_id IN ({inst_ids}))",
        f"DELETE FROM magic_links WHERE obligation_id IN (SELECT id FROM obligations WHERE institution_id IN ({inst_ids}))",
        f"DELETE FROM evidence WHERE institution_id IN ({inst_ids})",
        f"DELETE FROM evc_assignments WHERE visit_id IN (SELECT id FROM evc_visits WHERE institution_id IN ({inst_ids}))",
        "DELETE FROM evc_assignments WHERE expert_id IN (SELECT id FROM experts WHERE is_synthetic AND name LIKE '%(SYN)%')",
        f"DELETE FROM evc_visits WHERE institution_id IN ({inst_ids})",
        f"UPDATE institutional_documents SET obligation_id = NULL, previous_document_id = NULL WHERE institution_id IN ({inst_ids})",
        f"DELETE FROM institutional_documents WHERE institution_id IN ({inst_ids})",
        f"UPDATE applications SET stage_clock_id = NULL, institution_clock_id = NULL WHERE institution_id IN ({inst_ids})",
        f"DELETE FROM obligations WHERE institution_id IN ({inst_ids})",
        f"DELETE FROM clock_events WHERE clock_id IN (SELECT id FROM clocks WHERE application_id IN (SELECT id FROM applications WHERE institution_id IN ({inst_ids})) OR (application_id IS NULL AND id NOT IN (SELECT clock_id FROM obligations WHERE clock_id IS NOT NULL)))",
        f"DELETE FROM clocks WHERE application_id IN (SELECT id FROM applications WHERE institution_id IN ({inst_ids})) OR (application_id IS NULL AND id NOT IN (SELECT clock_id FROM obligations WHERE clock_id IS NOT NULL))",
        f"DELETE FROM application_events WHERE application_id IN (SELECT id FROM applications WHERE institution_id IN ({inst_ids}))",
        f"DELETE FROM applications WHERE institution_id IN ({inst_ids})",
        f"DELETE FROM institution_contacts WHERE institution_id IN ({inst_ids})",
        f"DELETE FROM files WHERE institution_id IN ({inst_ids})",
        f"DELETE FROM institutions WHERE id IN ({inst_ids})",
        "DELETE FROM experts WHERE is_synthetic AND name LIKE '%(SYN)%'",
        "DELETE FROM delegations WHERE delegate_user_id IN (SELECT id FROM users WHERE is_synthetic)",
        "UPDATE posts SET holder_user_id = NULL WHERE holder_user_id IN (SELECT id FROM users WHERE is_synthetic)",
        "DELETE FROM user_sessions WHERE user_id IN (SELECT id FROM users WHERE is_synthetic)",
        "UPDATE obligations SET assigned_user_id = NULL WHERE assigned_user_id IN (SELECT id FROM users WHERE is_synthetic)",
        "UPDATE applications SET assigned_officer_id = NULL WHERE assigned_officer_id IN (SELECT id FROM users WHERE is_synthetic)",
        "UPDATE escalations SET new_recipient_id = NULL WHERE new_recipient_id IN (SELECT id FROM users WHERE is_synthetic)",
        "UPDATE escalations SET previous_recipient_id = NULL WHERE previous_recipient_id IN (SELECT id FROM users WHERE is_synthetic)",
        "DELETE FROM users WHERE is_synthetic",
        "DELETE FROM scheduled_actions WHERE status IN ('DONE','FAILED') OR (action_type = 'REMINDER' AND entity_id NOT IN (SELECT id FROM obligations))",
    ]
    for s in stmts:
        db.execute(text(s))
    audit(db, actor, "SYNTHETIC_DATA_RESET", "system", "synthetic", None, {"scope": "institutions SYN-*, synthetic officers/experts"})
    db.flush()
    return {"ok": True}


def generate(db: Session, actor: User | None, seed: int = 20261030, scale: float = 1.0) -> dict:
    rng = random.Random(seed)
    t = today_ist()
    regions = db.execute(select(Region).order_by(Region.id)).scalars().all()
    rcode = {r.id: r.code for r in regions}
    routes = {r.code: r for r in db.execute(select(RouteTemplate).where(RouteTemplate.is_active.is_(True))).scalars()}
    route_map = get_params(db, "route.assignment")["map"]
    rules = {r.rule_key: r.id for r in db.execute(select(Rule).where(Rule.status == "EFFECTIVE")).scalars()}
    pw = hash_password("Synthetic@1234")
    cache = CalendarCache(db)

    # ---------------- officers (120) on 4 levels
    posts = db.execute(select(Post).order_by(Post.level.desc(), Post.id)).scalars().all()
    vacant_codes = {p.code for p in posts if p.holder_user_id is None}
    planned_vacant = set(rng.sample(sorted(c for c in vacant_codes if "DESK" in c or "DD" in c), 6))
    officers = []
    n_off = 0
    user_rows = []
    for p in posts:
        if p.holder_user_id or p.code in planned_vacant:
            continue
        role = "COMPETENT_AUTHORITY" if p.level == 4 else ("BUREAU_OFFICER" if p.level == 1 and rng.random() < 0.35 else "REGIONAL_OFFICER")
        user_rows.append((p, role))
    extra_needed = max(0, 120 - len(user_rows))
    user_ids_by_region = defaultdict(list)
    bureau_by_region = defaultdict(list)
    new_users = []
    for p, role in user_rows:
        n_off += 1
        nm = f"{rng.choice(FIRST)} {rng.choice(LAST)} (SYN)"
        new_users.append(dict(email=f"syn.officer{n_off:03d}@regulens.synthetic", full_name=nm, password_hash=pw, role=role,
                              region_id=p.region_id, post_id=p.id, is_synthetic=True, preferred_language="en", is_active=True,
                              failed_logins=0, totp_enabled=False, created_at=now()))
    for k in range(extra_needed):
        n_off += 1
        reg = regions[k % len(regions)]
        role = "COMMITTEE_MEMBER" if k < 8 else "BUREAU_OFFICER"
        new_users.append(dict(email=f"syn.officer{n_off:03d}@regulens.synthetic", full_name=f"{rng.choice(FIRST)} {rng.choice(LAST)} (SYN)",
                              password_hash=pw, role=role, region_id=reg.id, post_id=None, is_synthetic=True, preferred_language="en",
                              is_active=True, failed_logins=0, totp_enabled=False, created_at=now()))
    ids = db.execute(insert(User).returning(User.id, User.region_id, User.role, User.post_id, sort_by_parameter_order=True), new_users).all()
    for uid, reg, role, pid in ids:
        if pid:
            db.execute(text("UPDATE posts SET holder_user_id = :u WHERE id = :p"), {"u": uid, "p": pid})
        if role in ("REGIONAL_OFFICER", "BUREAU_OFFICER"):
            user_ids_by_region[reg].append(uid)
        if role == "BUREAU_OFFICER":
            bureau_by_region[reg].append(uid)
    # include demo officers in the pools so their dashboards have work
    for u in db.execute(select(User).where(User.is_synthetic.is_(False), User.role.in_(["REGIONAL_OFFICER", "BUREAU_OFFICER"]))).scalars():
        user_ids_by_region[u.region_id].append(u.id)
        if u.role == "BUREAU_OFFICER":
            bureau_by_region[u.region_id].append(u.id)
    # leave delegations (some active today)
    l1 = [p for p in db.execute(select(Post).where(Post.level == 1, Post.holder_user_id.is_not(None))).scalars()]
    for p in rng.sample(l1, min(5, len(l1))):
        peers = [u for u in user_ids_by_region[p.region_id] if u != p.holder_user_id]
        if peers:
            db.add(Delegation(post_id=p.id, delegate_user_id=rng.choice(peers), starts_on=t - timedelta(days=rng.randint(0, 3)),
                              ends_on=t + timedelta(days=rng.randint(3, 12)), reason="Leave (synthetic)"))
    desk_post = {r.id: db.execute(select(Post.id).where(Post.region_id == r.id, Post.level == 1).order_by(Post.id).limit(1)).scalar_one() for r in regions}

    # ---------------- institutions (2000)
    n_inst = int(2000 * scale)
    inst_rows = []
    weights = [16, 12, 12, 16, 10, 14, 12, 8]
    for k in range(n_inst):
        reg = rng.choices(regions, weights=weights[:len(regions)])[0]
        st = rng.choice(reg.states)
        tier = _w(rng, [(1, 15), (2, 50), (3, 35)])
        nonresp = rng.random() < 0.12
        resp = 0.0 if nonresp else round(min(3.0, max(0.3, rng.lognormvariate(0, 0.45))), 2)
        inst_rows.append(dict(aicte_id=f"SYN-{rcode[reg.id]}-{k + 1:05d}", name=f"{rng.choice(PLACES)} {rng.choice(INST_WORDS)} (SYN {k + 1:04d})",
                              region_id=reg.id, state=st, district=f"{rng.choice(PLACES)} district", tier=tier,
                              address="Fictional address for synthetic demonstration", lat=reg.lat + rng.uniform(-2.5, 2.5),
                              lon=reg.lon + rng.uniform(-2.5, 2.5), preferred_language=rng.choice(["en", "en", "hi", "mr", "ta"]),
                              digest_enabled=rng.random() < 0.3, responsiveness=resp, is_synthetic=True, created_at=now()))
    insts = db.execute(insert(Institution).returning(Institution.id, Institution.region_id, Institution.tier, Institution.responsiveness,
                                                     Institution.state, Institution.aicte_id, Institution.lat, Institution.lon, sort_by_parameter_order=True), inst_rows).all()
    contacts = []
    for iid, reg, tier, resp, st, aid, lat, lon in insts:
        bad = resp == 0.0 and rng.random() < 0.5
        dom = f"{aid.lower()}.{'invalid' if bad else 'example.in'}"
        contacts.append(dict(institution_id=iid, role="PRINCIPAL", name=f"Dr. {rng.choice(FIRST)} {rng.choice(LAST)} (SYN)", email=f"principal@{dom}",
                             phone=f"+9100{rng.randint(10**7, 10**8 - 1)}" if bad else f"+919{rng.randint(10**8, 10**9 - 1)}", verified=not bad, invalid=False))
        contacts.append(dict(institution_id=iid, role="COMPLIANCE", name=f"{rng.choice(FIRST)} {rng.choice(LAST)} (SYN)", email=f"compliance@{dom}",
                             phone=None, verified=not bad, invalid=False))
    db.execute(insert(InstitutionContact), contacts)
    inst_info = {i[0]: i for i in insts}
    cal_ids = {}
    for iid, reg, *_ in insts:
        key = (reg, inst_info[iid][4])
        if key not in cal_ids:
            cal_ids[key] = calendars_for_institution(db, db.get(Institution, iid))

    # ---------------- experts (160) + EVC
    experts = []
    for reg in regions:
        for k in range(20):
            experts.append(dict(name=f"Prof. {rng.choice(FIRST)} {rng.choice(LAST)} (SYN)", expertise=rng.sample(["ACADEMICS", "LABS", "CIVIL_INFRA", "LEGAL_LAND"], 2),
                                region_id=reg.id, city=reg.hq_city, lat=reg.lat + rng.uniform(-2, 2), lon=reg.lon + rng.uniform(-2, 2),
                                monthly_cap=rng.choice([3, 4, 5, 6]), unavailable_dates=[(t + timedelta(days=rng.randint(1, 60))).isoformat() for _ in range(rng.randint(0, 5))],
                                coi_institution_ids=[i[0] for i in rng.sample([x for x in insts if x[1] == reg.id], min(3, sum(1 for x in insts if x[1] == reg.id)))],
                                is_active=rng.random() > 0.05, is_synthetic=True))
    ex_ids = db.execute(insert(Expert).returning(Expert.id, Expert.region_id, sort_by_parameter_order=True), experts).all()
    experts_by_region = defaultdict(list)
    for eid, reg in ex_ids:
        experts_by_region[reg].append(eid)

    # ---------------- applications with event histories, clocks and obligations
    n_apps = int(6000 * scale)
    app_rows, plans = [], []
    misroute_idx = set(rng.sample(range(n_apps), int(200 * scale)))
    route_codes = sorted(routes)
    for k in range(n_apps):
        inst = rng.choice(insts)
        atype = _w(rng, APP_TYPE_WEIGHTS)
        truth = route_map.get(atype, "SCRUTINY_ONLY")
        route = truth
        if k in misroute_idx:
            route = rng.choice([c for c in route_codes if c != truth])
        created = t - timedelta(days=int(rng.triangular(1, 260, 40)))
        plans.append((inst, atype, route, truth, created))
        app_rows.append(dict(app_no=f"SYN-APP-{k + 1:06d}", institution_id=inst[0], application_type=atype, academic_year="2026-27",
                             route_template_id=routes[route].id, route_code=route, current_stage="SCRUTINY", status="IN_PROGRESS",
                             assigned_officer_id=rng.choice(bureau_by_region[inst[1]] or user_ids_by_region[inst[1]]),
                             stage_entered_at=_dt(created), priority=_w(rng, [("NORMAL", 80), ("HIGH", 15), ("URGENT", 5)]),
                             ground_truth_route=truth, is_synthetic=True, created_at=_dt(created), updated_at=now()))
    app_ids = [r[0] for r in db.execute(insert(Application).returning(Application.id, sort_by_parameter_order=True), app_rows).all()]

    events, clock_rows, clock_evs, obl_rows = [], [], [], []
    app_updates, evc_rows = [], []
    planted_late = 0
    target_late = int(300 * scale)
    clk = [0]

    def new_clock(label, side, budget, mode, cids, start_d, evs, aid, rule_key):
        """Compute with the real engine and stage rows; returns (local idx, ClockResult)."""
        spec = ClockSpec(budget, mode, "RESUME")
        res = compute(spec, [EE(k, _dt(d), days=dd, pause_kind=pk, policy=pol) for k, d, dd, pk, pol in evs], cache.get(cids), t)
        clk[0] += 1
        clock_rows.append(dict(owner_side=side, label=label[:150], budget_days=budget, day_mode=mode, calendar_ids=cids, revert_policy="RESUME",
                               state=res.state, started_at=_dt(start_d), due_date=res.due_date, source_rule_id=rules.get(rule_key),
                               application_id=aid, computed_at=now()))
        clock_evs.append([(i + 1, k, _dt(d), dd, pk, pol) for i, (k, d, dd, pk, pol) in enumerate(evs)])
        return len(clock_rows) - 1, res

    def add_obl(ci, res, *, iid, aid, otype, title, party, role, user, start_d, state, completed=None, source="SYNTHETIC", ack=None,
                stat=False, ver="NOT_APPLICABLE"):
        obl_rows.append(dict(obl_no=f"SYN-OBL-{len(obl_rows) + 1:06d}", institution_id=iid, application_id=aid, obligation_type=otype, title=title,
                             description="Synthetic obligation (fictional data)", responsible_role=role, responsible_party=party,
                             assigned_user_id=user, assigned_post_id=None, source_event=source, source_rule_id=None,
                             evidence_requirements=["Supporting document"] if party == "INSTITUTION" else [], start_date=start_d,
                             due_date=res.due_date, _ci=ci, state=state, priority="NORMAL", statutory_flag=stat, verification_status=ver,
                             escalation_level=0, completed_at=_dt(completed, 16) if completed else None,
                             acknowledged_at=_dt(ack) if ack else None, is_synthetic=True, created_at=_dt(start_d), updated_at=now()))

    for k, (aid, (inst, atype, route, truth, created)) in enumerate(zip(app_ids, plans)):
        iid, reg, tier, resp, st = inst[0], inst[1], inst[2], inst[3], inst[4]
        cids = cal_ids[(reg, st)]
        cal = cache.get(cids)
        defn = routes[route].definition
        stages = main_path(defn)
        officer = app_rows[k]["assigned_officer_id"]
        cur = created
        events.append(dict(application_id=aid, event_type="CREATED", to_stage=stages[0], payload={"route": route, "synthetic": True}, at=_dt(created)))
        final_status, cur_stage = None, stages[0]
        stage_clock_idx = inst_clock_idx = None
        for si, sc in enumerate(stages):
            s = next(x for x in defn["stages"] if x["code"] == sc)
            budget = s["budget_days"]
            enter = cur
            events.append(dict(application_id=aid, event_type="STAGE_ENTER", from_stage=stages[si - 1] if si else None, to_stage=sc,
                               payload={}, at=_dt(enter, 11)))
            slow = 1.0
            if sc == "EVC" and rcode[reg] == "ER":
                slow = 1.9  # planted bottleneck
            if sc in ("SCRUTINY",) and rcode[reg] == "NR":
                slow = 1.3
            ratio = rng.lognormvariate(math.log(STAGE_SPEED.get(sc, 0.85) * slow), 0.35)
            work_days = max(1, round(budget * ratio))
            evs = [("START", enter, None, None, None)]
            returned = s.get("returnable") and rng.random() < (0.32 if sc == "SCRUTINY" else 0.12) * (1.4 if tier == 3 else 1.0)
            done_d = walk_forward(enter, work_days, cal, "WORKING")
            inst_resp = None
            if returned:
                ret_d = walk_forward(enter, max(1, work_days // 2), cal, "WORKING")
                code = _w(rng, REASONS)
                events.append(dict(application_id=aid, event_type="RETURNED", from_stage=sc, to_stage=sc, reason=f"Synthetic deficiency: {code}",
                                   reason_code=code, payload={}, at=_dt(ret_d, 15)))
                evs.append(("PAUSE", ret_d, None, "INSTITUTION", None))
                resp_days = None if resp == 0.0 else max(1, round(15 * resp * rng.uniform(0.5, 1.3)))
                if resp_days is None or ret_d + timedelta(days=resp_days) > t:
                    # institution has not responded (yet): app parked with the institution
                    ci_s, r_s = new_clock(f"{sc} — SYN-APP-{k + 1:06d}", "AICTE", budget, "WORKING", cids, enter, evs, aid, "deadline.SCRUTINY_COMPLETION")
                    add_obl(ci_s, r_s, iid=iid, aid=aid, otype="SCRUTINY_COMPLETION" if sc.endswith("SCRUTINY") else "STAGE_COMPLETION",
                            title=f"{s['name']} — SYN-APP-{k + 1:06d}", party="AICTE", role=s["responsible_role"], user=officer, start_d=enter, state="PAUSED")
                    ievs = [("START", ret_d, None, None, None)]
                    ci_i, r_i = new_clock(f"Deficiency response — SYN-APP-{k + 1:06d}", "INSTITUTION", 15, "CALENDAR", cids, ret_d, ievs, aid,
                                          "deadline.DEFICIENCY_RESPONSE")
                    add_obl(ci_i, r_i, iid=iid, aid=aid, otype="DEFICIENCY_RESPONSE", title=f"Respond to deficiencies — SYN-APP-{k + 1:06d}",
                            party="INSTITUTION", role="INSTITUTION_PRINCIPAL", user=officer, start_d=ret_d, state="OPEN", ver="NOT_SUBMITTED",
                            ack=ret_d + timedelta(days=2) if resp else None)
                    stage_clock_idx, inst_clock_idx = ci_s, ci_i
                    cur_stage, final_status = sc, "RETURNED"
                    break
                resub = ret_d + timedelta(days=resp_days)
                events.append(dict(application_id=aid, event_type="RESUBMITTED", from_stage=sc, to_stage=s.get("resubmit_to") or sc, payload={},
                                   at=_dt(resub, 12)))
                ievs = [("START", ret_d, None, None, None), ("STOP_MET", resub, None, None, None)]
                ci_i, r_i = new_clock(f"Deficiency response — SYN-APP-{k + 1:06d}", "INSTITUTION", 15, "CALENDAR", cids, ret_d, ievs, aid,
                                      "deadline.DEFICIENCY_RESPONSE")
                add_obl(ci_i, r_i, iid=iid, aid=aid, otype="DEFICIENCY_RESPONSE", title=f"Respond to deficiencies — SYN-APP-{k + 1:06d}",
                        party="INSTITUTION", role="INSTITUTION_PRINCIPAL", user=officer, start_d=ret_d, state="MET", completed=resub, ver="VERIFIED")
                evs.append(("REVERT", resub, budget, None, "RESUME"))
                rs_slow = 2.2 if rcode[reg] == "NR" else 1.0  # planted re-scrutiny bottleneck
                extra = max(1, round((budget - work_days // 2) * rng.lognormvariate(math.log(0.6 * rs_slow), 0.3)))
                if s.get("resubmit_to") and s["resubmit_to"] != sc:
                    events.append(dict(application_id=aid, event_type="STAGE_ENTER", from_stage=sc, to_stage=s["resubmit_to"], payload={"via": "resubmission"},
                                       at=_dt(resub, 12)))
                done_d = walk_forward(resub, extra, cal, "WORKING")
            if done_d > t:
                ci_s, r_s = new_clock(f"{sc} — SYN-APP-{k + 1:06d}", "AICTE", budget, "WORKING", cids, enter, evs, aid, "deadline.SCRUTINY_COMPLETION")
                planted = False
                if planted_late < target_late and r_s.due_date and r_s.due_date >= t and rng.random() < 0.45:
                    planted = True  # planted fault: push this clock's start back so it is already overdue
                planted_src = "SYNTHETIC:PLANTED_LATE" if planted else "SYNTHETIC"
                if planted:
                    shift = (r_s.due_date - t).days + rng.randint(2, 20)
                    evs = [(kk, dd - timedelta(days=shift), x, pk, pol) for kk, dd, x, pk, pol in evs]
                    enter = enter - timedelta(days=shift)
                    clock_rows.pop(); clock_evs.pop()
                    ci_s, r_s = new_clock(f"{sc} — SYN-APP-{k + 1:06d}", "AICTE", budget, "WORKING", cids, enter, evs, aid, "deadline.SCRUTINY_COMPLETION")
                    planted_late += 1
                add_obl(ci_s, r_s, iid=iid, aid=aid, otype="SCRUTINY_COMPLETION" if sc.endswith("SCRUTINY") else "STAGE_COMPLETION",
                        title=f"{s['name']} — SYN-APP-{k + 1:06d}", party="AICTE", role=s["responsible_role"], user=officer, start_d=enter,
                        state="OPEN", source=planted_src, stat=bool(s.get("decision")))
                cur_stage = s.get("resubmit_to") if (returned and s.get("resubmit_to")) else sc
                final_status = "AWAITING_DECISION" if s.get("decision") else "IN_PROGRESS"
                stage_clock_idx = ci_s
                if sc == "EVC":
                    evc_rows.append((aid, iid, reg, enter, "OPEN"))
                break
            evs.append(("STOP_MET", done_d, None, None, None))
            ci_s, r_s = new_clock(f"{sc} — SYN-APP-{k + 1:06d}", "AICTE", budget, "WORKING", cids, enter, evs, aid, "deadline.SCRUTINY_COMPLETION")
            add_obl(ci_s, r_s, iid=iid, aid=aid, otype="SCRUTINY_COMPLETION" if sc.endswith("SCRUTINY") else "STAGE_COMPLETION",
                    title=f"{s['name']} — SYN-APP-{k + 1:06d}", party="AICTE", role=s["responsible_role"], user=officer, start_d=enter, state="MET",
                    completed=done_d, stat=bool(s.get("decision")))
            if sc == "EVC":
                evc_rows.append((aid, iid, reg, enter, "CLOSED"))
            if s.get("decision"):
                dec = "REJECTED" if rng.random() < 0.08 else "APPROVED"
                events.append(dict(application_id=aid, event_type="DECISION", from_stage=sc, reason="Synthetic decision record", payload={"decision": dec},
                                   at=_dt(done_d, 16)))
                final_status, cur_stage = dec, sc
                if dec == "APPROVED":
                    for u in range(1 if rng.random() < 0.7 else 0):
                        st_d = done_d + timedelta(days=rng.randint(1, 10))
                        bud = rng.choice([60, 90, 120, 180])
                        comp_ratio = rng.lognormvariate(math.log(0.75 / max(resp, 0.4)), 0.4) if resp else 9
                        comp = st_d + timedelta(days=int(bud * comp_ratio))
                        uevs = [("START", st_d, None, None, None)] + ([("STOP_MET", comp, None, None, None)] if comp <= t else [])
                        ci_u, r_u = new_clock("Approval undertaking", "INSTITUTION", bud, "CALENDAR", cids, st_d, uevs, aid, "deadline.APPROVAL_UNDERTAKING")
                        add_obl(ci_u, r_u, iid=iid, aid=aid, otype="APPROVAL_UNDERTAKING",
                                title=rng.choice(["Submit Fire Safety NOC", "Submit audited accounts", "Fill faculty vacancies and furnish list",
                                                  "Submit building stability certificate", "Submit updated land-use certificate"]),
                                party="INSTITUTION", role="INSTITUTION_PRINCIPAL", user=officer, start_d=st_d,
                                state="MET" if comp <= t else ("SUBMITTED" if rng.random() < 0.15 else "OPEN"),
                                completed=comp if comp <= t else None, stat=True, ver="VERIFIED" if comp <= t else "NOT_SUBMITTED")
                break
            cur = done_d
            if si + 1 < len(stages):
                events.append(dict(application_id=aid, event_type="STAGE_COMPLETE", from_stage=sc, to_stage=stages[si + 1], payload={}, at=_dt(done_d, 15)))
        app_updates.append((aid, cur_stage, final_status or "IN_PROGRESS", stage_clock_idx, inst_clock_idx))

    # ---------------- leases (1,500): 150 expired (planted), ~10% expiring within 90 days
    lease_insts = rng.sample(insts, min(len(insts), int(1500 * scale)))
    expired_set = set(i[0] for i in lease_insts[:int(150 * scale)])
    doc_rows, doc_obl_idx = [], []
    for inst in lease_insts:
        iid, reg, st = inst[0], inst[1], inst[4]
        if iid in expired_set:
            exp = t - timedelta(days=rng.randint(5, 200))
        elif rng.random() < 0.12:
            exp = t + timedelta(days=rng.randint(1, 90))
        else:
            exp = t + timedelta(days=rng.randint(91, 3000))
        issue = exp - timedelta(days=365 * rng.choice([5, 10, 15, 30]))
        start_d = min(t, exp - timedelta(days=90))
        # renewal obligation: due on the confirmed expiry date (calendar-day budget from start to expiry)
        ci, r = new_clock("Lease renewal", "INSTITUTION", (exp - start_d).days, "CALENDAR", cal_ids[(reg, st)], start_d,
                          [("START", start_d, None, None, None)], None, "deadline.LEASE_RENEWAL")
        add_obl(ci, r, iid=iid, aid=None, otype="LEASE_RENEWAL", title=f"Renew Lease Deed (expires {exp:%d %b %Y})", party="INSTITUTION",
                role="TRUST_SOCIETY", user=None, start_d=start_d, state="OPEN", stat=True, ver="NOT_SUBMITTED",
                source="SYNTHETIC:PLANTED_EXPIRED_LEASE" if iid in expired_set else "SYNTHETIC")
        doc_rows.append(dict(institution_id=iid, doc_type="LEASE_DEED", issue_date=issue, expiry_date=exp, ocr_status="IMPORTED",
                             verification_status="CONFIRMED", extraction_confidence=None, is_current=True, is_synthetic=True, verified_at=now(),
                             created_at=now()))
        doc_obl_idx.append(len(obl_rows) - 1)

    # ---------------- bulk insert clocks, events, obligations
    clock_ids = []
    for i in range(0, len(clock_rows), 3000):
        clock_ids += [r[0] for r in db.execute(insert(Clock).returning(Clock.id, sort_by_parameter_order=True), clock_rows[i:i + 3000]).all()]
    ce = []
    for cid, evs in zip(clock_ids, clock_evs):
        for seq, kind, at, days, pk, pol in evs:
            ce.append(dict(clock_id=cid, seq=seq, kind=kind, at=at, days=days, pause_kind=pk, policy=pol, reason="synthetic history"))
    for i in range(0, len(ce), 5000):
        db.execute(insert(ClockEvent), ce[i:i + 5000])
    # assign desk post for unassigned institution-side obligations
    for o in obl_rows:
        o["clock_id"] = clock_ids[o.pop("_ci")]
        if o["assigned_user_id"] is None:
            reg = inst_info[o["institution_id"]][1]
            pool = user_ids_by_region[reg]
            o["assigned_user_id"] = pool[o["institution_id"] % len(pool)] if pool else None
        o["source_rule_id"] = rules.get(f"deadline.{o['obligation_type']}")
    obl_ids = []
    for i in range(0, len(obl_rows), 3000):
        obl_ids += [r[0] for r in db.execute(insert(Obligation).returning(Obligation.id, sort_by_parameter_order=True), obl_rows[i:i + 3000]).all()]
    for d, oi in zip(doc_rows, doc_obl_idx):
        d["obligation_id"] = obl_ids[oi]
    for i in range(0, len(doc_rows), 3000):
        db.execute(insert(InstitutionalDocument), doc_rows[i:i + 3000])
    for i in range(0, len(events), 5000):
        db.execute(insert(ApplicationEvent), events[i:i + 5000])
    # final application state
    for aid, stg, stt, sci, ici in app_updates:
        db.execute(text("UPDATE applications SET current_stage=:s, status=:st, stage_clock_id=:c, institution_clock_id=:ic WHERE id=:a"),
                   {"s": stg, "st": stt, "c": clock_ids[sci] if sci is not None else None, "ic": clock_ids[ici] if ici is not None else None, "a": aid})

    # ---------------- EVC visits (historic closed + current mixed states) with expert assignments
    visit_rows, assign_plan = [], []
    for aid, iid, reg, enter, kind in evc_rows:
        pool = experts_by_region[reg]
        if kind == "CLOSED":
            sd = enter + timedelta(days=rng.randint(5, 15))
            visit_rows.append(dict(application_id=aid, institution_id=iid, status="CLOSED", required_expertise=["ACADEMICS", "LABS"], panel_expert_ids=[],
                                   scheduled_date=sd, visited_at=_dt(sd), report_received_at=_dt(sd + timedelta(days=2)), is_synthetic=True, created_at=_dt(enter)))
            assign_plan.append((len(visit_rows) - 1, rng.sample(pool, 3), sd))
        else:
            stt = _w(rng, [("QUEUED", 30), ("PANEL_PROPOSED", 15), ("SCHEDULED", 30), ("REPORT_PENDING", 10), ("DELAYED", 15)])
            sd = t + timedelta(days=rng.randint(2, 30)) if stt == "SCHEDULED" else (t - timedelta(days=rng.randint(3, 20)) if stt in ("REPORT_PENDING", "DELAYED") else None)
            visit_rows.append(dict(application_id=aid, institution_id=iid, status=stt, required_expertise=["ACADEMICS", "LABS"], panel_expert_ids=[],
                                   scheduled_date=sd, visited_at=_dt(sd) if stt == "REPORT_PENDING" else None,
                                   delayed_reason="Synthetic: panel member unavailable" if stt == "DELAYED" else None, is_synthetic=True, created_at=_dt(enter)))
            if sd:
                assign_plan.append((len(visit_rows) - 1, rng.sample(pool, 3), sd))
    vids = [r[0] for r in db.execute(insert(EvcVisit).returning(EvcVisit.id, sort_by_parameter_order=True), visit_rows).all()] if visit_rows else []
    asg = []
    for vi, exs, sd in assign_plan:
        db.execute(text("UPDATE evc_visits SET panel_expert_ids = CAST(:p AS jsonb) WHERE id = :v"), {"p": str(exs), "v": vids[vi]})
        for e in exs:
            asg.append(dict(visit_id=vids[vi], expert_id=e, visit_date=sd, active=True))
    if asg:
        db.execute(insert(EvcAssignment), asg)

    db.flush()
    from app.services.intelligence import refresh_mv
    db.commit()  # REFRESH CONCURRENTLY needs committed rows
    refresh_mv(db)
    counts = status(db)
    audit(db, actor, "SYNTHETIC_DATA_GENERATED", "system", "synthetic", None,
          {"seed": seed, "scale": scale, "counts": counts, "clock_rows": len(clock_rows), "application_events": len(events)})
    return counts | {"seed": seed, "clocks": len(clock_rows), "application_events": len(events), "obligations_total": len(obl_rows)}
