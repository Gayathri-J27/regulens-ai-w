"""Dashboards, Today's 10, breach forecast, capacity forecast and process mining — all from stored records."""
from __future__ import annotations

import statistics
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta

from sqlalchemy import and_, case, func, or_, select, text
from sqlalchemy.orm import Session

from app.core.permissions import INSTITUTION_ROLES
from app.core.scope import is_national
from app.core.security import now
from app.engines import priority as pr
from app.engines import risk as rk
from app.engines.workflow import main_path
from app.models import (Application, ApplicationEvent, EvcAssignment, EvcVisit, Escalation, Evidence, Expert, Institution,
                        InstitutionalDocument, Obligation, Region, RiskScore, RouteTemplate, User)
from app.services.clocks import today_ist
from app.services.config import get_params
from app.services.ledger import OPEN, obligation_view

LIVE_APP = ("IN_PROGRESS", "RETURNED", "AWAITING_DECISION", "ON_HOLD")


# ---------------------------------------------------------------- filters
def _app_filters(q, user: User, f: dict):
    q = q.join(Institution, Institution.id == Application.institution_id)
    if user.role in INSTITUTION_ROLES:
        q = q.where(Application.institution_id == user.institution_id)
    elif not is_national(user) and user.region_id:
        q = q.where(Institution.region_id == user.region_id)
    if f.get("region_id"):
        q = q.where(Institution.region_id == int(f["region_id"]))
    if f.get("state"):
        q = q.where(Institution.state == f["state"])
    if f.get("institution_id"):
        q = q.where(Application.institution_id == int(f["institution_id"]))
    if f.get("application_type"):
        q = q.where(Application.application_type == f["application_type"])
    if f.get("route_code"):
        q = q.where(Application.route_code == f["route_code"])
    if f.get("stage"):
        q = q.where(Application.current_stage == f["stage"])
    if f.get("officer_id"):
        q = q.where(Application.assigned_officer_id == int(f["officer_id"]))
    if f.get("priority"):
        q = q.where(Application.priority == f["priority"])
    if f.get("status"):
        q = q.where(Application.status == f["status"])
    if f.get("date_from"):
        q = q.where(Application.created_at >= f["date_from"])
    if f.get("date_to"):
        q = q.where(Application.created_at < date.fromisoformat(f["date_to"]) + timedelta(days=1))
    if f.get("committee_expert_id"):
        sub = select(EvcVisit.application_id).join(EvcAssignment, EvcAssignment.visit_id == EvcVisit.id).where(
            EvcAssignment.expert_id == int(f["committee_expert_id"]))
        q = q.where(Application.id.in_(sub))
    if f.get("synthetic") in ("0", "false"):
        q = q.where(Application.is_synthetic.is_(False))
    return q


def _obl_filters(q, user: User, f: dict):
    q = q.join(Institution, Institution.id == Obligation.institution_id)
    if user.role in INSTITUTION_ROLES:
        q = q.where(Obligation.institution_id == user.institution_id)
    elif not is_national(user) and user.region_id:
        q = q.where(Institution.region_id == user.region_id)
    if f.get("region_id"):
        q = q.where(Institution.region_id == int(f["region_id"]))
    if f.get("state"):
        q = q.where(Institution.state == f["state"])
    if f.get("institution_id"):
        q = q.where(Obligation.institution_id == int(f["institution_id"]))
    if f.get("officer_id"):
        q = q.where(Obligation.assigned_user_id == int(f["officer_id"]))
    if f.get("priority"):
        q = q.where(Obligation.priority == f["priority"])
    if f.get("synthetic") in ("0", "false"):
        q = q.where(Obligation.is_synthetic.is_(False))
    return q


MV_KEYS = {"region_id", "state", "route_code", "application_type", "stage", "status", "priority", "synthetic"}


def refresh_mv(db: Session) -> None:
    db.execute(text("REFRESH MATERIALIZED VIEW CONCURRENTLY mv_app_rollup"))
    db.execute(text("UPDATE mv_refresh_log SET refreshed_at = now() WHERE name = 'mv_app_rollup'"))


def dashboard(db: Session, user: User, f: dict) -> dict:
    t = today_ist()
    used_keys = {k for k, v in f.items() if v not in (None, "")}
    use_mv = used_keys <= MV_KEYS and user.role not in INSTITUTION_ROLES
    if use_mv:
        conds, params = ["1=1"], {}
        if not is_national(user) and user.region_id:
            conds.append("region_id = :ur"); params["ur"] = user.region_id
        for k, col in (("region_id", "region_id"), ("state", "state"), ("route_code", "route_code"), ("application_type", "application_type"),
                       ("stage", "current_stage"), ("status", "status"), ("priority", "priority")):
            if f.get(k):
                conds.append(f"{col} = :{k}"); params[k] = int(f[k]) if k == "region_id" else f[k]
        if f.get("synthetic") in ("0", "false"):
            conds.append("is_synthetic = false")
        w = " AND ".join(conds)
        rows = db.execute(text(f"SELECT current_stage, status, region_id, sum(n) FROM mv_app_rollup WHERE {w} GROUP BY 1,2,3"), params).all()
        refreshed = db.execute(text("SELECT refreshed_at FROM mv_refresh_log WHERE name='mv_app_rollup'")).scalar()
        source = {"applications": "materialized view mv_app_rollup", "refreshed_at": refreshed.isoformat() if refreshed else None}
    else:
        q = _app_filters(select(Application.current_stage, Application.status, Institution.region_id, func.count()), user, f)
        rows = db.execute(q.group_by(Application.current_stage, Application.status, Institution.region_id)).all()
        source = {"applications": "live query", "refreshed_at": now().isoformat()}
    total = sum(r[3] for r in rows)
    by_status = Counter()
    stage_pend = Counter()
    region_dist = Counter()
    for stg, st, reg, n in rows:
        by_status[st] += n
        region_dist[reg] += n
        if st in LIVE_APP:
            stage_pend[stg] += n

    oq = _obl_filters(select(Obligation.obligation_type, Obligation.state,
                             case((and_(Obligation.state.in_(OPEN), Obligation.due_date < t), "OVERDUE"),
                                  (and_(Obligation.state.in_(OPEN), Obligation.due_date <= t + timedelta(days=14)), "UPCOMING"),
                                  else_="OTHER"), func.count()), user, f)
    orows = db.execute(oq.group_by(Obligation.obligation_type, Obligation.state, text("3"))).all()
    overdue = sum(n for _, s, b, n in orows if b == "OVERDUE")
    upcoming = sum(n for _, s, b, n in orows if b == "UPCOMING")
    pend_comp = sum(n for ty, s, b, n in orows if ty in ("APPROVAL_UNDERTAKING", "INSTITUTIONAL_COMPLIANCE", "DEFICIENCY_RESPONSE") and s in OPEN)
    undertaking = Counter()
    for ty, s, b, n in orows:
        if ty == "APPROVAL_UNDERTAKING":
            undertaking["OVERDUE" if b == "OVERDUE" else s] += n

    dq = select(InstitutionalDocument.expiry_date).join(Institution, Institution.id == InstitutionalDocument.institution_id).where(
        InstitutionalDocument.is_current.is_(True))
    if not is_national(user) and user.region_id:
        dq = dq.where(Institution.region_id == user.region_id)
    if f.get("region_id"):
        dq = dq.where(Institution.region_id == int(f["region_id"]))
    doc_valid = Counter()
    for (exp,) in db.execute(dq).all():
        if exp is None:
            doc_valid["UNVERIFIED"] += 1
        elif exp < t:
            doc_valid["EXPIRED"] += 1
        elif exp <= t + timedelta(days=90):
            doc_valid["EXPIRING_90D"] += 1
        else:
            doc_valid["VALID"] += 1

    eq = select(func.count(func.distinct(Escalation.obligation_id))).join(Obligation, Obligation.id == Escalation.obligation_id).join(
        Institution, Institution.id == Obligation.institution_id).where(Escalation.status.in_(["OPEN", "ACKNOWLEDGED", "UNROUTABLE"]))
    if not is_national(user) and user.region_id:
        eq = eq.where(Institution.region_id == user.region_id)
    if f.get("region_id"):
        eq = eq.where(Institution.region_id == int(f["region_id"]))
    escalated = db.execute(eq).scalar_one()

    vq = select(EvcVisit.status, func.count()).join(Institution, Institution.id == EvcVisit.institution_id)
    if not is_national(user) and user.region_id:
        vq = vq.where(Institution.region_id == user.region_id)
    if f.get("region_id"):
        vq = vq.where(Institution.region_id == int(f["region_id"]))
    evc = dict(db.execute(vq.group_by(EvcVisit.status)).all())

    # upcoming deadlines by week (next 8 weeks) and overdue trend (by week the deadline was missed, last 8 weeks)
    weeks = []
    for i in range(8):
        a, b = t + timedelta(days=7 * i), t + timedelta(days=7 * i + 7)
        weeks.append((a, b))
    dq2 = _obl_filters(select(Obligation.due_date, func.count()), user, f).where(Obligation.state.in_(OPEN), Obligation.due_date >= t,
                                                                                 Obligation.due_date < t + timedelta(days=56)).group_by(Obligation.due_date)
    upc = defaultdict(int)
    for d, n in db.execute(dq2).all():
        upc[(d - t).days // 7] += n
    trend_q = _obl_filters(select(Obligation.due_date, func.count()), user, f).where(
        Obligation.due_date < t, Obligation.due_date >= t - timedelta(days=56),
        or_(Obligation.state.in_(OPEN), and_(Obligation.completed_at.is_not(None), func.date(Obligation.completed_at) > Obligation.due_date))
    ).group_by(Obligation.due_date)
    trend = defaultdict(int)
    for d, n in db.execute(trend_q).all():
        trend[(t - d).days // 7] += n

    # ageing of live applications
    aq = _app_filters(select(Application.created_at), user, f).where(Application.status.in_(LIVE_APP))
    buckets = Counter()
    for (c,) in db.execute(aq).all():
        age = (now() - c).days
        buckets["0-30" if age <= 30 else "31-60" if age <= 60 else "61-90" if age <= 90 else "90+"] += 1

    # officer workload (open obligations by assignee)
    wq = _obl_filters(select(Obligation.assigned_user_id, func.count()), user, f).where(Obligation.state.in_(OPEN),
                                                                                       Obligation.responsible_party == "AICTE").group_by(Obligation.assigned_user_id)
    wl = db.execute(wq.order_by(func.count().desc()).limit(12)).all()
    names = {u.id: u.full_name for u in db.execute(select(User).where(User.id.in_([w[0] for w in wl if w[0]]))).scalars()}
    regions = {r.id: r.code for r in db.execute(select(Region)).scalars()}

    bottleneck = max(stage_pend.items(), key=lambda kv: kv[1]) if stage_pend else None
    return {
        "as_of": t.isoformat(), "source": source, "filters": f,
        "kpis": {"total_applications": total,
                 "in_progress": sum(by_status[s] for s in LIVE_APP),
                 "completed": by_status["APPROVED"] + by_status["REJECTED"] + by_status["WITHDRAWN"] + by_status["MERGED"],
                 "pending_scrutiny": stage_pend["SCRUTINY"] + stage_pend["RESCRUTINY"], "pending_evc": stage_pend["EVC"],
                 "upcoming_deadlines_14d": upcoming, "overdue_obligations": overdue, "pending_institutional_compliance": pend_comp,
                 "expiring_documents_90d": doc_valid["EXPIRING_90D"], "expired_documents": doc_valid["EXPIRED"],
                 "escalated_cases": escalated},
        "status_breakdown": dict(by_status),
        "stage_pendency": [{"stage": k, "count": v} for k, v in sorted(stage_pend.items(), key=lambda kv: -kv[1])],
        "region_distribution": [{"region_id": k, "region": regions.get(k, str(k)), "count": v} for k, v in sorted(region_dist.items())],
        "ageing": [{"bucket": b, "count": buckets[b]} for b in ("0-30", "31-60", "61-90", "90+")],
        "upcoming_by_week": [{"week": f"W+{i}", "from": weeks[i][0].isoformat(), "count": upc[i]} for i in range(8)],
        "overdue_trend": [{"week": f"W-{i + 1}", "count": trend[i]} for i in reversed(range(8))],
        "evc_status": [{"status": k, "count": v} for k, v in evc.items()],
        "undertaking_status": [{"status": k, "count": v} for k, v in undertaking.items()],
        "document_validity": [{"status": k, "count": v} for k, v in doc_valid.items()],
        "officer_workload": [{"officer_id": w[0], "officer": names.get(w[0], "Unassigned"), "open": w[1]} for w in wl],
        "bottleneck": {"stage": bottleneck[0], "pending": bottleneck[1]} if bottleneck else None,
    }


# ---------------------------------------------------------------- Today's 10
def today10(db: Session, user: User, limit: int = 10) -> dict:
    """Single joined query (no per-row lookups); candidates capped to the 600 nearest deadlines."""
    w = get_params(db, "priority.weights")
    t = today_ist()
    esc_ids = select(Escalation.obligation_id).where(Escalation.new_recipient_id == user.id, Escalation.status.in_(["OPEN", "ACKNOWLEDGED"]))
    q = (select(Obligation, Institution.name, Institution.tier, Application.app_no)
         .join(Institution, Institution.id == Obligation.institution_id)
         .outerjoin(Application, Application.id == Obligation.application_id)
         .where(Obligation.state.in_(list(OPEN) + ["PAUSED"]),
                or_(Obligation.assigned_user_id == user.id, Obligation.id.in_(esc_ids)))
         .order_by(Obligation.due_date.asc().nulls_last()).limit(600))
    total = db.execute(select(func.count()).select_from(Obligation).where(
        Obligation.state.in_(list(OPEN) + ["PAUSED"]), or_(Obligation.assigned_user_id == user.id, Obligation.id.in_(esc_ids)))).scalar_one()
    items = []
    for o, iname, tier, app_no in db.execute(q).all():
        dtb = (o.due_date - t).days if o.due_date else None
        s = pr.score(dtb, tier, o.statutory_flag, (t - o.start_date).days, w)
        final = o.priority_override if o.priority_override is not None else s["priority"]
        items.append({"obligation_id": o.id, "obl_no": o.obl_no, "task": o.title, "institution": iname, "institution_tier": tier,
                      "application": app_no, "application_id": o.application_id,
                      "deadline": o.due_date.isoformat() if o.due_date else None, "days_remaining": dtb, "state": o.state,
                      "priority": round(final, 3), "computed_priority": s["priority"], "components": s["components"],
                      "overridden": o.priority_override is not None, "override_reason": o.priority_override_reason,
                      "why": pr.why(dtb, o.statutory_flag, tier, o.obligation_type),
                      "next_action": pr.next_action(o.obligation_type, o.state, o.responsible_party),
                      "escalated_to_me": o.assigned_user_id != user.id, "is_synthetic": o.is_synthetic})
    items.sort(key=lambda x: (-x["priority"], x["deadline"] or "9999"))
    return {"weights": w, "formula": "priority = w1×urgency + w2×tier_score + w3×statutory + w4×ageing",
            "urgency_rule": "1/max(days,0.5) if days>0; 2 + min(overdue,30)/10 if due/overdue; 0 if paused",
            "total_candidates": total, "items": items[:limit]}


# ---------------------------------------------------------------- breach forecast
def _history(db: Session) -> list[tuple]:
    rows = db.execute(select(Obligation.obligation_type, Institution.region_id, Institution.tier, Obligation.start_date,
                             Obligation.due_date, Obligation.completed_at)
                      .join(Institution, Institution.id == Obligation.institution_id)
                      .where(Obligation.state == "MET", Obligation.completed_at.is_not(None), Obligation.due_date.is_not(None))).all()
    out = []
    for ty, reg, tier, st, due, comp in rows:
        budget = max((due - st).days, 1)
        out.append((ty, reg, tier, max((comp.date() - st).days, 0) / budget))
    return out


def recompute_risk(db: Session, only_ids: list[int] | None = None) -> dict:
    t = today_ist()
    tables = rk.build(_history(db))
    th = get_params(db, "risk.thresholds")
    # institution history: miss rate and response ratio
    inst_hist = defaultdict(lambda: [0, 0])
    for iid, late in db.execute(select(Obligation.institution_id, func.date(Obligation.completed_at) > Obligation.due_date)
                                .where(Obligation.state == "MET", Obligation.responsible_party == "INSTITUTION", Obligation.due_date.is_not(None))).all():
        inst_hist[iid][0] += 1
        inst_hist[iid][1] += 1 if late else 0
    resp = defaultdict(list)
    for iid, st, due, comp in db.execute(select(Obligation.institution_id, Obligation.start_date, Obligation.due_date, Obligation.completed_at)
                                         .where(Obligation.obligation_type == "DEFICIENCY_RESPONSE", Obligation.state == "MET")).all():
        resp[iid].append(max((comp.date() - st).days, 0) / max((due - st).days, 1))
    loads = dict(db.execute(select(Obligation.assigned_user_id, func.count()).where(Obligation.state.in_(OPEN)).group_by(Obligation.assigned_user_id)).all())
    med = statistics.median([v for k, v in loads.items() if k]) if loads else None
    has_ev = set(db.execute(select(Evidence.obligation_id).distinct()).scalars())
    q = select(Obligation, Institution).join(Institution, Institution.id == Obligation.institution_id).where(
        Obligation.state.in_(OPEN), Obligation.due_date.is_not(None))
    if only_ids:
        q = q.where(Obligation.id.in_(only_ids))
    n, levels = 0, Counter()
    batch = []
    for o, inst in db.execute(q).all():
        h = inst_hist.get(inst.id)
        r = rk.estimate(tables, otype=o.obligation_type, region_id=inst.region_id, tier=inst.tier, start=o.start_date, due=o.due_date,
                        today=t, state=o.state, inst_miss_rate=(h[1] / h[0]) if h else None, inst_n=h[0] if h else 0,
                        has_evidence=o.id in has_ev or o.acknowledged_at is not None,
                        inst_response_ratio=statistics.mean(resp[inst.id]) if resp.get(inst.id) else None,
                        officer_load=loads.get(o.assigned_user_id), median_load=med, thresholds=th)
        batch.append({"obligation_id": o.id, "probability": r["probability"], "level": r["level"], "reasons": r["reasons"],
                      "sample_size": r["sample_size"], "segment": r["segment"],
                      "suggested_reminder": r.get("suggested_reminder"), "computed_at": now()})
        levels[r["level"]] += 1
        n += 1
    if batch:
        from sqlalchemy.dialects.postgresql import insert
        for i in range(0, len(batch), 2000):
            chunk = batch[i:i + 2000]
            stmt = insert(RiskScore).values(chunk)
            db.execute(stmt.on_conflict_do_update(index_elements=["obligation_id"], set_={
                k: getattr(stmt.excluded, k) for k in ("probability", "level", "reasons", "sample_size", "segment", "suggested_reminder", "computed_at")}))
    if not only_ids:  # drop scores of obligations that are no longer open
        db.execute(text("DELETE FROM risk_scores rs USING obligations o WHERE o.id = rs.obligation_id AND o.state NOT IN ('OPEN','ACKNOWLEDGED','SUBMITTED')"))
    return {"scored": n, "levels": dict(levels), "history_samples": tables["global"].n}


def forecast_list(db: Session, user: User, f: dict, limit: int = 50, offset: int = 0) -> dict:
    q = _obl_filters(select(Obligation, RiskScore).join(RiskScore, RiskScore.obligation_id == Obligation.id), user, f)
    if f.get("level"):
        q = q.where(RiskScore.level == f["level"])
    if f.get("obligation_type"):
        q = q.where(Obligation.obligation_type == f["obligation_type"])
    total = db.execute(select(func.count()).select_from(q.subquery())).scalar_one()
    rows = db.execute(q.order_by(RiskScore.probability.desc().nulls_last()).limit(limit).offset(offset)).all()
    lv = _obl_filters(select(RiskScore.level, func.count()).select_from(Obligation).join(RiskScore, RiskScore.obligation_id == Obligation.id), user, f)
    return {"total": total, "levels": dict(db.execute(lv.group_by(RiskScore.level)).all()),
            "items": [obligation_view(db, o) | {"risk": {"level": r.level, "probability": r.probability, "reasons": r.reasons,
                                                         "sample_size": r.sample_size, "segment": r.segment,
                                                         "suggested_reminder": r.suggested_reminder.isoformat() if r.suggested_reminder else None,
                                                         "computed_at": r.computed_at.isoformat()}} for o, r in rows]}


def capacity(db: Session, user: User, f: dict) -> dict:
    t = today_ist()
    q = _obl_filters(select(Obligation.assigned_user_id, Obligation.due_date), user, f).where(
        Obligation.state.in_(OPEN), Obligation.responsible_party == "AICTE", Obligation.due_date >= t, Obligation.due_date < t + timedelta(days=28))
    load = defaultdict(lambda: [0, 0, 0, 0])
    for uid, d in db.execute(q).all():
        load[uid][min((d - t).days // 7, 3)] += 1
    users = {u.id: u for u in db.execute(select(User).where(User.id.in_([k for k in load if k]))).scalars()}
    officers = [{"officer_id": k, "officer": users[k].full_name if k in users else "Unassigned", "role": users[k].role if k in users else None,
                 "region_id": users[k].region_id if k in users else None, "weeks": v, "total": sum(v)} for k, v in load.items()]
    officers.sort(key=lambda x: -x["total"])
    totals = [o["total"] for o in officers if o["officer_id"]]
    med = statistics.median(totals) if totals else 0
    suggestions = []
    by_region = defaultdict(list)
    for o in officers:
        if o["officer_id"]:
            by_region[(o["region_id"], o["role"])].append(o)
    for (reg, role), lst in by_region.items():
        lst.sort(key=lambda x: x["total"])
        if len(lst) < 2:
            continue
        lo, hi = lst[0], lst[-1]
        if hi["total"] > max(1.5 * med, 3) and hi["total"] - lo["total"] >= 4:
            move = (hi["total"] - lo["total"]) // 2
            suggestions.append({"from_officer": hi["officer"], "from_id": hi["officer_id"], "to_officer": lo["officer"], "to_id": lo["officer_id"],
                                "items": move, "reason": f"{hi['officer']} has {hi['total']} items due in 4 weeks vs {lo['total']} for a peer "
                                                          f"({role}, same Region); median is {med:.0f}.",
                                "requires": "authorised human approval — not applied automatically"})
    # committee (expert) load
    eq = select(Expert.id, Expert.name, Expert.monthly_cap, EvcAssignment.visit_date).join(EvcAssignment, EvcAssignment.expert_id == Expert.id).where(
        EvcAssignment.active.is_(True), EvcAssignment.visit_date >= t, EvcAssignment.visit_date < t + timedelta(days=28))
    ex = defaultdict(lambda: {"weeks": [0, 0, 0, 0]})
    for eid, name, cap, d in db.execute(eq).all():
        ex[eid]["name"], ex[eid]["cap"] = name, cap
        ex[eid]["weeks"][min((d - t).days // 7, 3)] += 1
    return {"as_of": t.isoformat(), "median_4w_load": med, "officers": officers[:40], "suggestions": suggestions[:20],
            "committees": [{"expert_id": k, **v} for k, v in sorted(ex.items(), key=lambda kv: -sum(kv[1]["weeks"]))[:20]]}


# ---------------------------------------------------------------- process mining
def process_mining(db: Session, user: User, f: dict) -> dict:
    aq = _app_filters(select(Application.id, Application.route_code, Institution.region_id, Application.is_synthetic), user, f)
    apps = {a: (r, reg, syn) for a, r, reg, syn in db.execute(aq).all()}
    if not apps:
        return {"empty": True}
    synthetic_share = sum(1 for v in apps.values() if v[2]) / len(apps)
    routes = {r.code: r.definition for r in db.execute(select(RouteTemplate).where(RouteTemplate.is_active.is_(True))).scalars()}
    ids = list(apps)
    evs = []
    for i in range(0, len(ids), 5000):
        evs += db.execute(select(ApplicationEvent.application_id, ApplicationEvent.event_type, ApplicationEvent.from_stage,
                                 ApplicationEvent.to_stage, ApplicationEvent.reason_code, ApplicationEvent.at)
                          .where(ApplicationEvent.application_id.in_(ids[i:i + 5000])).order_by(ApplicationEvent.application_id,
                                                                                                ApplicationEvent.at, ApplicationEvent.id)).all()
    by_app = defaultdict(list)
    for e in evs:
        by_app[e[0]].append(e)
    variants = Counter()
    conform = Counter()
    loops = Counter()
    returned = Counter()
    reasons = Counter()
    durations = defaultdict(list)
    region_dur = defaultdict(list)
    budgets = {}
    for code, d in routes.items():
        for s in d["stages"]:
            budgets[(code, s["code"])] = s["budget_days"]
    over_budget = defaultdict(float)
    t_now = now()
    for aid, lst in by_app.items():
        route, reg, _ = apps[aid]
        seq = [e[3] for e in lst if e[1] == "STAGE_ENTER"]
        variants[(route, " → ".join(seq))] += 1
        presc = main_path(routes[route]) if route in routes else []
        conform["conforming" if seq == presc[:len(seq)] else "deviating"] += 1
        enter = None
        for e in lst:
            if e[1] in ("RETURNED", "REVERTED"):
                loops[(e[2], e[3] if e[1] == "REVERTED" else "INSTITUTION")] += 1
                returned[e[2]] += 1
                if e[4]:
                    reasons[e[4]] += 1
            if e[1] == "RESUBMITTED":
                loops[("INSTITUTION", e[3])] += 1
            if e[1] == "STAGE_ENTER":
                if enter:
                    dur = (e[5] - enter[1]).total_seconds() / 86400
                    durations[enter[0]].append(dur)
                    region_dur[(reg, enter[0])].append(dur)
                    over_budget[enter[0]] += max(0.0, dur - 1.4 * budgets.get((route, enter[0]), 15))  # ~working->calendar days
                enter = (e[3], e[5])
            if e[1] in ("DECISION",) and enter:
                dur = (e[5] - enter[1]).total_seconds() / 86400
                durations[enter[0]].append(dur)
                region_dur[(reg, enter[0])].append(dur)
                enter = None
    stage_stats = []
    for s, v in durations.items():
        stage_stats.append({"stage": s, "n": len(v), "mean_days": round(statistics.mean(v), 1), "median_days": round(statistics.median(v), 1),
                            "p90_days": round(sorted(v)[int(0.9 * (len(v) - 1))], 1)})
    stage_stats.sort(key=lambda x: -x["median_days"])
    regions = {r.id: r.code for r in db.execute(select(Region)).scalars()}
    reg_table = []
    for (reg, s), v in region_dur.items():
        if len(v) >= 5:
            reg_table.append({"region_id": reg, "region": regions.get(reg), "stage": s, "n": len(v), "median_days": round(statistics.median(v), 1)})
    insights = []
    for s in {x["stage"] for x in reg_table}:
        rows = [x for x in reg_table if x["stage"] == s]
        if len(rows) < 3:
            continue
        overall = statistics.median([x["median_days"] for x in rows])
        worst = max(rows, key=lambda x: x["median_days"])
        if overall > 0 and worst["median_days"] > 1.3 * overall:
            insights.append(f"Region {worst['region']} has a median {s.lower()} duration of {worst['median_days']} days, "
                            f"{worst['median_days'] / overall:.1f}× the median across Regions ({overall:.1f} days; n={worst['n']}).")
    if reasons:
        top = reasons.most_common(2)
        insights.append("The most common recorded return reasons are " + " and ".join(f"{k.replace('_', ' ').lower()} ({v})" for k, v in top) + ".")
    if returned:
        s, n = returned.most_common(1)[0]
        insights.append(f"{s} is the most frequently returned/reverted stage ({n} times).")
    tot_over = sum(over_budget.values()) or 1
    delay = [{"stage": k, "excess_days": round(v, 1), "share": round(v / tot_over, 3)} for k, v in sorted(over_budget.items(), key=lambda kv: -kv[1])]
    if delay and delay[0]["share"] > 0:
        insights.append(f"{delay[0]['stage']} contributes {delay[0]['share']:.0%} of all time spent beyond stage budgets.")
    return {"applications": len(apps), "synthetic_share": round(synthetic_share, 3),
            "data_label": "Includes synthetic demonstration data" if synthetic_share > 0 else "Live records",
            "conformance": dict(conform),
            "variants": [{"route": r, "variant": v, "count": n, "prescribed": " → ".join(main_path(routes[r])) if r in routes else None,
                          "conforms": v == " → ".join(main_path(routes[r])[:len(v.split(' → '))]) if r in routes else None}
                         for (r, v), n in variants.most_common(25)],
            "loop_heatmap": [{"from": a, "to": b, "count": n} for (a, b), n in loops.most_common()],
            "returned_stages": [{"stage": k, "count": v} for k, v in returned.most_common()],
            "deficiency_reasons": [{"reason": k, "count": v} for k, v in reasons.most_common()],
            "stage_durations": stage_stats, "region_bottlenecks": sorted(reg_table, key=lambda x: (x["stage"], -x["median_days"])),
            "delay_contribution": delay, "insights": insights}
