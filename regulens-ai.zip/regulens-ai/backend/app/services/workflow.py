"""Application workflow service: routes, stages, returns, reverts, decisions and case exceptions."""
from __future__ import annotations

import secrets

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.permissions import INSTITUTION_ROLES
from app.core.security import now
from app.engines import workflow as wf
from app.models import (Application, ApplicationEvent, Clock, EvcVisit, Institution, Obligation, RouteTemplate, User)
from app.services import ledger
from app.services.audit import audit, snapshot
from app.services.clocks import add_event, today_ist
from app.services.config import current_config_version, get_params, pinned_params
from app.services.escalation import officer_for_institution
from app.services.notifications import notify_institution, notify_user

APP_TYPES = ["NEW_INSTITUTION", "EXTENSION_OF_APPROVAL", "INCREASE_IN_INTAKE", "NEW_COURSE", "CHANGE_OF_SITE", "CLOSURE",
             "CONVERSION"]
REASON_CODES = ["MISSING_EVIDENCE", "INCOMPLETE_DOCUMENTATION", "LAND_DOCUMENT_ISSUE", "FACULTY_SHORTFALL",
                "INFRASTRUCTURE_DEFICIENCY", "FEE_MISMATCH", "AFFIDAVIT_FORMAT", "OTHER"]


def seed_routes(db: Session) -> None:
    for code, (name, defn) in wf.DEFAULT_ROUTES.items():
        if db.execute(select(RouteTemplate.id).where(RouteTemplate.code == code)).first():
            continue
        errs = wf.validate_definition(defn)
        assert not errs, errs
        db.add(RouteTemplate(code=code, version=1, name=name, definition=defn, description=f"{name} (configurable default)"))
    db.flush()


def active_route(db: Session, code: str) -> RouteTemplate:
    r = db.execute(select(RouteTemplate).where(RouteTemplate.code == code, RouteTemplate.is_active.is_(True))
                   .order_by(RouteTemplate.version.desc()).limit(1)).scalar_one_or_none()
    if not r:
        raise HTTPException(422, f"Unknown or inactive route {code}")
    return r


def expected_route(db: Session, application_type: str, config_version_id: int | None = None) -> str | None:
    params, _ = pinned_params(db, config_version_id, "route.assignment")
    return params.get("map", {}).get(application_type)


def _event(db: Session, app: Application, kind: str, actor: User | None, *, frm=None, to=None, reason=None, code=None, payload=None):
    db.add(ApplicationEvent(application_id=app.id, event_type=kind, from_stage=frm, to_stage=to, actor_id=actor.id if actor else None,
                            reason=reason, reason_code=code, payload=payload or {}, at=now()))


def _defn(db: Session, app: Application) -> dict:
    return db.get(RouteTemplate, app.route_template_id).definition


def _competent_authority(db: Session) -> User | None:
    return db.execute(select(User).where(User.role == "COMPETENT_AUTHORITY", User.is_active.is_(True))
                      .order_by(User.is_synthetic, User.id).limit(1)).scalar_one_or_none()


def _stage_assignee(db: Session, app: Application, role: str) -> User | None:
    if role == "COMPETENT_AUTHORITY":
        return _competent_authority(db)
    if role == "BUREAU_OFFICER" and app.assigned_officer_id:
        return db.get(User, app.assigned_officer_id)
    if app.assigned_officer_id:
        u = db.get(User, app.assigned_officer_id)
        if u and u.role == role:
            return u
    return officer_for_institution(db, db.get(Institution, app.institution_id))


def current_stage_obligation(db: Session, app: Application) -> Obligation | None:
    if not app.stage_clock_id:
        return None
    return db.execute(select(Obligation).where(Obligation.clock_id == app.stage_clock_id)).scalar_one_or_none()


def register(db: Session, actor: User, *, institution_id: int, application_type: str, route_code: str | None = None,
             assigned_officer_id: int | None = None, academic_year: str = "2026-27", priority: str = "NORMAL") -> Application:
    if application_type not in APP_TYPES:
        raise HTTPException(422, f"application_type must be one of {APP_TYPES}")
    inst = db.get(Institution, institution_id)
    if not inst:
        raise HTTPException(404, "Institution not found")
    cv = current_config_version(db)
    exp = expected_route(db, application_type, cv.id)
    code = route_code or exp
    if not code:
        raise HTTPException(422, "No route configured for this application type; choose a route explicitly.")
    rt = active_route(db, code)
    n = db.execute(select(func.count(Application.id))).scalar_one() + 1
    app = Application(app_no=f"APP-{academic_year[:4]}-{n:06d}-{secrets.token_hex(2).upper()}", institution_id=inst.id,
                      application_type=application_type, academic_year=academic_year, route_template_id=rt.id, route_code=code,
                      current_stage=wf.first_stage(rt.definition), status="IN_PROGRESS",
                      assigned_officer_id=assigned_officer_id, config_version_id=cv.id, priority=priority, created_by=actor.id)
    db.add(app)
    db.flush()
    _event(db, app, "CREATED", actor, to=app.current_stage, payload={"route": code, "route_version": rt.version,
                                                                      "expected_route": exp, "config_version": cv.id})
    audit(db, actor, "APPLICATION_REGISTERED", "application", app.id, None, snapshot(app),
          None if code == exp else f"route {code} chosen explicitly (rule suggests {exp})")
    enter_stage(db, app, app.current_stage, actor)
    if assigned_officer_id:
        notify_user(db, db.get(User, assigned_officer_id), "application_assigned",
                    {"app_no": app.app_no, "institution": inst.name, "stage": app.current_stage,
                     "due": app_due(db, app)}, entity=("application", app.id), key_suffix="asg")
    return app


def app_due(db: Session, app: Application) -> str:
    c = db.get(Clock, app.stage_clock_id) if app.stage_clock_id else None
    return c.due_date.strftime("%d %b %Y") if c and c.due_date else "—"


def enter_stage(db: Session, app: Application, code: str, actor: User | None, *, budget_days: int | None = None,
                note: str = "") -> Obligation:
    defn = _defn(db, app)
    s = wf.stage(defn, code)
    assignee = _stage_assignee(db, app, s["responsible_role"])
    otype = "SCRUTINY_COMPLETION" if code in ("SCRUTINY", "RESCRUTINY") else "STAGE_COMPLETION"
    o = ledger.create_obligation(
        db, actor, institution_id=app.institution_id, application_id=app.id, obligation_type=otype,
        title=f"{s['name']} — {app.app_no}", description=f"Complete stage {s['name']} of {app.app_no}. {note}".strip(),
        responsible_role=s["responsible_role"], assigned_user_id=assignee.id if assignee else None, source_event=f"STAGE_ENTER:{code}",
        budget_days=budget_days if budget_days is not None else s["budget_days"], day_mode=s.get("day_mode", "WORKING"),
        rule_params={"revert_policy": defn.get("revert_policy", "RESUME")}, statutory=bool(s.get("decision")),
        owner_side="AICTE", notify=False)
    app.current_stage, app.stage_entered_at, app.stage_clock_id = code, now(), o.clock_id
    app.status = "AWAITING_DECISION" if s.get("decision") else "IN_PROGRESS"
    _event(db, app, "STAGE_ENTER", actor, to=code, payload={"obligation_id": o.id, "budget_days": o.due_date and s["budget_days"]})
    if code == "EVC":
        from app.services.evc import queue_visit
        queue_visit(db, app, actor)
    if assignee:
        notify_user(db, assignee, "application_assigned",
                    {"app_no": app.app_no, "institution": app.institution.name if app.institution else "", "stage": s["name"],
                     "due": o.due_date.strftime("%d %b %Y") if o.due_date else "—"},
                    entity=("application", app.id), key_suffix=f"stage-{code}-{o.id}")
    return o


def _facts(db: Session, app: Application) -> dict:
    v = db.execute(select(EvcVisit).where(EvcVisit.application_id == app.id).order_by(EvcVisit.id.desc()).limit(1)).scalar_one_or_none()
    return {"evc_report": bool(v and v.status in ("REPORT_RECEIVED", "CLOSED"))}


def _check_actor(db: Session, actor: User, app: Application, code: str):
    s = wf.stage(_defn(db, app), code)
    if s.get("decision") and actor.role != "COMPETENT_AUTHORITY":
        raise HTTPException(403, "Only the competent authority acts at the decision stage.")


def complete_stage(db: Session, actor: User, app: Application, fields: dict) -> Application:
    if app.status not in ("IN_PROGRESS",):
        raise HTTPException(409, f"Application is {app.status}; stage completion is not possible.")
    defn = _defn(db, app)
    _check_actor(db, actor, app, app.current_stage)
    try:
        t = wf.plan_complete(defn, app.current_stage, fields, _facts(db, app))
    except wf.WorkflowError as e:
        raise HTTPException(422, str(e))
    before = snapshot(app)
    o = current_stage_obligation(db, app)
    if o and o.state not in ledger.CLOSED:
        ledger._close(db, actor, o, "MET", f"Stage {t.from_stage} completed")
    _event(db, app, "STAGE_COMPLETE", actor, frm=t.from_stage, to=t.to_stage, payload={"fields": fields})
    inst = db.get(Institution, app.institution_id)
    notify_institution(db, inst, "stage_completed", {"app_no": app.app_no, "stage": t.from_stage, "next_stage": t.to_stage or "—"},
                       entity=("application", app.id), key_suffix=f"done-{t.from_stage}-{o.id if o else 0}", urgent=False)
    enter_stage(db, app, t.to_stage, actor)
    audit(db, actor, "STAGE_COMPLETED", "application", app.id, before, snapshot(app), str(fields)[:500])
    return app


def return_to_institution(db: Session, actor: User, app: Application, reason: str, reason_code: str = "OTHER",
                          response_days: int | None = None) -> Application:
    if app.status != "IN_PROGRESS":
        raise HTTPException(409, f"Application is {app.status}.")
    try:
        wf.plan_return(_defn(db, app), app.current_stage, reason)
    except wf.WorkflowError as e:
        raise HTTPException(422, str(e))
    before = snapshot(app)
    stage_o = current_stage_obligation(db, app)
    if stage_o:  # AICTE-side clock pauses: waiting for the institution does not count against the officer
        ledger.pause(db, actor, stage_o, "INSTITUTION", f"Returned to institution: {reason}")
    inst_o = ledger.create_obligation(db, actor, institution_id=app.institution_id, application_id=app.id,
                                      obligation_type="DEFICIENCY_RESPONSE", title=f"Respond to deficiencies — {app.app_no}",
                                      description=reason, source_event=f"RETURNED:{app.current_stage}",
                                      budget_days=response_days, evidence_requirements=["Deficiency response with supporting documents"],
                                      owner_side="INSTITUTION", notify=False)
    app.status, app.institution_clock_id = "RETURNED", inst_o.clock_id
    _event(db, app, "RETURNED", actor, frm=app.current_stage, to=app.current_stage, reason=reason, code=reason_code,
           payload={"institution_obligation_id": inst_o.id})
    notify_institution(db, db.get(Institution, app.institution_id), "application_returned",
                       {"app_no": app.app_no, "reason": reason, "due": inst_o.due_date.strftime("%d %b %Y") if inst_o.due_date else "—"},
                       entity=("application", app.id), key_suffix=f"ret-{inst_o.id}")
    audit(db, actor, "APPLICATION_RETURNED", "application", app.id, before, snapshot(app), reason)
    return app


def resubmit(db: Session, actor: User, app: Application, note: str = "") -> Application:
    if app.status != "RETURNED":
        raise HTTPException(409, "Only returned applications can be resubmitted.")
    if actor.role in INSTITUTION_ROLES and actor.institution_id != app.institution_id:
        raise HTTPException(403, "Not your institution's application.")
    defn = _defn(db, app)
    t = wf.plan_resubmit(defn, app.current_stage)
    before = snapshot(app)
    inst_o = db.execute(select(Obligation).where(Obligation.clock_id == app.institution_clock_id)).scalar_one_or_none()
    if inst_o and inst_o.state not in ledger.CLOSED:
        inst_o.verification_status = "VERIFIED"
        ledger._close(db, actor, inst_o, "MET", f"Institution resubmitted. {note}".strip())  # institution clock stops
    stage_o = current_stage_obligation(db, app)
    if stage_o:
        clock = db.get(Clock, stage_o.clock_id)
        target_budget = wf.stage(defn, t.to_stage)["budget_days"]
        add_event(db, clock, "REVERT", policy=t.clock_policy, days=target_budget, actor=actor,
                  reason=f"Resubmission received; AICTE clock resumes under {t.clock_policy}")
        stage_o.state = "OPEN"
        if t.to_stage != app.current_stage:
            stage_o.title = f"{wf.stage(defn, t.to_stage)['name']} — {app.app_no}"
            stage_o.obligation_type = "SCRUTINY_COMPLETION" if t.to_stage in ("SCRUTINY", "RESCRUTINY") else stage_o.obligation_type
        ledger.schedule_reminders(db, stage_o)
    _event(db, app, "RESUBMITTED", actor, frm=app.current_stage, to=t.to_stage, reason=note or None,
           payload={"clock_policy": t.clock_policy})
    if t.to_stage != app.current_stage:
        _event(db, app, "STAGE_ENTER", actor, frm=app.current_stage, to=t.to_stage, payload={"via": "resubmission"})
    app.current_stage, app.status, app.stage_entered_at = t.to_stage, "IN_PROGRESS", now()
    audit(db, actor, "APPLICATION_RESUBMITTED", "application", app.id, before, snapshot(app), note or None)
    return app


def revert(db: Session, actor: User, app: Application, target: str, reason: str) -> Application:
    if app.status not in ("IN_PROGRESS", "AWAITING_DECISION"):
        raise HTTPException(409, f"Application is {app.status}.")
    defn = _defn(db, app)
    try:
        t = wf.plan_revert(defn, app.current_stage, target, reason)
    except wf.WorkflowError as e:
        raise HTTPException(422, str(e))
    before = snapshot(app)
    cur = current_stage_obligation(db, app)
    if cur and cur.state not in ledger.CLOSED:
        ledger._close(db, actor, cur, "WAIVED", f"Reverted to {target}: {reason}")
    s = wf.stage(defn, target)
    # budget for the re-entered stage follows the route's revert policy
    if t.clock_policy == "RESTART":
        budget = s["budget_days"]
    elif t.clock_policy == "RESET_TO_STAGE_BUDGET":
        budget = s.get("revert_budget_days", s["budget_days"])
    else:  # RESUME: whatever remained on the last clock of that stage
        prev = db.execute(select(Obligation).where(Obligation.application_id == app.id, Obligation.source_event == f"STAGE_ENTER:{target}")
                          .order_by(Obligation.id.desc()).limit(1)).scalar_one_or_none()
        from app.services.clocks import explain_clock
        rem = explain_clock(db, db.get(Clock, prev.clock_id))["remaining"] if prev else s["budget_days"]
        budget = max(1, rem)
    _event(db, app, "REVERTED", actor, frm=app.current_stage, to=target, reason=reason, payload={"policy": t.clock_policy, "budget": budget})
    enter_stage(db, app, target, actor, budget_days=budget, note=f"Re-entered after revert ({t.clock_policy}).")
    if target == "EVC":
        from app.services.evc import queue_visit
        queue_visit(db, app, actor, force_new=True)
    audit(db, actor, "APPLICATION_REVERTED", "application", app.id, before, snapshot(app), reason)
    return app


def decide(db: Session, actor: User, app: Application, decision: str, note: str) -> Application:
    if actor.role != "COMPETENT_AUTHORITY":
        raise HTTPException(403, "Statutory decisions are recorded only by the competent authority.")
    if app.status != "AWAITING_DECISION":
        raise HTTPException(409, "Application is not awaiting a decision.")
    try:
        wf.plan_decide(_defn(db, app), app.current_stage, decision, note)
    except wf.WorkflowError as e:
        raise HTTPException(422, str(e))
    before = snapshot(app)
    o = current_stage_obligation(db, app)
    if o and o.state not in ledger.CLOSED:
        ledger._close(db, actor, o, "MET", f"Decision recorded: {decision}")
    app.status = "REJECTED" if decision == "REJECTED" else "APPROVED"
    app.decision, app.decision_by, app.decision_at, app.decision_note = decision, actor.id, now(), note
    _event(db, app, "DECISION", actor, frm=app.current_stage, reason=note, payload={"decision": decision})
    notify_institution(db, db.get(Institution, app.institution_id), "decision_recorded", {"app_no": app.app_no, "decision": decision},
                       entity=("application", app.id), key_suffix="decision")
    audit(db, actor, "DECISION_RECORDED", "application", app.id, before, snapshot(app), note)
    return app


def assign(db: Session, actor: User, app: Application, officer_id: int, reason: str) -> Application:
    u = db.get(User, officer_id)
    if not u or u.role not in ("BUREAU_OFFICER", "REGIONAL_OFFICER"):
        raise HTTPException(422, "Assignee must be a Bureau or Regional officer.")
    before = snapshot(app)
    app.assigned_officer_id = u.id
    o = current_stage_obligation(db, app)
    if o and o.state not in ledger.CLOSED and wf.stage(_defn(db, app), app.current_stage)["responsible_role"] in (u.role, "BUREAU_OFFICER"):
        ledger.assign(db, actor, o, u.id, reason or "application reassigned")
    _event(db, app, "ASSIGNED", actor, frm=app.current_stage, to=app.current_stage, reason=reason, payload={"officer_id": u.id})
    notify_user(db, u, "application_assigned", {"app_no": app.app_no, "institution": app.institution.name, "stage": app.current_stage,
                                                "due": app_due(db, app)}, entity=("application", app.id), key_suffix=f"asg{u.id}-{now().timestamp():.0f}")
    audit(db, actor, "APPLICATION_ASSIGNED", "application", app.id, before, snapshot(app), reason)
    return app


# ---------------------------------------------------------------- exceptions
def _open_obligations(db: Session, app_id: int) -> list[Obligation]:
    return db.execute(select(Obligation).where(Obligation.application_id == app_id,
                                               Obligation.state.in_(list(ledger.OPEN) + ["PAUSED"]))).scalars().all()


def withdraw(db: Session, actor: User, app: Application, reason: str) -> dict:
    if app.status in ("APPROVED", "REJECTED", "WITHDRAWN", "MERGED"):
        raise HTTPException(409, f"Application already {app.status}.")
    before = snapshot(app)
    n = 0
    for o in _open_obligations(db, app.id):
        ledger._close(db, actor, o, "CANCELLED", f"Application withdrawn: {reason}")
        n += 1
    app.status = "WITHDRAWN"
    _event(db, app, "EXCEPTION", actor, frm=app.current_stage, reason=reason, code="WITHDRAWN")
    audit(db, actor, "APPLICATION_WITHDRAWN", "application", app.id, before, snapshot(app), reason)
    return {"cancelled_obligations": n}


def merge(db: Session, actor: User, app: Application, primary_id: int, reason: str) -> dict:
    primary = db.get(Application, primary_id)
    if not primary or primary.id == app.id or primary.institution_id != app.institution_id:
        raise HTTPException(422, "Primary must be a different application of the same institution.")
    before = snapshot(app)
    moved, deduped = 0, 0
    prim_titles = {(o.obligation_type, o.title.split(" — ")[0]) for o in _open_obligations(db, primary.id)}
    for o in _open_obligations(db, app.id):
        key = (o.obligation_type, o.title.split(" — ")[0])
        if o.obligation_type in ("STAGE_COMPLETION", "SCRUTINY_COMPLETION") or key in prim_titles:
            ledger._close(db, actor, o, "MERGED", f"Duplicate of {primary.app_no}")
            target = db.execute(select(Obligation).where(Obligation.application_id == primary.id, Obligation.obligation_type == o.obligation_type)
                                .limit(1)).scalar_one_or_none()
            o.merged_into_id = target.id if target else None
            deduped += 1
        else:
            o.application_id = primary.id  # re-parent
            moved += 1
            audit(db, actor, "OBLIGATION_REPARENTED", "obligation", o.id, {"application_id": app.id}, {"application_id": primary.id}, reason)
    app.status, app.merged_into_id = "MERGED", primary.id
    _event(db, app, "EXCEPTION", actor, reason=reason, code="MERGED", payload={"primary": primary.id})
    audit(db, actor, "APPLICATION_MERGED", "application", app.id, before, snapshot(app), reason)
    return {"reparented": moved, "deduplicated": deduped, "primary": primary.app_no}


def appeal(db: Session, actor: User, app: Application, reason: str, pause_parent: bool = True) -> Application:
    if app.status not in ("REJECTED", "APPROVED", "IN_PROGRESS", "RETURNED", "AWAITING_DECISION"):
        raise HTTPException(409, f"Cannot appeal an application that is {app.status}.")
    child = register(db, actor, institution_id=app.institution_id, application_type=app.application_type,
                     route_code=app.route_code if app.route_code != "SCRUTINY_ONLY" else "SCRUTINY_ONLY", academic_year=app.academic_year)
    child.parent_application_id = app.id
    paused = 0
    if pause_parent:
        for o in _open_obligations(db, app.id):
            if o.state != "PAUSED":
                ledger.pause(db, actor, o, "LEGAL_HOLD", f"Appeal {child.app_no} pending: {reason}")
                paused += 1
    _event(db, app, "EXCEPTION", actor, reason=reason, code="APPEAL", payload={"child": child.id, "paused": paused})
    audit(db, actor, "APPEAL_FILED", "application", app.id, None, {"child_application": child.id, "paused_obligations": paused}, reason)
    return child


def legal_hold(db: Session, actor: User, app: Application, reason: str, order_file_id: int | None, lift: bool = False) -> dict:
    if not order_file_id and not lift:
        raise HTTPException(422, "Attach the court order to place a hold.")
    n = 0
    before = snapshot(app)
    for o in _open_obligations(db, app.id):
        if lift and o.state == "PAUSED":
            ledger.resume(db, actor, o, f"Legal hold lifted: {reason}", kind="LEGAL_HOLD")
            n += 1
        elif not lift:
            ledger.pause(db, actor, o, "LEGAL_HOLD", f"Court-ordered hold: {reason}")
            n += 1
    if not lift:
        app.status = "ON_HOLD"
    else:
        app.status = "RETURNED" if app.institution_clock_id and any(
            o.obligation_type == "DEFICIENCY_RESPONSE" and o.state in ledger.OPEN for o in _open_obligations(db, app.id)) else (
            "AWAITING_DECISION" if app.current_stage == "DECISION" else "IN_PROGRESS")
    _event(db, app, "EXCEPTION", actor, reason=reason, code="LEGAL_HOLD_LIFTED" if lift else "LEGAL_HOLD",
           payload={"order_file_id": order_file_id, "obligations": n})
    audit(db, actor, "LEGAL_HOLD_LIFTED" if lift else "LEGAL_HOLD_PLACED", "application", app.id, before, snapshot(app) | {"order_file_id": order_file_id}, reason)
    return {"obligations_affected": n}


def app_view(db: Session, a: Application, detail: bool = False) -> dict:
    inst = a.institution
    d = {"id": a.id, "app_no": a.app_no, "institution_id": a.institution_id, "institution": inst.name if inst else None,
         "region_id": inst.region_id if inst else None, "state": inst.state if inst else None, "application_type": a.application_type,
         "route_code": a.route_code, "current_stage": a.current_stage, "status": a.status, "assigned_officer_id": a.assigned_officer_id,
         "stage_entered_at": a.stage_entered_at.isoformat() if a.stage_entered_at else None, "created_at": a.created_at.isoformat(),
         "priority": a.priority, "decision": a.decision, "is_synthetic": a.is_synthetic, "academic_year": a.academic_year,
         "age_days": (now() - a.created_at).days}
    if detail:
        rt = db.get(RouteTemplate, a.route_template_id)
        exp = expected_route(db, a.application_type, a.config_version_id)
        stage_o = current_stage_obligation(db, a)
        evs = db.execute(select(ApplicationEvent).where(ApplicationEvent.application_id == a.id).order_by(ApplicationEvent.at, ApplicationEvent.id)).scalars().all()
        officer = db.get(User, a.assigned_officer_id) if a.assigned_officer_id else None
        d |= {"route": {"code": rt.code, "version": rt.version, "name": rt.name, "definition": rt.definition},
              "expected_route": exp, "route_mismatch": bool(exp and exp != a.route_code),
              "config_version_id": a.config_version_id, "assigned_officer": officer.full_name if officer else None,
              "stage_obligation": ledger.obligation_view(db, stage_o) if stage_o else None,
              "decision_note": a.decision_note, "parent_application_id": a.parent_application_id, "merged_into_id": a.merged_into_id,
              "events": [{"id": e.id, "type": e.event_type, "from": e.from_stage, "to": e.to_stage, "actor_id": e.actor_id,
                          "reason": e.reason, "reason_code": e.reason_code, "at": e.at.isoformat(), "payload": e.payload} for e in evs],
              "obligations": [ledger.obligation_view(db, o) for o in db.execute(select(Obligation).where(Obligation.application_id == a.id)
                                                                                 .order_by(Obligation.id)).scalars()],
              "allowed_reverts": (rt.definition.get("revert_targets") or {}).get(a.current_stage, []),
              "stage_def": wf.stage(rt.definition, a.current_stage)}
        v = db.execute(select(EvcVisit).where(EvcVisit.application_id == a.id).order_by(EvcVisit.id.desc()).limit(1)).scalar_one_or_none()
        d["evc_visit_id"] = v.id if v else None
        d["evc_status"] = v.status if v else None
    return d
