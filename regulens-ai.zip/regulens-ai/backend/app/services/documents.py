"""Approval-letter extraction jobs and institutional document validity (lease etc.)."""
from __future__ import annotations

from datetime import date

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import now
from app.engines import extraction as ex
from app.engines import ocr
from app.models import (Evidence, ExtractionItem, ExtractionJob, Institution, InstitutionalDocument, Obligation, StoredFile, User)
from app.services import ledger
from app.services.audit import audit, snapshot
from app.services.clocks import today_ist
from app.services.files import read

KIND_TO_TYPE = {"UNDERTAKING": "APPROVAL_UNDERTAKING", "CONDITION": "APPROVAL_UNDERTAKING", "REQUIRED_DOCUMENT": "INSTITUTIONAL_COMPLIANCE",
                "SUBMISSION_DEADLINE": "INSTITUTIONAL_COMPLIANCE", "RENEWAL": "DOCUMENT_RENEWAL"}


# ---------------------------------------------------------------- approval letter -> proposals
def run_extraction(db: Session, actor: User, f: StoredFile, institution_id: int, application_id: int | None,
                   letter_date: date | None) -> ExtractionJob:
    data = read(f)
    log = [f"file {f.filename} sha256={f.sha256[:12]}… scan={f.scan_engine}"]
    try:
        tx = ocr.extract_text(data, f.mime)
    except RuntimeError as e:
        raise HTTPException(500, f"Text extraction failed: {e}")
    text = tx["text"]
    log.append(f"text via {tx['method']} ({len(text)} chars, {tx['pages']} page(s))")
    if not letter_date:
        ds = ocr.parse_dates(text[:600])
        letter_date = ds[0][0] if ds else None
        log.append(f"letter date inferred from header: {letter_date}" if letter_date else "letter date not found; relative deadlines stay unresolved")
    extractor = "LOCAL_RULE_BASED (no LLM)"
    raw: list[dict] = []
    if settings.llm_provider == "anthropic" and settings.anthropic_api_key:
        try:
            raw = ex.llm_extract(text, settings.anthropic_api_key, settings.anthropic_model)
            extractor = f"LLM anthropic:{settings.anthropic_model}"
        except Exception as e:  # noqa: BLE001 — LLM unavailability must not stop the workflow
            log.append(f"LLM unavailable ({type(e).__name__}); fell back to local rule-based extractor")
            raw = ex.local_extract(text, letter_date)
    else:
        raw = ex.local_extract(text, letter_date)
    ok, rejected = ex.validate_and_verify(raw, text, letter_date)
    log.append(f"{len(raw)} candidate(s); {len(ok)} passed schema + source-sentence verification; {len(rejected)} rejected")
    for r in rejected:
        log.append(f"REJECTED: {r['reason']} :: {str(r['item'].get('source_sentence', ''))[:90]}")
    job = ExtractionJob(file_id=f.id, application_id=application_id, institution_id=institution_id, letter_date=letter_date,
                        text_method=tx["method"], extractor=extractor, status="REVIEW", full_text=text, rejected_count=len(rejected),
                        log=log, created_by=actor.id)
    db.add(job)
    db.flush()
    for it in ok:
        db.add(ExtractionItem(job_id=job.id, kind=it["kind"], title=it["title"], description="", source_sentence=it["source_sentence"],
                              source_offset=it["source_offset"], due_text=it["due_text"], due_date=it["due_date"],
                              responsible_role=it["responsible_role"], evidence_requirement=it["evidence_requirement"],
                              obligation_type=KIND_TO_TYPE[it["kind"]], confidence=it["confidence"]))
    db.flush()
    audit(db, actor, "EXTRACTION_RUN", "extraction_job", job.id, None,
          {"extractor": extractor, "proposed": len(ok), "rejected": len(rejected), "text_method": tx["method"], "file_id": f.id})
    return job


def review_item(db: Session, actor: User, item: ExtractionItem, action: str, edits: dict | None, reason: str | None) -> ExtractionItem:
    job = db.get(ExtractionJob, item.job_id)
    if item.status != "PROPOSED":
        raise HTTPException(409, f"Item already {item.status}.")
    before = snapshot(item)
    if action == "reject":
        if not reason:
            raise HTTPException(422, "A rejection reason is required.")
        item.status, item.reject_reason, item.reviewed_by = "REJECTED", reason, actor.id
        audit(db, actor, "EXTRACTION_ITEM_REJECTED", "extraction_item", item.id, before, snapshot(item), reason)
        return item
    if action != "accept":
        raise HTTPException(422, "action must be accept or reject")
    for k in ("title", "description", "due_date", "responsible_role", "evidence_requirement", "obligation_type"):
        if edits and k in edits and edits[k] not in (None, ""):
            v = edits[k]
            if k == "due_date" and isinstance(v, str):
                v = date.fromisoformat(v)
            if getattr(item, k) != v:
                setattr(item, k, v)
                item.edited = True
    if not item.due_date:
        raise HTTPException(422, "A confirmed due date is required before the obligation can be created (the system never invents one).")
    start = job.letter_date or today_ist()
    if item.due_date < start:
        start = min(start, today_ist())
    o = ledger.create_obligation(db, actor, institution_id=job.institution_id, application_id=job.application_id,
                                 obligation_type=item.obligation_type, title=item.title, description=item.description,
                                 responsible_role=item.responsible_role, source_event=f"APPROVAL_LETTER:{job.id}",
                                 source_document_id=job.file_id, source_text=item.source_sentence,
                                 evidence_requirements=[item.evidence_requirement] if item.evidence_requirement else [],
                                 start_date=start if start <= item.due_date else today_ist(), due_date=item.due_date,
                                 owner_side="INSTITUTION")
    item.status, item.obligation_id, item.reviewed_by = "ACCEPTED", o.id, actor.id
    audit(db, actor, "EXTRACTION_ITEM_CONFIRMED", "extraction_item", item.id, before, snapshot(item) | {"obligation_id": o.id},
          "edited before confirmation" if item.edited else None)
    if not db.execute(select(ExtractionItem.id).where(ExtractionItem.job_id == job.id, ExtractionItem.status == "PROPOSED")).first():
        job.status = "COMPLETED"
    return item


def manual_item(db: Session, actor: User, job: ExtractionJob, data: dict) -> ExtractionItem:
    """Officer adds an item the extractor missed (also the path when no extractor is available)."""
    sent = data.get("source_sentence") or ""
    off = ex.find_source(job.full_text, sent) if sent else None
    if sent and off is None:
        raise HTTPException(422, "The quoted sentence does not appear in the letter text.")
    it = ExtractionItem(job_id=job.id, kind=data.get("kind", "CONDITION"), title=data["title"], description=data.get("description", ""),
                        source_sentence=sent or "(added manually by officer)", source_offset=off, due_text=None,
                        due_date=date.fromisoformat(data["due_date"]) if data.get("due_date") else None,
                        responsible_role=data.get("responsible_role", "INSTITUTION_PRINCIPAL"),
                        evidence_requirement=data.get("evidence_requirement"),
                        obligation_type=data.get("obligation_type", "APPROVAL_UNDERTAKING"), confidence=1.0, edited=True)
    db.add(it)
    db.flush()
    audit(db, actor, "EXTRACTION_ITEM_MANUAL", "extraction_item", it.id, None, snapshot(it))
    return it


# ---------------------------------------------------------------- institutional documents
def upload_document(db: Session, actor: User, f: StoredFile, institution_id: int, doc_type: str,
                    previous_id: int | None = None) -> InstitutionalDocument:
    res = ocr.ocr_document(read(f), f.mime)
    d = InstitutionalDocument(institution_id=institution_id, doc_type=doc_type, file_id=f.id, ocr_text=res["text"],
                              ocr_result={k: v for k, v in res.items() if k != "text"}, extraction_confidence=res["confidence"],
                              ocr_status=res["status"], issue_date=date.fromisoformat(res["issue"]) if res.get("issue") else None,
                              expiry_date=None,  # stays empty until an official confirms — OCR is never treated as verified
                              verification_status="PENDING", previous_document_id=previous_id, is_current=False, uploaded_by=actor.id)
    db.add(d)
    db.flush()
    audit(db, actor, "DOCUMENT_UPLOADED", "institutional_document", d.id, None,
          {"doc_type": doc_type, "ocr_expiry": res["expiry"], "confidence": res["confidence"], "status": res["status"],
           "engine": res["engine"], "agreement": res["agreement"], "renewal_of": previous_id})
    # renewal submission satisfies the open renewal obligation's evidence step
    if previous_id:
        prev = db.get(InstitutionalDocument, previous_id)
        if prev and prev.obligation_id:
            o = db.get(Obligation, prev.obligation_id)
            if o and o.state in ("OPEN", "ACKNOWLEDGED"):
                ledger.submit_evidence(db, actor, o, f, "PORTAL", f"Renewed {doc_type} uploaded (document #{d.id})")
    return d


def confirm_document(db: Session, actor: User, d: InstitutionalDocument, expiry: date, issue: date | None, note: str | None) -> InstitutionalDocument:
    if d.verification_status != "PENDING":
        raise HTTPException(409, f"Document already {d.verification_status}.")
    before = snapshot(d)
    ocr_exp = (d.ocr_result or {}).get("expiry")
    corrected = ocr_exp != expiry.isoformat()
    d.expiry_date, d.issue_date = expiry, issue or d.issue_date
    d.verification_status = "CORRECTED" if corrected else "CONFIRMED"
    d.verified_by, d.verified_at = actor.id, now()
    for old in db.execute(select(InstitutionalDocument).where(InstitutionalDocument.institution_id == d.institution_id,
                                                              InstitutionalDocument.doc_type == d.doc_type,
                                                              InstitutionalDocument.is_current.is_(True))).scalars():
        old.is_current = False
    d.is_current = True
    otype = "LEASE_RENEWAL" if d.doc_type == "LEASE_DEED" else "DOCUMENT_RENEWAL"
    start = today_ist() if expiry >= today_ist() else expiry
    o = ledger.create_obligation(db, actor, institution_id=d.institution_id, obligation_type=otype,
                                 title=f"Renew {d.doc_type.replace('_', ' ').title()} (expires {expiry:%d %b %Y})",
                                 description=f"Officer-confirmed expiry from document #{d.id}.", source_event=f"DOCUMENT_CONFIRMED:{d.id}",
                                 source_document_id=d.file_id, evidence_requirements=[f"Renewed {d.doc_type.replace('_', ' ').lower()}"],
                                 start_date=start, due_date=expiry, owner_side="INSTITUTION")
    d.obligation_id = o.id
    audit(db, actor, "DOCUMENT_EXPIRY_CORRECTED" if corrected else "DOCUMENT_EXPIRY_CONFIRMED", "institutional_document", d.id,
          before, snapshot(d), note or (f"OCR proposed {ocr_exp}" if corrected else None))
    # a confirmed renewal closes the previous document's renewal obligation via verified evidence
    if d.previous_document_id:
        prev = db.get(InstitutionalDocument, d.previous_document_id)
        if prev and prev.obligation_id:
            po = db.get(Obligation, prev.obligation_id)
            pend = db.execute(select(Evidence).where(Evidence.obligation_id == po.id, Evidence.status == "RECEIVED_PENDING_VERIFICATION")).scalars().first()
            if pend:
                ledger.review_evidence(db, actor, pend, True, None)
    return d


def reject_document(db: Session, actor: User, d: InstitutionalDocument, reason: str) -> InstitutionalDocument:
    if not reason:
        raise HTTPException(422, "Reason required")
    before = snapshot(d)
    d.verification_status, d.verified_by, d.verified_at = "REJECTED", actor.id, now()
    audit(db, actor, "DOCUMENT_REJECTED", "institutional_document", d.id, before, snapshot(d), reason)
    return d


def ocr_evidence(db: Session, ev: Evidence) -> None:
    f = db.get(StoredFile, ev.file_id) if ev.file_id else None
    if not f:
        ev.ocr_status = "NOT_APPLICABLE"
        return
    try:
        res = ocr.extract_text(read(f), f.mime)
        ev.ocr_text, ev.ocr_status = res["text"][:20000], "DONE"
    except Exception as e:  # noqa: BLE001
        ev.ocr_status = f"FAILED"
        ev.ocr_text = str(e)[:500]


def document_view(db: Session, d: InstitutionalDocument) -> dict:
    inst = db.get(Institution, d.institution_id)
    t = today_ist()
    status = "UNVERIFIED"
    if d.expiry_date:
        days = (d.expiry_date - t).days
        status = "EXPIRED" if days < 0 else ("EXPIRING_SOON" if days <= 90 else "VALID")
    return {"id": d.id, "institution_id": d.institution_id, "institution": inst.name if inst else None, "doc_type": d.doc_type,
            "issue_date": d.issue_date.isoformat() if d.issue_date else None, "expiry_date": d.expiry_date.isoformat() if d.expiry_date else None,
            "validity": status, "days_to_expiry": (d.expiry_date - t).days if d.expiry_date else None, "file_id": d.file_id,
            "ocr_status": d.ocr_status, "extraction_confidence": d.extraction_confidence, "ocr_result": d.ocr_result,
            "verification_status": d.verification_status, "verified_by": d.verified_by,
            "verified_at": d.verified_at.isoformat() if d.verified_at else None, "obligation_id": d.obligation_id,
            "previous_document_id": d.previous_document_id, "is_current": d.is_current, "is_synthetic": d.is_synthetic,
            "region_id": inst.region_id if inst else None}
