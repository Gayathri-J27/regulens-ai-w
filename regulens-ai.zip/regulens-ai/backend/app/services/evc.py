"""EVC management: QUEUED -> PANEL_PROPOSED -> SCHEDULED -> VISITED -> REPORT_PENDING -> REPORT_RECEIVED -> CLOSED (+DELAYED)."""
from __future__ import annotations

from datetime import date, timedelta

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.security import now
from app.engines.evc_ranker import ExpertView, propose
from app.models import Application, EvcAssignment, EvcVisit, Expert, Institution, Obligation, Region, StoredFile, User
from app.services import ledger
from app.services.audit import audit, snapshot
from app.services.clocks import today_ist
from app.services.config import get_params
from app.services.notifications import notify_institution, notify_user

EXPERTISE_BY_TYPE = {
    "NEW_INSTITUTION": ["CIVIL_INFRA", "ACADEMICS", "LABS"],
    "INCREASE_IN_INTAKE": ["ACADEMICS", "LABS"],
    "NEW_COURSE": ["ACADEMICS", "LABS"],
    "CHANGE_OF_SITE": ["CIVIL_INFRA", "LEGAL_LAND"],
    "CLOSURE": ["ACADEMICS", "LEGAL_LAND"],
    "CONVERSION": ["ACADEMICS", "CIVIL_INFRA"],
    "EXTENSION_OF_APPROVAL": ["ACADEMICS"],
}


def queue_visit(db: Session, app: Application, actor: User | None, force_new: bool = False) -> EvcVisit:
    existing = db.execute(select(EvcVisit).where(EvcVisit.application_id == app.id, EvcVisit.status != "CLOSED")).scalar_one_or_none()
    if existing and not force_new:
        return existing
    if existing:
        existing.status = "CLOSED"
    v = EvcVisit(application_id=app.id, institution_id=app.institution_id, status="QUEUED",
                 required_expertise=EXPERTISE_BY_TYPE.get(app.application_type, ["ACADEMICS"]))
    db.add(v)
    db.flush()
    o = ledger.create_obligation(db, actor, institution_id=app.institution_id, application_id=app.id, obligation_type="EVC_SCHEDULING",
                                 title=f"Schedule EVC — {app.app_no}", source_event=f"EVC_QUEUED:{v.id}", owner_side="AICTE",
                                 responsible_role="REGIONAL_OFFICER", notify=False)
    v.schedule_obligation_id = o.id
    audit(db, actor, "EVC_QUEUED", "evc_visit", v.id, None, snapshot(v))
    return v


def _expert_views(db: Session, visit_date: date) -> list[ExpertView]:
    m0 = visit_date.replace(day=1)
    m1 = (m0 + timedelta(days=32)).replace(day=1)
    loads = dict(db.execute(select(EvcAssignment.expert_id, func.count()).where(EvcAssignment.active.is_(True),
                                                                               EvcAssignment.visit_date >= m0,
                                                                               EvcAssignment.visit_date < m1)
                            .group_by(EvcAssignment.expert_id)).all())
    return [ExpertView(e.id, e.name, tuple(e.expertise or []), e.region_id, e.lat, e.lon, e.monthly_cap, e.is_active,
                       frozenset(e.unavailable_dates or []), frozenset(e.coi_institution_ids or []), loads.get(e.id, 0))
            for e in db.execute(select(Expert)).scalars()]


def _coords(db: Session, inst: Institution) -> tuple[float, float]:
    if inst.lat is not None and inst.lon is not None:
        return inst.lat, inst.lon
    r = db.get(Region, inst.region_id)  # no geocode on record: use the Regional office location
    return r.lat, r.lon


def propose_panel(db: Session, actor: User, v: EvcVisit, visit_date: date) -> dict:
    if v.status not in ("QUEUED", "PANEL_PROPOSED", "DELAYED"):
        raise HTTPException(409, f"Visit is {v.status}.")
    if visit_date < today_ist():
        raise HTTPException(422, "Visit date cannot be in the past.")
    inst = db.get(Institution, v.institution_id)
    coords = _coords(db, inst)
    res = propose(_expert_views(db, visit_date), institution_id=inst.id, institution_region=inst.region_id, inst_coords=coords,
                  visit_date=visit_date, required=v.required_expertise or [], weights=get_params(db, "evc.weights"))
    before = snapshot(v)
    v.proposal, v.proposed_date, v.status = res, visit_date, "PANEL_PROPOSED"
    audit(db, actor, "EVC_PANEL_PROPOSED", "evc_visit", v.id, before,
          {"panels": [p["expert_ids"] for p in res["panels"]], "excluded": len(res["excluded"])})
    return res


def schedule(db: Session, actor: User, v: EvcVisit, expert_ids: list[int], visit_date: date, override_reason: str | None,
             reschedule: bool = False) -> EvcVisit:
    if reschedule:
        if v.status not in ("SCHEDULED", "DELAYED"):
            raise HTTPException(409, "Only scheduled/delayed visits can be rescheduled.")
    elif v.status != "PANEL_PROPOSED":
        raise HTTPException(409, "Propose a panel before scheduling.")
    if len(set(expert_ids)) < 2:
        raise HTTPException(422, "A panel needs at least two distinct experts.")
    # re-run the filters for the chosen date and panel: exclusions cannot be silently bypassed
    inst = db.get(Institution, v.institution_id)
    coords = _coords(db, inst)
    res = propose(_expert_views(db, visit_date), institution_id=inst.id, institution_region=inst.region_id, inst_coords=coords,
                  visit_date=visit_date, required=v.required_expertise or [], weights=get_params(db, "evc.weights"))
    current = {a.expert_id for a in db.execute(select(EvcAssignment).where(EvcAssignment.visit_id == v.id, EvcAssignment.active.is_(True))).scalars()}
    excl = {x["expert_id"]: x for x in res["excluded"]}
    blocking = []
    for eid in expert_ids:
        if eid in excl:
            reasons = excl[eid]["reasons"]
            if eid in current and all("monthly visit cap" in r for r in reasons):
                continue  # their existing assignment to this visit is what fills the cap
            blocking.append((eid, reasons))
    if blocking:
        coi = [b for b in blocking if any("conflict of interest" in r for r in b[1])]
        if coi and actor.role != "AICTE_ADMIN":
            raise HTTPException(403, "Conflict-of-interest exclusions can only be overridden by an AICTE Administrator with a recorded reason.")
        if not override_reason:
            raise HTTPException(422, "Excluded expert(s) selected: " + "; ".join(f"#{e}: {', '.join(r)}" for e, r in blocking)
                                + ". An override reason is required.")
    before = snapshot(v)
    for a in db.execute(select(EvcAssignment).where(EvcAssignment.visit_id == v.id, EvcAssignment.active.is_(True))).scalars():
        a.active = False
    for eid in expert_ids:
        db.add(EvcAssignment(visit_id=v.id, expert_id=eid, visit_date=visit_date))
    v.panel_expert_ids, v.scheduled_date, v.status = expert_ids, visit_date, "SCHEDULED"
    v.override_reason = override_reason if blocking else v.override_reason
    if reschedule:
        v.reschedule_count += 1
    so = db.get(Obligation, v.schedule_obligation_id) if v.schedule_obligation_id else None
    if so and so.state not in ledger.CLOSED:
        ledger._close(db, actor, so, "MET", f"EVC scheduled for {visit_date}")
    app = db.get(Application, v.application_id)
    audit(db, actor, "EVC_RESCHEDULED" if reschedule else "EVC_SCHEDULED", "evc_visit", v.id, before, snapshot(v),
          override_reason if blocking else None)
    if blocking:
        audit(db, actor, "EVC_EXCLUSION_OVERRIDDEN", "evc_visit", v.id, None, {"overridden": [{"expert_id": e, "reasons": r} for e, r in blocking]},
              override_reason)
    notify_institution(db, inst, "evc_scheduled", {"app_no": app.app_no, "institution": inst.name, "date": visit_date.strftime("%d %b %Y")},
                       entity=("evc_visit", v.id), key_suffix=f"s{v.reschedule_count}")
    for e in db.execute(select(Expert).where(Expert.id.in_(expert_ids))).scalars():
        if e.user_id:
            notify_user(db, db.get(User, e.user_id), "evc_scheduled", {"app_no": app.app_no, "institution": inst.name,
                                                                       "date": visit_date.strftime("%d %b %Y")},
                        entity=("evc_visit", v.id), key_suffix=f"x{e.id}-{v.reschedule_count}")
    return v


def record_visit(db: Session, actor: User, v: EvcVisit) -> EvcVisit:
    if v.status not in ("SCHEDULED", "DELAYED"):
        raise HTTPException(409, f"Visit is {v.status}.")
    if v.scheduled_date and v.scheduled_date > today_ist():
        raise HTTPException(409, "The visit date has not arrived yet.")
    before = snapshot(v)
    v.visited_at, v.status = now(), "REPORT_PENDING"
    app = db.get(Application, v.application_id)
    o = ledger.create_obligation(db, actor, institution_id=v.institution_id, application_id=v.application_id, obligation_type="EVC_REPORT",
                                 title=f"Upload EVC report — {app.app_no}", source_event=f"EVC_VISITED:{v.id}", owner_side="AICTE",
                                 responsible_role="COMMITTEE_MEMBER", notify=True,
                                 assigned_user_id=_panel_user(db, v) or actor.id)
    v.report_obligation_id = o.id
    audit(db, actor, "EVC_VISIT_RECORDED", "evc_visit", v.id, before, snapshot(v))
    return v


def _panel_user(db: Session, v: EvcVisit) -> int | None:
    for e in db.execute(select(Expert).where(Expert.id.in_(v.panel_expert_ids or []))).scalars():
        if e.user_id:
            return e.user_id
    return None


def submit_report(db: Session, actor: User, v: EvcVisit, file: StoredFile | None, findings: list[dict]) -> EvcVisit:
    if v.status != "REPORT_PENDING":
        raise HTTPException(409, f"Visit is {v.status}; record the visit first.")
    if actor.role == "COMMITTEE_MEMBER":
        mine = db.execute(select(Expert.id).where(Expert.user_id == actor.id, Expert.id.in_(v.panel_expert_ids or []))).first()
        if not mine:
            raise HTTPException(403, "Only panel members of this visit can submit its report.")
    before = snapshot(v)
    v.report_file_id = file.id if file else None
    v.findings = [{"text": f.get("text", ""), "severity": f.get("severity", "MINOR"),
                   "proposed_undertaking": f.get("proposed_undertaking"), "due_days": f.get("due_days"),
                   "status": "PROPOSED"} for f in findings]
    v.report_received_at, v.status = now(), "REPORT_RECEIVED"
    ro = db.get(Obligation, v.report_obligation_id) if v.report_obligation_id else None
    if ro and ro.state not in ledger.CLOSED:
        ledger._close(db, actor, ro, "MET", "EVC report uploaded")
    audit(db, actor, "EVC_REPORT_RECEIVED", "evc_visit", v.id, before, snapshot(v))
    return v


def confirm_findings(db: Session, actor: User, v: EvcVisit, decisions: list[dict]) -> dict:
    """Officer confirmation: only confirmed findings become Promise Ledger obligations."""
    if v.status not in ("REPORT_RECEIVED", "CLOSED"):
        raise HTTPException(409, "No report to confirm yet.")
    created = []
    findings = list(v.findings or [])
    for d in decisions:
        i = d["index"]
        if i >= len(findings) or findings[i]["status"] != "PROPOSED":
            continue
        f = dict(findings[i])
        if d.get("accept") and f.get("proposed_undertaking"):
            o = ledger.create_obligation(db, actor, institution_id=v.institution_id, application_id=v.application_id,
                                         obligation_type="APPROVAL_UNDERTAKING", title=d.get("title") or f["proposed_undertaking"],
                                         description=f"From EVC finding: {f['text']}", source_event=f"EVC_FINDING:{v.id}:{i}",
                                         source_document_id=v.report_file_id, source_text=f["text"],
                                         budget_days=int(d.get("due_days") or f.get("due_days") or 30), day_mode="CALENDAR",
                                         evidence_requirements=[d.get("evidence") or "Compliance evidence for EVC finding"],
                                         owner_side="INSTITUTION")
            f["status"], f["obligation_id"] = "CONFIRMED", o.id
            created.append(o.id)
        else:
            f["status"] = "DISMISSED" if not d.get("accept") else "NOTED"
            f["note"] = d.get("note")
        findings[i] = f
    before = snapshot(v)
    v.findings = findings
    if all(f["status"] != "PROPOSED" for f in findings):
        v.status = "CLOSED"
    audit(db, actor, "EVC_FINDINGS_CONFIRMED", "evc_visit", v.id, before, snapshot(v) | {"obligations_created": created})
    return {"obligations_created": created, "status": v.status}


def mark_delayed(db: Session, actor: User | None, v: EvcVisit, reason: str) -> EvcVisit:
    if v.status in ("CLOSED", "REPORT_RECEIVED", "DELAYED"):
        return v
    before = snapshot(v)
    v.status, v.delayed_reason = "DELAYED", reason
    app = db.get(Application, v.application_id)
    inst = db.get(Institution, v.institution_id)
    from app.services.escalation import officer_for_institution
    notify_user(db, officer_for_institution(db, inst), "evc_delayed", {"app_no": app.app_no, "institution": inst.name, "reason": reason},
                entity=("evc_visit", v.id), key_suffix="delay")
    audit(db, actor, "EVC_DELAYED", "evc_visit", v.id, before, snapshot(v), reason)
    return v


def delay_sweep(db: Session) -> int:
    """Visits scheduled in the past without being recorded, or queued past their scheduling deadline, become DELAYED."""
    t = today_ist()
    n = 0
    for v in db.execute(select(EvcVisit).where(EvcVisit.status == "SCHEDULED", EvcVisit.scheduled_date < t - timedelta(days=2))).scalars():
        mark_delayed(db, None, v, f"Visit date {v.scheduled_date} passed without the visit being recorded")
        n += 1
    for v in db.execute(select(EvcVisit).join(Obligation, Obligation.id == EvcVisit.schedule_obligation_id)
                        .where(EvcVisit.status.in_(["QUEUED", "PANEL_PROPOSED"]), Obligation.due_date < t)).scalars():
        mark_delayed(db, None, v, "Scheduling deadline passed without a panel being scheduled")
        n += 1
    return n


def visit_view(db: Session, v: EvcVisit) -> dict:
    app = db.get(Application, v.application_id)
    inst = db.get(Institution, v.institution_id)
    experts = {e.id: e for e in db.execute(select(Expert).where(Expert.id.in_(v.panel_expert_ids or [0]))).scalars()}
    return {"id": v.id, "application_id": v.application_id, "app_no": app.app_no if app else None, "institution_id": v.institution_id,
            "institution": inst.name if inst else None, "region_id": inst.region_id if inst else None, "status": v.status,
            "required_expertise": v.required_expertise, "proposed_date": v.proposed_date.isoformat() if v.proposed_date else None,
            "scheduled_date": v.scheduled_date.isoformat() if v.scheduled_date else None,
            "panel": [{"id": i, "name": experts[i].name if i in experts else f"#{i}"} for i in (v.panel_expert_ids or [])],
            "proposal": v.proposal, "findings": v.findings, "report_file_id": v.report_file_id,
            "visited_at": v.visited_at.isoformat() if v.visited_at else None, "override_reason": v.override_reason,
            "delayed_reason": v.delayed_reason, "reschedule_count": v.reschedule_count, "is_synthetic": v.is_synthetic,
            "schedule_obligation_id": v.schedule_obligation_id, "report_obligation_id": v.report_obligation_id}
