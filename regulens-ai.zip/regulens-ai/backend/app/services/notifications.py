"""Notification engine.

Delivery states: QUEUED -> SENT -> DELIVERED, or BOUNCED / FAILED.
* A message is only DELIVERED when the channel adapter confirms delivery (in-app inbox write,
  dev mailbox capture, provider delivery receipt). SMTP hand-off without a receipt stays SENT.
* Transient failures retry after 1m, 10m, 1h, 6h, then FAILED + fallback channel.
* Bounces mark the contact invalid, raise a contact-invalid alert and fall back to another channel.
* Every message has an idempotency key, so replays (e.g. after a worker crash) never duplicate.
"""
from __future__ import annotations

import smtplib
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage

from sqlalchemy import select, text
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import now
from app.models import DeliveryLog, Institution, InstitutionContact, Notification, NotificationTemplate, Post, User
from app.services.templates_seed import T

RETRY = [1, 10, 60, 360]
LANGS = ("en", "hi", "mr", "ta")


class _Safe(dict):
    def __missing__(self, k):
        return "{" + k + "}"


def seed_templates(db: Session) -> int:
    n = 0
    for key, langs in T.items():
        for lang, (subj, body) in langs.items():
            if db.execute(select(NotificationTemplate.id).where(NotificationTemplate.key == key, NotificationTemplate.language == lang)).first():
                continue
            db.add(NotificationTemplate(key=key, language=lang, version=1, subject=subj, body=body,
                                        translation_source="SOURCE_EN" if lang == "en" else "DRAFT_REQUIRES_HUMAN_REVIEW"))
            n += 1
    db.flush()
    return n


def render(db: Session, key: str, lang: str, ctx: dict) -> tuple[str, str, int, str]:
    tpl = None
    for l in (lang, "en"):
        tpl = db.execute(select(NotificationTemplate).where(NotificationTemplate.key == key, NotificationTemplate.language == l,
                                                            NotificationTemplate.is_active.is_(True))
                         .order_by(NotificationTemplate.version.desc()).limit(1)).scalar_one_or_none()
        if tpl:
            lang = l
            break
    if not tpl:
        subj, body = T[key]["en"]
        return subj.format_map(_Safe(ctx)), body.format_map(_Safe(ctx)), 0, "en"
    return tpl.subject.format_map(_Safe(ctx)), tpl.body.format_map(_Safe(ctx)), tpl.version, lang


def _enqueue(db: Session, *, key: str, channel: str, template_key: str, lang: str, ctx: dict, user_id: int | None = None,
             contact_id: int | None = None, institution_id: int | None = None, address: str | None = None,
             entity: tuple[str, int] | None = None, run_at: datetime | None = None, fallback_of: int | None = None,
             provider: str | None = None) -> int | None:
    subj, body, ver, lang = render(db, template_key, lang, ctx)
    stmt = insert(Notification).values(
        idempotency_key=key[:160], recipient_user_id=user_id, recipient_contact_id=contact_id, institution_id=institution_id,
        channel=channel, address=address, template_key=template_key, template_version=ver, language=lang, subject=subj,
        body=body, status="QUEUED", attempts=0, next_attempt_at=run_at or now(),
        entity_type=entity[0] if entity else None, entity_id=entity[1] if entity else None, fallback_of_id=fallback_of,
        provider=provider, created_at=now(),
    ).on_conflict_do_nothing(index_elements=["idempotency_key"]).returning(Notification.id)
    return db.execute(stmt).scalar_one_or_none()


def _channels(db: Session, audience: str) -> list[str]:
    from app.services.config import get_params
    return get_params(db, "notification.channels").get(audience, ["IN_APP"])


def notify_user(db: Session, user: User | None, template_key: str, ctx: dict, *, entity: tuple[str, int] | None = None,
                key_suffix: str = "", channels: list[str] | None = None, institution_id: int | None = None) -> list[int]:
    if user is None or not user.is_active:
        return []
    from app.core.permissions import INSTITUTION_ROLES
    chans = channels or _channels(db, "institution" if user.role in INSTITUTION_ROLES else "officer")
    ids = []
    for ch in chans:
        addr = user.email if ch == "EMAIL" else (user.phone if ch in ("SMS", "WHATSAPP") else None)
        if ch in ("SMS", "WHATSAPP") and not addr:
            continue
        k = f"{template_key}:{entity[0] if entity else '-'}:{entity[1] if entity else '-'}:u{user.id}:{ch}:{key_suffix}"
        nid = _enqueue(db, key=k, channel=ch, template_key=template_key, lang=user.preferred_language or "en", ctx=ctx,
                       user_id=user.id, institution_id=institution_id or user.institution_id, address=addr, entity=entity)
        if nid:
            ids.append(nid)
    return ids


def notify_institution(db: Session, institution: Institution, template_key: str, ctx: dict, *,
                       entity: tuple[str, int] | None = None, key_suffix: str = "", roles=("PRINCIPAL", "COMPLIANCE"),
                       urgent: bool = True) -> list[int]:
    """Notify institution contacts (email/SMS) and their portal users (in-app)."""
    ids: list[int] = []
    chans = _channels(db, "institution")
    digest_at = None
    if institution.digest_enabled and not urgent:
        from app.services.config import get_params
        hr = get_params(db, "notification.channels").get("digest_hour_ist", 18)
        ist = now().astimezone(timezone(timedelta(hours=5, minutes=30)))
        t = ist.replace(hour=hr, minute=0, second=0, microsecond=0)
        digest_at = t if t > ist else t + timedelta(days=1)
    contacts = db.execute(select(InstitutionContact).where(InstitutionContact.institution_id == institution.id,
                                                           InstitutionContact.role.in_(roles))).scalars().all()
    for c in contacts:
        for ch in chans:
            if ch == "IN_APP":
                continue
            addr = c.email if ch == "EMAIL" else c.phone
            if not addr:
                continue
            k = f"{template_key}:{entity[0] if entity else '-'}:{entity[1] if entity else '-'}:c{c.id}:{ch}:{key_suffix}"
            nid = _enqueue(db, key=k, channel=ch, template_key=template_key, lang=institution.preferred_language, ctx=ctx,
                           contact_id=c.id, institution_id=institution.id, address=addr, entity=entity,
                           run_at=digest_at if ch == "EMAIL" else None, provider="digest" if (digest_at and ch == "EMAIL") else None)
            if nid:
                ids.append(nid)
    if "IN_APP" in chans:
        for u in db.execute(select(User).where(User.institution_id == institution.id, User.is_active.is_(True))).scalars():
            ids += notify_user(db, u, template_key, ctx, entity=entity, key_suffix=key_suffix, channels=["IN_APP"])
    return ids


def notify_role(db: Session, role: str, template_key: str, ctx: dict, *, entity=None, key_suffix: str = "") -> list[int]:
    ids = []
    for u in db.execute(select(User).where(User.role == role, User.is_active.is_(True), User.is_synthetic.is_(False))).scalars():
        ids += notify_user(db, u, template_key, ctx, entity=entity, key_suffix=key_suffix)
    return ids


# ---------------------------------------------------------------- channel adapters
class DeliveryResult:
    def __init__(self, outcome: str, provider: str, detail: str = ""):
        self.outcome, self.provider, self.detail = outcome, provider, detail  # DELIVERED | SENT | BOUNCE | TRANSIENT


def _looks_invalid(addr: str | None) -> bool:
    # Synthetic test data marks unreachable contacts with the reserved '.invalid' TLD / 000 numbers.
    return not addr or addr.endswith(".invalid") or addr.replace("+", "").startswith("91000")


def _adapter(n: Notification) -> DeliveryResult:
    if n.channel == "IN_APP":
        return DeliveryResult("DELIVERED", "in-app-inbox")
    if n.channel == "EMAIL":
        if _looks_invalid(n.address):
            return DeliveryResult("BOUNCE", "dev-mailbox" if not settings.smtp_host else "smtp", "550 mailbox unavailable")
        if settings.smtp_host:
            msg = EmailMessage()
            msg["From"], msg["To"], msg["Subject"] = settings.smtp_from, n.address, n.subject
            msg.set_content(n.body)
            try:
                with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=10) as s:
                    s.send_message(msg)
                return DeliveryResult("SENT", "smtp", "accepted by relay; no delivery receipt")
            except Exception as ex:  # noqa: BLE001
                return DeliveryResult("TRANSIENT", "smtp", str(ex)[:200])
        return DeliveryResult("DELIVERED", "dev-mailbox", "captured in development mailbox (delivery_log)")
    if n.channel == "SMS":
        if _looks_invalid(n.address):
            return DeliveryResult("BOUNCE", f"sms-{settings.sms_provider}", "number not reachable")
        # dev log provider: hand-off recorded; delivery receipt arrives on the next dispatcher pass
        return DeliveryResult("SENT", f"sms-{settings.sms_provider}", "logged to development SMS log")
    if n.channel == "WHATSAPP":
        return DeliveryResult("SENT", f"whatsapp-{settings.whatsapp_provider}", "preview stored; no credentials configured")
    return DeliveryResult("TRANSIENT", "unknown", "unsupported channel")


def dispatch_due(db: Session, limit: int = 500, worker: str = "dispatcher") -> dict:
    """Process QUEUED messages whose time has come. Safe to run concurrently (SKIP LOCKED)."""
    rows = db.execute(select(Notification).where(Notification.status == "QUEUED", Notification.next_attempt_at <= now(),
                                                 (Notification.provider.is_(None)) | (Notification.provider != "digest"))
                      .order_by(Notification.next_attempt_at).limit(limit).with_for_update(skip_locked=True)).scalars().all()
    stats = {"processed": 0, "delivered": 0, "sent": 0, "bounced": 0, "retry": 0, "failed": 0}
    for n in rows:
        stats["processed"] += 1
        n.attempts += 1
        r = _adapter(n)
        n.provider = r.provider
        db.add(DeliveryLog(notification_id=n.id, channel=n.channel, provider=r.provider, address=n.address,
                           payload={"subject": n.subject, "body": n.body, "language": n.language, "detail": r.detail},
                           outcome=r.outcome))
        if r.outcome == "DELIVERED":
            n.status, n.sent_at, n.delivered_at = "DELIVERED", now(), now()
            stats["delivered"] += 1
        elif r.outcome == "SENT":
            n.status, n.sent_at = "SENT", now()
            stats["sent"] += 1
        elif r.outcome == "BOUNCE":
            n.status, n.error = "BOUNCED", r.detail
            stats["bounced"] += 1
            _handle_bounce(db, n)
        else:
            if n.attempts <= len(RETRY):
                n.next_attempt_at = now() + timedelta(minutes=RETRY[n.attempts - 1])
                n.error = r.detail
                stats["retry"] += 1
            else:
                n.status, n.error = "FAILED", r.detail
                stats["failed"] += 1
                _fallback(db, n)
    db.flush()
    # simulated delivery receipts for the dev SMS log (provider DLR webhook in production)
    if settings.sms_provider == "devlog":
        cutoff = now() - timedelta(seconds=5)
        for n in db.execute(select(Notification).where(Notification.status == "SENT", Notification.channel == "SMS",
                                                       Notification.sent_at <= cutoff).limit(limit)).scalars():
            n.status, n.delivered_at = "DELIVERED", now()
            db.add(DeliveryLog(notification_id=n.id, channel="SMS", provider=n.provider or "sms-devlog", address=n.address,
                               payload={"dlr": "DELIVRD (simulated by dev log provider)"}, outcome="DELIVERED"))
            stats["delivered"] += 1
    return stats


def apply_receipt(db: Session, notification_id: int, status: str, detail: str = "") -> Notification:
    n = db.get(Notification, notification_id)
    if n and status in ("DELIVERED", "BOUNCED", "FAILED"):
        n.status = status
        if status == "DELIVERED":
            n.delivered_at = now()
        else:
            n.error = detail
            _handle_bounce(db, n) if status == "BOUNCED" else _fallback(db, n)
        db.add(DeliveryLog(notification_id=n.id, channel=n.channel, provider=n.provider or "webhook", address=n.address,
                           payload={"receipt": status, "detail": detail}, outcome=status))
    return n


def _handle_bounce(db: Session, n: Notification) -> None:
    if n.recipient_contact_id:
        c = db.get(InstitutionContact, n.recipient_contact_id)
        if c and not c.invalid:
            c.invalid = True
            c.invalid_reason = f"{n.channel} bounced: {n.error}"
            inst = db.get(Institution, c.institution_id)
            from app.services.escalation import officer_for_institution
            officer = officer_for_institution(db, inst)
            notify_user(db, officer, "contact_invalid", {"institution": inst.name, "role": c.role, "address": n.address,
                                                         "reason": n.error}, entity=("contact", c.id), key_suffix="1")
    _fallback(db, n)


def _fallback(db: Session, n: Notification) -> None:
    if n.fallback_of_id:
        return  # one fallback hop only
    from app.services.config import get_params
    fb = get_params(db, "notification.channels").get("fallback", {}).get(n.channel)
    if not fb:
        return
    addr = None
    if n.recipient_contact_id:
        c = db.get(InstitutionContact, n.recipient_contact_id)
        addr = (c.email if fb == "EMAIL" else c.phone) if c else None
    elif n.recipient_user_id:
        u = db.get(User, n.recipient_user_id)
        addr = (u.email if fb == "EMAIL" else u.phone) if u else None
    if not addr:
        return
    db.execute(insert(Notification).values(
        idempotency_key=f"fb:{n.id}:{fb}", recipient_user_id=n.recipient_user_id, recipient_contact_id=n.recipient_contact_id,
        institution_id=n.institution_id, channel=fb, address=addr, template_key=n.template_key,
        template_version=n.template_version, language=n.language, subject=n.subject, body=n.body, status="QUEUED",
        attempts=0, next_attempt_at=now(), entity_type=n.entity_type, entity_id=n.entity_id, fallback_of_id=n.id,
        created_at=now()).on_conflict_do_nothing(index_elements=["idempotency_key"]))


def run_digests(db: Session) -> int:
    """Combine due digest-held emails into one daily digest per contact address."""
    rows = db.execute(select(Notification).where(Notification.status == "QUEUED", Notification.provider == "digest",
                                                 Notification.next_attempt_at <= now())
                      .with_for_update(skip_locked=True)).scalars().all()
    groups: dict[tuple, list[Notification]] = {}
    for n in rows:
        groups.setdefault((n.recipient_contact_id, n.address, n.institution_id, n.language), []).append(n)
    made = 0
    day = now().date().isoformat()
    for (cid, addr, iid, lang), items in groups.items():
        lines = "\n".join(f"• {x.subject}" for x in items)
        nid = _enqueue(db, key=f"digest:{cid}:{day}:{items[0].id}", channel="EMAIL", template_key="daily_digest", lang=lang,
                       ctx={"count": len(items), "lines": lines}, contact_id=cid, institution_id=iid, address=addr)
        for x in items:
            x.status, x.sent_at, x.provider = "SENT", now(), f"digest#{nid}"
        made += 1
    return made
