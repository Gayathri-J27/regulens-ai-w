"""Bootstrap reference data and demo accounts (idempotent).

All people, institutions and experts here are fictional. Holiday dates are illustrative and must be
replaced by the official AICTE / State gazette calendars before any real use.
"""
from __future__ import annotations

from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models import (Expert, Holiday, HolidayCalendar, Institution, InstitutionContact, Post, Region, User)
from app.services.audit import audit
from app.services.config import ensure_default_rules
from app.services.notifications import seed_templates
from app.services.workflow import seed_routes

DEMO_PASSWORD = "Demo@1234"

REGIONS = [
    ("SR", "Southern Region", "Chennai", 13.08, 80.27, ["Tamil Nadu", "Puducherry", "Kerala"]),
    ("SWR", "South-Western Region", "Bengaluru", 12.97, 77.59, ["Karnataka", "Goa"]),
    ("SCR", "South-Central Region", "Hyderabad", 17.38, 78.48, ["Telangana", "Andhra Pradesh"]),
    ("WR", "Western Region", "Mumbai", 19.07, 72.88, ["Maharashtra", "Gujarat"]),
    ("CR", "Central Region", "Bhopal", 23.26, 77.41, ["Madhya Pradesh", "Chhattisgarh"]),
    ("NR", "Northern Region", "Kanpur", 26.45, 80.33, ["Uttar Pradesh", "Uttarakhand", "Bihar"]),
    ("NWR", "North-Western Region", "Chandigarh", 30.73, 76.78, ["Punjab", "Haryana", "Delhi", "Rajasthan", "Himachal Pradesh"]),
    ("ER", "Eastern Region", "Kolkata", 22.57, 88.36, ["West Bengal", "Odisha", "Jharkhand", "Assam"]),
]

NATIONAL_HOLIDAYS = {  # illustrative 2026–27 list (verify against the official calendar)
    "2026-01-26": "Republic Day", "2026-03-04": "Holi", "2026-03-21": "Id-ul-Fitr", "2026-04-03": "Good Friday",
    "2026-05-01": "Buddha Purnima", "2026-05-27": "Id-ul-Zuha", "2026-08-15": "Independence Day", "2026-08-26": "Milad-un-Nabi",
    "2026-09-04": "Janmashtami", "2026-10-02": "Gandhi Jayanti", "2026-10-20": "Dussehra", "2026-11-09": "Diwali",
    "2026-11-24": "Guru Nanak Jayanti", "2026-12-25": "Christmas", "2027-01-26": "Republic Day", "2027-03-22": "Holi",
}
STATE_HOLIDAYS = {
    "Tamil Nadu": {"2026-01-15": "Pongal", "2026-01-16": "Thiruvalluvar Day", "2026-04-14": "Tamil New Year", "2027-01-15": "Pongal"},
    "Maharashtra": {"2026-03-19": "Gudi Padwa", "2026-05-01": "Maharashtra Day", "2026-09-14": "Ganesh Chaturthi"},
    "Karnataka": {"2026-03-19": "Ugadi", "2026-11-01": "Kannada Rajyotsava"},
    "West Bengal": {"2026-10-17": "Maha Saptami", "2026-10-19": "Maha Navami"},
    "Kerala": {"2026-08-26": "Thiruvonam"},
    "Telangana": {"2026-06-02": "Telangana Formation Day"},
    "Uttar Pradesh": {"2026-11-15": "Chhath Puja"},
}


def _cal(db, code, name, scope, state=None, holidays=None):
    c = db.execute(select(HolidayCalendar).where(HolidayCalendar.code == code)).scalar_one_or_none()
    if c:
        return c
    c = HolidayCalendar(code=code, name=name, scope=scope, state=state, weekend_days=[5, 6])
    db.add(c)
    db.flush()
    for d, n in (holidays or {}).items():
        db.add(Holiday(calendar_id=c.id, day=date.fromisoformat(d), name=n))
    return c


def bootstrap(db: Session) -> dict:
    if db.execute(select(Region.id)).first():
        return {"skipped": True, "reason": "reference data already present"}
    _cal(db, "AICTE-NATIONAL", "AICTE national holidays (illustrative)", "AICTE_NATIONAL", holidays=NATIONAL_HOLIDAYS)
    for st, hol in STATE_HOLIDAYS.items():
        _cal(db, f"STATE-{st.upper().replace(' ', '-')}", f"{st} state holidays (illustrative)", "STATE", st, hol)
    regions = {}
    for code, name, city, lat, lon, states in REGIONS:
        rc = _cal(db, f"AICTE-{code}", f"AICTE {name} office holidays", "AICTE_REGION",
                  holidays={"2026-12-31": "Regional office closure (illustrative)"} if code == "SR" else {})
        r = Region(code=code, name=name, hq_city=city, lat=lat, lon=lon, states=states, holiday_calendar_id=rc.id)
        db.add(r)
        db.flush()
        regions[code] = r
    # organisational posts: L4 HQ, L3 regional head, L2 deputy (x2), L1 desks (x8)
    hq = Post(code="HQ-ADVISER-APPROVAL", title="Adviser — Approval Bureau (HQ)", level=4)
    hq2 = Post(code="HQ-DIRECTOR-MONITORING", title="Director — Compliance Monitoring (HQ)", level=4)
    db.add_all([hq, hq2])
    db.flush()
    for code, r in regions.items():
        head = Post(code=f"{code}-RO-HEAD", title=f"Regional Officer — {r.name}", level=3, region_id=r.id, parent_post_id=hq.id)
        db.add(head)
        db.flush()
        for k in (1, 2):
            dd = Post(code=f"{code}-DD-{k}", title=f"Deputy Director {k} — {r.name}", level=2, region_id=r.id, parent_post_id=head.id)
            db.add(dd)
            db.flush()
            for j in range(1, 5):
                db.add(Post(code=f"{code}-DESK-{(k - 1) * 4 + j}", title=f"Desk Officer {(k - 1) * 4 + j} — {r.name}", level=1,
                            region_id=r.id, parent_post_id=dd.id))
    db.flush()
    ensure_default_rules(db)
    seed_routes(db)
    seed_templates(db)
    out = create_demo_accounts(db, regions)
    audit(db, None, "SYSTEM_BOOTSTRAPPED", "system", "bootstrap", None, {"regions": len(regions), "demo_accounts": out["accounts"]})
    return out


def _post(db, code) -> Post:
    return db.execute(select(Post).where(Post.code == code)).scalar_one()


def create_demo_accounts(db: Session, regions: dict) -> dict:
    sr, wr = regions["SR"], regions["WR"]
    inst = Institution(aicte_id="DEMO-SR-0001", name="Kaveri Institute of Technology (SYNTHETIC DEMO)", region_id=sr.id, state="Tamil Nadu",
                       district="Chengalpattu", tier=2, address="Plot 14, Old Mahabalipuram Road, Chengalpattu (fictional)", lat=12.84, lon=80.05,
                       preferred_language="en", is_synthetic=True, responsiveness=1.0)
    inst2 = Institution(aicte_id="DEMO-WR-0001", name="Sahyadri College of Engineering (SYNTHETIC DEMO)", region_id=wr.id, state="Maharashtra",
                        district="Pune", tier=1, address="Survey 22, Hinjewadi, Pune (fictional)", lat=18.59, lon=73.74, preferred_language="mr",
                        is_synthetic=True)
    db.add_all([inst, inst2])
    db.flush()
    people = [
        ("superadmin@regulens.demo", "Shreya Iyer (Super Admin)", "SUPER_ADMIN", None, None, None),
        ("admin@regulens.demo", "Arvind Menon (AICTE Admin)", "AICTE_ADMIN", None, None, "HQ-DIRECTOR-MONITORING"),
        ("admin2@regulens.demo", "Farah Qureshi (AICTE Admin, 2nd approver)", "AICTE_ADMIN", None, None, None),
        ("ro.south@regulens.demo", "Karthik Raman (Regional Officer, SR desk)", "REGIONAL_OFFICER", sr.id, None, "SR-DESK-1"),
        ("dd.south@regulens.demo", "Lakshmi Narayanan (Deputy Director, SR)", "REGIONAL_OFFICER", sr.id, None, "SR-DD-1"),
        ("head.south@regulens.demo", "Dr. P. Venkatesan (Regional Head, SR)", "REGIONAL_OFFICER", sr.id, None, "SR-RO-HEAD"),
        ("bureau@regulens.demo", "Meera Pillai (Bureau Officer, SR)", "BUREAU_OFFICER", sr.id, None, "SR-DESK-2"),
        ("ro.west@regulens.demo", "Rohan Deshmukh (Regional Officer, WR)", "REGIONAL_OFFICER", wr.id, None, "WR-DESK-1"),
        ("committee@regulens.demo", "Prof. Anita Krishnan (EVC Expert)", "COMMITTEE_MEMBER", sr.id, None, None),
        ("authority@regulens.demo", "Dr. Rajesh Sharma (Competent Authority)", "COMPETENT_AUTHORITY", None, None, "HQ-ADVISER-APPROVAL"),
        ("auditor@regulens.demo", "Neha Gupta (Audit Officer)", "AUDIT_OFFICER", None, None, None),
        ("principal@kaveri-demo.in", "Dr. S. Balasubramanian (Principal, demo)", "INSTITUTION_PRINCIPAL", sr.id, inst.id, None),
        ("compliance@kaveri-demo.in", "Divya Sundaram (Compliance, demo)", "INSTITUTION_COMPLIANCE", sr.id, inst.id, None),
        ("principal@sahyadri-demo.in", "Dr. Vikram Patil (Principal, demo)", "INSTITUTION_PRINCIPAL", wr.id, inst2.id, None),
    ]
    pw = hash_password(DEMO_PASSWORD)
    users = {}
    for email, name, role, reg, iid, post in people:
        u = User(email=email, full_name=name, password_hash=pw, role=role, region_id=reg, institution_id=iid,
                 phone="+919800000" + str(100 + len(users)), preferred_language="ta" if email == "principal@kaveri-demo.in" else "en")
        db.add(u)
        db.flush()
        if post:
            p = _post(db, post)
            p.holder_user_id, u.post_id = u.id, p.id
        users[email] = u
    for i, (role, u) in enumerate([("PRINCIPAL", users["principal@kaveri-demo.in"]), ("COMPLIANCE", users["compliance@kaveri-demo.in"])]):
        db.add(InstitutionContact(institution_id=inst.id, role=role, name=u.full_name, email=u.email, phone=u.phone, verified=True, user_id=u.id))
    db.add(InstitutionContact(institution_id=inst.id, role="TRUST_REP", name="Kaveri Educational Trust (fictional)", email="trust@kaveri-demo.in",
                              phone="+919800000199", verified=False))
    db.add(InstitutionContact(institution_id=inst2.id, role="PRINCIPAL", name=users["principal@sahyadri-demo.in"].full_name,
                              email="principal@sahyadri-demo.in", phone="+919800000198", verified=True, user_id=users["principal@sahyadri-demo.in"].id))
    # demo experts near Chennai (one linked to the committee login, one with a declared conflict of interest)
    ex = [("Prof. Anita Krishnan (fictional)", ["ACADEMICS", "LABS"], 13.01, 80.23, users["committee@regulens.demo"].id, []),
          ("Dr. Ramesh Iyengar (fictional)", ["CIVIL_INFRA", "LEGAL_LAND"], 12.92, 80.12, None, []),
          ("Dr. Sujatha Rao (fictional)", ["ACADEMICS", "CIVIL_INFRA"], 13.05, 80.21, None, [inst.id]),
          ("Prof. Imran Sheikh (fictional)", ["LABS", "ACADEMICS"], 11.02, 76.96, None, []),
          ("Dr. Kavitha Menon (fictional)", ["CIVIL_INFRA", "LABS"], 9.93, 76.27, None, []),
          ("Prof. George Thomas (fictional)", ["LEGAL_LAND", "ACADEMICS"], 10.79, 78.70, None, [])]
    for name, exp, lat, lon, uid, coi in ex:
        db.add(Expert(name=name, expertise=exp, region_id=sr.id, city="Tamil Nadu", lat=lat, lon=lon, monthly_cap=4, user_id=uid,
                      coi_institution_ids=coi, unavailable_dates=[], is_synthetic=True))
    db.flush()
    return {"accounts": len(people), "password": DEMO_PASSWORD, "demo_institution_id": inst.id}


def seed_demo_workload(db: Session) -> dict:
    """Idempotent: gives the demo institutions realistic open items so the portal and inboxes are not empty."""
    from datetime import timedelta
    from app.models import Application, InstitutionalDocument
    from app.services import ledger, workflow
    from app.services.clocks import today_ist
    inst = db.execute(select(Institution).where(Institution.aicte_id == "DEMO-SR-0001")).scalar_one_or_none()
    if not inst or db.execute(select(Application.id).where(Application.institution_id == inst.id)).first():
        return {"skipped": True}
    u = {x.email: x for x in db.execute(select(User).where(User.is_synthetic.is_(False))).scalars()}
    ro, bur = u["ro.south@regulens.demo"], u["bureau@regulens.demo"]
    t = today_ist()
    app = workflow.register(db, ro, institution_id=inst.id, application_type="INCREASE_IN_INTAKE", assigned_officer_id=bur.id)
    workflow.return_to_institution(db, bur, app, "Faculty list for the additional intake is incomplete; upload qualifications of 6 new faculty.",
                                   "FACULTY_SHORTFALL")
    workflow.register(db, ro, institution_id=inst.id, application_type="NEW_COURSE", assigned_officer_id=bur.id)
    mk = lambda **k: ledger.create_obligation(db, ro, institution_id=inst.id, owner_side="INSTITUTION", source_event="DEMO_SEED", **k)
    mk(obligation_type="APPROVAL_UNDERTAKING", title="Submit valid Fire Safety NOC", due_date=t + timedelta(days=20),
       evidence_requirements=["Fire Safety NOC issued by the State Fire Service"])
    mk(obligation_type="INSTITUTIONAL_COMPLIANCE", title="Upload audited statement of accounts 2025-26", start_date=t - timedelta(days=50),
       budget_days=40, day_mode="CALENDAR", evidence_requirements=["Audited accounts signed by a chartered accountant"])
    o3 = mk(obligation_type="APPROVAL_UNDERTAKING", title="Display the approval letter on the institution website", due_date=t + timedelta(days=60),
            evidence_requirements=["Screenshot or URL of the published approval letter"])
    ledger.acknowledge(db, u["principal@kaveri-demo.in"], o3, "PORTAL")
    exp = t + timedelta(days=45)
    d = InstitutionalDocument(institution_id=inst.id, doc_type="LEASE_DEED", issue_date=exp.replace(year=exp.year - 9), expiry_date=exp,
                              ocr_status="IMPORTED", verification_status="CONFIRMED", verified_by=ro.id, is_current=True, is_synthetic=True)
    db.add(d)
    db.flush()
    lo = mk(obligation_type="LEASE_RENEWAL", title=f"Renew Lease Deed (expires {exp:%d %b %Y})", due_date=exp,
            evidence_requirements=["Registered renewed lease deed"])
    d.obligation_id = lo.id
    return {"seeded": True}
