"""Secure file intake: type/size validation, SHA-256, malware scan, storage (local or S3/MinIO)."""
from __future__ import annotations

import hashlib
import secrets
import socket
import struct
from pathlib import Path

from fastapi import HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models import StoredFile, User
from app.services.audit import audit

ALLOWED = {"application/pdf": b"%PDF", "image/png": b"\x89PNG", "image/jpeg": b"\xff\xd8\xff"}
EICAR = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"


def sniff_mime(data: bytes) -> str | None:
    for mime, magic in ALLOWED.items():
        if data.startswith(magic):
            return mime
    return None


# ---------------------------------------------------------------- malware scanning
def scan(data: bytes) -> tuple[str, str]:
    """ClamAV (clamd INSTREAM) when CLAMD_HOST is configured; otherwise a clearly-labelled local fallback."""
    if settings.clamd_host:
        try:
            with socket.create_connection((settings.clamd_host, settings.clamd_port), timeout=20) as s:
                s.sendall(b"zINSTREAM\0")
                for i in range(0, len(data), 8192):
                    chunk = data[i:i + 8192]
                    s.sendall(struct.pack("!L", len(chunk)) + chunk)
                s.sendall(struct.pack("!L", 0))
                resp = s.recv(4096).decode(errors="ignore")
            if "FOUND" in resp:
                return "INFECTED", f"clamav: {resp.strip()}"
            if "OK" in resp:
                return "CLEAN", "clamav"
            return "ERROR", f"clamav: {resp.strip()}"
        except OSError as ex:
            return "ERROR", f"clamav unreachable: {ex}"
    if EICAR in data:
        return "INFECTED", "local-signature-scanner (EICAR) — dev fallback, ClamAV not configured"
    if data.startswith(b"%PDF"):
        head = data[:200000]
        if b"/Launch" in head or (b"/JavaScript" in head and b"/OpenAction" in head):
            return "INFECTED", "local-signature-scanner (active PDF content) — dev fallback, ClamAV not configured"
    return "CLEAN", "local-signature-scanner — dev fallback, ClamAV not configured"


# ---------------------------------------------------------------- storage
class LocalStorage:
    def put(self, key: str, data: bytes) -> None:
        p = settings.storage_dir / key
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)

    def get(self, key: str) -> bytes:
        return (settings.storage_dir / key).read_bytes()


class S3Storage:  # MinIO / any S3-compatible store
    def __init__(self):
        import boto3  # optional dependency, installed in the Docker image
        self.c = boto3.client("s3", endpoint_url=settings.s3_endpoint, aws_access_key_id=settings.s3_access_key,
                              aws_secret_access_key=settings.s3_secret_key)
        self.b = settings.s3_bucket

    def put(self, key, data):
        self.c.put_object(Bucket=self.b, Key=key, Body=data, ServerSideEncryption="AES256")

    def get(self, key):
        return self.c.get_object(Bucket=self.b, Key=key)["Body"].read()


_store = None


def storage():
    global _store
    if _store is None:
        _store = S3Storage() if settings.storage_backend == "s3" else LocalStorage()
    return _store


def store_bytes(db: Session, actor: User | None, data: bytes, filename: str, purpose: str,
                institution_id: int | None = None) -> StoredFile:
    if len(data) == 0:
        raise HTTPException(422, "Empty file.")
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(413, f"File exceeds {settings.max_upload_mb} MB limit.")
    mime = sniff_mime(data)
    if not mime:
        raise HTTPException(415, "Only PDF, PNG and JPEG files are accepted (checked by file signature, not extension).")
    digest = hashlib.sha256(data).hexdigest()
    status, engine = scan(data)
    if status != "CLEAN":
        audit(db, actor, "UPLOAD_BLOCKED", "file", digest[:16], None, {"filename": filename, "scan": status, "engine": engine})
        db.commit()
        raise HTTPException(422, f"File rejected by malware scan ({engine}).")
    safe = "".join(ch for ch in Path(filename).name if ch.isalnum() or ch in "._-")[:120] or "upload"
    key = f"{purpose}/{digest[:2]}/{digest}-{secrets.token_hex(4)}-{safe}"
    storage().put(key, data)
    f = StoredFile(storage_key=key, filename=safe, mime=mime, size=len(data), sha256=digest, scan_status=status, scan_engine=engine,
                   institution_id=institution_id, uploaded_by=actor.id if actor else None, purpose=purpose)
    db.add(f)
    db.flush()
    audit(db, actor, "FILE_UPLOADED", "file", f.id, None, {"filename": safe, "sha256": digest, "size": len(data), "mime": mime,
                                                           "scan": engine, "purpose": purpose})
    return f


async def store_upload(db: Session, actor: User | None, up: UploadFile, purpose: str, institution_id: int | None = None) -> StoredFile:
    data = await up.read()
    return store_bytes(db, actor, data, up.filename or "upload", purpose, institution_id)


def read(f: StoredFile) -> bytes:
    return storage().get(f.storage_key)
