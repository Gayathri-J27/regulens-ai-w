"""Integration adapters + migration workflow (preview -> validation -> staging -> commit/cutover simulation).

Canonical schema (one per entity). CSV and API adapters both normalise into these dicts; the
synthetic adapter generates them. The existing AICTE system stays authoritative for statutory decisions.
"""
from __future__ import annotations

import csv
import io
from datetime import date, datetime, time, timedelta, timezone

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import now
from app.models import Application, ImportBatch, Institution, Region, User
from app.services import ledger, workflow
from app.services.audit import audit

IST = timezone(timedelta(hours=5, minutes=30))

CANONICAL = {
    "institution": {"required": ["aicte_id", "name", "region_code", "state"],
                    "optional": ["district", "tier", "address", "preferred_language", "principal_name", "principal_email", "principal_phone"]},
    "application": {"required": ["institution_aicte_id", "application_type"],
                    "optional": ["route_code", "submitted_on", "academic_year", "external_ref"]},
    "undertaking": {"required": ["institution_aicte_id", "title", "due_date"],
                    "optional": ["start_date", "description", "evidence_requirement", "application_ref", "obligation_type"]},
    "document": {"required": ["institution_aicte_id", "doc_type", "expiry_date"], "optional": ["issue_date", "confirmed_by"]},
    "evc_visit": {"required": ["institution_aicte_id", "application_ref", "scheduled_date"], "optional": ["status"]},
}


def _d(v: str | None) -> date | None:
    if not v:
        return None
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%d.%m.%Y"):
        try:
            return datetime.strptime(v.strip(), fmt).date()
        except ValueError:
            pass
    raise ValueError(f"unparseable date '{v}'")


def validate_rows(db: Session, entity: str, rows: list[dict]) -> tuple[list[dict], list[dict], list[dict]]:
    spec = CANONICAL.get(entity)
    if not spec:
        raise HTTPException(422, f"entity must be one of {list(CANONICAL)}")
    regions = {r.code: r.id for r in db.execute(select(Region)).scalars()}
    known_inst = {a for a in db.execute(select(Institution.aicte_id)).scalars()}
    seen = set()
    good, errors, dups = [], [], []
    for i, raw in enumerate(rows, start=2):
        r = {k.strip(): (v.strip() if isinstance(v, str) else v) for k, v in raw.items() if k}
        miss = [c for c in spec["required"] if not r.get(c)]
        if miss:
            errors.append({"row": i, "error": f"missing {', '.join(miss)}"})
            continue
        try:
            if entity == "institution":
                if r["region_code"] not in regions:
                    raise ValueError(f"unknown region {r['region_code']}")
                if r["aicte_id"] in known_inst:
                    dups.append({"row": i, "key": r["aicte_id"], "reason": "already exists in ReguLens"})
                    continue
                key = r["aicte_id"]
                if r.get("tier") and r["tier"] not in ("1", "2", "3"):
                    raise ValueError("tier must be 1, 2 or 3")
            else:
                if r["institution_aicte_id"] not in known_inst and r["institution_aicte_id"] not in seen:
                    raise ValueError(f"unknown institution {r['institution_aicte_id']}")
                key = tuple(r.get(c) for c in spec["required"])
            if entity == "application" and r["application_type"] not in workflow.APP_TYPES:
                raise ValueError(f"application_type must be one of {workflow.APP_TYPES}")
            for c in ("due_date", "start_date", "expiry_date", "issue_date", "submitted_on", "scheduled_date"):
                if r.get(c):
                    r[c] = _d(r[c]).isoformat()
            if entity == "undertaking" and r.get("start_date") and r["start_date"] > r["due_date"]:
                raise ValueError("start_date after due_date")
        except ValueError as e:
            errors.append({"row": i, "error": str(e)})
            continue
        if key in seen:
            dups.append({"row": i, "key": str(key), "reason": "duplicate within file"})
            continue
        seen.add(key)
        good.append(r)
    return good, errors, dups


def stage(db: Session, actor: User, adapter: str, entity: str, rows: list[dict], filename: str | None) -> ImportBatch:
    good, errors, dups = validate_rows(db, entity, rows)
    b = ImportBatch(adapter=adapter, entity=entity, filename=filename, status="STAGED", staged_rows=good, errors=errors, duplicates=dups,
                    counts={"received": len(rows), "valid": len(good), "errors": len(errors), "duplicates": len(dups)}, created_by=actor.id)
    db.add(b)
    db.flush()
    audit(db, actor, "IMPORT_STAGED", "import_batch", b.id, None, b.counts | {"adapter": adapter, "entity": entity})
    return b


def parse_csv(data: bytes) -> list[dict]:
    text = data.decode("utf-8-sig", errors="replace")
    return list(csv.DictReader(io.StringIO(text)))


def commit(db: Session, actor: User, b: ImportBatch, dry_run: bool) -> dict:
    """Apply staged rows. dry_run=True is the cutover simulation: everything runs, then rolls back."""
    if b.status != "STAGED":
        raise HTTPException(409, f"Batch is {b.status}")
    sp = db.begin_nested()
    created, recon = 0, []
    try:
        regions = {r.code: r.id for r in db.execute(select(Region)).scalars()}
        for r in b.staged_rows:
            inst = None
            if b.entity != "institution":
                inst = db.execute(select(Institution).where(Institution.aicte_id == r["institution_aicte_id"])).scalar_one()
            if b.entity == "institution":
                i = Institution(aicte_id=r["aicte_id"], name=r["name"], region_id=regions[r["region_code"]], state=r["state"],
                                district=r.get("district"), tier=int(r.get("tier") or 2), address=r.get("address"),
                                preferred_language=r.get("preferred_language") or "en")
                db.add(i)
                db.flush()
                if r.get("principal_email") or r.get("principal_phone"):
                    from app.models import InstitutionContact
                    db.add(InstitutionContact(institution_id=i.id, role="PRINCIPAL", name=r.get("principal_name") or "Principal",
                                              email=r.get("principal_email"), phone=r.get("principal_phone")))
            elif b.entity == "application":
                a = workflow.register(db, actor, institution_id=inst.id, application_type=r["application_type"], route_code=r.get("route_code") or None,
                                      academic_year=r.get("academic_year") or "2026-27")
                if r.get("submitted_on"):
                    a.created_at = datetime.combine(date.fromisoformat(r["submitted_on"]), time(10), tzinfo=IST)
            elif b.entity == "undertaking":
                start = date.fromisoformat(r["start_date"]) if r.get("start_date") else None
                due = date.fromisoformat(r["due_date"])
                o = ledger.create_obligation(db, actor, institution_id=inst.id, obligation_type=r.get("obligation_type") or "APPROVAL_UNDERTAKING",
                                             title=r["title"], description=r.get("description") or "", source_event=f"IMPORT:{b.id}",
                                             evidence_requirements=[r["evidence_requirement"]] if r.get("evidence_requirement") else [],
                                             start_date=min(start or due, due), due_date=due, owner_side="INSTITUTION", notify=not dry_run)
                recon.append({"title": r["title"], "reconstructed_due": o.due_date.isoformat() if o.due_date else None,
                              "state": "OVERDUE" if o.due_date and o.due_date < date.today() else "OPEN"})
            elif b.entity == "document":
                from app.models import InstitutionalDocument
                d = InstitutionalDocument(institution_id=inst.id, doc_type=r["doc_type"], expiry_date=date.fromisoformat(r["expiry_date"]),
                                          issue_date=date.fromisoformat(r["issue_date"]) if r.get("issue_date") else None,
                                          ocr_status="IMPORTED", verification_status="CONFIRMED", verified_by=actor.id, verified_at=now(),
                                          is_current=True)
                db.add(d)
                db.flush()
                exp = d.expiry_date
                o = ledger.create_obligation(db, actor, institution_id=inst.id,
                                             obligation_type="LEASE_RENEWAL" if r["doc_type"] == "LEASE_DEED" else "DOCUMENT_RENEWAL",
                                             title=f"Renew {r['doc_type'].replace('_', ' ').title()} (expires {exp:%d %b %Y})",
                                             source_event=f"IMPORT:{b.id}", start_date=min(date.today(), exp), due_date=exp,
                                             owner_side="INSTITUTION", notify=False)
                d.obligation_id = o.id
            elif b.entity == "evc_visit":
                a = db.execute(select(Application).where(Application.app_no == r["application_ref"])).scalar_one_or_none()
                if not a:
                    raise HTTPException(422, f"application {r['application_ref']} not found")
                from app.services.evc import queue_visit
                queue_visit(db, a, actor)
            created += 1
        if dry_run:
            sp.rollback()
        else:
            sp.commit()
    except Exception:
        sp.rollback()
        raise
    result = {"created": created, "dry_run": dry_run, "clock_reconstruction": recon[:50]}
    if not dry_run:
        b.status, b.committed_at = "COMMITTED", now()
    b.counts = {**b.counts, "last_run": result | {"clock_reconstruction": len(recon)}}
    audit(db, actor, "IMPORT_CUTOVER_SIMULATED" if dry_run else "IMPORT_COMMITTED", "import_batch", b.id, None,
          {"created": created, "dry_run": dry_run})
    return result


OPENAPI_CONTRACT = {
    "openapi": "3.0.3",
    "info": {"title": "ReguLens canonical import API (stub)", "version": "1.0",
             "description": "Contract for a future feed from the authoritative AICTE portal. In this prototype the endpoint is a "
                            "testable stub: payloads are validated and staged exactly like CSV imports; no AICTE system is connected."},
    "paths": {"/api/integration/v1/{entity}": {"post": {
        "parameters": [{"name": "entity", "in": "path", "required": True, "schema": {"type": "string", "enum": list(CANONICAL)}}],
        "requestBody": {"content": {"application/json": {"schema": {"type": "object", "properties": {
            "records": {"type": "array", "items": {"type": "object"}}, "source_system": {"type": "string"}}}}}},
        "responses": {"200": {"description": "Batch staged (preview/validation report)"}}}}},
    "components": {"schemas": {e: {"type": "object", "required": s["required"],
                                   "properties": {c: {"type": "string"} for c in s["required"] + s["optional"]}} for e, s in CANONICAL.items()}},
}
