"""Tamper-evident audit trail service: append, verify, seal, anchor, demo tamper test."""
from __future__ import annotations

import json
import time
from datetime import date, datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import correlation_id, now
from app.engines.audit_chain import GENESIS, entry_hash, sign_head, verify_chain
from app.models import AuditDemoLog, AuditLog, AuditSeal, AuditVerification, User

_CHAIN_LOCK = 724_001  # advisory lock id serialising chain appends


def jsonable(v: Any) -> Any:
    if v is None:
        return None
    return json.loads(json.dumps(v, default=lambda o: o.isoformat() if hasattr(o, "isoformat") else str(o)))


def snapshot(obj, fields: list[str] | None = None) -> dict:
    cols = fields or [c.key for c in obj.__table__.columns]
    return jsonable({c: getattr(obj, c) for c in cols if c not in ("password_hash", "totp_secret", "reset_token_hash")})


def audit(db: Session, actor: User | None, action: str, entity_type: str, entity_id: Any,
          before: dict | None = None, after: dict | None = None, reason: str | None = None) -> AuditLog:
    """Append one entry. Serialised by an advisory transaction lock so the chain stays linear."""
    db.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": _CHAIN_LOCK})
    last = db.execute(select(AuditLog.hash).order_by(AuditLog.id.desc()).limit(1)).scalar_one_or_none()
    prev = last or GENESIS
    new_id = db.execute(text("SELECT nextval('audit_log_id_seq')")).scalar_one()
    entry = {
        "id": new_id, "ts": now(), "actor_id": actor.id if actor else None,
        "actor_role": actor.role if actor else "SYSTEM", "action": action, "entity_type": entity_type,
        "entity_id": None if entity_id is None else str(entity_id), "before": jsonable(before), "after": jsonable(after),
        "reason": reason, "correlation_id": correlation_id.get(),
    }
    h = entry_hash(prev, entry)
    row = AuditLog(**entry, prev_hash=prev, hash=h)
    db.add(row)
    db.flush()
    return row


def _row_dict(r) -> dict:
    return {"id": r.id, "ts": r.ts, "actor_id": r.actor_id, "actor_role": r.actor_role, "action": r.action,
            "entity_type": r.entity_type, "entity_id": r.entity_id, "before": r.before, "after": r.after,
            "reason": r.reason, "correlation_id": r.correlation_id, "prev_hash": r.prev_hash, "hash": r.hash}


def _iter_rows(db: Session, model, batch: int = 5000):
    last = 0
    while True:
        rows = db.execute(select(model).where(model.id > last).order_by(model.id).limit(batch)).scalars().all()
        if not rows:
            return
        for r in rows:
            yield _row_dict(r)
        last = rows[-1].id


def verify(db: Session, trigger: str, user: User | None = None, target: str = "MAIN") -> AuditVerification:
    t0 = time.perf_counter()
    model = AuditLog if target == "MAIN" else AuditDemoLog
    res = verify_chain(_iter_rows(db, model))
    seals_checked = 0
    if res["ok"] and target == "MAIN":
        # independent check of signed daily heads against the chain and the external anchor store
        anchored = _read_anchor()
        for s in db.execute(select(AuditSeal).order_by(AuditSeal.day)).scalars():
            seals_checked += 1
            h = db.execute(select(AuditLog.hash).where(AuditLog.id == s.last_audit_id)).scalar_one_or_none()
            sig_ok = sign_head(settings.audit_signing_key, s.day.isoformat(), s.head_hash, s.last_audit_id) == s.signature
            anc = anchored.get(s.day.isoformat())
            anchor_ok = anc is None or (anc["head_hash"] == s.head_hash and anc["signature"] == s.signature)
            if h != s.head_hash or not sig_ok or not anchor_ok:
                res = {"ok": False, "checked": res["checked"], "first_broken_id": s.last_audit_id,
                       "detail": f"sealed head for {s.day} does not match chain/signature/anchor"}
                break
    v = AuditVerification(trigger=trigger, target=target, ok=res["ok"], checked=res["checked"],
                          first_broken_id=res["first_broken_id"], detail=res.get("detail"), seals_checked=seals_checked,
                          duration_ms=round((time.perf_counter() - t0) * 1000, 1), run_by=user.id if user else None)
    db.add(v)
    db.flush()
    if not res["ok"] and target == "MAIN":
        from app.services.notifications import notify_role
        notify_role(db, "AUDIT_OFFICER", "audit_chain_broken", {"first_broken_id": res["first_broken_id"],
                                                                 "detail": res.get("detail") or ""},
                    entity=("audit", res["first_broken_id"] or 0), key_suffix=f"v{v.id}")
    return v


# ---------------------------------------------------------------- daily sealing + external anchor
def _anchor_file():
    return settings.anchor_dir / "daily-heads.jsonl"


def _read_anchor() -> dict:
    p = _anchor_file()
    out = {}
    if p.exists():
        for line in p.read_text().splitlines():
            if line.strip():
                d = json.loads(line)
                out[d["day"]] = d
    return out


def seal_day(db: Session, day: date) -> AuditSeal | None:
    """Seal all entries up to the end of ``day`` (IST) under a signed head; append to the anchor store."""
    if db.execute(select(AuditSeal).where(AuditSeal.day == day)).scalar_one_or_none():
        return None
    end = datetime.combine(day + timedelta(days=1), datetime.min.time(), tzinfo=timezone(timedelta(hours=5, minutes=30)))
    prev_seal = db.execute(select(AuditSeal).order_by(AuditSeal.last_audit_id.desc()).limit(1)).scalar_one_or_none()
    lo = prev_seal.last_audit_id if prev_seal else 0
    agg = db.execute(select(func.min(AuditLog.id), func.max(AuditLog.id), func.count())
                     .where(AuditLog.id > lo, AuditLog.ts < end)).one()
    if not agg[1]:
        return None
    head = db.execute(select(AuditLog.hash).where(AuditLog.id == agg[1])).scalar_one()
    sig = sign_head(settings.audit_signing_key, day.isoformat(), head, agg[1])
    seal = AuditSeal(day=day, first_audit_id=agg[0], last_audit_id=agg[1], entry_count=agg[2], head_hash=head, signature=sig)
    db.add(seal)
    # append-only external anchor (dev trust anchor; use S3 Object Lock / WORM storage in production)
    with open(_anchor_file(), "a") as f:
        f.write(json.dumps({"day": day.isoformat(), "last_audit_id": agg[1], "head_hash": head, "signature": sig,
                            "sealed_at": now().isoformat()}) + "\n")
    seal.anchored = True
    db.flush()
    return seal


# ---------------------------------------------------------------- isolated tamper demonstration
def tamper_demo(db: Session, user: User) -> dict:
    """Builds a fresh *isolated* demo chain (audit_demo_log), verifies it, alters one record and
    re-verifies. The production audit_log is never touched."""
    db.execute(text("TRUNCATE audit_demo_log RESTART IDENTITY"))
    prev = GENESIS
    t = now()
    for i in range(1, 21):
        e = {"id": i, "ts": t + timedelta(seconds=i), "actor_id": user.id, "actor_role": user.role,
             "action": "DEMO_STATE_CHANGE", "entity_type": "demo_obligation", "entity_id": str(1000 + i % 5),
             "before": {"state": "OPEN"}, "after": {"state": "MET" if i % 2 else "SUBMITTED"},
             "reason": f"synthetic demo event {i}", "correlation_id": "tamper-demo"}
        h = entry_hash(prev, e)
        db.add(AuditDemoLog(**e, prev_hash=prev, hash=h))
        prev = h
    db.flush()
    before = verify(db, "DEMO", user, target="DEMO")
    victim = 13
    db.execute(text("UPDATE audit_demo_log SET after = '{\"state\": \"WAIVED\"}'::jsonb, reason = 'silently altered' WHERE id = :i"),
               {"i": victim})
    after = verify(db, "DEMO", user, target="DEMO")
    audit(db, user, "AUDIT_TAMPER_DEMO_RUN", "audit_demo_log", victim, None,
          {"before_ok": before.ok, "after_ok": after.ok, "detected_at": after.first_broken_id})
    return {"isolated_table": "audit_demo_log", "entries": 20, "altered_entry": victim,
            "verification_before": {"ok": before.ok, "checked": before.checked},
            "verification_after": {"ok": after.ok, "checked": after.checked, "first_broken_id": after.first_broken_id,
                                   "detail": after.detail},
            "detected": (not after.ok) and after.first_broken_id == victim}
