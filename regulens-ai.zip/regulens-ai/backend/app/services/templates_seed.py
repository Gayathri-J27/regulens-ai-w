"""Notification templates (v1) in English, Hindi, Marathi and Tamil.

Stored as fixed, versioned rows — nothing is machine-translated at send time.
The en text is the source; hi/mr/ta texts were drafted by the development team and are flagged
DRAFT_REQUIRES_HUMAN_REVIEW until a native-speaker reviewer approves them (KNOWN_LIMITATIONS.md).
"""

T: dict[str, dict[str, tuple[str, str]]] = {
    "application_assigned": {
        "en": ("Application {app_no} assigned to you", "Application {app_no} ({institution}) is assigned to you at stage {stage}. Due: {due}."),
        "hi": ("आवेदन {app_no} आपको सौंपा गया", "आवेदन {app_no} ({institution}) चरण {stage} पर आपको सौंपा गया है। नियत तिथि: {due}।"),
        "mr": ("अर्ज {app_no} आपल्याकडे सोपवला", "अर्ज {app_no} ({institution}) टप्पा {stage} वर आपल्याकडे सोपवला आहे. देय दिनांक: {due}."),
        "ta": ("விண்ணப்பம் {app_no} உங்களுக்கு ஒதுக்கப்பட்டது", "விண்ணப்பம் {app_no} ({institution}) {stage} நிலையில் உங்களுக்கு ஒதுக்கப்பட்டுள்ளது. இறுதி நாள்: {due}."),
    },
    "stage_completed": {
        "en": ("{app_no}: {stage} completed", "Stage {stage} of application {app_no} was completed. Next stage: {next_stage}."),
        "hi": ("{app_no}: {stage} पूर्ण", "आवेदन {app_no} का चरण {stage} पूर्ण हुआ। अगला चरण: {next_stage}।"),
        "mr": ("{app_no}: {stage} पूर्ण", "अर्ज {app_no} चा टप्पा {stage} पूर्ण झाला. पुढील टप्पा: {next_stage}."),
        "ta": ("{app_no}: {stage} நிறைவு", "விண்ணப்பம் {app_no} இன் {stage} நிலை நிறைவடைந்தது. அடுத்த நிலை: {next_stage}."),
    },
    "application_returned": {
        "en": ("Action required: application {app_no} returned", "Application {app_no} was returned for: {reason}. Please respond by {due}."),
        "hi": ("कार्रवाई आवश्यक: आवेदन {app_no} लौटाया गया", "आवेदन {app_no} इस कारण से लौटाया गया: {reason}। कृपया {due} तक उत्तर दें।"),
        "mr": ("कृती आवश्यक: अर्ज {app_no} परत पाठवला", "अर्ज {app_no} या कारणासाठी परत पाठवला: {reason}. कृपया {due} पर्यंत उत्तर द्या."),
        "ta": ("நடவடிக்கை தேவை: விண்ணப்பம் {app_no} திருப்பி அனுப்பப்பட்டது", "விண்ணப்பம் {app_no} இதற்காக திருப்பி அனுப்பப்பட்டது: {reason}. {due} க்குள் பதிலளிக்கவும்."),
    },
    "deadline_upcoming": {
        "en": ("Reminder: {title} due {due}", "{title} ({obl_no}) is due on {due} — {days} day(s) left."),
        "hi": ("अनुस्मारक: {title} की नियत तिथि {due}", "{title} ({obl_no}) की नियत तिथि {due} है — {days} दिन शेष।"),
        "mr": ("स्मरणपत्र: {title} देय {due}", "{title} ({obl_no}) ची देय तारीख {due} आहे — {days} दिवस बाकी."),
        "ta": ("நினைவூட்டல்: {title} இறுதி நாள் {due}", "{title} ({obl_no}) இன் இறுதி நாள் {due} — {days} நாள்(கள்) மீதம்."),
    },
    "deadline_overdue": {
        "en": ("OVERDUE: {title}", "{title} ({obl_no}) was due on {due} and is overdue by {days} day(s)."),
        "hi": ("समय सीमा पार: {title}", "{title} ({obl_no}) की नियत तिथि {due} थी; {days} दिन की देरी।"),
        "mr": ("मुदत ओलांडली: {title}", "{title} ({obl_no}) ची देय तारीख {due} होती; {days} दिवस उशीर."),
        "ta": ("காலாவதி: {title}", "{title} ({obl_no}) {due} அன்று செலுத்த வேண்டியது; {days} நாள் தாமதம்."),
    },
    "undertaking_created": {
        "en": ("New obligation: {title}", "A new obligation {obl_no} has been recorded for your institution: {title}. Due: {due}. Evidence: {evidence}."),
        "hi": ("नया दायित्व: {title}", "आपकी संस्था के लिए नया दायित्व {obl_no} दर्ज किया गया: {title}। नियत तिथि: {due}। साक्ष्य: {evidence}।"),
        "mr": ("नवीन दायित्व: {title}", "आपल्या संस्थेसाठी नवीन दायित्व {obl_no} नोंदवले: {title}. देय: {due}. पुरावा: {evidence}."),
        "ta": ("புதிய கடமை: {title}", "உங்கள் நிறுவனத்திற்கு புதிய கடமை {obl_no} பதிவு செய்யப்பட்டது: {title}. இறுதி நாள்: {due}. ஆதாரம்: {evidence}."),
    },
    "evidence_submitted": {
        "en": ("Evidence received for {obl_no}", "{institution} submitted evidence for {title}. Receipt {receipt}. Please verify."),
        "hi": ("{obl_no} हेतु साक्ष्य प्राप्त", "{institution} ने {title} के लिए साक्ष्य जमा किया। रसीद {receipt}। कृपया सत्यापित करें।"),
        "mr": ("{obl_no} साठी पुरावा प्राप्त", "{institution} ने {title} साठी पुरावा सादर केला. पावती {receipt}. कृपया पडताळणी करा."),
        "ta": ("{obl_no} க்கான ஆதாரம் பெறப்பட்டது", "{institution} {title} க்கான ஆதாரத்தை சமர்ப்பித்தது. ரசீது {receipt}. சரிபார்க்கவும்."),
    },
    "evidence_verified": {
        "en": ("Evidence verified: {obl_no}", "Your evidence for {title} (receipt {receipt}) has been verified. The obligation is closed."),
        "hi": ("साक्ष्य सत्यापित: {obl_no}", "{title} के लिए आपका साक्ष्य (रसीद {receipt}) सत्यापित हुआ। दायित्व बंद।"),
        "mr": ("पुरावा पडताळला: {obl_no}", "{title} साठी आपला पुरावा (पावती {receipt}) पडताळला. दायित्व बंद."),
        "ta": ("ஆதாரம் சரிபார்க்கப்பட்டது: {obl_no}", "{title} க்கான உங்கள் ஆதாரம் (ரசீது {receipt}) சரிபார்க்கப்பட்டது. கடமை மூடப்பட்டது."),
    },
    "evidence_rejected": {
        "en": ("Evidence not accepted: {obl_no}", "Evidence for {title} (receipt {receipt}) was not accepted: {reason}. Please resubmit by {due}."),
        "hi": ("साक्ष्य अस्वीकृत: {obl_no}", "{title} का साक्ष्य (रसीद {receipt}) अस्वीकृत: {reason}। कृपया {due} तक पुनः जमा करें।"),
        "mr": ("पुरावा अमान्य: {obl_no}", "{title} चा पुरावा (पावती {receipt}) अमान्य: {reason}. कृपया {due} पर्यंत पुन्हा सादर करा."),
        "ta": ("ஆதாரம் ஏற்கப்படவில்லை: {obl_no}", "{title} ஆதாரம் (ரசீது {receipt}) ஏற்கப்படவில்லை: {reason}. {due} க்குள் மீண்டும் சமர்ப்பிக்கவும்."),
    },
    "document_expiring": {
        "en": ("{doc_type} expires {due}", "The {doc_type} of {institution} expires on {due} ({days} day(s)). Upload the renewed document."),
        "hi": ("{doc_type} की समाप्ति {due}", "{institution} का {doc_type} {due} को समाप्त होगा ({days} दिन)। नवीनीकृत दस्तावेज़ अपलोड करें।"),
        "mr": ("{doc_type} ची मुदत {due}", "{institution} चे {doc_type} {due} रोजी संपेल ({days} दिवस). नूतनीकृत दस्तऐवज अपलोड करा."),
        "ta": ("{doc_type} காலாவதி {due}", "{institution} இன் {doc_type} {due} அன்று காலாவதியாகும் ({days} நாள்). புதுப்பிக்கப்பட்ட ஆவணத்தை பதிவேற்றவும்."),
    },
    "evc_scheduled": {
        "en": ("EVC scheduled for {app_no}", "An Expert Visit Committee visit to {institution} is scheduled on {date}."),
        "hi": ("{app_no} हेतु EVC निर्धारित", "{institution} में विशेषज्ञ दौरा समिति का दौरा {date} को निर्धारित है।"),
        "mr": ("{app_no} साठी EVC निश्चित", "{institution} येथे तज्ज्ञ भेट समितीची भेट {date} रोजी निश्चित आहे."),
        "ta": ("{app_no} க்கான EVC திட்டமிடப்பட்டது", "{institution} க்கு நிபுணர் வருகைக் குழு வருகை {date} அன்று திட்டமிடப்பட்டுள்ளது."),
    },
    "evc_delayed": {
        "en": ("EVC delayed: {app_no}", "The EVC for {app_no} ({institution}) is delayed: {reason}."),
        "hi": ("EVC में विलंब: {app_no}", "{app_no} ({institution}) की EVC में विलंब: {reason}।"),
        "mr": ("EVC विलंब: {app_no}", "{app_no} ({institution}) ची EVC विलंबित: {reason}."),
        "ta": ("EVC தாமதம்: {app_no}", "{app_no} ({institution}) EVC தாமதம்: {reason}."),
    },
    "escalation": {
        "en": ("Escalation L{level}: {title}", "{obl_no} — {title} ({institution}) is overdue by {days} day(s) and has been escalated to you (level {level}). Previous owner: {previous}."),
        "hi": ("एस्केलेशन L{level}: {title}", "{obl_no} — {title} ({institution}) {days} दिन से लंबित है और आपको (स्तर {level}) भेजा गया है। पूर्व स्वामी: {previous}।"),
        "mr": ("एस्कलेशन L{level}: {title}", "{obl_no} — {title} ({institution}) {days} दिवस प्रलंबित असून आपल्याकडे (स्तर {level}) पाठवले आहे. पूर्वीचे जबाबदार: {previous}."),
        "ta": ("மேல்நிலை அனுப்புதல் L{level}: {title}", "{obl_no} — {title} ({institution}) {days} நாள் தாமதமாகி உங்களுக்கு (நிலை {level}) அனுப்பப்பட்டது. முந்தைய பொறுப்பாளர்: {previous}."),
    },
    "contact_invalid": {
        "en": ("Contact unreachable for {institution}", "Messages to the {role} contact ({address}) of {institution} are failing ({reason}). Please update contact details."),
        "hi": ("{institution} का संपर्क अप्राप्य", "{institution} के {role} संपर्क ({address}) पर संदेश विफल ({reason})। कृपया संपर्क विवरण अद्यतन करें।"),
        "mr": ("{institution} चा संपर्क अनुपलब्ध", "{institution} च्या {role} संपर्कावर ({address}) संदेश अयशस्वी ({reason}). कृपया संपर्क तपशील अद्ययावत करा."),
        "ta": ("{institution} தொடர்பு கிடைக்கவில்லை", "{institution} இன் {role} தொடர்புக்கு ({address}) செய்திகள் தோல்வி ({reason}). தொடர்பு விவரங்களை புதுப்பிக்கவும்."),
    },
    "nudge": {
        "en": ("Early reminder: {title}", "{title} ({obl_no}) is at {risk} risk of missing its {due} deadline. Reason: {why}. Please act early."),
        "hi": ("अग्रिम अनुस्मारक: {title}", "{title} ({obl_no}) के {due} की समय सीमा चूकने का {risk} जोखिम है। कारण: {why}। कृपया शीघ्र कार्रवाई करें।"),
        "mr": ("आगाऊ स्मरणपत्र: {title}", "{title} ({obl_no}) ची {due} ची मुदत चुकण्याचा {risk} धोका आहे. कारण: {why}. कृपया लवकर कृती करा."),
        "ta": ("முன்கூட்டிய நினைவூட்டல்: {title}", "{title} ({obl_no}) {due} இறுதி நாளை தவறவிடும் {risk} அபாயம் உள்ளது. காரணம்: {why}. விரைவில் செயல்படவும்."),
    },
    "audit_chain_broken": {
        "en": ("AUDIT ALERT: hash chain verification failed", "Audit chain verification failed at entry {first_broken_id}: {detail}."),
        "hi": ("ऑडिट चेतावनी: हैश श्रृंखला सत्यापन विफल", "प्रविष्टि {first_broken_id} पर ऑडिट श्रृंखला सत्यापन विफल: {detail}।"),
        "mr": ("ऑडिट इशारा: हॅश साखळी पडताळणी अयशस्वी", "नोंद {first_broken_id} येथे ऑडिट साखळी पडताळणी अयशस्वी: {detail}."),
        "ta": ("தணிக்கை எச்சரிக்கை: ஹாஷ் சங்கிலி சரிபார்ப்பு தோல்வி", "பதிவு {first_broken_id} இல் தணிக்கை சங்கிலி சரிபார்ப்பு தோல்வி: {detail}."),
    },
    "magic_link": {
        "en": ("Secure link for {obl_no}", "Use this single-use link (valid 7 days) to respond to {title}: {link}"),
        "hi": ("{obl_no} हेतु सुरक्षित लिंक", "{title} का उत्तर देने हेतु यह एकल-उपयोग लिंक (7 दिन मान्य) उपयोग करें: {link}"),
        "mr": ("{obl_no} साठी सुरक्षित दुवा", "{title} ला उत्तर देण्यासाठी हा एकदाच वापरता येणारा दुवा (7 दिवस वैध) वापरा: {link}"),
        "ta": ("{obl_no} க்கான பாதுகாப்பான இணைப்பு", "{title} க்கு பதிலளிக்க இந்த ஒருமுறை இணைப்பைப் (7 நாள் செல்லும்) பயன்படுத்தவும்: {link}"),
    },
    "daily_digest": {
        "en": ("ReguLens daily digest — {count} update(s)", "{lines}"),
        "hi": ("ReguLens दैनिक सारांश — {count} अद्यतन", "{lines}"),
        "mr": ("ReguLens दैनिक सारांश — {count} अद्यतने", "{lines}"),
        "ta": ("ReguLens தினசரி சுருக்கம் — {count} புதுப்பிப்புகள்", "{lines}"),
    },
    "decision_recorded": {
        "en": ("Decision recorded for {app_no}", "The competent authority recorded the decision '{decision}' for application {app_no}."),
        "hi": ("{app_no} हेतु निर्णय दर्ज", "सक्षम प्राधिकारी ने आवेदन {app_no} हेतु निर्णय '{decision}' दर्ज किया।"),
        "mr": ("{app_no} साठी निर्णय नोंदवला", "सक्षम प्राधिकाऱ्याने अर्ज {app_no} साठी निर्णय '{decision}' नोंदवला."),
        "ta": ("{app_no} க்கான முடிவு பதிவு", "தகுதியான அதிகாரி விண்ணப்பம் {app_no} க்கு '{decision}' முடிவை பதிவு செய்தார்."),
    },
    "password_reset": {
        "en": ("ReguLens password reset", "Your password reset code is {code}. It expires in 15 minutes."),
        "hi": ("ReguLens पासवर्ड रीसेट", "आपका पासवर्ड रीसेट कोड {code} है। यह 15 मिनट में समाप्त होगा।"),
        "mr": ("ReguLens पासवर्ड रीसेट", "आपला पासवर्ड रीसेट कोड {code} आहे. तो 15 मिनिटांत कालबाह्य होईल."),
        "ta": ("ReguLens கடவுச்சொல் மீட்டமைப்பு", "உங்கள் கடவுச்சொல் மீட்டமைப்பு குறியீடு {code}. இது 15 நிமிடங்களில் காலாவதியாகும்."),
    },
}
