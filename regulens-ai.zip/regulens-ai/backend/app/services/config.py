"""Rules-as-code access + configuration versioning (DRAFT -> PREVIEWED -> APPROVED -> EFFECTIVE).

Nothing here is marked HANDBOOK_CONFIRMED: the APH clause/page for each value has not been verified
in this prototype, so every default is an administrator-configurable parameter, labelled as such.
"""
from __future__ import annotations

from datetime import date
from typing import Any

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import now
from app.models import ConfigVersion, Rule, User
from app.services.audit import audit, snapshot

OBLIGATION_TYPES = {
    "STAGE_COMPLETION": "Application stage completion",
    "SCRUTINY_COMPLETION": "Scrutiny completion",
    "EVC_SCHEDULING": "EVC scheduling",
    "EVC_REPORT": "EVC report submission",
    "APPROVAL_UNDERTAKING": "Approval undertaking",
    "INSTITUTIONAL_COMPLIANCE": "Institutional compliance submission",
    "DEFICIENCY_RESPONSE": "Institution response to deficiencies",
    "LEASE_RENEWAL": "Lease renewal",
    "DOCUMENT_RENEWAL": "Other prescribed document renewal",
    "ADMIN_TASK": "Officer-assigned administrative task",
}
STATUTORY_TYPES = {"APPROVAL_UNDERTAKING", "LEASE_RENEWAL", "DOCUMENT_RENEWAL", "INSTITUTIONAL_COMPLIANCE"}
INSTITUTION_SIDE = {"APPROVAL_UNDERTAKING", "INSTITUTIONAL_COMPLIANCE", "DEFICIENCY_RESPONSE", "LEASE_RENEWAL", "DOCUMENT_RENEWAL"}

# rule_key -> (name, type, params, description)
DEFAULT_RULES: dict[str, tuple[str, str, dict, str]] = {
    "deadline.STAGE_COMPLETION": ("Generic stage completion budget", "DEADLINE",
                                  {"budget_days": 15, "day_mode": "WORKING", "revert_policy": "RESUME"},
                                  "Default budget for a workflow stage when the route template gives none."),
    "deadline.SCRUTINY_COMPLETION": ("Scrutiny completion budget", "DEADLINE",
                                     {"budget_days": 15, "day_mode": "WORKING", "revert_policy": "RESUME"}, ""),
    "deadline.EVC_SCHEDULING": ("EVC scheduling budget", "DEADLINE",
                                {"budget_days": 10, "day_mode": "WORKING", "revert_policy": "RESUME"},
                                "Time to constitute a panel and fix a visit date once an EVC is queued."),
    "deadline.EVC_REPORT": ("EVC report submission budget", "DEADLINE",
                            {"budget_days": 3, "day_mode": "WORKING", "revert_policy": "RESUME"},
                            "Time after the visit for the panel report to be uploaded."),
    "deadline.DEFICIENCY_RESPONSE": ("Institution response to deficiency", "DEADLINE",
                                     {"budget_days": 15, "day_mode": "CALENDAR", "revert_policy": "RESUME"},
                                     "Institution-side clock started when an application is returned."),
    "deadline.APPROVAL_UNDERTAKING": ("Approval undertaking default", "DEADLINE",
                                      {"budget_days": 90, "day_mode": "CALENDAR", "revert_policy": "RESUME"},
                                      "Used only when an undertaking has no explicit due date."),
    "deadline.INSTITUTIONAL_COMPLIANCE": ("Compliance submission default", "DEADLINE",
                                          {"budget_days": 30, "day_mode": "CALENDAR", "revert_policy": "RESUME"}, ""),
    "deadline.LEASE_RENEWAL": ("Lease renewal lead time", "DEADLINE",
                               {"budget_days": 0, "day_mode": "CALENDAR", "lead_days": 90},
                               "Renewal obligation due on the confirmed expiry date; reminders start lead_days before."),
    "deadline.DOCUMENT_RENEWAL": ("Document renewal lead time", "DEADLINE",
                                  {"budget_days": 0, "day_mode": "CALENDAR", "lead_days": 60}, ""),
    "deadline.ADMIN_TASK": ("Administrative task default", "DEADLINE",
                            {"budget_days": 7, "day_mode": "WORKING", "revert_policy": "RESUME"}, ""),
    "reminder.offsets": ("Reminder offsets", "REMINDER",
                         {"days_before": [7, 3, 1], "on_due": True, "overdue_every_days": 3, "document_days_before": [90, 60, 30, 7]}, ""),
    "escalation.timeline": ("Escalation timeline", "ESCALATION",
                            {"levels": [{"level": 1, "days_overdue": 1}, {"level": 2, "days_overdue": 5},
                                        {"level": 3, "days_overdue": 10}]}, "Days overdue at which each level fires."),
    "priority.weights": ("Today's 10 priority weights", "PRIORITY",
                         {"w1": 10.0, "w2": 2.0, "w3": 3.0, "w4": 1.5},
                         "priority = w1*urgency + w2*tier_score + w3*statutory + w4*ageing"),
    "risk.thresholds": ("Breach forecast thresholds", "RISK",
                        {"medium": 0.30, "high": 0.60, "min_samples": 30, "shrinkage_k": 30}, ""),
    "evc.weights": ("EVC panel ranking weights", "EVC",
                    {"travel": 0.35, "workload": 0.30, "expertise": 0.35, "panel_size": 3,
                     "region_policy": "SAME_REGION_ONLY", "max_distance_km": 1200}, ""),
    "route.assignment": ("Route assignment by application type", "ROUTE",
                         {"map": {"NEW_INSTITUTION": "SCRUTINY_EVC_SAC", "EXTENSION_OF_APPROVAL": "SCRUTINY_ONLY",
                                  "INCREASE_IN_INTAKE": "SCRUTINY_EVC", "NEW_COURSE": "SCRUTINY_EVC",
                                  "CHANGE_OF_SITE": "EVC_SAC", "CLOSURE": "EVC_ONLY",
                                  "CONVERSION": "SCRUTINY_SAC"}}, ""),
    "notification.channels": ("Notification channel policy", "NOTIFICATION",
                              {"officer": ["IN_APP", "EMAIL"], "institution": ["IN_APP", "EMAIL", "SMS"],
                               "fallback": {"EMAIL": "SMS", "SMS": "EMAIL", "WHATSAPP": "SMS"},
                               "retry_minutes": [1, 10, 60, 360], "digest_hour_ist": 18}, ""),
    "retention.policy": ("Data retention", "RETENTION",
                         {"audit_years": 10, "notification_days": 730, "evidence_years": 8, "session_days": 30}, ""),
    "dashboard.refresh": ("Dashboard aggregate refresh", "DASHBOARD", {"refresh_minutes": 10}, ""),
}


def _effective_q(rule_key: str, on: date | None = None):
    on = on or date.today()
    return (select(Rule).where(Rule.rule_key == rule_key, Rule.status == "EFFECTIVE", Rule.is_active.is_(True),
                               (Rule.effective_from.is_(None)) | (Rule.effective_from <= on),
                               (Rule.effective_to.is_(None)) | (Rule.effective_to >= on))
            .order_by(Rule.version.desc()).limit(1))


def get_rule(db: Session, rule_key: str, on: date | None = None) -> Rule | None:
    return db.execute(_effective_q(rule_key, on)).scalar_one_or_none()


def get_params(db: Session, rule_key: str, on: date | None = None) -> dict[str, Any]:
    r = get_rule(db, rule_key, on)
    if r:
        return dict(r.params)
    return dict(DEFAULT_RULES[rule_key][2]) if rule_key in DEFAULT_RULES else {}


def ensure_default_rules(db: Session, actor: User | None = None) -> None:
    for key, (name, typ, params, desc) in DEFAULT_RULES.items():
        if db.execute(select(Rule.id).where(Rule.rule_key == key)).first():
            continue
        r = Rule(rule_key=key, version=1, name=name, description=desc, rule_type=typ, params=params,
                 condition={}, action={}, effective_from=date(2026, 1, 1), source_type="CONFIGURABLE_PARAMETER",
                 citation="Administrator-configurable default — APH clause not verified in this prototype.",
                 status="EFFECTIVE", is_active=True, created_by=actor.id if actor else None, approved_at=now())
        db.add(r)
        db.flush()
        audit(db, actor, "RULE_SEEDED", "rule", r.id, None, snapshot(r))
    snapshot_config(db, "initial configuration")


def snapshot_config(db: Session, reason: str) -> ConfigVersion:
    ids = [r.id for r in db.execute(select(Rule).where(Rule.status == "EFFECTIVE", Rule.is_active.is_(True))).scalars()]
    cv = ConfigVersion(reason=reason, rule_ids=sorted(ids))
    db.add(cv)
    db.flush()
    return cv


def current_config_version(db: Session) -> ConfigVersion:
    cv = db.execute(select(ConfigVersion).order_by(ConfigVersion.id.desc()).limit(1)).scalar_one_or_none()
    return cv or snapshot_config(db, "bootstrap")


def pinned_params(db: Session, config_version_id: int | None, rule_key: str) -> tuple[dict, Rule | None]:
    """Parameters as of an application's pinned configuration version (cases keep their config)."""
    if config_version_id:
        cv = db.get(ConfigVersion, config_version_id)
        if cv and cv.rule_ids:
            r = db.execute(select(Rule).where(Rule.id.in_(cv.rule_ids), Rule.rule_key == rule_key)).scalar_one_or_none()
            if r:
                return dict(r.params), r
    r = get_rule(db, rule_key)
    return (dict(r.params) if r else get_params(db, rule_key)), r


# ---------------------------------------------------------------- lifecycle
def create_draft(db: Session, actor: User, data: dict) -> Rule:
    key = data["rule_key"]
    latest = db.execute(select(Rule).where(Rule.rule_key == key).order_by(Rule.version.desc()).limit(1)).scalar_one_or_none()
    if data.get("source_type") == "HANDBOOK_CONFIRMED" and not (data.get("aph_edition") and data.get("section") and data.get("page")):
        raise HTTPException(422, "HANDBOOK_CONFIRMED rules require APH edition, section and page of the verified source.")
    r = Rule(rule_key=key, version=(latest.version + 1) if latest else 1, name=data.get("name") or (latest.name if latest else key),
             description=data.get("description", latest.description if latest else ""),
             rule_type=data.get("rule_type") or (latest.rule_type if latest else "CUSTOM"),
             condition=data.get("condition") or {}, action=data.get("action") or {}, params=data.get("params") or {},
             effective_from=data.get("effective_from"), effective_to=data.get("effective_to"),
             source_type=data.get("source_type", "CONFIGURABLE_PARAMETER"), aph_edition=data.get("aph_edition"),
             section=data.get("section"), page=data.get("page"), citation=data.get("citation"),
             status="DRAFT", is_active=False, created_by=actor.id)
    db.add(r)
    db.flush()
    audit(db, actor, "RULE_DRAFT_CREATED", "rule", r.id, None, snapshot(r))
    return r


def update_draft(db: Session, actor: User, r: Rule, data: dict) -> Rule:
    if r.status not in ("DRAFT", "PREVIEWED"):
        raise HTTPException(409, "Only draft rules can be edited; create a new version instead.")
    before = snapshot(r)
    for k in ("name", "description", "condition", "action", "params", "effective_from", "effective_to", "source_type",
              "aph_edition", "section", "page", "citation"):
        if k in data:
            setattr(r, k, data[k])
    r.status = "DRAFT"
    r.impact_preview = None
    audit(db, actor, "RULE_DRAFT_EDITED", "rule", r.id, before, snapshot(r))
    return r


def record_preview(db: Session, actor: User, r: Rule, impact: dict) -> Rule:
    if r.status not in ("DRAFT", "PREVIEWED"):
        raise HTTPException(409, "Impact preview applies to drafts only.")
    r.impact_preview = impact
    r.status = "PREVIEWED"
    audit(db, actor, "RULE_IMPACT_PREVIEWED", "rule", r.id, None, {"impact": impact})
    return r


def approve(db: Session, actor: User, r: Rule, note: str | None) -> Rule:
    if r.status != "PREVIEWED":
        raise HTTPException(409, "An impact preview must be run before approval.")
    if r.created_by == actor.id:
        raise HTTPException(403, "Two-person rule: the approver must be different from the author of the change.")
    before = snapshot(r)
    r.approved_by = actor.id
    r.approved_at = now()
    r.status = "APPROVED"
    audit(db, actor, "RULE_APPROVED", "rule", r.id, before, snapshot(r), note)
    publish_if_due(db, actor, r)
    return r


def publish_if_due(db: Session, actor: User | None, r: Rule) -> bool:
    if r.status != "APPROVED":
        return False
    if r.effective_from and r.effective_from > date.today():
        return False  # scheduler publishes it on the effective date
    for old in db.execute(select(Rule).where(Rule.rule_key == r.rule_key, Rule.status == "EFFECTIVE")).scalars():
        old.status = "SUPERSEDED"
        old.is_active = False
        old.effective_to = old.effective_to or date.today()
    r.status = "EFFECTIVE"
    r.is_active = True
    cv = snapshot_config(db, f"{r.rule_key} v{r.version} effective")
    audit(db, actor, "RULE_EFFECTIVE", "rule", r.id, None, {"config_version": cv.id})
    return True


def set_active(db: Session, actor: User, r: Rule, active: bool, reason: str) -> Rule:
    if r.status not in ("EFFECTIVE", "RETIRED"):
        raise HTTPException(409, "Only published rules can be activated/deactivated.")
    before = snapshot(r)
    r.is_active = active
    r.status = "EFFECTIVE" if active else "RETIRED"
    snapshot_config(db, f"{r.rule_key} {'activated' if active else 'deactivated'}")
    audit(db, actor, "RULE_ACTIVATED" if active else "RULE_DEACTIVATED", "rule", r.id, before, snapshot(r), reason)
    return r
