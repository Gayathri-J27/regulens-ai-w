"""Reports built from database records, with CSV and PDF export (permission-scoped, logged)."""
from __future__ import annotations

import csv
import io
from collections import Counter, defaultdict
from datetime import date, timedelta

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.scope import is_national
from app.models import (Application, ApplicationEvent, AuditVerification, Escalation, EvcVisit, Institution, InstitutionalDocument,
                        Notification, Obligation, Region, RiskScore, User)
from app.services.clocks import today_ist
from app.services.intelligence import _app_filters, _obl_filters, dashboard
from app.services.ledger import OPEN

REPORTS = {
    "region_pendency": "Region-wise application pendency",
    "stage_pendency": "Stage-wise pendency",
    "officer_workload": "Officer workload",
    "evc_status": "EVC status",
    "undertaking_compliance": "Undertaking compliance",
    "institutional_compliance": "Institutional compliance",
    "document_expiry": "Document expiry",
    "overdue_obligations": "Overdue obligations",
    "escalation_history": "Escalation history",
    "notification_delivery": "Notification delivery",
    "application_movement": "Application movement",
    "audit_verification": "Audit verification",
    "risk_forecast": "Risk forecast",
    "institution_health": "Institution compliance health",
}


def _inst_scope(q, user, f):
    if not is_national(user) and user.region_id:
        q = q.where(Institution.region_id == user.region_id)
    if f.get("region_id"):
        q = q.where(Institution.region_id == int(f["region_id"]))
    if f.get("institution_id"):
        q = q.where(Institution.id == int(f["institution_id"]))
    return q


def build(db: Session, user: User, name: str, f: dict, limit: int = 5000) -> dict:
    if name not in REPORTS:
        raise HTTPException(404, "Unknown report")
    t = today_ist()
    regions = {r.id: r.code for r in db.execute(select(Region)).scalars()}
    cols, rows = [], []
    if name == "region_pendency":
        q = _app_filters(select(Institution.region_id, Application.status, func.count()), user, f).group_by(Institution.region_id, Application.status)
        agg = defaultdict(Counter)
        for reg, st, n in db.execute(q).all():
            agg[reg][st] += n
        cols = ["Region", "In progress", "Returned", "Awaiting decision", "On hold", "Approved", "Rejected", "Total"]
        for reg, c in sorted(agg.items()):
            rows.append([regions.get(reg), c["IN_PROGRESS"], c["RETURNED"], c["AWAITING_DECISION"], c["ON_HOLD"], c["APPROVED"], c["REJECTED"], sum(c.values())])
    elif name == "stage_pendency":
        d = dashboard(db, user, {k: v for k, v in f.items() if k in ("region_id", "route_code", "application_type")})
        cols = ["Stage", "Pending applications"]
        rows = [[s["stage"], s["count"]] for s in d["stage_pendency"]]
    elif name == "officer_workload":
        q = _obl_filters(select(Obligation.assigned_user_id, func.count(), func.sum((Obligation.due_date < t).cast(int_type()))), user, f).where(
            Obligation.state.in_(OPEN)).group_by(Obligation.assigned_user_id)
        users = {u.id: u for u in db.execute(select(User)).scalars()}
        cols = ["Officer", "Role", "Region", "Open obligations", "Overdue"]
        for uid, n, od in sorted(db.execute(q).all(), key=lambda r: -r[1]):
            u = users.get(uid)
            rows.append([u.full_name if u else "Unassigned", u.role if u else "", regions.get(u.region_id) if u else "", n, int(od or 0)])
    elif name == "evc_status":
        q = _inst_scope(select(EvcVisit, Institution).join(Institution, Institution.id == EvcVisit.institution_id), user, f)
        if f.get("status"):
            q = q.where(EvcVisit.status == f["status"])
        cols = ["Visit", "Institution", "Region", "Status", "Scheduled", "Panel size", "Reschedules", "Delay reason"]
        for v, i in db.execute(q.order_by(EvcVisit.id.desc()).limit(limit)).all():
            rows.append([v.id, i.name, regions.get(i.region_id), v.status, v.scheduled_date, len(v.panel_expert_ids or []), v.reschedule_count, v.delayed_reason or ""])
    elif name in ("undertaking_compliance", "institutional_compliance", "overdue_obligations"):
        types = {"undertaking_compliance": ["APPROVAL_UNDERTAKING"],
                 "institutional_compliance": ["INSTITUTIONAL_COMPLIANCE", "DEFICIENCY_RESPONSE", "LEASE_RENEWAL", "DOCUMENT_RENEWAL"]}.get(name)
        q = _obl_filters(select(Obligation, Institution.name, Institution.region_id), user, f)
        if types:
            q = q.where(Obligation.obligation_type.in_(types))
        if name == "overdue_obligations":
            q = q.where(Obligation.state.in_(OPEN), Obligation.due_date < t)
        if f.get("status"):
            q = q.where(Obligation.state == f["status"])
        if f.get("date_from"):
            q = q.where(Obligation.due_date >= date.fromisoformat(f["date_from"]))
        if f.get("date_to"):
            q = q.where(Obligation.due_date <= date.fromisoformat(f["date_to"]))
        cols = ["Obligation", "Type", "Institution", "Region", "Title", "Due", "State", "Days overdue", "Escalation level", "Verification"]
        for o, iname, reg in db.execute(q.order_by(Obligation.due_date).limit(limit)).all():
            od = (t - o.due_date).days if o.due_date and o.due_date < t and o.state in OPEN else 0
            rows.append([o.obl_no, o.obligation_type, iname, regions.get(reg), o.title, o.due_date, o.state, od, o.escalation_level, o.verification_status])
    elif name == "document_expiry":
        q = _inst_scope(select(InstitutionalDocument, Institution).join(Institution, Institution.id == InstitutionalDocument.institution_id)
                        .where(InstitutionalDocument.is_current.is_(True)), user, f)
        cols = ["Institution", "Region", "Document", "Expiry", "Days to expiry", "Verification", "Status"]
        for d, i in db.execute(q.order_by(InstitutionalDocument.expiry_date.nulls_first()).limit(limit)).all():
            days = (d.expiry_date - t).days if d.expiry_date else None
            rows.append([i.name, regions.get(i.region_id), d.doc_type, d.expiry_date, days, d.verification_status,
                         "UNVERIFIED" if days is None else "EXPIRED" if days < 0 else "EXPIRING" if days <= 90 else "VALID"])
    elif name == "escalation_history":
        q = _inst_scope(select(Escalation, Obligation, Institution).join(Obligation, Obligation.id == Escalation.obligation_id)
                        .join(Institution, Institution.id == Obligation.institution_id), user, f)
        users = {u.id: u.full_name for u in db.execute(select(User)).scalars()}
        cols = ["Escalation", "Obligation", "Institution", "Level", "Previous", "New recipient", "Via", "Triggered", "Status", "Reason"]
        for e, o, i in db.execute(q.order_by(Escalation.id.desc()).limit(limit)).all():
            via = next((p.get("result") for p in reversed(e.resolution_path or []) if p.get("user")), "UNROUTABLE")
            rows.append([e.id, o.obl_no, i.name, e.level, users.get(e.previous_recipient_id, ""), users.get(e.new_recipient_id, "— admin alerted"),
                         via, e.triggered_at.date(), e.status, e.reason])
    elif name == "notification_delivery":
        q = select(Notification.channel, Notification.status, func.count())
        if not is_national(user) and user.region_id:
            q = q.join(Institution, Institution.id == Notification.institution_id, isouter=True).where(
                (Institution.region_id == user.region_id) | (Notification.institution_id.is_(None)))
        if f.get("date_from"):
            q = q.where(Notification.created_at >= f["date_from"])
        agg = defaultdict(Counter)
        for ch, st, n in db.execute(q.group_by(Notification.channel, Notification.status)).all():
            agg[ch][st] += n
        cols = ["Channel", "Queued", "Sent", "Delivered", "Bounced", "Failed", "Total", "Delivered %"]
        for ch, c in sorted(agg.items()):
            tot = sum(c.values())
            rows.append([ch, c["QUEUED"], c["SENT"], c["DELIVERED"], c["BOUNCED"], c["FAILED"], tot, round(100 * c["DELIVERED"] / tot, 1) if tot else 0])
    elif name == "application_movement":
        q = _app_filters(select(ApplicationEvent, Application.app_no), user, f).join(ApplicationEvent, ApplicationEvent.application_id == Application.id)
        if f.get("date_from"):
            q = q.where(ApplicationEvent.at >= f["date_from"])
        cols = ["Application", "Event", "From", "To", "Reason code", "Reason", "At"]
        for e, no in db.execute(q.order_by(ApplicationEvent.at.desc()).limit(limit)).all():
            rows.append([no, e.event_type, e.from_stage or "", e.to_stage or "", e.reason_code or "", (e.reason or "")[:120], e.at.strftime("%Y-%m-%d %H:%M")])
    elif name == "audit_verification":
        cols = ["Run", "At", "Trigger", "Target", "Result", "Entries checked", "Seals checked", "First broken id", "Duration ms"]
        for v in db.execute(select(AuditVerification).order_by(AuditVerification.id.desc()).limit(limit)).scalars():
            rows.append([v.id, v.ran_at.strftime("%Y-%m-%d %H:%M:%S"), v.trigger, v.target, "PASS" if v.ok else "FAIL", v.checked, v.seals_checked,
                         v.first_broken_id or "", v.duration_ms])
    elif name == "risk_forecast":
        q = _obl_filters(select(Obligation, RiskScore, Institution.name), user, f).join(RiskScore, RiskScore.obligation_id == Obligation.id)
        cols = ["Obligation", "Institution", "Type", "Due", "Risk", "Probability", "Sample size", "Top reason"]
        for o, r, iname in db.execute(q.order_by(RiskScore.probability.desc().nulls_last()).limit(limit)).all():
            rows.append([o.obl_no, iname, o.obligation_type, o.due_date, r.level, r.probability, r.sample_size, (r.reasons or [{}])[0].get("reason", "")])
    elif name == "institution_health":
        q = _inst_scope(select(Institution), user, f).limit(min(limit, 2500))
        insts = db.execute(q).scalars().all()
        ids = [i.id for i in insts]
        stats = defaultdict(Counter)
        for iid, st, due, comp in db.execute(select(Obligation.institution_id, Obligation.state, Obligation.due_date, Obligation.completed_at)
                                              .where(Obligation.institution_id.in_(ids or [0]), Obligation.responsible_party == "INSTITUTION")).all():
            c = stats[iid]
            if st in OPEN:
                c["open"] += 1
                if due and due < t:
                    c["overdue"] += 1
            elif st == "MET":
                c["met"] += 1
                if comp and due and comp.date() <= due:
                    c["ontime"] += 1
        cols = ["Institution", "Region", "Tier", "Open", "Overdue", "Completed", "On-time %"]
        for i in insts:
            c = stats[i.id]
            rows.append([i.name, regions.get(i.region_id), i.tier, c["open"], c["overdue"], c["met"], round(100 * c["ontime"] / c["met"], 1) if c["met"] else ""])
        rows.sort(key=lambda r: -r[4])
    return {"name": name, "title": REPORTS[name], "columns": cols,
            "rows": [[(x.isoformat() if isinstance(x, date) else x) for x in r] for r in rows], "generated": t.isoformat(), "filters": f}


def int_type():
    from sqlalchemy import Integer
    return Integer


def to_csv(rep: dict) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([f"# {rep['title']} — generated {rep['generated']} — ReguLens AI (includes synthetic demonstration data where labelled)"])
    w.writerow(rep["columns"])
    w.writerows(rep["rows"])
    return buf.getvalue().encode("utf-8-sig")


def to_pdf(rep: dict, who: str) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=28, rightMargin=28, topMargin=28, bottomMargin=28,
                            title=rep["title"], author="ReguLens AI")
    ss = getSampleStyleSheet()
    cell = ss["BodyText"].clone("c")
    cell.fontSize, cell.leading = 7, 9
    els = [Paragraph(f"ReguLens AI — {rep['title']}", ss["Title"]),
           Paragraph(f"Generated {rep['generated']} by {who}. Filters: {rep['filters'] or 'none'}. Rows: {len(rep['rows'])}.", ss["Normal"]),
           Spacer(1, 8)]
    data = [[Paragraph(f"<b>{c}</b>", cell) for c in rep["columns"]]]
    for r in rep["rows"][:1500]:
        data.append([Paragraph(str(x if x is not None else ""), cell) for x in r])
    tb = Table(data, repeatRows=1)
    tb.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e3a5f")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                            ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#c7d2e0")),
                            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f3f6fa")]), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    els.append(tb)
    if len(rep["rows"]) > 1500:
        els.append(Paragraph(f"Truncated to 1,500 rows in PDF; use CSV for all {len(rep['rows'])} rows.", ss["Italic"]))
    doc.build(els)
    return buf.getvalue()
