# Security and privacy

Designed in alignment with India's Digital Personal Data Protection Act, 2023 (DPDP). **No legal certification is
claimed**; a data-protection review is required before any real deployment.

## Controls implemented

| Area | Control |
|---|---|
| Authentication | bcrypt hashes; server-side opaque sessions (SHA-256 of token stored); 8 h absolute / 60 min idle expiry; logout revokes; 5 failures → 15 min lockout; optional TOTP for officer roles; password reset by single-use 15-minute code without account enumeration. |
| Authorisation | Role → permission matrix checked on every endpoint (backend, not UI); Region, institution and committee-assignment scoping in queries; PostgreSQL RLS (FORCE) on obligations, evidence, institutional documents and applications for institution users. |
| Input & files | Pydantic validation; SQLAlchemy parameterised queries; file type by magic bytes (PDF/PNG/JPEG), 15 MB limit, SHA-256 checksum, malware scan (ClamAV or labelled fallback), randomised storage keys, signed 5-minute download URLs, `nosniff`. |
| Web | React output escaping; CSP `default-src 'none'` on API JSON; `X-Frame-Options`, `Referrer-Policy: no-referrer`; HSTS at nginx; tokens sent as `Authorization` headers (no cookies → no CSRF surface). |
| Abuse | Rate limits on login, password reset and magic links; magic links are hashed, single-use, single-obligation and expire after 7 days. |
| Audit | Hash-chained append-only log (DB triggers), hourly verification, signed daily heads with an external anchor, export logging, correlation ids. |
| Encryption | TLS at ingress; encryption at rest via encrypted volumes / managed database and S3 server-side encryption (`AES256` on every object put). |

## Data minimisation and purpose limitation

Only data needed to monitor regulatory obligations is stored: institution master data, named contacts in official
roles, officer accounts, and documents submitted as evidence. No student data is processed. Contact details are used
only for regulatory notifications. Synthetic and demo records are flagged and can be removed independently.

## Retention (rule `retention.policy`, configurable and versioned)

| Data | Default | Enforcement |
|---|---|---|
| Sessions | 30 days after expiry/revocation | daily `RETENTION_PURGE` job |
| Notifications / delivery logs | 730 days | daily `RETENTION_PURGE` job |
| Evidence files | 8 years | operational archival (not automated in the prototype) |
| Audit trail | 10 years | never deleted by the application; archived with seals |

Every purge run writes an audit entry with the counts deleted ("deletion logging").

## Breach-response procedure

1. **Detect** — sources: hourly audit-chain verification alerts (Audit Officer), failed-login/lockout spikes, malware
   blocks (`UPLOAD_BLOCKED` audit entries), infrastructure monitoring.
2. **Contain (≤ 1 h)** — revoke sessions (`UPDATE user_sessions SET revoked = true`), disable affected accounts, rotate
   `SECRET_KEY` (invalidates signed URLs) and `AUDIT_SIGNING_KEY` (seal the day first), block offending IPs at the gateway.
3. **Assess** — use `correlation_id` and the audit trail to scope accessed records; run `python -m app.cli verify-audit`
   to establish integrity and the first broken link if tampering is suspected; compare with the external anchor.
4. **Notify** — inform the designated AICTE data-protection contact; notify the Data Protection Board of India and
   affected Data Principals as required by the DPDP Act and its rules, without undue delay.
5. **Recover** — restore from backups verified against sealed heads; re-verify the chain; document root cause.
6. **Review** — post-incident report, control changes recorded as versioned configuration where applicable.
