# ReguLens AI — benchmark scorecard

Run at 2026-10-30T13:22:54.000096+00:00 · local prototype (single host, local channel adapters) · 9.5 s

## 1. Workflow accuracy

| Metric | Value |
|---|---|
| applications with ground truth | 6000 |
| route assignment accuracy | 1.0 |
| planted misroutes | 200 |
| misroutes flagged | 200 |
| misroute recall | 1.0 |
| misroute precision | 1.0 |
| current stage valid for route | 1.0 |

## 2. Alert timeliness

| Metric | Value |
|---|---|
| reminders scheduled | 200 |
| actions run | 150 |
| notifications created | 569 |
| delivered | 364 |
| sent awaiting receipt | 123 |
| p50 due to delivered s | 3.311 |
| p95 due to delivered s | 3.324 |
| wall clock s | 3.38 |
| note | Measured in this environment with local channel adapters; SMS delivery receipts arrive on a later dispatcher pass. |

## 3. Deadline reliability

| Metric | Value |
|---|---|
| clocks sampled | 1500 |
| engine vs reference agreement | 1.0 |
| stored due date matches recomputation | 1.0 |
| reminders due | 260 |
| reminders missed | 0 |
| missed per 100k | 0.0 |

## 3b. Scheduler crash recovery

| Metric | Value |
|---|---|
| actions | 60 |
| claimed by A | 60 |
| crashed mid run | 30 |
| leases recovered | 30 |
| completed | 60 |
| missed after recovery | 0 |
| notifications | 176 |
| duplicate notifications | 0 |
| obligations with notifications | 60 |

## 4. Pending-case visibility

| Metric | Value |
|---|---|
| risk recompute s | 1.54 |
| top10 query ms | 3.0 |
| obligations scored | 4953 |
| history samples | 15409 |
| planted late obligations | 300 |
| planted late flagged overdue | 1.0 |
| planted late rated high | 1.0 |

## 5. Manual follow-up reduction

| Metric | Value |
|---|---|
| open obligations | 5418 |
| follow ups per obligation policy | 4 |
| baseline manual followups | 21672 |
| system scheduled reminders | 990 |
| system generated notifications | 8516 |
| officer manual followups recorded | 0 |
| automated share | 1.0 |
| note | Baseline assumes each open obligation needs the configured reminder schedule by hand; see the impact calculator for hours. |

## 6. Audit completeness

| Metric | Value |
|---|---|
| non synthetic obligations | 126 |
| with creation audit | 126 |
| obligation audit coverage | 1.0 |
| clock events after start | 93 |
| clock audit entries | 93 |
| clock event audit coverage | 1.0 |
| chain entries verified | 4237 |
| chain ok | True |
| verify s | 0.27 |
| tamper detected | True |
| tamper first broken id | 13 |
| tamper detect s | 0.023 |

## Permission matrix

| Metric | Value |
|---|---|
| probes | 16 |
| unauthorised data leaks | 0 |
| unexpected results | 0 |

## Targets (measured, not asserted)

- zero missed scheduled actions: **MET**
- zero duplicate notifications: **MET**
- zero unauthorised data leaks: **MET**
