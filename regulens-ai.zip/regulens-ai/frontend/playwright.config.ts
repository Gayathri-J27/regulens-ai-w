import { defineConfig } from '@playwright/test'
import fs from 'node:fs'

const local = '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome'
export default defineConfig({
  testDir: './e2e',
  testMatch: /.*\.spec\.ts/,
  timeout: 60000,
  use: {
    baseURL: process.env.E2E_BASE_URL || 'http://localhost:4173',
    launchOptions: { executablePath: process.env.CHROME_PATH || (fs.existsSync(local) ? local : undefined) },
    screenshot: 'only-on-failure',
  },
  reporter: [['list']],
})
