import { expect, test, type Page } from '@playwright/test'
import path from 'node:path'

const DOCS = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../../demo_docs')

async function login(page: Page, email: string) {
  await page.goto('/login')
  await page.getByLabel('Email').fill(email)
  await page.getByLabel('Password').fill('Demo@1234')
  await page.getByRole('button', { name: 'Sign in' }).click()
  await expect(page).not.toHaveURL(/\/login/)
}

test('every sidebar item for an administrator opens a working page', async ({ page }) => {
  await login(page, 'admin@regulens.demo')
  const links = await page.getByRole('navigation', { name: 'Main' }).getByRole('link').all()
  const hrefs = await Promise.all(links.map((l) => l.getAttribute('href')))
  for (const h of hrefs) {
    await page.goto(h!)
    await expect(page.locator('main h1').first()).toBeVisible()
    await expect(page.getByText('This page does not exist')).toHaveCount(0)
  }
})

const apiAs = (page: Page, path: string, body?: unknown) => page.evaluate(async ([p, b]) => {
  const r = await fetch(p as string, { method: b ? 'POST' : 'GET', headers: { Authorization: `Bearer ${sessionStorage.getItem('regulens.token')}`, 'Content-Type': 'application/json' }, body: b ? JSON.stringify(b) : undefined })
  return r.json()
}, [path, body] as const)

test('institution submits evidence in the portal; officer verifies it; ledger closes', async ({ page, browser }) => {
  const title = `Submit Fire Safety NOC (e2e ${Date.now()})`
  const officer = await browser.newPage()
  await login(officer, 'ro.south@regulens.demo')
  const inst = (await apiAs(officer, '/api/institutions?q=DEMO-SR-0001')).items[0]
  await apiAs(officer, '/api/ledger', { institution_id: inst.id, obligation_type: 'APPROVAL_UNDERTAKING', title, budget_days: 20, evidence_requirements: ['Fire NOC'] })

  await login(page, 'principal@kaveri-demo.in')
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Kaveri')
  const card = page.locator('article', { hasText: title }).first()
  await card.getByRole('button', { name: /Upload evidence|Send the document/ }).click()
  await card.locator('input[type=file]').setInputFiles(path.join(DOCS, 'evidence_fire_noc.pdf'))
  await card.getByRole('button', { name: 'Submit' }).click()
  await expect(page.getByRole('status')).toContainText('RCPT-')

  await officer.goto(`/ledger?view=verification&q=${encodeURIComponent(title)}`)
  await officer.getByRole('link', { name: title }).first().click()
  await officer.getByRole('button', { name: 'Verify' }).click()
  await expect(officer.getByText('Evidence decision recorded.')).toBeVisible()
  await expect(officer.getByRole('heading', { name: 'Why this date?' })).toBeVisible()
  await expect(officer.locator('dd').filter({ hasText: /^✓met$/ }).first()).toBeVisible()
})

test('a regional officer cannot open another Region\'s case even by URL', async ({ page }) => {
  await login(page, 'ro.south@regulens.demo')
  const sr = (await apiAs(page, '/api/applications?page_size=1')).items[0]
  await page.getByRole('button', { name: 'Sign out' }).click()
  await login(page, 'ro.west@regulens.demo')
  await page.goto(`/applications/${sr.id}`)
  await expect(page.getByRole('alert')).toContainText(/Not permitted|another Region/)
})
