// Captures screenshots of key screens against a running stack (also used for docs/screenshots).
// Usage: node e2e/screens.mjs [baseUrl] [outDir]
import { chromium } from '@playwright/test'
import fs from 'node:fs'

const base = process.argv[2] || 'http://localhost:4173'
const out = process.argv[3] || '../docs/screenshots'
fs.mkdirSync(out, { recursive: true })
const exe = process.env.CHROME_PATH || (fs.existsSync('/opt/pw-browsers/chromium-1243/chrome-linux64/chrome') ? '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome' : undefined)
const browser = await chromium.launch({ executablePath: exe })

async function as(email, shots, viewport = { width: 1440, height: 900 }) {
  const ctx = await browser.newContext({ viewport })
  const page = await ctx.newPage()
  const errors = []
  page.on('pageerror', (e) => errors.push(e.message))
  page.on('console', (m) => { if (m.type() === 'error' && !m.text().includes('fonts.g')) errors.push(m.text()) })
  await page.goto(base + '/login')
  await page.fill('input[type=email]', email)
  await page.fill('input[type=password]', 'Demo@1234')
  await page.click('button[type=submit]')
  await page.waitForURL((u) => !u.pathname.startsWith('/login'), { timeout: 15000 })
  for (const [name, path, wait] of shots) {
    await page.goto(base + path)
    await page.waitForLoadState('networkidle').catch(() => {})
    if (wait) await page.waitForSelector(wait, { timeout: 20000 }).catch(() => errors.push(`missing ${wait} on ${path}`))
    await page.waitForTimeout(400)
    await page.screenshot({ path: `${out}/${name}.png`, fullPage: false })
    console.log('shot', name, path)
  }
  await ctx.close()
  return errors
}

const errs = []
errs.push(...await as('ro.south@regulens.demo', [
  ['01-overview-regional', '/', 'text=Total applications'],
  ['02-applications', '/applications', 'table'],
  ['03-ledger-overdue', '/ledger?view=overdue', 'table'],
  ['05-today', '/today', 'ol'],
  ['06-evc-queue', '/evc', 'table'],
  ['07-forecast', '/forecast', 'article'],
  ['08-process-mining', '/process-mining', 'text=Findings from the data'],
  ['09-documents', '/documents?validity=EXPIRED', 'table'],
  ['10-escalations', '/escalations', 'table'],
  ['11-reports', '/reports', 'table'],
]))
// obligation detail with paused/extension history: pick a recent officer-created obligation
errs.push(...await as('ro.south@regulens.demo', [['04-obligation-why', process.env.OBL_PATH || '/ledger?view=mine', 'h1']]))
errs.push(...await as('auditor@regulens.demo', [['12-audit', '/audit', 'table']]))
errs.push(...await as('admin@regulens.demo', [['13-admin-rules', '/admin', 'table'], ['14-simulator', '/simulator', 'textarea']]))
errs.push(...await as('principal@kaveri-demo.in', [['15-portal-mobile', '/portal', 'h1']], { width: 390, height: 844 }))
await browser.close()
console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no page errors')
