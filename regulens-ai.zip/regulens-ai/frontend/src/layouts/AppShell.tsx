import { useQuery } from '@tanstack/react-query'
import { Activity, AlertTriangle, BarChart3, Bell, BookCheck, Building2, CalendarClock, ClipboardList, FileCheck2, FileSearch, FlaskConical,
  GitBranch, Home, Inbox, Landmark, ListChecks, Menu, Settings, Shield, Users, X } from 'lucide-react'
import { useState, type ReactNode } from 'react'
import { useTranslation } from 'react-i18next'
import { NavLink, Outlet, useLocation } from 'react-router-dom'
import { cx } from '../components/ui'
import { api } from '../services/api'
import { isInstitution, useAuth } from '../services/auth'

const NAV: { key: string; to: string; icon: ReactNode }[] = [
  { key: 'overview', to: '/', icon: <Home size={16} /> },
  { key: 'applications', to: '/applications', icon: <ClipboardList size={16} /> },
  { key: 'workflow', to: '/workflow', icon: <GitBranch size={16} /> },
  { key: 'ledger', to: '/ledger', icon: <BookCheck size={16} /> },
  { key: 'today', to: '/today', icon: <Inbox size={16} /> },
  { key: 'evc', to: '/evc', icon: <Users size={16} /> },
  { key: 'undertakings', to: '/undertakings', icon: <FileSearch size={16} /> },
  { key: 'compliance', to: '/compliance', icon: <Building2 size={16} /> },
  { key: 'documents', to: '/documents', icon: <FileCheck2 size={16} /> },
  { key: 'notifications', to: '/notifications', icon: <Bell size={16} /> },
  { key: 'escalations', to: '/escalations', icon: <AlertTriangle size={16} /> },
  { key: 'process_mining', to: '/process-mining', icon: <Activity size={16} /> },
  { key: 'forecast', to: '/forecast', icon: <CalendarClock size={16} /> },
  { key: 'reports', to: '/reports', icon: <BarChart3 size={16} /> },
  { key: 'audit', to: '/audit', icon: <Shield size={16} /> },
  { key: 'simulator', to: '/simulator', icon: <FlaskConical size={16} /> },
  { key: 'admin', to: '/admin', icon: <Landmark size={16} /> },
  { key: 'settings', to: '/settings', icon: <Settings size={16} /> },
]

export default function AppShell() {
  const { me, logout } = useAuth()
  const { t } = useTranslation()
  const [open, setOpen] = useState(false)
  const loc = useLocation()
  const unread = useQuery({ queryKey: ['unread'], queryFn: () => api('/api/notifications?unread=true&page_size=1'), refetchInterval: 30000 })
  if (!me) return null
  const inst = isInstitution(me.role)
  const items = inst
    ? [{ key: 'portal', to: '/portal', icon: <Building2 size={16} /> }, ...NAV.filter((n) => ['applications', 'notifications', 'settings'].includes(n.key))]
    : NAV.filter((n) => me.modules.includes(n.key))
  const nav = (
    <nav aria-label="Main" className="flex flex-col gap-0.5 px-2 pb-4">
      {items.map((n) => (
        <NavLink key={n.key} to={n.to} end={n.to === '/'} onClick={() => setOpen(false)}
          className={({ isActive }) => cx('flex items-center gap-2.5 rounded-md px-2.5 py-2 text-[13.5px] focus-visible:outline focus-visible:outline-2 focus-visible:outline-white',
            isActive ? 'bg-white/15 font-semibold text-white' : 'text-white/70 hover:bg-white/10 hover:text-white')}>
          <span className="opacity-80">{n.icon}</span><span className="flex-1">{t(`nav.${n.key}`)}</span>
          {n.key === 'notifications' && unread.data?.unread > 0 && <span className="rounded bg-white px-1.5 text-[11px] font-semibold text-ink" aria-label={`${unread.data.unread} unread`}>{unread.data.unread > 99 ? '99+' : unread.data.unread}</span>}
        </NavLink>
      ))}
    </nav>
  )
  return (
    <div className="min-h-screen bg-mist/60">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-white focus:p-2">Skip to content</a>
      <aside className={cx('fixed inset-y-0 left-0 z-40 w-60 overflow-y-auto bg-ink transition-transform lg:translate-x-0', open ? 'translate-x-0' : '-translate-x-full')}>
        <div className="flex items-center gap-2 px-4 pb-4 pt-5">
          <img src="/favicon.svg" alt="" className="h-7 w-7" />
          <div>
            <div className="font-serif text-[17px] font-semibold leading-none text-white">ReguLens AI</div>
            <div className="mt-1 text-[10.5px] leading-tight text-white/55">Regulatory intelligence for AICTE</div>
          </div>
          <button className="ml-auto text-white/70 lg:hidden" onClick={() => setOpen(false)} aria-label="Close menu"><X size={18} /></button>
        </div>
        {nav}
      </aside>
      {open && <div className="fixed inset-0 z-30 bg-ink/40 lg:hidden" onClick={() => setOpen(false)} />}
      <div className="lg:pl-60">
        <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-rule bg-white px-4">
          <button className="rounded p-1.5 text-ink lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu"><Menu size={20} /></button>
          <div className="min-w-0 flex-1 truncate text-[13px] text-ink/70">
            <span className="font-medium text-ink">{me.full_name}</span>
            <span className="mx-2 text-rule">|</span>{me.role_label}{me.region ? ` · ${me.region}` : ''}{me.institution ? ` · ${me.institution}` : ''}
          </div>
          <span className="hidden rounded bg-mist px-2 py-0.5 text-[11px] text-ink/60 sm:inline" title="This prototype is not connected to AICTE production systems">Prototype · synthetic data</span>
          <button onClick={logout} className="rounded-md px-2.5 py-1.5 text-[13px] text-ink/70 hover:bg-mist hover:text-ink">{t('common.signout')}</button>
        </header>
        <main id="main" key={loc.pathname} className="mx-auto max-w-[1400px] px-4 py-6 sm:px-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
