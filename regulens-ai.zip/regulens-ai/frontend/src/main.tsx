import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { lazy, StrictMode, Suspense } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import './index.css'
import './services/i18n'
import { Loading } from './components/ui'
import AppShell from './layouts/AppShell'
import { AuthProvider, isInstitution, useAuth } from './services/auth'

const P = (f: () => Promise<any>, name: string) => lazy(() => f().then((m) => ({ default: m[name] })))
const Login = P(() => import('./pages/Login'), 'Login')
const MagicLink = P(() => import('./pages/Login'), 'MagicLinkPage')
const Overview = P(() => import('./pages/Overview'), 'Overview')
const Applications = P(() => import('./pages/Applications'), 'Applications')
const ApplicationNew = P(() => import('./pages/Applications'), 'ApplicationNew')
const ApplicationDetail = P(() => import('./pages/Applications'), 'ApplicationDetail')
const Workflow = P(() => import('./pages/Workflow'), 'Workflow')
const Ledger = P(() => import('./pages/Ledger'), 'Ledger')
const ObligationDetail = P(() => import('./pages/Ledger'), 'ObligationDetail')
const Today = P(() => import('./pages/Today'), 'Today')
const Evc = P(() => import('./pages/Evc'), 'Evc')
const EvcDetail = P(() => import('./pages/Evc'), 'EvcDetail')
const Undertakings = P(() => import('./pages/Undertakings'), 'Undertakings')
const ExtractionReview = P(() => import('./pages/Undertakings'), 'ExtractionReview')
const Compliance = P(() => import('./pages/Compliance'), 'Compliance')
const InstitutionDetail = P(() => import('./pages/Compliance'), 'InstitutionDetail')
const Documents = P(() => import('./pages/Documents'), 'Documents')
const DocumentDetail = P(() => import('./pages/Documents'), 'DocumentDetail')
const Notifications = P(() => import('./pages/Notifications'), 'Notifications')
const Escalations = P(() => import('./pages/Escalations'), 'Escalations')
const ProcessMining = P(() => import('./pages/ProcessMining'), 'ProcessMining')
const Forecast = P(() => import('./pages/Forecast'), 'Forecast')
const Reports = P(() => import('./pages/Reports'), 'Reports')
const Audit = P(() => import('./pages/Audit'), 'Audit')
const Simulator = P(() => import('./pages/Simulator'), 'Simulator')
const Admin = P(() => import('./pages/Admin'), 'Admin')
const Settings = P(() => import('./pages/Settings'), 'Settings')
const Portal = P(() => import('./pages/Portal'), 'Portal')

const qc = new QueryClient({ defaultOptions: { queries: { staleTime: 15000, retry: (n, e: any) => n < 1 && !(e?.status >= 400 && e?.status < 500) } } })

function Guard() {
  const { me, loading } = useAuth()
  if (loading) return <Loading />
  if (!me) return <Navigate to="/login" replace />
  return <AppShell />
}
function Home() {
  const { me } = useAuth()
  return isInstitution(me?.role) ? <Navigate to="/portal" replace /> : me?.modules.includes('overview') ? <Overview /> : <Navigate to="/today" replace />
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={qc}>
      <AuthProvider>
        <BrowserRouter>
          <Suspense fallback={<Loading />}>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/m/:token" element={<MagicLink />} />
              <Route element={<Guard />}>
                <Route index element={<Home />} />
                <Route path="applications" element={<Applications />} />
                <Route path="applications/new" element={<ApplicationNew />} />
                <Route path="applications/:id" element={<ApplicationDetail />} />
                <Route path="workflow" element={<Workflow />} />
                <Route path="ledger" element={<Ledger />} />
                <Route path="ledger/:id" element={<ObligationDetail />} />
                <Route path="today" element={<Today />} />
                <Route path="evc" element={<Evc />} />
                <Route path="evc/:id" element={<EvcDetail />} />
                <Route path="undertakings" element={<Undertakings />} />
                <Route path="undertakings/jobs/:id" element={<ExtractionReview />} />
                <Route path="compliance" element={<Compliance />} />
                <Route path="institutions/:id" element={<InstitutionDetail />} />
                <Route path="documents" element={<Documents />} />
                <Route path="documents/:id" element={<DocumentDetail />} />
                <Route path="notifications" element={<Notifications />} />
                <Route path="escalations" element={<Escalations />} />
                <Route path="process-mining" element={<ProcessMining />} />
                <Route path="forecast" element={<Forecast />} />
                <Route path="reports" element={<Reports />} />
                <Route path="audit" element={<Audit />} />
                <Route path="simulator" element={<Simulator />} />
                <Route path="admin" element={<Admin />} />
                <Route path="settings" element={<Settings />} />
                <Route path="portal" element={<Portal />} />
                <Route path="*" element={<div className="py-16 text-center text-ink/70">This page does not exist. <a className="text-ledger underline" href="/">Go to the overview</a>.</div>} />
              </Route>
            </Routes>
          </Suspense>
        </BrowserRouter>
      </AuthProvider>
    </QueryClientProvider>
  </StrictMode>,
)

if ('serviceWorker' in navigator && import.meta.env.PROD) navigator.serviceWorker.register('/sw.js').catch(() => undefined)
