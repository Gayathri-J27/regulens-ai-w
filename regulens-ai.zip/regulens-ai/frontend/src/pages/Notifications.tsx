import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button, Dialog, Empty, ErrorBox, Loading, PageHeader, Pager, Panel, Select, Status, Table, Tabs, cx, fmtDateTime, label } from '../components/ui'
import { api, qs } from '../services/api'
import { useAuth } from '../services/auth'

const entityLink = (n: any) => n.entity_type === 'obligation' ? `/ledger/${n.entity_id}` : n.entity_type === 'application' ? `/applications/${n.entity_id}`
  : n.entity_type === 'evc_visit' ? `/evc/${n.entity_id}` : n.entity_type === 'escalation' ? '/escalations' : null

export function Notifications() {
  const { can } = useAuth()
  const qc = useQueryClient()
  const [tab, setTab] = useState('inbox')
  const [page, setPage] = useState(1)
  const [f, setF] = useState<Record<string, string>>({})
  const [open, setOpen] = useState<any>(null)
  const inbox = useQuery({ queryKey: ['notif', page], queryFn: () => api(`/api/notifications${qs({ page, page_size: 25 })}`), enabled: tab === 'inbox' })
  const all = useQuery({ queryKey: ['notif-all', page, f], queryFn: () => api(`/api/notifications/all${qs({ ...f, page, page_size: 30 })}`), enabled: tab === 'all' })
  const del = useQuery({ queryKey: ['deliveries', open?.id], queryFn: () => api(`/api/notifications/${open.id}/deliveries`), enabled: !!open && can('notification.view_all') })
  const read = useMutation({ mutationFn: (id: number) => api(`/api/notifications/${id}/read`, { method: 'POST' }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['notif'] }); qc.invalidateQueries({ queryKey: ['unread'] }) } })
  const readAll = useMutation({ mutationFn: () => api('/api/notifications/read-all', { method: 'POST' }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['notif'] }); qc.invalidateQueries({ queryKey: ['unread'] }) } })
  const dispatch = useMutation({ mutationFn: () => api('/api/notifications/dispatch', { method: 'POST' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['notif-all'] }) })
  return (
    <div>
      <PageHeader title="Notifications" sub="In-app inbox, plus the delivery log for email, SMS and WhatsApp. A message is shown as delivered only when the channel confirms it."
        actions={tab === 'inbox' ? <Button variant="secondary" onClick={() => readAll.mutate()}>Mark all read</Button> : can('notification.nudge') && <Button variant="secondary" loading={dispatch.isPending} onClick={() => dispatch.mutate()}>Run dispatcher now</Button>} />
      {can('notification.view_all') && <Tabs value={tab} onChange={(t) => { setTab(t); setPage(1) }} tabs={[{ id: 'inbox', label: 'My inbox' }, { id: 'all', label: 'All messages and delivery' }]} />}
      {tab === 'inbox' && (
        <Panel pad={false}>
          <ErrorBox error={inbox.error} />
          {inbox.isLoading ? <Loading /> : inbox.data?.items.length ? <>
            <ul className="divide-y divide-rule">
              {inbox.data.items.map((n: any) => (
                <li key={n.id} className={cx('flex gap-3 px-4 py-3', !n.read_at && 'bg-ledger-50/50')}>
                  <span className={cx('mt-1.5 h-2 w-2 shrink-0 rounded-full', n.read_at ? 'bg-transparent' : 'bg-ledger')} aria-label={n.read_at ? 'read' : 'unread'} />
                  <div className="min-w-0 flex-1">
                    <div className="font-medium">{n.subject}</div>
                    <p className="text-[13px] text-ink/75">{n.body}</p>
                    <div className="mt-1 flex gap-3 text-[11.5px] text-ink/55"><span>{fmtDateTime(n.created_at)}</span><span>{label(n.template_key)} v{n.template_version} · {n.language}</span>
                      {entityLink(n) && <Link className="text-ledger hover:underline" to={entityLink(n)!} onClick={() => read.mutate(n.id)}>Open</Link>}
                      {!n.read_at && <button className="text-ledger hover:underline" onClick={() => read.mutate(n.id)}>Mark read</button>}</div>
                  </div>
                </li>))}
            </ul>
            <Pager page={page} pages={inbox.data.pages} total={inbox.data.total} onPage={setPage} /></> : <div className="p-4"><Empty>No notifications.</Empty></div>}
        </Panel>
      )}
      {tab === 'all' && (
        <>
          <div className="mb-3 flex flex-wrap gap-2">
            <Select aria-label="Status" className="max-w-[180px]" value={f.status || ''} onChange={(e) => { setF({ ...f, status: e.target.value }); setPage(1) }}><option value="">All statuses</option>
              {['QUEUED', 'SENT', 'DELIVERED', 'BOUNCED', 'FAILED'].map((s) => <option key={s}>{s}</option>)}</Select>
            <Select aria-label="Channel" className="max-w-[180px]" value={f.channel || ''} onChange={(e) => { setF({ ...f, channel: e.target.value }); setPage(1) }}><option value="">All channels</option>
              {['IN_APP', 'EMAIL', 'SMS', 'WHATSAPP'].map((s) => <option key={s}>{s}</option>)}</Select>
            {all.data?.by_status && <span className="self-center text-xs text-ink/60">{Object.entries(all.data.by_status).map(([k, v]) => `${label(k)} ${v}`).join(' · ')}</span>}
          </div>
          <Panel pad={false}>
            {all.isLoading ? <Loading /> : all.data?.items.length ? <>
              <Table head={['#', 'Channel', 'To', 'Subject', 'Template', 'Status', 'Attempts', 'Created']} dense>
                {all.data.items.map((n: any) => <tr key={n.id} className="cursor-pointer" onClick={() => setOpen(n)}>
                  <td>{n.id}</td><td>{n.channel}</td><td className="max-w-[180px] truncate">{n.address || 'inbox'}</td><td className="max-w-[320px]">{n.subject}</td>
                  <td className="text-xs">{n.template_key} · {n.language}</td><td><Status value={n.status} />{n.fallback_of_id && <div className="text-[11px] text-ink/55">fallback of #{n.fallback_of_id}</div>}</td>
                  <td>{n.attempts}</td><td className="whitespace-nowrap">{fmtDateTime(n.created_at)}</td></tr>)}
              </Table>
              <Pager page={page} pages={all.data.pages} total={all.data.total} onPage={setPage} /></> : <div className="p-4"><Empty /></div>}
          </Panel>
        </>
      )}
      <Dialog open={!!open} onClose={() => setOpen(null)} title={`Message #${open?.id}`} wide>
        {open && <div className="space-y-2 text-sm">
          <p><b>{open.subject}</b></p><p className="whitespace-pre-wrap">{open.body}</p>
          <p className="text-xs text-ink/60">Provider {open.provider || '—'} · sent {fmtDateTime(open.sent_at)} · delivered {fmtDateTime(open.delivered_at)} {open.error && `· error: ${open.error}`}</p>
          <h3 className="pt-2 font-semibold">Delivery log</h3>
          {del.data?.length ? <Table head={['When', 'Provider', 'Outcome', 'Detail']} dense>{del.data.map((x: any) => <tr key={x.id}><td>{fmtDateTime(x.at)}</td><td>{x.provider}</td>
            <td><Status value={x.outcome === 'BOUNCE' ? 'BOUNCED' : x.outcome === 'TRANSIENT' ? 'QUEUED' : x.outcome} /></td><td className="text-xs">{x.payload?.detail || x.payload?.dlr || x.payload?.receipt}</td></tr>)}</Table> : <Empty>Not yet attempted.</Empty>}
        </div>}
      </Dialog>
    </div>
  )
}
