import { useMutation } from '@tanstack/react-query'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Button, ErrorBox, Field, Input, Notice, PageHeader, Panel, cx } from '../components/ui'
import { api } from '../services/api'
import { useAuth } from '../services/auth'
import { LANGS, setLanguage } from '../services/i18n'

export const simpleMode = {
  get: () => { try { return localStorage.getItem('regulens.simple') === '1' } catch { return false } },
  set: (v: boolean) => { try { localStorage.setItem('regulens.simple', v ? '1' : '0') } catch { /* ignore */ } },
}

export function Settings() {
  const { me, refresh } = useAuth()
  const { t, i18n } = useTranslation()
  const [simple, setSimple] = useState(simpleMode.get())
  const [setup, setSetup] = useState<any>(null)
  const [code, setCode] = useState('')
  const enable = useMutation({ mutationFn: () => api('/api/auth/totp/enable', { body: { code } }), onSuccess: () => { setSetup(null); setCode(''); refresh() } })
  const disable = useMutation({ mutationFn: () => api('/api/auth/totp/disable', { body: { code } }), onSuccess: () => { setCode(''); refresh() } })
  const officer = me && !me.role.startsWith('INSTITUTION')
  return (
    <div className="max-w-3xl space-y-4">
      <PageHeader title={t('nav.settings')} />
      <Panel title={t('common.language')}>
        <div className="flex flex-wrap gap-2" role="radiogroup" aria-label={t('common.language')}>
          {LANGS.map((l) => <button key={l.code} role="radio" aria-checked={i18n.language === l.code} onClick={() => setLanguage(l.code)}
            className={cx('rounded-md border px-3 py-2 text-sm', i18n.language === l.code ? 'border-ledger bg-ledger-50 font-semibold' : 'border-rule hover:bg-mist')}>{l.label}</button>)}
        </div>
        <p className="mt-2 text-xs text-ink/60">Changes interface labels. Notifications are sent in each recipient's preferred language using stored, versioned templates.</p>
        <label className="mt-4 flex items-center gap-2 text-sm"><input type="checkbox" checked={simple} onChange={(e) => { setSimple(e.target.checked); simpleMode.set(e.target.checked) }} />
          {t('common.simple_mode')} — larger text and plainer wording in the institution portal</label>
      </Panel>
      <Panel title="Account">
        <dl className="grid grid-cols-[140px_1fr] gap-y-1 text-sm"><dt className="text-ink/60">Name</dt><dd>{me?.full_name}</dd><dt className="text-ink/60">Email</dt><dd>{me?.email}</dd>
          <dt className="text-ink/60">Role</dt><dd>{me?.role_label}</dd><dt className="text-ink/60">Scope</dt><dd>{me?.institution || me?.region || 'National'}</dd></dl>
      </Panel>
      {officer && <Panel title="Two-step sign-in (TOTP)">
        {me?.totp_enabled ? <div className="space-y-2"><Notice tone="green">Enabled. You will be asked for a code from your authenticator app at sign-in.</Notice>
          <div className="flex gap-2"><Input className="max-w-[160px]" placeholder="Current code" value={code} onChange={(e) => setCode(e.target.value)} /><Button variant="secondary" onClick={() => disable.mutate()}>Turn off</Button></div>
          <ErrorBox error={disable.error} /></div> : setup ? (
          <div className="space-y-2 text-sm"><p>Add this key to an authenticator app (Google Authenticator, Microsoft Authenticator, etc.):</p>
            <code className="block break-all rounded bg-mist p-2">{setup.secret}</code><p className="break-all text-xs text-ink/60">{setup.otpauth_uri}</p>
            <Field label="Enter the 6-digit code to confirm"><Input className="max-w-[160px]" value={code} onChange={(e) => setCode(e.target.value)} /></Field>
            <ErrorBox error={enable.error} /><Button onClick={() => enable.mutate()}>Turn on</Button></div>
        ) : <Button variant="secondary" onClick={async () => setSetup(await api('/api/auth/totp/setup', { method: 'POST' }))}>Set up two-step sign-in</Button>}
      </Panel>}
      <Panel title="Privacy">
        <p className="text-sm text-ink/75">ReguLens follows data-minimisation principles aligned with India's DPDP Act 2023 (no legal certification is claimed). Sessions expire after 8 hours or 60 minutes of inactivity; every export and record change is logged.</p>
      </Panel>
    </div>
  )
}
