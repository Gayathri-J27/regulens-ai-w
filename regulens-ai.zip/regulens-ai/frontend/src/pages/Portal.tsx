import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'
import { Button, DaysLeft, Empty, ErrorBox, Field, Input, Loading, Notice, PageHeader, Panel, Status, Synthetic, Table, Textarea, cx, fmtDate,
  fmtDateTime, label, useToast } from '../components/ui'
import { api } from '../services/api'
import { HealthCard } from './Compliance'
import { UploadDocument } from './Documents'
import { simpleMode } from './Settings'

export function Portal() {
  const { t } = useTranslation()
  const qc = useQueryClient()
  const toast = useToast()
  const simple = simpleMode.get()
  const s = (k: string) => t(simple ? `portal.simple.${k}` : `portal.${k}`, { defaultValue: t(`portal.${k}`) })
  const q = useQuery({ queryKey: ['portal'], queryFn: () => api('/api/portal/summary') })
  const [up, setUp] = useState<number | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [note, setNote] = useState('')
  const [docOpen, setDocOpen] = useState(false)
  const ack = useMutation({ mutationFn: (id: number) => api(`/api/ledger/${id}/do/acknowledge`, { body: {} }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['portal'] }); toast.ok('Acknowledged.') }, onError: toast.fail })
  const send = useMutation({
    mutationFn: () => { const fd = new FormData(); fd.append('file', file!); fd.append('note', note); return api(`/api/ledger/${up}/evidence`, { form: fd }) },
    onSuccess: (r: any) => { setUp(null); setFile(null); setNote(''); qc.invalidateQueries({ queryKey: ['portal'] }); toast.ok(`${t('portal.receipt_issued')}: ${r.receipt_no}`) }, onError: toast.fail,
  })
  if (q.isLoading) return <Loading />
  if (q.error) return <ErrorBox error={q.error} />
  const d = q.data
  const open = d.obligations.filter((o: any) => ['OPEN', 'ACKNOWLEDGED', 'SUBMITTED', 'PAUSED'].includes(o.state))
  return (
    <div className={cx(simple && 'simple-mode')}>
      <PageHeader title={d.institution.name} sub={<>{d.institution.aicte_id} <Synthetic on={d.institution.is_synthetic} /></>} />
      <h2 className="mb-2 font-semibold">{t('portal.title')}</h2>
      <HealthCard h={d.health} />
      <h2 className="mb-2 mt-6 font-semibold">{t('portal.open')} ({open.length})</h2>
      {open.length ? <div className="space-y-2">
        {open.map((o: any) => (
          <article key={o.id} className={cx('rounded-lg border bg-white p-4', o.display_state === 'OVERDUE' ? 'border-late/50' : 'border-rule')}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <Link to={`/ledger/${o.id}`} className="font-medium text-ledger hover:underline">{o.title}</Link>
                <div className="mt-0.5 text-[13px] text-ink/70">{t('common.due')} {fmtDate(o.due_date)} · <DaysLeft days={o.days_remaining} state={o.state} /> · <Status value={o.display_state === 'OVERDUE' ? 'OVERDUE' : o.state === 'SUBMITTED' ? 'PENDING_VERIFICATION' : o.state} /></div>
                {o.verification_status === 'REJECTED' && <p className="mt-1 text-[13px] text-late">Your last submission was not accepted — open the item to see why, then send it again.</p>}
              </div>
              <div className="flex flex-wrap gap-2">
                {o.state === 'OPEN' && <Button variant="secondary" onClick={() => ack.mutate(o.id)}>{s('acknowledge')}</Button>}
                {['OPEN', 'ACKNOWLEDGED'].includes(o.state) && <Button onClick={() => setUp(up === o.id ? null : o.id)}>{s('upload')}</Button>}
              </div>
            </div>
            {up === o.id && (
              <div className="mt-3 grid gap-3 border-t border-rule pt-3 sm:grid-cols-2">
                <Field label={s('upload_help')}><Input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
                <Field label="Note"><Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
                <div className="sm:col-span-2"><Button loading={send.isPending} disabled={!file} onClick={() => send.mutate()}>{t('common.submit')}</Button></div>
              </div>
            )}
          </article>
        ))}
      </div> : <Empty>No open requirements. Well done.</Empty>}
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Panel title={t('portal.receipts')} pad={false}>
          {d.receipts.length ? <Table head={['Receipt', 'Submitted', t('common.status')]}>{d.receipts.map((r: any) => <tr key={r.receipt_no}>
            <td><Link className="text-ledger hover:underline" to={`/ledger/${r.obligation_id}`}>{r.receipt_no}</Link></td><td>{fmtDateTime(r.submitted_at)}</td>
            <td><Status value={r.status === 'RECEIVED_PENDING_VERIFICATION' ? 'PENDING_VERIFICATION' : r.status} />{r.review_reason && <div className="text-xs text-late">{r.review_reason}</div>}</td></tr>)}</Table>
            : <div className="p-4"><Empty>No submissions yet.</Empty></div>}
        </Panel>
        <Panel title={t('portal.documents')} pad={false} actions={<Button size="sm" variant="secondary" onClick={() => setDocOpen(!docOpen)}>Upload document</Button>}>
          {docOpen && <div className="border-b border-rule p-4"><UploadDocument onDone={() => { setDocOpen(false); q.refetch(); toast.ok('Uploaded. An official will confirm the dates.') }} /></div>}
          {d.documents.length ? <Table head={['Document', 'Expiry', t('common.status')]}>{d.documents.map((x: any) => <tr key={x.id}>
            <td><Link className="text-ledger hover:underline" to={`/documents/${x.id}`}>{label(x.doc_type)}</Link></td><td>{fmtDate(x.expiry_date)} {x.days_to_expiry != null && <DaysLeft days={x.days_to_expiry} state="OPEN" />}</td>
            <td><Status value={x.verification_status === 'PENDING' ? 'PENDING' : x.validity} /></td></tr>)}</Table> : <div className="p-4"><Empty /></div>}
        </Panel>
        <Panel title={t('portal.applications')} pad={false}>
          {d.applications.length ? <Table head={['Application', 'Stage', t('common.status')]}>{d.applications.map((a: any) => <tr key={a.id}>
            <td><Link className="text-ledger hover:underline" to={`/applications/${a.id}`}>{a.app_no}</Link><div className="text-xs text-ink/55">{label(a.application_type)}</div></td><td>{label(a.current_stage)}</td><td><Status value={a.status} /></td></tr>)}</Table>
            : <div className="p-4"><Empty /></div>}
        </Panel>
        <Panel title="Completed">
          <ul className="text-[13px]">{d.obligations.filter((o: any) => o.state === 'MET').slice(0, 10).map((o: any) => <li key={o.id} className="border-b border-rule/60 py-1.5"><Link className="hover:underline" to={`/ledger/${o.id}`}>{o.title}</Link></li>)}</ul>
          {!d.obligations.some((o: any) => o.state === 'MET') && <Empty />}
        </Panel>
      </div>
      {toast.node}
    </div>
  )
}
