import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Badge, Button, Empty, ErrorBox, Input, Loading, PageHeader, Pager, Panel, Select, Status, Table, fmtDate, fmtDateTime, useToast } from '../components/ui'
import { api, qs } from '../services/api'
import { useAuth } from '../services/auth'

export function Escalations() {
  const { can } = useAuth()
  const qc = useQueryClient()
  const toast = useToast()
  const [f, setF] = useState<Record<string, string>>({ status: 'OPEN', mine: can('escalation.view') ? '' : 'true' })
  const [page, setPage] = useState(1)
  const [notes, setNotes] = useState<Record<number, string>>({})
  const q = useQuery({ queryKey: ['esc', f, page], queryFn: () => api(`/api/escalations${qs({ ...f, page, page_size: 25 })}`) })
  const act = useMutation({ mutationFn: ({ id, action }: any) => api(`/api/escalations/${id}`, { body: { action, note: notes[id] || '' } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['esc'] }); toast.ok('Recorded.') }, onError: toast.fail })
  const sweep = useMutation({ mutationFn: () => api('/api/escalations/run-sweep', { method: 'POST' }),
    onSuccess: (r: any) => { qc.invalidateQueries({ queryKey: ['esc'] }); toast.ok(`${r.escalations_created} new escalation(s).`) }, onError: toast.fail })
  return (
    <div>
      <PageHeader title="Escalations" sub="Raised automatically when an obligation stays overdue past the escalation timeline. The recipient is resolved at the moment of escalation: delegate on leave cover, post holder, nearest Region, then the next level."
        actions={can('rule.edit') && <Button variant="secondary" loading={sweep.isPending} onClick={() => sweep.mutate()}>Run escalation sweep now</Button>} />
      <div className="mb-3 flex flex-wrap gap-2">
        <Select aria-label="Status" className="max-w-[180px]" value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}><option value="">All</option>
          {['OPEN', 'ACKNOWLEDGED', 'CLOSED', 'UNROUTABLE'].map((s) => <option key={s}>{s}</option>)}</Select>
        <Select aria-label="Level" className="max-w-[140px]" value={f.level || ''} onChange={(e) => setF({ ...f, level: e.target.value })}><option value="">All levels</option>{[1, 2, 3].map((l) => <option key={l} value={l}>Level {l}</option>)}</Select>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.mine === 'true'} onChange={(e) => setF({ ...f, mine: e.target.checked ? 'true' : '' })} /> Escalated to me</label>
        {q.data?.by_status && <span className="self-center text-xs text-ink/60">{Object.entries(q.data.by_status).map(([k, v]) => `${k.toLowerCase()} ${v}`).join(' · ')}</span>}
      </div>
      <Panel pad={false}>
        <ErrorBox error={q.error} />
        {q.isLoading ? <Loading /> : q.data?.items.length ? <>
          <Table head={['Obligation', 'Institution', 'Level', 'From → to', 'Resolution path', 'Triggered', 'Status', '']}>
            {q.data.items.map((e: any) => <tr key={e.id}>
              <td className="max-w-[260px]"><Link className="text-ledger hover:underline" to={`/ledger/${e.obligation_id}`}>{e.title}</Link><div className="text-[11px] text-ink/55">due {fmtDate(e.due_date)}</div></td>
              <td className="max-w-[200px] text-[12.5px]">{e.institution}</td><td><Badge tone="red">L{e.level}</Badge></td>
              <td className="text-[12.5px]">{e.previous || '—'} → <b>{e.new_recipient || 'administrator (unroutable)'}</b></td>
              <td className="text-[11.5px] text-ink/65">{e.path.map((p: any) => p.result).join(' → ')}</td><td className="whitespace-nowrap">{fmtDateTime(e.triggered_at)}</td>
              <td><Status value={e.status} />{e.closure_note && <div className="text-[11px] text-ink/55">{e.closure_note}</div>}</td>
              <td className="min-w-[200px]">{can('escalation.act') && e.status !== 'CLOSED' && <div className="flex flex-col gap-1">
                {e.status === 'OPEN' && <Button size="sm" variant="secondary" onClick={() => act.mutate({ id: e.id, action: 'acknowledge' })}>Acknowledge</Button>}
                <div className="flex gap-1"><Input className="h-8" placeholder="Closure note" value={notes[e.id] || ''} onChange={(x) => setNotes({ ...notes, [e.id]: x.target.value })} />
                  <Button size="sm" disabled={!notes[e.id]} onClick={() => act.mutate({ id: e.id, action: 'close' })}>Close</Button></div></div>}</td></tr>)}
          </Table>
          <Pager page={page} pages={q.data.pages} total={q.data.total} onPage={setPage} /></> : <div className="p-4"><Empty>No escalations match.</Empty></div>}
      </Panel>
      {toast.node}
    </div>
  )
}
