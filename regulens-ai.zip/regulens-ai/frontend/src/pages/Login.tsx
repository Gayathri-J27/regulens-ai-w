import { zodResolver } from '@hookform/resolvers/zod'
import { useQuery } from '@tanstack/react-query'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { Navigate, useParams } from 'react-router-dom'
import { z } from 'zod'
import { Button, ErrorBox, Field, Input, Loading, Notice, Status, Textarea, fmtDate } from '../components/ui'
import { api, token } from '../services/api'
import { useAuth } from '../services/auth'
import { LANGS, setLanguage } from '../services/i18n'

const schema = z.object({ email: z.string().email('Enter a valid email address'), password: z.string().min(1, 'Enter your password') })
type F = z.infer<typeof schema>

export function Login() {
  const { me, setMe } = useAuth()
  const [err, setErr] = useState<unknown>(null)
  const [mfa, setMfa] = useState(false)
  const [code, setCode] = useState('')
  const [reset, setReset] = useState<null | 'request' | 'confirm'>(null)
  const { register, handleSubmit, setValue, formState: { errors, isSubmitting } } = useForm<F>({ resolver: zodResolver(schema) })
  const demo = useQuery({ queryKey: ['demo-accounts'], queryFn: () => api<any[]>('/api/auth/demo-accounts'), retry: false })
  if (me) return <Navigate to="/" replace />

  const submit = async (f: F) => {
    setErr(null)
    try {
      const r = await api('/api/auth/login', { body: f })
      token.set(r.token)
      if (r.mfa_required) setMfa(true)
      else setMe(r.user)
    } catch (e) { setErr(e) }
  }
  const verify = async () => {
    try { const r = await api('/api/auth/totp/verify', { body: { code } }); setMe(r.user) } catch (e) { setErr(e) }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-[1fr_1.1fr]">
      <section className="flex flex-col justify-between bg-ink px-8 py-10 text-white sm:px-14">
        <div className="flex items-center gap-2.5"><img src="/favicon.svg" className="h-8 w-8" alt="" /><span className="font-serif text-xl font-semibold">ReguLens AI</span></div>
        <div className="max-w-md py-10">
          <h1 className="font-serif text-[34px] font-semibold leading-tight">Every approval condition, every deadline, one ledger.</h1>
          <p className="mt-4 text-[15px] leading-relaxed text-white/75">
            ReguLens tracks applications, undertakings, EVC visits and document validity for AICTE officers and institutions.
            Deadlines are computed from recorded history, pause while an institution is responding, and every change is sealed into a verifiable audit chain.
          </p>
          <p className="mt-6 text-[13px] text-white/55">Statutory approval and verification decisions remain with authorised officers. AI only proposes; officers confirm.</p>
        </div>
        <p className="text-xs text-white/45">Prototype. Not connected to AICTE production systems. All institutions and people shown are fictional.</p>
      </section>
      <section className="flex items-center justify-center px-6 py-10">
        <div className="w-full max-w-md">
          <div className="mb-6 flex justify-end gap-1 text-xs">
            {LANGS.map((l) => <button key={l.code} onClick={() => setLanguage(l.code)} className="rounded px-2 py-1 text-ink/70 hover:bg-mist">{l.label}</button>)}
          </div>
          {reset ? <ResetFlow mode={reset} setMode={setReset} /> : mfa ? (
            <div className="space-y-4">
              <h2 className="font-serif text-2xl font-semibold">Enter your authentication code</h2>
              <Field label="6-digit code from your authenticator app"><Input inputMode="numeric" autoComplete="one-time-code" value={code} onChange={(e) => setCode(e.target.value)} /></Field>
              <ErrorBox error={err} />
              <Button className="w-full" onClick={verify}>Verify and sign in</Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit(submit)} className="space-y-4" noValidate>
              <h2 className="font-serif text-2xl font-semibold">Sign in</h2>
              <Field label="Email" error={errors.email?.message}><Input type="email" autoComplete="username" {...register('email')} /></Field>
              <Field label="Password" error={errors.password?.message}><Input type="password" autoComplete="current-password" {...register('password')} /></Field>
              <ErrorBox error={err} />
              <Button type="submit" className="w-full" loading={isSubmitting}>Sign in</Button>
              <button type="button" onClick={() => setReset('request')} className="text-sm text-ledger hover:underline">Forgot password?</button>
            </form>
          )}
          {demo.data && !mfa && !reset && (
            <div className="mt-8">
              <h3 className="text-sm font-semibold text-ink">Demo access</h3>
              <p className="mb-2 text-xs text-ink/60">Pick a role to fill the form. Password for all demo accounts: <b>Demo@1234</b></p>
              <ul className="divide-y divide-rule rounded-md border border-rule text-[13px]">
                {demo.data.map((a) => (
                  <li key={a.email}>
                    <button type="button" className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left hover:bg-mist"
                      onClick={() => { setValue('email', a.email); setValue('password', 'Demo@1234') }}>
                      <span className="truncate">{a.name}</span><span className="shrink-0 text-xs text-ink/55">{a.role_label}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}

function ResetFlow({ mode, setMode }: { mode: 'request' | 'confirm'; setMode: (m: null | 'request' | 'confirm') => void }) {
  const [email, setEmail] = useState('')
  const [code, setCode] = useState('')
  const [pw, setPw] = useState('')
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState<unknown>(null)
  return (
    <div className="space-y-4">
      <h2 className="font-serif text-2xl font-semibold">Reset password</h2>
      <Field label="Email"><Input value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
      {mode === 'confirm' && <>
        <Field label="Reset code" hint="In this demo the code is delivered to the development mailbox (Notifications → All messages)."><Input value={code} onChange={(e) => setCode(e.target.value)} /></Field>
        <Field label="New password" hint="At least 10 characters, mixing letters with numbers or symbols."><Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} /></Field>
      </>}
      {msg && <Notice tone="green">{msg}</Notice>}
      <ErrorBox error={err} />
      <div className="flex gap-2">
        {mode === 'request'
          ? <Button onClick={async () => { setErr(null); try { const r = await api('/api/auth/password-reset/request', { body: { email } }); setMsg(r.message); setMode('confirm') } catch (e) { setErr(e) } }}>Send reset code</Button>
          : <Button onClick={async () => { setErr(null); try { await api('/api/auth/password-reset/confirm', { body: { email, code, new_password: pw } }); setMsg('Password changed. Sign in with the new password.'); setTimeout(() => setMode(null), 1500) } catch (e) { setErr(e) } }}>Set new password</Button>}
        <Button variant="secondary" onClick={() => setMode(null)}>Back to sign in</Button>
      </div>
    </div>
  )
}

/** Tier-2 single-obligation access: no account needed, single use, 7-day expiry. */
export function MagicLinkPage() {
  const { token: tk } = useParams()
  const [receipt, setReceipt] = useState<any>(null)
  const [file, setFile] = useState<File | null>(null)
  const [note, setNote] = useState('')
  const [err, setErr] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)
  const q = useQuery({ queryKey: ['magic', tk], queryFn: () => api(`/api/m/${tk}`), retry: false })
  const o = q.data?.obligation
  return (
    <div className="min-h-screen bg-mist/60 px-4 py-10">
      <div className="mx-auto max-w-xl rounded-lg border border-rule bg-white p-6">
        <div className="mb-4 flex items-center gap-2"><img src="/favicon.svg" className="h-7 w-7" alt="" /><span className="font-serif text-lg font-semibold">ReguLens AI — secure response link</span></div>
        {q.isLoading && <Loading />}
        <ErrorBox error={q.error} />
        {receipt ? (
          <Notice tone="green"><b>Submitted.</b> Receipt <b>{receipt.receipt_no}</b> — status {receipt.status.replace(/_/g, ' ').toLowerCase()}. File checksum {receipt.sha256.slice(0, 16)}…. This link has now been used and cannot be opened again.</Notice>
        ) : o && (
          <div className="space-y-4">
            <div>
              <div className="text-xs text-ink/60">{o.institution} · {o.obl_no}</div>
              <h1 className="mt-1 text-xl font-semibold">{o.title}</h1>
              <p className="mt-1 text-sm text-ink/75">Due {fmtDate(o.due_date)} · <Status value={o.state} /></p>
            </div>
            {o.description && <p className="text-sm">{o.description}</p>}
            <div><div className="text-sm font-medium">What to send</div><ul className="ml-5 list-disc text-sm">{(o.evidence_requirements || []).map((e: string) => <li key={e}>{e}</li>)}</ul></div>
            {o.state === 'OPEN' && <Button variant="secondary" onClick={async () => { try { await api(`/api/m/${tk}/acknowledge`, { method: 'POST' }); q.refetch() } catch (e) { setErr(e) } }}>I acknowledge this requirement</Button>}
            <Field label="Document (PDF, JPG or PNG, up to 15 MB)"><Input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
            <Field label="Note to the officer (optional)"><Textarea value={note} onChange={(e) => setNote(e.target.value)} /></Field>
            <ErrorBox error={err} />
            <Button disabled={!file} loading={busy} onClick={async () => {
              setBusy(true); setErr(null)
              const fd = new FormData(); fd.append('file', file!); fd.append('note', note)
              try { setReceipt(await api(`/api/m/${tk}/evidence`, { form: fd })) } catch (e) { setErr(e) } finally { setBusy(false) }
            }}>Submit evidence</Button>
            <p className="text-xs text-ink/55">Link expires {fmtDate(q.data.expires_at)}. It works once: submitting evidence closes it.</p>
          </div>
        )}
      </div>
    </div>
  )
}
