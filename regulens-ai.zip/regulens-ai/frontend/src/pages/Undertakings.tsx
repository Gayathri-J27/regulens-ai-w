import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { Button, Empty, ErrorBox, Field, Input, Loading, Notice, PageHeader, Panel, Select, Status, Table, Textarea, cx, fmtDate, fmtDateTime, label,
  useToast } from '../components/ui'
import { useMeta } from '../hooks/useMeta'
import { api, qs } from '../services/api'

export function Undertakings() {
  const nav = useNavigate()
  const [instQ, setInstQ] = useState('')
  const [v, setV] = useState<Record<string, string>>({})
  const [file, setFile] = useState<File | null>(null)
  const insts = useQuery({ queryKey: ['inst-search', instQ], queryFn: () => api(`/api/institutions${qs({ q: instQ, page_size: 30 })}`) })
  const apps = useQuery({ queryKey: ['inst-apps', v.institution_id], queryFn: () => api(`/api/applications${qs({ q: '', page_size: 50 })}`), enabled: false })
  const jobs = useQuery({ queryKey: ['extraction-jobs'], queryFn: () => api('/api/extraction/jobs?page_size=20') })
  const undertakings = useQuery({ queryKey: ['ledger', 'undertakings'], queryFn: () => api('/api/ledger?view=all&obligation_type=APPROVAL_UNDERTAKING&sort=recent&page_size=10') })
  const up = useMutation({
    mutationFn: () => { const fd = new FormData(); fd.append('file', file!); fd.append('institution_id', v.institution_id); if (v.application_id) fd.append('application_id', v.application_id)
      if (v.letter_date) fd.append('letter_date', v.letter_date); return api('/api/extraction/jobs', { form: fd }) },
    onSuccess: (j: any) => nav(`/undertakings/jobs/${j.id}`),
  })
  return (
    <div>
      <PageHeader title="Undertakings" sub="Turn an approval letter into ledger obligations. The extractor only proposes; each item is confirmed, edited or rejected by an officer." />
      <div className="grid gap-4 lg:grid-cols-[420px_1fr]">
        <Panel title="Upload approval letter (PDF)">
          <div className="space-y-3">
            <Field label="Find institution"><Input value={instQ} onChange={(e) => setInstQ(e.target.value)} placeholder="Name or AICTE ID" /></Field>
            <Field label="Institution"><Select value={v.institution_id || ''} onChange={(e) => setV({ ...v, institution_id: e.target.value })}><option value="">Select…</option>
              {insts.data?.items.map((i: any) => <option key={i.id} value={i.id}>{i.name}</option>)}</Select></Field>
            <Field label="Application ID (optional)"><Input value={v.application_id || ''} onChange={(e) => setV({ ...v, application_id: e.target.value })} /></Field>
            <Field label="Letter date" hint="Used to resolve 'within N days'. If empty, the first date in the letter header is used."><Input type="date" value={v.letter_date || ''} onChange={(e) => setV({ ...v, letter_date: e.target.value })} /></Field>
            <Field label="Letter" hint="Digital or scanned PDF. Scanned pages go through OpenCV clean-up and OCR."><Input type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
            <ErrorBox error={up.error} />
            <Button loading={up.isPending} disabled={!file || !v.institution_id} onClick={() => up.mutate()}>Extract proposed obligations</Button>
          </div>
        </Panel>
        <div className="space-y-4">
          <Panel title="Extraction jobs" pad={false}>
            {jobs.isLoading ? <Loading /> : jobs.data?.items.length ? <Table head={['Job', 'Institution', 'Extractor', 'Items', 'Status', 'Created']}>
              {jobs.data.items.map((j: any) => <tr key={j.id}><td><Link className="text-ledger hover:underline" to={`/undertakings/jobs/${j.id}`}>#{j.id}</Link></td>
                <td>{j.institution_id}</td><td className="text-xs">{j.extractor}</td><td>{j.items}</td><td><Status value={j.status === 'REVIEW' ? 'PENDING' : 'CLOSED'} /></td><td>{fmtDateTime(j.created_at)}</td></tr>)}
            </Table> : <div className="p-4"><Empty>No letters processed yet.</Empty></div>}
          </Panel>
          <Panel title="Recent approval undertakings" pad={false}>
            {undertakings.data?.items.length ? <Table head={['Undertaking', 'Institution', 'Due', 'State']}>
              {undertakings.data.items.map((o: any) => <tr key={o.id}><td><Link className="text-ledger hover:underline" to={`/ledger/${o.id}`}>{o.title}</Link></td><td>{o.institution}</td><td>{fmtDate(o.due_date)}</td><td><Status value={o.display_state} /></td></tr>)}
            </Table> : <div className="p-4"><Empty /></div>}
          </Panel>
        </div>
      </div>
    </div>
  )
}

function highlight(text: string, needle: string | null) {
  if (!needle) return text
  const norm = (s: string) => s.replace(/\s+/g, ' ')
  const t = norm(text)
  const i = t.toLowerCase().indexOf(norm(needle).toLowerCase().slice(0, 60))
  if (i < 0) return t
  const end = i + norm(needle).length
  return <>{t.slice(0, i)}<mark id="hl">{t.slice(i, end)}</mark>{t.slice(end)}</>
}

export function ExtractionReview() {
  const { id } = useParams()
  const meta = useMeta()
  const qc = useQueryClient()
  const toast = useToast()
  const [sel, setSel] = useState<number | null>(null)
  const [edit, setEdit] = useState<Record<string, any>>({})
  const [rej, setRej] = useState('')
  const [manual, setManual] = useState<Record<string, string> | null>(null)
  const q = useQuery({ queryKey: ['job', id], queryFn: () => api(`/api/extraction/jobs/${id}`) })
  const rv = useMutation({ mutationFn: (b: any) => api(`/api/extraction/items/${b.id}/review`, { body: b.body }),
    onSuccess: (j) => { qc.setQueryData(['job', id], j); setEdit({}); setRej(''); toast.ok('Recorded.') }, onError: toast.fail })
  const add = useMutation({ mutationFn: (b: any) => api(`/api/extraction/jobs/${id}/items`, { body: b }), onSuccess: (j) => { qc.setQueryData(['job', id], j); setManual(null) }, onError: toast.fail })
  if (q.isLoading) return <Loading />
  if (q.error) return <ErrorBox error={q.error} />
  const j = q.data
  const cur = j.items.find((i: any) => i.id === sel)
  return (
    <div>
      <PageHeader title={`Approval letter review #${j.id}`} sub={<>{j.institution} · letter dated {fmtDate(j.letter_date)} · text via {j.text_method}</>}
        actions={<a className="text-sm text-ledger hover:underline" href={j.file_url} target="_blank" rel="noreferrer">Open original PDF</a>} />
      <div className="mb-3"><Notice tone={j.extractor.startsWith('LLM') ? 'blue' : 'amber'}>
        Extractor: <b>{j.extractor}</b>. {j.extractor.startsWith('LOCAL') ? 'No language model was used — a deterministic sentence rule set produced these proposals. ' : ''}
        Every proposal quotes a sentence verified to exist in the letter; {j.rejected_count} candidate(s) failed schema or source checks and were discarded. Only items you accept create obligations.
      </Notice></div>
      <div className="grid gap-4 xl:grid-cols-2">
        <div className="space-y-3">
          {j.items.map((it: any) => (
            <article key={it.id} onClick={() => { setSel(it.id); setEdit({}) }} className={cx('cursor-pointer rounded-lg border bg-white p-3', sel === it.id ? 'border-ledger ring-1 ring-ledger' : 'border-rule')}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2"><Status value={it.status} /><span className="text-xs text-ink/60">{label(it.kind)} → {meta.data?.obligation_types[it.obligation_type]}</span></div>
                <span className="text-xs text-ink/60" title="Heuristic confidence of the extractor, not a verification">confidence {Math.round(it.confidence * 100)}%</span>
              </div>
              <h3 className="mt-1.5 font-medium">{it.title}</h3>
              <blockquote className="mt-1 border-l-2 border-ledger pl-2 text-[12.5px] italic text-ink/80">{it.source_sentence}</blockquote>
              <div className="mt-1.5 flex flex-wrap gap-x-4 text-[12.5px]"><span>Due: <b>{it.due_date ? fmtDate(it.due_date) : 'not stated — officer must set'}</b>{it.due_text && ` (“${it.due_text}”)`}</span>
                <span>Responsible: {label(it.responsible_role)}</span>{it.evidence_requirement && <span>Evidence: {it.evidence_requirement}</span>}</div>
              {it.obligation_id && <Link to={`/ledger/${it.obligation_id}`} className="mt-1 inline-block text-xs text-ledger hover:underline">Ledger obligation #{it.obligation_id}</Link>}
              {it.reject_reason && <p className="mt-1 text-xs text-late">Rejected: {it.reject_reason}</p>}
              {sel === it.id && it.status === 'PROPOSED' && (
                <div className="mt-3 grid gap-2 border-t border-rule pt-3 sm:grid-cols-2" onClick={(e) => e.stopPropagation()}>
                  <Field label="Title" className="sm:col-span-2"><Input defaultValue={it.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} /></Field>
                  <Field label="Due date"><Input type="date" defaultValue={it.due_date || ''} onChange={(e) => setEdit({ ...edit, due_date: e.target.value })} /></Field>
                  <Field label="Obligation type"><Select defaultValue={it.obligation_type} onChange={(e) => setEdit({ ...edit, obligation_type: e.target.value })}>
                    {Object.entries(meta.data?.obligation_types || {}).map(([k, x]) => <option key={k} value={k}>{x}</option>)}</Select></Field>
                  <Field label="Responsible role"><Select defaultValue={it.responsible_role} onChange={(e) => setEdit({ ...edit, responsible_role: e.target.value })}>
                    {['INSTITUTION_PRINCIPAL', 'INSTITUTION_COMPLIANCE', 'TRUST_SOCIETY', 'ACCOUNTS'].map((r) => <option key={r} value={r}>{label(r)}</option>)}</Select></Field>
                  <Field label="Evidence requirement"><Input defaultValue={it.evidence_requirement || ''} onChange={(e) => setEdit({ ...edit, evidence_requirement: e.target.value })} /></Field>
                  <div className="flex flex-wrap items-end gap-2 sm:col-span-2">
                    <Button onClick={() => rv.mutate({ id: it.id, body: { action: 'accept', edits: edit } })}>{Object.keys(edit).length ? 'Save edits and accept' : 'Accept'}</Button>
                    <Input className="max-w-[240px]" placeholder="Reason to reject" value={rej} onChange={(e) => setRej(e.target.value)} />
                    <Button variant="secondary" disabled={!rej} onClick={() => rv.mutate({ id: it.id, body: { action: 'reject', reason: rej } })}>Reject</Button>
                  </div>
                </div>
              )}
            </article>
          ))}
          {!j.items.length && <Empty>No obligations were proposed. Add them manually below.</Empty>}
          {manual ? (
            <Panel title="Add an item the extractor missed">
              <div className="grid gap-2 sm:grid-cols-2">
                <Field label="Title" className="sm:col-span-2"><Input value={manual.title || ''} onChange={(e) => setManual({ ...manual, title: e.target.value })} /></Field>
                <Field label="Source sentence (copied from the letter)" className="sm:col-span-2"><Textarea value={manual.source_sentence || ''} onChange={(e) => setManual({ ...manual, source_sentence: e.target.value })} /></Field>
                <Field label="Due date"><Input type="date" value={manual.due_date || ''} onChange={(e) => setManual({ ...manual, due_date: e.target.value })} /></Field>
                <Field label="Evidence"><Input value={manual.evidence_requirement || ''} onChange={(e) => setManual({ ...manual, evidence_requirement: e.target.value })} /></Field>
                <div className="sm:col-span-2"><Button onClick={() => add.mutate(manual)}>Add as proposal</Button></div>
              </div>
            </Panel>
          ) : <Button variant="secondary" onClick={() => setManual({})}>Add item manually</Button>}
        </div>
        <div className="xl:sticky xl:top-20 xl:self-start">
          <Panel title="Letter text" actions={cur && <a href="#hl" className="text-xs text-ledger">Jump to highlighted sentence</a>}>
            <div className="max-h-[70vh] overflow-y-auto whitespace-pre-wrap text-[13px] leading-relaxed">{highlight(j.full_text, cur?.source_sentence || null)}</div>
          </Panel>
          <details className="mt-3 text-xs text-ink/70"><summary className="cursor-pointer">Processing log</summary><ul className="mt-1 list-disc pl-4">{j.log.map((l: string, i: number) => <li key={i}>{l}</li>)}</ul></details>
          <iframe title="Original approval letter" src={j.file_url} className="mt-3 h-[520px] w-full rounded border border-rule" />
        </div>
      </div>
      {toast.node}
    </div>
  )
}
