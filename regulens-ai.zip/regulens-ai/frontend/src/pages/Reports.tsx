import { useQuery } from '@tanstack/react-query'
import { useState } from 'react'
import { Button, Empty, ErrorBox, Input, Loading, PageHeader, Panel, Select, Table, cx, useToast } from '../components/ui'
import { useMeta } from '../hooks/useMeta'
import { api, download, qs } from '../services/api'
import { useAuth } from '../services/auth'

export function Reports() {
  const meta = useMeta()
  const { can } = useAuth()
  const toast = useToast()
  const cat = useQuery({ queryKey: ['reports'], queryFn: () => api('/api/reports') })
  const [name, setName] = useState('region_pendency')
  const [f, setF] = useState<Record<string, string>>({})
  const rep = useQuery({ queryKey: ['report', name, f], queryFn: () => api(`/api/reports/${name}${qs(f)}`) })
  const exp = async (fmt: string) => { try { await download(`/api/reports/${name}${qs({ ...f, fmt })}`, `${name}.${fmt}`); toast.ok(`Exported ${fmt.toUpperCase()} — logged in the audit trail.`) } catch (e) { toast.fail(e) } }
  return (
    <div>
      <PageHeader title="Reports" sub="Built from live records and scoped to your access. Every export is logged." />
      <div className="grid gap-4 lg:grid-cols-[240px_1fr]">
        <nav aria-label="Reports" className="rounded-lg border border-rule bg-white p-1">
          {cat.data?.map((r: any) => <button key={r.name} onClick={() => setName(r.name)} className={cx('block w-full rounded px-3 py-2 text-left text-[13px]', name === r.name ? 'bg-ledger-50 font-semibold text-ink' : 'text-ink/75 hover:bg-mist')}>{r.title}</button>)}
        </nav>
        <div>
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Select aria-label="Region" className="max-w-[160px]" value={f.region_id || ''} onChange={(e) => setF({ ...f, region_id: e.target.value })}><option value="">All Regions</option>{meta.data?.regions.map((r) => <option key={r.id} value={r.id}>{r.code}</option>)}</Select>
            <Input aria-label="Institution ID" className="max-w-[140px]" placeholder="Institution ID" value={f.institution_id || ''} onChange={(e) => setF({ ...f, institution_id: e.target.value })} />
            <Input aria-label="Status" className="max-w-[160px]" placeholder="Status (e.g. OPEN)" value={f.status || ''} onChange={(e) => setF({ ...f, status: e.target.value.toUpperCase() })} />
            <Input aria-label="From" type="date" className="max-w-[160px]" value={f.date_from || ''} onChange={(e) => setF({ ...f, date_from: e.target.value })} />
            <Input aria-label="To" type="date" className="max-w-[160px]" value={f.date_to || ''} onChange={(e) => setF({ ...f, date_to: e.target.value })} />
            {can('report.export') && <><Button variant="secondary" onClick={() => exp('csv')}>Export CSV</Button><Button variant="secondary" onClick={() => exp('pdf')}>Export PDF</Button></>}
          </div>
          <Panel title={rep.data?.title} pad={false} actions={rep.data && <span className="text-xs text-ink/60">{rep.data.rows.length}{rep.data.truncated ? '+ (first 500 shown; export for all)' : ''} rows · generated {rep.data.generated}</span>}>
            <ErrorBox error={rep.error} />
            {rep.isLoading ? <Loading /> : rep.data?.rows.length ? <Table head={rep.data.columns} dense>{rep.data.rows.map((r: any[], i: number) => <tr key={i}>{r.map((c, j) => <td key={j}>{c === null || c === '' ? '—' : String(c)}</td>)}</tr>)}</Table> : <div className="p-4"><Empty>No rows for these filters.</Empty></div>}
          </Panel>
        </div>
      </div>
      {toast.node}
    </div>
  )
}
