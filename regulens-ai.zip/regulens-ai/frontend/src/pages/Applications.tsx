import { zodResolver } from '@hookform/resolvers/zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { z } from 'zod'
import { Badge, Button, DaysLeft, Dialog, Empty, ErrorBox, Field, Input, Loading, Notice, PageHeader, Pager, Panel, Select, Status, Synthetic,
  Table, Textarea, fmtDate, fmtDateTime, label, useToast } from '../components/ui'
import { regionName, useMeta } from '../hooks/useMeta'
import { api, qs } from '../services/api'
import { isInstitution, useAuth } from '../services/auth'

export function Applications() {
  const [sp, setSp] = useSearchParams()
  const { can, me } = useAuth()
  const meta = useMeta()
  const f = Object.fromEntries(sp.entries())
  const page = Number(f.page || 1)
  const q = useQuery({ queryKey: ['apps', f], queryFn: () => api(`/api/applications${qs({ ...f, page_size: 25 })}`) })
  const set = (k: string, v: string) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); n.delete('page'); setSp(n) }
  return (
    <div>
      <PageHeader title="Applications" sub="Every application with its route, current stage and stage clock."
        actions={can('application.create') && <Link to="/applications/new"><Button>Register application</Button></Link>} />
      <div className="mb-3 grid grid-cols-2 gap-2 md:grid-cols-6">
        <Input aria-label="Search" placeholder="Application no. or institution" defaultValue={f.q} onKeyDown={(e) => e.key === 'Enter' && set('q', (e.target as HTMLInputElement).value)} />
        <Select aria-label="Status" value={f.status || ''} onChange={(e) => set('status', e.target.value)}><option value="">All statuses</option>
          {['IN_PROGRESS', 'RETURNED', 'AWAITING_DECISION', 'ON_HOLD', 'APPROVED', 'REJECTED', 'WITHDRAWN', 'MERGED'].map((s) => <option key={s} value={s}>{label(s)}</option>)}</Select>
        <Select aria-label="Stage" value={f.stage || ''} onChange={(e) => set('stage', e.target.value)}><option value="">All stages</option>
          {meta.data?.stages.map((s) => <option key={s} value={s}>{label(s)}</option>)}</Select>
        <Select aria-label="Route" value={f.route_code || ''} onChange={(e) => set('route_code', e.target.value)}><option value="">All routes</option>
          {meta.data?.routes.map((r) => <option key={r.code} value={r.code}>{r.name}</option>)}</Select>
        {!isInstitution(me?.role) && <Select aria-label="Region" value={f.region_id || ''} onChange={(e) => set('region_id', e.target.value)}><option value="">All Regions</option>
          {meta.data?.regions.map((r) => <option key={r.id} value={r.id}>{r.code}</option>)}</Select>}
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.mine === 'true'} onChange={(e) => set('mine', e.target.checked ? 'true' : '')} /> Assigned to me</label>
      </div>
      <Panel pad={false}>
        <ErrorBox error={q.error} />
        {q.isLoading ? <Loading /> : q.data?.items.length ? (
          <>
            <Table head={['Application', 'Institution', 'Region', 'Type', 'Route', 'Stage', 'Status', 'Age']}>
              {q.data.items.map((a: any) => (
                <tr key={a.id}>
                  <td><Link className="font-medium text-ledger hover:underline" to={`/applications/${a.id}`}>{a.app_no}</Link> <Synthetic on={a.is_synthetic} /></td>
                  <td className="max-w-[260px]">{a.institution}</td><td>{regionName(meta.data, a.region_id)}</td>
                  <td>{label(a.application_type)}</td><td className="text-xs">{label(a.route_code)}</td><td>{label(a.current_stage)}</td>
                  <td><Status value={a.status} /></td><td className="tabular-nums">{a.age_days} d</td>
                </tr>
              ))}
            </Table>
            <Pager page={page} pages={q.data.pages} total={q.data.total} onPage={(p) => { const n = new URLSearchParams(sp); n.set('page', String(p)); setSp(n) }} />
          </>
        ) : <div className="p-4"><Empty>No applications match these filters.</Empty></div>}
      </Panel>
    </div>
  )
}

const appSchema = z.object({ institution_id: z.coerce.number().int().positive('Choose an institution'), application_type: z.string().min(1, 'Choose a type'),
  route_code: z.string().optional(), assigned_officer_id: z.string().optional(), priority: z.string() })

export function ApplicationNew() {
  const meta = useMeta()
  const nav = useNavigate()
  const { me } = useAuth()
  const [instQ, setInstQ] = useState('')
  const [newInst, setNewInst] = useState(false)
  const insts = useQuery({ queryKey: ['inst-search', instQ], queryFn: () => api(`/api/institutions${qs({ q: instQ, page_size: 30 })}`) })
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(appSchema), defaultValues: { priority: 'NORMAL' } as any })
  const [err, setErr] = useState<unknown>(null)
  const submit = async (v: any) => {
    setErr(null)
    try {
      const a = await api('/api/applications', { body: { ...v, route_code: v.route_code || null, assigned_officer_id: v.assigned_officer_id ? Number(v.assigned_officer_id) : null } })
      nav(`/applications/${a.id}`)
    } catch (e) { setErr(e) }
  }
  return (
    <div className="max-w-3xl">
      <PageHeader title="Register application" sub="The route is assigned by the configured route rule unless you choose one explicitly; the choice is recorded." />
      <Panel>
        <form onSubmit={handleSubmit(submit)} className="grid gap-4 sm:grid-cols-2" noValidate>
          <Field label="Find institution" className="sm:col-span-2"><Input placeholder="Type a name or AICTE ID" value={instQ} onChange={(e) => setInstQ(e.target.value)} /></Field>
          <Field label="Institution" error={(errors as any).institution_id?.message} className="sm:col-span-2">
            <Select {...register('institution_id')}><option value="">Select…</option>
              {insts.data?.items.map((i: any) => <option key={i.id} value={i.id}>{i.name} ({i.aicte_id})</option>)}</Select>
          </Field>
          <div className="sm:col-span-2"><Button type="button" variant="ghost" size="sm" onClick={() => setNewInst(true)}>Institution not listed? Register it</Button></div>
          <Field label="Application type" error={(errors as any).application_type?.message}>
            <Select {...register('application_type')}><option value="">Select…</option>{meta.data?.application_types.map((t) => <option key={t} value={t}>{label(t)}</option>)}</Select>
          </Field>
          <Field label="Route" hint="Leave as 'By rule' to apply route.assignment."><Select {...register('route_code')}><option value="">By rule</option>
            {meta.data?.routes.map((r) => <option key={r.code} value={r.code}>{r.name}</option>)}</Select></Field>
          <Field label="Assign to officer"><Select {...register('assigned_officer_id')}><option value="">Later</option>
            {meta.data?.officers.filter((o) => !me?.region_id || o.region_id === me.region_id).map((o) => <option key={o.id} value={o.id}>{o.name} ({label(o.role)})</option>)}</Select></Field>
          <Field label="Priority"><Select {...register('priority')}>{['NORMAL', 'HIGH', 'URGENT'].map((p) => <option key={p}>{p}</option>)}</Select></Field>
          <div className="sm:col-span-2"><ErrorBox error={err} /></div>
          <div className="flex gap-2 sm:col-span-2"><Button type="submit" loading={isSubmitting}>Register application</Button><Button type="button" variant="secondary" onClick={() => nav(-1)}>Cancel</Button></div>
        </form>
      </Panel>
      <InstitutionDialog open={newInst} onClose={() => { setNewInst(false); insts.refetch() }} />
    </div>
  )
}

const instSchema = z.object({ aicte_id: z.string().min(3), name: z.string().min(3), region_id: z.coerce.number(), state: z.string().min(2), district: z.string().optional(),
  tier: z.coerce.number().min(1).max(3), principal_name: z.string().optional(), principal_email: z.string().email().or(z.literal('')).optional(),
  principal_phone: z.string().optional(), preferred_language: z.string() })

export function InstitutionDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const meta = useMeta()
  const { me } = useAuth()
  const { register, handleSubmit, watch, formState: { errors } } = useForm({ resolver: zodResolver(instSchema), defaultValues: { tier: 2, preferred_language: 'en', region_id: me?.region_id || '' } as any })
  const [err, setErr] = useState<unknown>(null)
  const rid = watch('region_id')
  const states = meta.data?.regions.find((r) => String(r.id) === String(rid))?.states || []
  return (
    <Dialog open={open} onClose={onClose} title="Register institution (synthetic)">
      <form className="grid gap-3 sm:grid-cols-2" onSubmit={handleSubmit(async (v: any) => { try { await api('/api/institutions', { body: { ...v, is_synthetic: true } }); onClose() } catch (e) { setErr(e) } })}>
        <Field label="AICTE institution ID" error={(errors as any).aicte_id?.message}><Input {...register('aicte_id')} /></Field>
        <Field label="Tier"><Select {...register('tier')}><option value={1}>1</option><option value={2}>2</option><option value={3}>3</option></Select></Field>
        <Field label="Name" className="sm:col-span-2" error={(errors as any).name?.message}><Input {...register('name')} /></Field>
        <Field label="Region"><Select {...register('region_id')}>{meta.data?.regions.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</Select></Field>
        <Field label="State" error={(errors as any).state?.message}><Select {...register('state')}><option value="">Select…</option>{states.map((s) => <option key={s}>{s}</option>)}</Select></Field>
        <Field label="Principal name"><Input {...register('principal_name')} /></Field>
        <Field label="Principal email" error={(errors as any).principal_email?.message}><Input {...register('principal_email')} /></Field>
        <Field label="Principal phone"><Input {...register('principal_phone')} /></Field>
        <Field label="Preferred language"><Select {...register('preferred_language')}><option value="en">English</option><option value="hi">Hindi</option><option value="mr">Marathi</option><option value="ta">Tamil</option></Select></Field>
        <div className="sm:col-span-2"><ErrorBox error={err} /></div>
        <div className="sm:col-span-2"><Button type="submit">Register institution</Button></div>
      </form>
    </Dialog>
  )
}

type Act = null | 'complete' | 'return' | 'resubmit' | 'revert' | 'decide' | 'assign' | 'exception'

export function ApplicationDetail() {
  const { id } = useParams()
  const { can, me } = useAuth()
  const meta = useMeta()
  const qc = useQueryClient()
  const toast = useToast()
  const [act, setAct] = useState<Act>(null)
  const q = useQuery({ queryKey: ['app', id], queryFn: () => api(`/api/applications/${id}`) })
  const a = q.data
  if (q.isLoading) return <Loading />
  if (q.error) return <ErrorBox error={q.error} />
  const stage = a.stage_def
  const live = ['IN_PROGRESS', 'AWAITING_DECISION'].includes(a.status)
  const done = () => { setAct(null); qc.invalidateQueries({ queryKey: ['app', id] }) }
  return (
    <div>
      <PageHeader title={a.app_no} sub={<>{a.institution} · {label(a.application_type)} · academic year {a.academic_year} <Synthetic on={a.is_synthetic} /></>}
        actions={<>
          {live && a.status === 'IN_PROGRESS' && !stage.decision && can('workflow.transition') && <Button onClick={() => setAct('complete')}>Complete {label(a.current_stage)}</Button>}
          {a.status === 'IN_PROGRESS' && stage.returnable && can('workflow.return') && <Button variant="secondary" onClick={() => setAct('return')}>Return to institution</Button>}
          {a.status === 'RETURNED' && can('workflow.resubmit') && <Button onClick={() => setAct('resubmit')}>{isInstitution(me?.role) ? 'Resubmit application' : 'Record resubmission'}</Button>}
          {live && a.allowed_reverts.length > 0 && can('workflow.revert') && <Button variant="secondary" onClick={() => setAct('revert')}>Revert stage</Button>}
          {a.status === 'AWAITING_DECISION' && can('workflow.decide') && <Button onClick={() => setAct('decide')}>Record decision</Button>}
          {can('application.assign') && live && <Button variant="secondary" onClick={() => setAct('assign')}>Assign</Button>}
          {can('exception.record') && <Button variant="quiet" onClick={() => setAct('exception')}>Exception…</Button>}
        </>} />
      {a.route_mismatch && <div className="mb-3"><Notice tone="amber">Route check: this application is on <b>{label(a.route_code)}</b> but the route rule for {label(a.application_type)} gives <b>{label(a.expected_route)}</b>. Review the routing (planted fault in synthetic data, or an explicit officer choice).</Notice></div>}
      <div className="grid gap-4 lg:grid-cols-[1fr_380px]">
        <div className="space-y-4">
          <Panel title="Route and progress">
            <ol className="flex flex-wrap items-center gap-1.5 text-[13px]" aria-label="Route stages">
              {a.route.definition.stages.filter((s: any) => !s.entry_only_via_resubmit || a.current_stage === s.code).map((s: any, i: number, arr: any[]) => {
                const entered = a.events.some((e: any) => e.type === 'STAGE_ENTER' && e.to === s.code)
                const cur = s.code === a.current_stage
                return (
                  <li key={s.code} className="flex items-center gap-1.5">
                    <span className={`rounded-md border px-2.5 py-1 ${cur ? 'border-ledger bg-ledger text-white' : entered ? 'border-ok/40 bg-ok-50 text-ok' : 'border-rule text-ink/55'}`}
                      aria-current={cur ? 'step' : undefined}>{entered && !cur ? '✓ ' : ''}{s.name} <span className="opacity-70">· {s.budget_days} {s.day_mode === 'WORKING' ? 'wd' : 'd'}</span></span>
                    {i < arr.length - 1 && <span aria-hidden className="text-ink/30">→</span>}
                  </li>
                )
              })}
            </ol>
            <p className="mt-3 text-xs text-ink/60">Route {a.route.name} v{a.route.version} · revert policy {a.route.definition.revert_policy} · pinned configuration v{a.config_version_id}</p>
          </Panel>
          {a.stage_obligation && (
            <Panel title="Current stage clock" actions={<Link className="text-sm text-ledger hover:underline" to={`/ledger/${a.stage_obligation.id}`}>Open obligation and Why?</Link>}>
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <span>{a.stage_obligation.title}</span><Status value={a.stage_obligation.display_state} />
                <span>Due {fmtDate(a.stage_obligation.due_date)}</span><DaysLeft days={a.stage_obligation.days_remaining} state={a.stage_obligation.state} />
                <span className="text-ink/60">Owner: {a.assigned_officer || 'unassigned'}</span>
              </div>
            </Panel>
          )}
          <Panel title="Obligations for this application" pad={false}>
            {a.obligations.length ? <Table head={['Obligation', 'Type', 'Party', 'Due', 'State']}>
              {a.obligations.map((o: any) => (
                <tr key={o.id}><td><Link className="text-ledger hover:underline" to={`/ledger/${o.id}`}>{o.title}</Link></td><td className="text-xs">{o.type_label}</td>
                  <td>{label(o.responsible_party)}</td><td>{fmtDate(o.due_date)}</td><td><Status value={o.display_state} /></td></tr>
              ))}
            </Table> : <div className="p-4"><Empty /></div>}
          </Panel>
        </div>
        <Panel title="Movement history">
          <ol className="relative space-y-3 border-l border-rule pl-4 text-[13px]">
            {a.events.map((e: any) => (
              <li key={e.id}>
                <span className="absolute -left-[5px] mt-1.5 h-2.5 w-2.5 rounded-full border-2 border-white bg-ledger" aria-hidden />
                <div className="font-medium">{label(e.type)}{e.to && e.type !== 'RETURNED' ? ` → ${label(e.to)}` : ''}</div>
                <div className="text-xs text-ink/60">{fmtDateTime(e.at)}{e.reason_code ? ` · ${label(e.reason_code)}` : ''}</div>
                {e.reason && <div className="mt-0.5 text-xs text-ink/80">{e.reason}</div>}
                {e.payload?.decision && <Badge tone="navy">{label(e.payload.decision)}</Badge>}
              </li>
            ))}
          </ol>
          {a.evc_visit_id && <Link to={`/evc/${a.evc_visit_id}`} className="mt-4 inline-block text-sm text-ledger hover:underline">EVC visit #{a.evc_visit_id} — {label(a.evc_status)}</Link>}
        </Panel>
      </div>
      <ActionDialog act={act} a={a} meta={meta.data} onClose={() => setAct(null)} onDone={(m) => { toast.ok(m); done() }} />
      {toast.node}
    </div>
  )
}

function ActionDialog({ act, a, meta, onClose, onDone }: { act: Act; a: any; meta: any; onClose: () => void; onDone: (m: string) => void }) {
  const [v, setV] = useState<Record<string, string>>({})
  const set = (k: string, x: string) => setV((p) => ({ ...p, [k]: x }))
  const m = useMutation({
    mutationFn: async () => {
      const id = a.id
      if (act === 'complete') return api(`/api/applications/${id}/complete-stage`, { body: { fields: { scrutiny_remarks: v.scrutiny_remarks, committee_recommendation: v.committee_recommendation } } })
      if (act === 'return') return api(`/api/applications/${id}/return`, { body: { reason: v.reason || '', reason_code: v.reason_code || 'OTHER', response_days: v.days ? Number(v.days) : null } })
      if (act === 'resubmit') return api(`/api/applications/${id}/resubmit`, { body: { reason: v.reason || '' } })
      if (act === 'revert') return api(`/api/applications/${id}/revert`, { body: { target: v.target, reason: v.reason || '' } })
      if (act === 'decide') return api(`/api/applications/${id}/decide`, { body: { decision: v.decision, note: v.reason || '' } })
      if (act === 'assign') return api(`/api/applications/${id}/assign`, { body: { officer_id: Number(v.officer), reason: v.reason || '' } })
      if (act === 'exception') {
        let order: number | null = null
        if (v.kind === 'LEGAL_HOLD' && (document.getElementById('order-file') as HTMLInputElement)?.files?.[0]) {
          const fd = new FormData(); fd.append('file', (document.getElementById('order-file') as HTMLInputElement).files![0]); fd.append('purpose', 'court_order'); fd.append('institution_id', String(a.institution_id))
          order = (await api('/api/files', { form: fd })).id
        }
        return api(`/api/applications/${id}/exception`, { body: { kind: v.kind, reason: v.reason || '', primary_application_id: v.primary ? Number(v.primary) : null, order_file_id: order } })
      }
    },
    onSuccess: () => { setV({}); onDone('Saved and recorded in the audit trail.') },
  })
  const titles: Record<string, string> = { complete: `Complete ${label(a.current_stage)}`, return: 'Return to institution', resubmit: 'Resubmission', revert: 'Revert to an earlier stage',
    decide: 'Record statutory decision', assign: 'Assign application', exception: 'Record a case exception' }
  if (!act) return null
  return (
    <Dialog open={!!act} onClose={onClose} title={titles[act]}>
      <div className="space-y-3">
        {act === 'complete' && <>
          {(a.stage_def.required_fields || []).includes('scrutiny_remarks') && <Field label="Scrutiny remarks (required)"><Textarea value={v.scrutiny_remarks || ''} onChange={(e) => set('scrutiny_remarks', e.target.value)} /></Field>}
          {(a.stage_def.required_fields || []).includes('committee_recommendation') && <Field label="Committee recommendation (required)"><Textarea value={v.committee_recommendation || ''} onChange={(e) => set('committee_recommendation', e.target.value)} /></Field>}
          {a.stage_def.requires?.evc_report && <Notice>This stage completes only after the EVC report has been received.</Notice>}
          <p className="text-xs text-ink/60">The stage clock stops as met and the next stage starts automatically with its own clock.</p>
        </>}
        {act === 'return' && <>
          <Field label="Deficiency category"><Select value={v.reason_code || ''} onChange={(e) => set('reason_code', e.target.value)}><option value="">Select…</option>{meta?.reason_codes.map((r: string) => <option key={r} value={r}>{label(r)}</option>)}</Select></Field>
          <Field label="What the institution must fix (required)"><Textarea value={v.reason || ''} onChange={(e) => set('reason', e.target.value)} /></Field>
          <Field label="Response window (days)" hint="Leave empty to use rule deadline.DEFICIENCY_RESPONSE."><Input type="number" min={1} value={v.days || ''} onChange={(e) => set('days', e.target.value)} /></Field>
          <Notice>The AICTE stage clock pauses and an institution-side clock starts. Waiting time is not counted against the officer.</Notice>
        </>}
        {act === 'resubmit' && <Field label="Note"><Textarea value={v.reason || ''} onChange={(e) => set('reason', e.target.value)} /></Field>}
        {act === 'revert' && <>
          <Field label="Revert to"><Select value={v.target || ''} onChange={(e) => set('target', e.target.value)}><option value="">Select…</option>{a.allowed_reverts.map((s: string) => <option key={s} value={s}>{label(s)}</option>)}</Select></Field>
          <Field label="Reason (required)"><Textarea value={v.reason || ''} onChange={(e) => set('reason', e.target.value)} /></Field>
          <p className="text-xs text-ink/60">Revert policy for this route: {a.route.definition.revert_policy}.</p>
        </>}
        {act === 'decide' && <>
          <Notice tone="amber">This records a statutory decision of the competent authority. ReguLens never decides approvals automatically.</Notice>
          <Field label="Decision"><Select value={v.decision || ''} onChange={(e) => set('decision', e.target.value)}><option value="">Select…</option>
            <option value="APPROVED">Approved</option><option value="APPROVED_WITH_CONDITIONS">Approved with conditions</option><option value="REJECTED">Rejected</option></Select></Field>
          <Field label="Decision note (required)"><Textarea value={v.reason || ''} onChange={(e) => set('reason', e.target.value)} /></Field>
        </>}
        {act === 'assign' && <>
          <Field label="Officer"><Select value={v.officer || ''} onChange={(e) => set('officer', e.target.value)}><option value="">Select…</option>
            {meta?.officers.filter((o: any) => o.region_id === a.region_id).map((o: any) => <option key={o.id} value={o.id}>{o.name} ({label(o.role)})</option>)}</Select></Field>
          <Field label="Reason"><Input value={v.reason || ''} onChange={(e) => set('reason', e.target.value)} /></Field>
        </>}
        {act === 'exception' && <>
          <Field label="Exception"><Select value={v.kind || ''} onChange={(e) => set('kind', e.target.value)}><option value="">Select…</option>
            <option value="WITHDRAWN">Withdrawn by institution</option><option value="MERGED">Duplicate — merge into another application</option>
            <option value="APPEAL">Appeal filed (creates child case, pauses this one)</option><option value="LEGAL_HOLD">Court-ordered hold</option><option value="LIFT_HOLD">Lift court-ordered hold</option></Select></Field>
          {v.kind === 'MERGED' && <Field label="Primary application ID"><Input value={v.primary || ''} onChange={(e) => set('primary', e.target.value)} /></Field>}
          {v.kind === 'LEGAL_HOLD' && <Field label="Court order (PDF/image, required)"><Input id="order-file" type="file" accept=".pdf,.png,.jpg,.jpeg" /></Field>}
          <Field label="Reason (required)"><Textarea value={v.reason || ''} onChange={(e) => set('reason', e.target.value)} /></Field>
          <p className="text-xs text-ink/60">History is never overwritten: obligations are cancelled, paused or re-parented with audit entries.</p>
        </>}
        <ErrorBox error={m.error} />
        <div className="flex gap-2"><Button loading={m.isPending} onClick={() => m.mutate()}>Confirm</Button><Button variant="secondary" onClick={onClose}>Cancel</Button></div>
      </div>
    </Dialog>
  )
}
