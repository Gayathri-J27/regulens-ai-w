import { useMutation, useQuery } from '@tanstack/react-query'
import { useState } from 'react'
import { Button, ErrorBox, Field, Input, Loading, Notice, PageHeader, Panel, Select, Stat, Table, Tabs, fmtDate, label } from '../components/ui'
import { api } from '../services/api'

const KEYS = ['deadline.SCRUTINY_COMPLETION', 'deadline.STAGE_COMPLETION', 'deadline.EVC_SCHEDULING', 'deadline.DEFICIENCY_RESPONSE', 'deadline.APPROVAL_UNDERTAKING',
  'deadline.INSTITUTIONAL_COMPLIANCE', 'escalation.timeline', 'route.assignment', 'risk.thresholds']

export function Simulator() {
  const [tab, setTab] = useState('rules')
  return (
    <div>
      <PageHeader title="Rule simulator" sub="Try a proposed parameter against stored cases before it goes through approval. Replays use the production clock engine on real clock histories." />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'rules', label: 'Replay a rule change' }, { id: 'impact', label: 'Impact calculator' }]} />
      {tab === 'rules' ? <RuleSim /> : <Impact />}
    </div>
  )
}

function RuleSim() {
  const [key, setKey] = useState(KEYS[0])
  const rules = useQuery({ queryKey: ['rules', key], queryFn: () => api(`/api/admin/rules?rule_key=${key}&status=EFFECTIVE`) })
  const cur = rules.data?.[0]?.params
  const [params, setParams] = useState('')
  const run = useMutation({ mutationFn: () => api('/api/simulator/run', { body: { rule_key: key, params: JSON.parse(params || JSON.stringify(cur || {})) } }) })
  const r: any = run.data
  return (
    <div className="grid gap-4 lg:grid-cols-[380px_1fr]">
      <Panel title="Proposed parameter">
        <div className="space-y-3">
          <Field label="Rule"><Select value={key} onChange={(e) => { setKey(e.target.value); setParams(''); run.reset() }}>{KEYS.map((k) => <option key={k}>{k}</option>)}</Select></Field>
          {cur && <p className="text-xs text-ink/65">Current effective value (v{rules.data[0].version}, {label(rules.data[0].source_type)}): <code>{JSON.stringify(cur)}</code></p>}
          <Field label="Proposed parameters (JSON)" hint='e.g. {"budget_days": 12, "day_mode": "WORKING"}'>
            <textarea className="h-40 w-full rounded-md border border-rule p-2 font-mono text-[12px]" value={params || JSON.stringify(cur || {}, null, 2)} onChange={(e) => setParams(e.target.value)} />
          </Field>
          <ErrorBox error={run.error} />
          <Button loading={run.isPending} onClick={() => run.mutate()}>Run simulation</Button>
          <p className="text-xs text-ink/55">Simulation never changes records. To adopt a value, create a draft under Administration → Rules; it then needs an impact preview and a second approver.</p>
        </div>
      </Panel>
      <div>
        {run.isPending && <Loading label="Replaying clock histories…" />}
        {r && <div className="space-y-4">
          <div className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-rule bg-rule md:grid-cols-4">
            <Stat label="Records replayed" value={(r.obligations_replayed ?? 0).toLocaleString()} />
            <Stat label="Obligations affected" value={(r.obligations_affected ?? 0).toLocaleString()} tone="amber" />
            <Stat label="Cases affected" value={(r.cases_affected ?? 0).toLocaleString()} />
            <Stat label="Deadlines changed" value={(r.deadlines_changed ?? 0).toLocaleString()} />
            {'potential_additional_breaches_open' in r && <Stat label="New breaches among open items" value={r.potential_additional_breaches_open} tone="red" />}
            {r.historical_backtest && <Stat label="Back-test: would have been late" value={r.historical_backtest.would_have_been_late} tone="red" sub={`${r.historical_backtest.would_have_been_on_time} late ones would have been on time`} />}
            {'mean_due_shift_days' in r && <Stat label="Mean due-date shift" value={`${r.mean_due_shift_days} d`} />}
            {r.workload_14d && <Stat label="Due in next 14 days" value={`${r.workload_14d.before} → ${r.workload_14d.after}`} sub={`${r.workload_14d.officers_with_change} officers' load changes`} />}
            {'stage_changes' in r && <Stat label="Stage / route changes" value={r.stage_changes} />}
          </div>
          {r.note && <Notice>{r.note}</Notice>}
          {r.current_levels && <Panel title="Escalation levels now vs proposed"><p className="text-sm">Now: {JSON.stringify(r.current_levels)} · Proposed: {JSON.stringify(r.proposed_levels)}</p></Panel>}
          {r.changes && <Panel title="Route changes" pad={false}><Table head={['Type', 'From', 'To', 'Applications']}>{r.changes.map((c: any, i: number) => <tr key={i}><td>{label(c.type)}</td><td>{c.from}</td><td>{c.to}</td><td>{c.applications}</td></tr>)}</Table></Panel>}
          {r.sample?.length > 0 && <Panel title="Sample of changed deadlines" pad={false}><Table head={['Obligation', 'State', 'Current due', 'Proposed due']} dense>
            {r.sample.map((s: any) => <tr key={s.obl_no}><td>{s.obl_no}</td><td>{label(s.state)}</td><td>{fmtDate(s.old_due)}</td><td className="font-medium">{fmtDate(s.new_due)}</td></tr>)}</Table></Panel>}
          <p className="text-xs text-ink/55">Method: {r.method}.</p>
        </div>}
      </div>
    </div>
  )
}

function Impact() {
  const [v, setV] = useState({ obligations: 18000, reminders_per_obligation: 3, minutes_per_followup: 12, status_checks_per_obligation: 4, minutes_per_status_check: 6, automated_followup_pct: 85, institutions: 2000 })
  const run = useMutation({ mutationFn: () => api('/api/impact', { body: v }) })
  const r: any = run.data
  const fields: [keyof typeof v, string][] = [['obligations', 'Obligations per year'], ['reminders_per_obligation', 'Follow-ups per obligation'], ['minutes_per_followup', 'Minutes per manual follow-up'],
    ['status_checks_per_obligation', 'Manual status checks per obligation'], ['minutes_per_status_check', 'Minutes per status check'], ['automated_followup_pct', 'Share of follow-ups automated (%)'], ['institutions', 'Institutions']]
  return (
    <div className="grid gap-4 lg:grid-cols-[380px_1fr]">
      <Panel title="Assumptions">
        <div className="space-y-2">{fields.map(([k, l]) => <Field key={k} label={l}><Input type="number" value={v[k]} onChange={(e) => setV({ ...v, [k]: Number(e.target.value) })} /></Field>)}
          <Button onClick={() => run.mutate()} loading={run.isPending}>Calculate</Button></div>
      </Panel>
      {r && <div className="space-y-4">
        <Notice tone="amber"><b>{r.label}</b></Notice>
        <Panel title="Low / base / high" pad={false}>
          <Table head={['Scenario', 'Manual follow-ups (baseline)', 'Automated', 'Still manual', 'Officer-hours saved', 'FTE']}>
            {Object.entries(r.scenarios).map(([k, s]: any) => <tr key={k}><td className="font-medium">{label(k)}</td><td>{s.manual_followups_baseline.toLocaleString()}</td><td>{s.followups_automated.toLocaleString()}</td>
              <td>{s.manual_followups_remaining.toLocaleString()}</td><td className="font-semibold">{s.officer_hours_saved.toLocaleString()}</td><td>{s.fte_equivalent}</td></tr>)}
          </Table>
        </Panel>
        <Panel title="Formulas"><ul className="space-y-1 text-[13px]">{Object.entries(r.formulas).map(([k, f]: any) => <li key={k}><b>{label(k)}</b> = {f}</li>)}</ul>
          <p className="mt-2 text-xs text-ink/60">Sensitivity: low = {r.sensitivity.low}; high = {r.sensitivity.high}.</p></Panel>
        <Panel title="Deadline misses"><p className="text-sm">Observed late completion rate in stored history: <b>{r.deadline_miss.historical_late_rate_pct}%</b> (n={r.deadline_miss.sample}). {r.deadline_miss.note}</p></Panel>
      </div>}
    </div>
  )
}
