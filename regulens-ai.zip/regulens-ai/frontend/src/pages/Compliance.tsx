import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Link, useParams, useSearchParams } from 'react-router-dom'
import { Button, DaysLeft, Empty, ErrorBox, Field, Input, Loading, PageHeader, Pager, Panel, Select, Stat, Status, Synthetic, Table, fmtDate,
  label, useToast } from '../components/ui'
import { regionName, useMeta } from '../hooks/useMeta'
import { api, qs } from '../services/api'
import { useAuth } from '../services/auth'
import { InstitutionDialog } from './Applications'

export function Compliance() {
  const [sp, setSp] = useSearchParams()
  const meta = useMeta()
  const { can } = useAuth()
  const [add, setAdd] = useState(false)
  const f = Object.fromEntries(sp.entries())
  const page = Number(f.page || 1)
  const q = useQuery({ queryKey: ['institutions', f], queryFn: () => api(`/api/institutions${qs({ ...f, page_size: 25 })}`) })
  const ov = useQuery({ queryKey: ['ledger', 'inst-overdue', f.region_id], queryFn: () => api(`/api/ledger${qs({ view: 'overdue', region_id: f.region_id, page_size: 8 })}`) })
  const sub = useQuery({ queryKey: ['ledger', 'verification', f.region_id], queryFn: () => api(`/api/ledger${qs({ view: 'verification', region_id: f.region_id, page_size: 8 })}`) })
  const set = (k: string, v: string) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); n.delete('page'); setSp(n) }
  return (
    <div>
      <PageHeader title="Institutional compliance" sub="Institutions, their compliance health and the submissions waiting for verification."
        actions={can('institution.manage') && <Button onClick={() => setAdd(true)}>Register institution</Button>} />
      <div className="mb-4 grid gap-4 lg:grid-cols-2">
        <Panel title={`Submissions awaiting verification (${sub.data?.total ?? '…'})`} pad={false}>
          {sub.data?.items.length ? <Table head={['Obligation', 'Institution', 'Due']} dense>{sub.data.items.map((o: any) => <tr key={o.id}>
            <td><Link className="text-ledger hover:underline" to={`/ledger/${o.id}`}>{o.title}</Link></td><td>{o.institution}</td><td>{fmtDate(o.due_date)}</td></tr>)}</Table>
            : <div className="p-4"><Empty>Nothing waiting for verification.</Empty></div>}
        </Panel>
        <Panel title={`Overdue obligations (${ov.data?.total ?? '…'})`} pad={false}>
          {ov.data?.items.length ? <Table head={['Obligation', 'Institution', 'Overdue']} dense>{ov.data.items.map((o: any) => <tr key={o.id}>
            <td><Link className="text-ledger hover:underline" to={`/ledger/${o.id}`}>{o.title}</Link></td><td>{o.institution}</td><td><DaysLeft days={o.days_remaining} state={o.state} /></td></tr>)}</Table>
            : <div className="p-4"><Empty /></div>}
        </Panel>
      </div>
      <div className="mb-3 grid grid-cols-2 gap-2 md:grid-cols-4">
        <Input aria-label="Search institutions" placeholder="Name or AICTE ID" defaultValue={f.q} onKeyDown={(e) => e.key === 'Enter' && set('q', (e.target as HTMLInputElement).value)} />
        <Select aria-label="Region" value={f.region_id || ''} onChange={(e) => set('region_id', e.target.value)}><option value="">All Regions</option>{meta.data?.regions.map((r) => <option key={r.id} value={r.id}>{r.code}</option>)}</Select>
        <Select aria-label="Data" value={f.synthetic || ''} onChange={(e) => set('synthetic', e.target.value)}><option value="">Incl. synthetic</option><option value="0">Exclude synthetic</option></Select>
      </div>
      <Panel pad={false}>
        <ErrorBox error={q.error} />
        {q.isLoading ? <Loading /> : <>
          <Table head={['Institution', 'AICTE ID', 'Region', 'State', 'Tier', 'Language']}>
            {q.data.items.map((i: any) => <tr key={i.id}><td><Link className="text-ledger hover:underline" to={`/institutions/${i.id}`}>{i.name}</Link> <Synthetic on={i.is_synthetic} /></td>
              <td className="text-xs">{i.aicte_id}</td><td>{regionName(meta.data, i.region_id)}</td><td>{i.state}</td><td>{i.tier}</td><td>{i.preferred_language}</td></tr>)}
          </Table>
          <Pager page={page} pages={q.data.pages} total={q.data.total} onPage={(p) => { const n = new URLSearchParams(sp); n.set('page', String(p)); setSp(n) }} /></>}
      </Panel>
      <InstitutionDialog open={add} onClose={() => { setAdd(false); q.refetch() }} />
    </div>
  )
}

export function HealthCard({ h }: { h: any }) {
  return (
    <div className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-rule bg-rule sm:grid-cols-3 lg:grid-cols-6">
      <Stat label="Open obligations" value={h.open_obligations} />
      <Stat label="Completed" value={h.completed_obligations} tone="green" />
      <Stat label="Due in 30 days" value={h.upcoming_30d} tone="amber" />
      <Stat label="Overdue" value={h.overdue} tone={h.overdue ? 'red' : undefined} />
      <Stat label="On-time record" value={h.on_time_rate == null ? '—' : `${Math.round(h.on_time_rate * 100)}%`} sub={`${h.on_time_sample} completed`} />
      <Stat label="Contacts" value={`${h.contact_health.verified}/${h.contact_health.total}`} sub={h.contact_health.invalid ? `${h.contact_health.invalid} unreachable` : 'verified'} tone={h.contact_health.invalid ? 'red' : 'green'} />
    </div>
  )
}

export function InstitutionDetail() {
  const { id } = useParams()
  const meta = useMeta()
  const qc = useQueryClient()
  const toast = useToast()
  const q = useQuery({ queryKey: ['institution', id], queryFn: () => api(`/api/institutions/${id}`) })
  const obls = useQuery({ queryKey: ['ledger', 'inst', id], queryFn: () => api(`/api/ledger${qs({ institution_id: id, page_size: 50 })}`) })
  const [c, setC] = useState<Record<string, string>>({ role: 'COMPLIANCE' })
  const add = useMutation({ mutationFn: () => api(`/api/institutions/${id}/contacts`, { body: { ...c, verified: false } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['institution', id] }); setC({ role: 'COMPLIANCE' }); toast.ok('Contact added.') }, onError: toast.fail })
  if (q.isLoading) return <Loading />
  if (q.error) return <ErrorBox error={q.error} />
  const i = q.data
  return (
    <div>
      <PageHeader title={i.name} sub={<>{i.aicte_id} · {regionName(meta.data, i.region_id)} · {i.state}{i.district ? `, ${i.district}` : ''} · tier {i.tier} · language {i.preferred_language}{i.digest_enabled ? ' · daily digest' : ''} <Synthetic on={i.is_synthetic} /></>} />
      <h2 className="mb-2 text-[15px] font-semibold">Compliance health card</h2>
      <HealthCard h={i.health} />
      <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_380px]">
        <Panel title="Obligations" pad={false}>
          {obls.data?.items.length ? <Table head={['Obligation', 'Type', 'Due', 'Remaining', 'State']}>
            {obls.data.items.map((o: any) => <tr key={o.id}><td><Link className="text-ledger hover:underline" to={`/ledger/${o.id}`}>{o.title}</Link></td><td className="text-xs">{o.type_label}</td>
              <td>{fmtDate(o.due_date)}</td><td><DaysLeft days={o.days_remaining} state={o.state} /></td><td><Status value={o.display_state} /></td></tr>)}
          </Table> : <div className="p-4"><Empty /></div>}
        </Panel>
        <div className="space-y-4">
          <Panel title="Document expiry">
            {i.health.documents.length ? <ul className="text-sm">{i.health.documents.map((d: any, k: number) => <li key={k} className="flex justify-between border-b border-rule/60 py-1.5">
              <span>{label(d.doc_type)}</span><span>{fmtDate(d.expiry_date)} · <DaysLeft days={d.days} state="OPEN" /></span></li>)}</ul> : <Empty>No documents on record.</Empty>}
          </Panel>
          <Panel title="Contacts">
            <ul className="space-y-1.5 text-[13px]">{i.contacts.map((x: any) => <li key={x.id}><b>{label(x.role)}</b>: {x.name}<div className="text-xs text-ink/60">{x.email || '—'} · {x.phone || '—'}
              {x.verified ? ' · verified' : ' · unverified'}{x.invalid && <span className="text-late"> · unreachable: {x.invalid_reason}</span>}</div></li>)}</ul>
            <div className="mt-3 grid gap-2 border-t border-rule pt-3">
              <Select value={c.role} onChange={(e) => setC({ ...c, role: e.target.value })}>{['PRINCIPAL', 'COMPLIANCE', 'TRUST_REP', 'ACCOUNTS'].map((r) => <option key={r} value={r}>{label(r)}</option>)}</Select>
              <Input placeholder="Name" value={c.name || ''} onChange={(e) => setC({ ...c, name: e.target.value })} />
              <Input placeholder="Email" value={c.email || ''} onChange={(e) => setC({ ...c, email: e.target.value })} />
              <Input placeholder="Phone" value={c.phone || ''} onChange={(e) => setC({ ...c, phone: e.target.value })} />
              <Button size="sm" disabled={!c.name} onClick={() => add.mutate()}>Add contact</Button>
            </div>
          </Panel>
        </div>
      </div>
      {toast.node}
    </div>
  )
}
