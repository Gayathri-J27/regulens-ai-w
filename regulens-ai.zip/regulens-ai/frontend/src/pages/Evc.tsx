import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Link, useParams, useSearchParams } from 'react-router-dom'
import { Badge, Button, Empty, ErrorBox, Field, Input, Loading, Notice, PageHeader, Pager, Panel, Select, Status, Synthetic, Table, Textarea, cx,
  fmtDate, label, useToast } from '../components/ui'
import { regionName, useMeta } from '../hooks/useMeta'
import { api, qs } from '../services/api'
import { useAuth } from '../services/auth'

const STATES = ['QUEUED', 'PANEL_PROPOSED', 'SCHEDULED', 'REPORT_PENDING', 'REPORT_RECEIVED', 'DELAYED', 'CLOSED']

export function Evc() {
  const [sp, setSp] = useSearchParams()
  const meta = useMeta()
  const status = sp.get('status') || 'QUEUED'
  const page = Number(sp.get('page') || 1)
  const q = useQuery({ queryKey: ['evc', status, page, sp.get('region_id')], queryFn: () => api(`/api/evc/visits${qs({ status, page, page_size: 25, region_id: sp.get('region_id') })}`) })
  return (
    <div>
      <PageHeader title="EVC management" sub="Expert Visit Committee queue: panel proposal with recorded exclusions, scheduling, visits, reports and confirmed findings." />
      <div className="mb-4 flex flex-wrap gap-2" role="tablist" aria-label="EVC status">
        {STATES.map((s) => <button key={s} role="tab" aria-selected={status === s} onClick={() => setSp({ status: s })}
          className={cx('rounded-md border px-3 py-1.5 text-sm', status === s ? 'border-ledger bg-ledger-50 font-medium' : 'border-rule bg-white hover:bg-mist')}>
          {label(s)} <span className="tabular-nums text-ink/55">{q.data?.by_status?.[s] ?? ''}</span></button>)}
      </div>
      <Panel pad={false}>
        <ErrorBox error={q.error} />
        {q.isLoading ? <Loading /> : q.data?.items.length ? <>
          <Table head={['Visit', 'Application', 'Institution', 'Region', 'Status', 'Visit date', 'Panel']}>
            {q.data.items.map((v: any) => <tr key={v.id}>
              <td><Link className="font-medium text-ledger hover:underline" to={`/evc/${v.id}`}>#{v.id}</Link> <Synthetic on={v.is_synthetic} /></td>
              <td><Link className="hover:underline" to={`/applications/${v.application_id}`}>{v.app_no}</Link></td><td>{v.institution}</td>
              <td>{regionName(meta.data, v.region_id)}</td><td><Status value={v.status} />{v.delayed_reason && <div className="text-xs text-warn">{v.delayed_reason}</div>}</td>
              <td>{fmtDate(v.scheduled_date || v.proposed_date)}</td><td className="text-xs">{v.panel.map((p: any) => p.name).join(', ') || '—'}</td></tr>)}
          </Table>
          <Pager page={page} pages={q.data.pages} total={q.data.total} onPage={(p) => setSp({ status, page: String(p) })} /></> : <div className="p-4"><Empty>No visits in this state.</Empty></div>}
      </Panel>
    </div>
  )
}

export function EvcDetail() {
  const { id } = useParams()
  const { can, me } = useAuth()
  const qc = useQueryClient()
  const toast = useToast()
  const q = useQuery({ queryKey: ['evc-visit', id], queryFn: () => api(`/api/evc/visits/${id}`) })
  const v = q.data
  const [date, setDate] = useState('')
  const [chosen, setChosen] = useState<number[]>([])
  const [override, setOverride] = useState('')
  const [findings, setFindings] = useState([{ text: '', severity: 'MAJOR', proposed_undertaking: '', due_days: '30' }])
  const [file, setFile] = useState<File | null>(null)
  const [reason, setReason] = useState('')
  const refresh = () => qc.invalidateQueries({ queryKey: ['evc-visit', id] })
  const m = useMutation({
    mutationFn: async (kind: string) => {
      if (kind === 'propose') return api(`/api/evc/visits/${id}/propose`, { body: { visit_date: date } })
      if (kind === 'schedule' || kind === 'reschedule') return api(`/api/evc/visits/${id}/schedule`, { body: { expert_ids: chosen, visit_date: date || v.proposed_date || v.scheduled_date, override_reason: override || null, reschedule: kind === 'reschedule' } })
      if (kind === 'visited') return api(`/api/evc/visits/${id}/visited`, { method: 'POST' })
      if (kind === 'delay') return api(`/api/evc/visits/${id}/delay`, { body: { reason } })
      if (kind === 'report') {
        const fd = new FormData(); fd.append('findings', JSON.stringify(findings.filter((f) => f.text).map((f) => ({ ...f, due_days: Number(f.due_days) || null, proposed_undertaking: f.proposed_undertaking || null }))))
        if (file) fd.append('file', file)
        return api(`/api/evc/visits/${id}/report`, { form: fd })
      }
    },
    onSuccess: (r: any, k) => { refresh(); if (k === 'propose' && r?.panels?.[0]) setChosen(r.panels[0].expert_ids); toast.ok('Saved.') }, onError: toast.fail,
  })
  const confirm = useMutation({ mutationFn: (decisions: any[]) => api(`/api/evc/visits/${id}/confirm-findings`, { body: { decisions } }),
    onSuccess: (r: any) => { refresh(); toast.ok(`${r.obligations_created.length} undertaking(s) added to the Promise Ledger.`) }, onError: toast.fail })
  if (q.isLoading) return <Loading />
  if (q.error) return <ErrorBox error={q.error} />
  const p = v.proposal
  const canSched = can('evc.schedule')
  return (
    <div>
      <PageHeader title={`EVC visit #${v.id}`} sub={<>{v.institution} · <Link className="text-ledger hover:underline" to={`/applications/${v.application_id}`}>{v.app_no}</Link> · required expertise {v.required_expertise.map(label).join(', ')} <Synthetic on={v.is_synthetic} /></>}
        actions={<><Status value={v.status} />{canSched && !['CLOSED', 'REPORT_RECEIVED'].includes(v.status) && <Button size="sm" variant="quiet" onClick={() => m.mutate('delay')} disabled={!reason}>Mark delayed</Button>}</>} />
      {canSched && !['CLOSED', 'REPORT_RECEIVED', 'REPORT_PENDING'].includes(v.status) && (
        <Panel title={['SCHEDULED', 'DELAYED'].includes(v.status) ? 'Reschedule' : 'Propose a panel'} className="mb-4">
          <div className="flex flex-wrap items-end gap-2">
            <Field label="Visit date"><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></Field>
            <Button onClick={() => m.mutate('propose')} disabled={!date} loading={m.isPending && m.variables === 'propose'}>Rank eligible experts</Button>
            <Field label="Delay reason (to mark delayed)" className="min-w-[260px] flex-1"><Input value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
          </div>
        </Panel>
      )}
      {p && !['CLOSED', 'REPORT_RECEIVED', 'REPORT_PENDING'].includes(v.status) && (
        <div className="mb-4 grid gap-4 lg:grid-cols-[1fr_380px]">
          <Panel title={`Proposed panels for ${fmtDate(p.visit_date)}`}>
            {p.note && <Notice tone="amber">{p.note}</Notice>}
            <div className="space-y-3">
              {p.panels.map((pn: any, i: number) => (
                <label key={i} className={cx('block cursor-pointer rounded-md border p-3', JSON.stringify(chosen) === JSON.stringify(pn.expert_ids) ? 'border-ledger bg-ledger-50' : 'border-rule')}>
                  <input type="radio" name="panel" className="mr-2" checked={JSON.stringify(chosen) === JSON.stringify(pn.expert_ids)} onChange={() => setChosen(pn.expert_ids)} />
                  <b>Panel {i + 1}</b> — score {pn.panel_score} · expertise coverage {Math.round(pn.expertise_coverage * 100)}%
                  <ul className="mt-1.5 grid gap-1 text-[12.5px] sm:grid-cols-3">{pn.members.map((m: any) => <li key={m.expert_id} className="rounded bg-white px-2 py-1 ring-1 ring-rule">
                    <div className="font-medium">{m.name}</div><div className="text-ink/60">{m.expertise.map(label).join(', ')}</div>
                    <div className="text-ink/60">{m.distance_km} km · {m.month_load}/{m.monthly_cap} this month · score {m.score}</div></li>)}</ul>
                  <p className="mt-1 text-[11.5px] text-ink/60">{pn.explanation}</p>
                </label>
              ))}
            </div>
            <div className="mt-3 flex flex-wrap items-end gap-2">
              {me?.role === 'AICTE_ADMIN' && <Field label="Override reason (only if selecting an excluded expert)" className="flex-1"><Input value={override} onChange={(e) => setOverride(e.target.value)} /></Field>}
              <Button disabled={!chosen.length} onClick={() => m.mutate(['SCHEDULED', 'DELAYED'].includes(v.status) ? 'reschedule' : 'schedule')}>Approve panel and schedule</Button>
            </div>
            <p className="mt-2 text-xs text-ink/60">Weights: travel {p.weights.travel}, workload {p.weights.workload}, expertise {p.weights.expertise}; Region policy {label(p.weights.region_policy)}. An officer approves; nothing is scheduled automatically.</p>
          </Panel>
          <Panel title={`Excluded experts (${p.excluded.length})`}>
            <ul className="max-h-[420px] space-y-1.5 overflow-y-auto text-[12.5px]">
              {p.excluded.slice(0, 80).map((x: any) => <li key={x.expert_id}><span className="font-medium">{x.name}</span>{x.coi && <Badge tone="red">conflict of interest</Badge>}<div className="text-ink/60">{x.reasons.join('; ')}</div></li>)}
            </ul>
          </Panel>
        </div>
      )}
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Visit">
          <p className="text-sm">Scheduled: <b>{fmtDate(v.scheduled_date)}</b> · reschedules {v.reschedule_count}</p>
          <p className="mt-1 text-sm">Panel: {v.panel.map((x: any) => x.name).join(', ') || '—'}</p>
          {v.override_reason && <p className="mt-1 text-xs text-warn">Override recorded: {v.override_reason}</p>}
          {['SCHEDULED', 'DELAYED'].includes(v.status) && can('evc.report') && <Button className="mt-3" onClick={() => m.mutate('visited')}>Record visit as held</Button>}
          {v.status === 'REPORT_PENDING' && can('evc.report') && (
            <div className="mt-4 space-y-3 border-t border-rule pt-3">
              <h3 className="text-sm font-semibold">Upload report and findings</h3>
              <Field label="Report file"><Input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
              {findings.map((f, i) => (
                <div key={i} className="grid gap-2 rounded border border-rule p-2 sm:grid-cols-2">
                  <Field label={`Finding ${i + 1}`} className="sm:col-span-2"><Textarea rows={2} value={f.text} onChange={(e) => setFindings(findings.map((x, j) => j === i ? { ...x, text: e.target.value } : x))} /></Field>
                  <Field label="Proposed undertaking"><Input value={f.proposed_undertaking} onChange={(e) => setFindings(findings.map((x, j) => j === i ? { ...x, proposed_undertaking: e.target.value } : x))} /></Field>
                  <Field label="Days to comply"><Input type="number" value={f.due_days} onChange={(e) => setFindings(findings.map((x, j) => j === i ? { ...x, due_days: e.target.value } : x))} /></Field>
                </div>))}
              <div className="flex gap-2"><Button variant="secondary" size="sm" onClick={() => setFindings([...findings, { text: '', severity: 'MINOR', proposed_undertaking: '', due_days: '30' }])}>Add finding</Button>
                <Button onClick={() => m.mutate('report')}>Submit report</Button></div>
            </div>
          )}
          {v.report_url && <a className="mt-3 inline-block text-sm text-ledger hover:underline" href={v.report_url} target="_blank" rel="noreferrer">Open EVC report</a>}
        </Panel>
        <Panel title="Findings">
          {v.findings.length ? <ul className="space-y-2 text-[13px]">{v.findings.map((f: any, i: number) => (
            <li key={i} className="rounded border border-rule p-2">
              <div className="flex items-center gap-2"><Badge tone={f.severity === 'MAJOR' ? 'amber' : 'grey'}>{label(f.severity)}</Badge><Status value={f.status} /></div>
              <p className="mt-1">{f.text}</p>
              {f.proposed_undertaking && <p className="text-xs text-ink/70">Proposed undertaking: {f.proposed_undertaking} ({f.due_days} days)</p>}
              {f.obligation_id && <Link className="text-xs text-ledger hover:underline" to={`/ledger/${f.obligation_id}`}>Ledger obligation #{f.obligation_id}</Link>}
              {f.status === 'PROPOSED' && can('evc.confirm_findings') && <div className="mt-2 flex gap-2">
                <Button size="sm" onClick={() => confirm.mutate([{ index: i, accept: true }])} disabled={!f.proposed_undertaking}>Confirm → create undertaking</Button>
                <Button size="sm" variant="secondary" onClick={() => confirm.mutate([{ index: i, accept: false, note: 'dismissed by officer' }])}>Dismiss</Button></div>}
            </li>))}</ul> : <Empty>No findings recorded yet.</Empty>}
        </Panel>
      </div>
      {toast.node}
    </div>
  )
}
