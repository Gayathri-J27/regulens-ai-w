import { useQuery } from '@tanstack/react-query'
import { useState } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Button, ErrorBox, Input, Loading, PageHeader, Panel, Select, Stat, label } from '../components/ui'
import { regionName, useMeta } from '../hooks/useMeta'
import { api, qs } from '../services/api'
import { useAuth } from '../services/auth'

const BLUE = '#1F5AA6', INK = '#14233C', RED = '#B42318', AMBER = '#B54708', GREEN = '#067647', GREY = '#8FA3C2'
const STATUS_COLOR: Record<string, string> = { OVERDUE: RED, EXPIRED: RED, DELAYED: AMBER, EXPIRING_90D: AMBER, MET: GREEN, VALID: GREEN, CLOSED: GREY,
  REPORT_RECEIVED: GREEN, SCHEDULED: BLUE, OPEN: BLUE, SUBMITTED: INK, QUEUED: GREY, PANEL_PROPOSED: BLUE, REPORT_PENDING: AMBER, UNVERIFIED: GREY }

export function ChartBox({ title, children, h = 220 }: { title: string; children: any; h?: number }) {
  return (
    <Panel title={title}>
      <div style={{ height: h }}><ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer></div>
    </Panel>
  )
}

const axis = { fontSize: 11, fill: '#14233CB0' }

export function Overview() {
  const { me } = useAuth()
  const meta = useMeta()
  const [f, setF] = useState<Record<string, string>>({})
  const q = useQuery({ queryKey: ['dashboard', f], queryFn: () => api(`/api/dashboard${qs(f)}`) })
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }))
  const d = q.data
  const regional = me?.region && !['SUPER_ADMIN', 'AICTE_ADMIN', 'COMPETENT_AUTHORITY', 'AUDIT_OFFICER'].includes(me.role)
  return (
    <div>
      <PageHeader title={regional ? `${me?.region} dashboard` : 'National overview'}
        sub={d ? <>Figures computed from the database as of {d.as_of}. Application counts: {d.source.applications}.</> : undefined} />
      <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6" role="group" aria-label="Dashboard filters">
        {!regional && <Select aria-label="Region" value={f.region_id || ''} onChange={(e) => set('region_id', e.target.value)}>
          <option value="">All Regions</option>{meta.data?.regions.map((r) => <option key={r.id} value={r.id}>{r.code} — {r.name}</option>)}</Select>}
        <Select aria-label="State" value={f.state || ''} onChange={(e) => set('state', e.target.value)}>
          <option value="">All states</option>{[...new Set(meta.data?.regions.filter((r) => !f.region_id || String(r.id) === f.region_id).flatMap((r) => r.states))].map((s) => <option key={s}>{s}</option>)}</Select>
        <Select aria-label="Application type" value={f.application_type || ''} onChange={(e) => set('application_type', e.target.value)}>
          <option value="">All types</option>{meta.data?.application_types.map((t) => <option key={t} value={t}>{label(t)}</option>)}</Select>
        <Select aria-label="Route" value={f.route_code || ''} onChange={(e) => set('route_code', e.target.value)}>
          <option value="">All routes</option>{meta.data?.routes.map((r) => <option key={r.code} value={r.code}>{r.name}</option>)}</Select>
        <Select aria-label="Stage" value={f.stage || ''} onChange={(e) => set('stage', e.target.value)}>
          <option value="">All stages</option>{meta.data?.stages.map((s) => <option key={s} value={s}>{label(s)}</option>)}</Select>
        <Select aria-label="Status" value={f.status || ''} onChange={(e) => set('status', e.target.value)}>
          <option value="">All statuses</option>{['IN_PROGRESS', 'RETURNED', 'AWAITING_DECISION', 'ON_HOLD', 'APPROVED', 'REJECTED', 'WITHDRAWN'].map((s) => <option key={s} value={s}>{label(s)}</option>)}</Select>
        <Select aria-label="Officer" value={f.officer_id || ''} onChange={(e) => set('officer_id', e.target.value)}>
          <option value="">All officers</option>{meta.data?.officers.filter((o) => !f.region_id || String(o.region_id) === f.region_id).slice(0, 150).map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</Select>
        <Select aria-label="Priority" value={f.priority || ''} onChange={(e) => set('priority', e.target.value)}>
          <option value="">Any priority</option>{['NORMAL', 'HIGH', 'URGENT'].map((p) => <option key={p}>{p}</option>)}</Select>
        <Input aria-label="Submitted from" type="date" value={f.date_from || ''} onChange={(e) => set('date_from', e.target.value)} />
        <Input aria-label="Submitted to" type="date" value={f.date_to || ''} onChange={(e) => set('date_to', e.target.value)} />
        <Select aria-label="Data" value={f.synthetic || ''} onChange={(e) => set('synthetic', e.target.value)}>
          <option value="">Incl. synthetic</option><option value="0">Exclude synthetic</option></Select>
        <Button variant="quiet" onClick={() => setF({})}>Clear filters</Button>
      </div>
      <ErrorBox error={q.error} />
      {q.isLoading && <Loading />}
      {d && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-rule bg-rule sm:grid-cols-3 lg:grid-cols-6">
            <Stat label="Total applications" value={d.kpis.total_applications.toLocaleString()} to="/applications" />
            <Stat label="In progress" value={d.kpis.in_progress.toLocaleString()} sub={`${d.kpis.completed.toLocaleString()} completed`} to="/applications?status=IN_PROGRESS" />
            <Stat label="Pending scrutiny" value={d.kpis.pending_scrutiny} to="/applications?stage=SCRUTINY" />
            <Stat label="Pending EVC" value={d.kpis.pending_evc} to="/evc" />
            <Stat label="Overdue obligations" value={d.kpis.overdue_obligations.toLocaleString()} tone="red" to="/ledger?view=overdue" />
            <Stat label="Due in 14 days" value={d.kpis.upcoming_deadlines_14d.toLocaleString()} tone="amber" to="/ledger?view=upcoming" />
            <Stat label="Pending institutional compliance" value={d.kpis.pending_institutional_compliance.toLocaleString()} to="/ledger?view=institution" />
            <Stat label="Documents expiring (90 days)" value={d.kpis.expiring_documents_90d} tone="amber" sub={`${d.kpis.expired_documents} already expired`} to="/documents?validity=EXPIRING" />
            <Stat label="Escalated cases" value={d.kpis.escalated_cases.toLocaleString()} tone="red" to="/escalations" />
            <Stat label="Approved" value={(d.status_breakdown.APPROVED || 0).toLocaleString()} tone="green" />
            <Stat label="Returned to institutions" value={d.status_breakdown.RETURNED || 0} to="/applications?status=RETURNED" />
            <Stat label="Bottleneck stage" value={d.bottleneck ? label(d.bottleneck.stage) : '—'} sub={d.bottleneck ? `${d.bottleneck.pending} pending` : ''} tone="amber" />
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <ChartBox title="Stage-wise pendency (live applications)">
              <BarChart data={d.stage_pendency} layout="vertical" margin={{ left: 30 }}>
                <CartesianGrid horizontal={false} stroke="#E4E9F0" /><XAxis type="number" tick={axis} /><YAxis type="category" dataKey="stage" tick={axis} width={90} />
                <Tooltip /><Bar dataKey="count" name="Applications" fill={BLUE} radius={[0, 3, 3, 0]} />
              </BarChart>
            </ChartBox>
            <ChartBox title="Applications by Region">
              <BarChart data={d.region_distribution}>
                <CartesianGrid vertical={false} stroke="#E4E9F0" /><XAxis dataKey="region" tick={axis} /><YAxis tick={axis} />
                <Tooltip /><Bar dataKey="count" name="Applications" fill={INK} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ChartBox>
            <ChartBox title="Deadlines due — next 8 weeks">
              <BarChart data={d.upcoming_by_week}>
                <CartesianGrid vertical={false} stroke="#E4E9F0" /><XAxis dataKey="week" tick={axis} /><YAxis tick={axis} />
                <Tooltip labelFormatter={(_, p: any) => p?.[0] ? `Week from ${p[0].payload.from}` : ''} /><Bar dataKey="count" name="Obligations due" fill={BLUE} />
              </BarChart>
            </ChartBox>
            <ChartBox title="Missed deadlines by week (last 8 weeks)">
              <LineChart data={d.overdue_trend}>
                <CartesianGrid vertical={false} stroke="#E4E9F0" /><XAxis dataKey="week" tick={axis} /><YAxis tick={axis} />
                <Tooltip /><Line type="monotone" dataKey="count" name="Deadlines missed" stroke={RED} strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ChartBox>
            <ChartBox title="Application ageing (live)">
              <BarChart data={d.ageing}>
                <CartesianGrid vertical={false} stroke="#E4E9F0" /><XAxis dataKey="bucket" tick={axis} unit=" d" /><YAxis tick={axis} />
                <Tooltip /><Bar dataKey="count" name="Applications">{d.ageing.map((a: any, i: number) => <Cell key={i} fill={i === 3 ? AMBER : BLUE} />)}</Bar>
              </BarChart>
            </ChartBox>
            <ChartBox title="Officer workload — open AICTE-side obligations">
              <BarChart data={d.officer_workload} layout="vertical" margin={{ left: 40 }}>
                <CartesianGrid horizontal={false} stroke="#E4E9F0" /><XAxis type="number" tick={axis} /><YAxis type="category" dataKey="officer" tick={{ ...axis, fontSize: 10 }} width={140} />
                <Tooltip /><Bar dataKey="open" name="Open items" fill={INK} />
              </BarChart>
            </ChartBox>
          </div>
          <div className="grid gap-4 lg:grid-cols-3">
            {[['EVC scheduling status', d.evc_status], ['Undertaking compliance', d.undertaking_status], ['Lease / document validity', d.document_validity]].map(([t, rows]: any) => (
              <ChartBox key={t} title={t} h={200}>
                <BarChart data={rows}>
                  <XAxis dataKey="status" tick={{ ...axis, fontSize: 9.5 }} interval={0} angle={-20} textAnchor="end" height={50} /><YAxis tick={axis} /><Tooltip />
                  <Bar dataKey="count" name="Count">{rows.map((r: any, i: number) => <Cell key={i} fill={STATUS_COLOR[r.status] || BLUE} />)}</Bar>
                </BarChart>
              </ChartBox>
            ))}
          </div>
          <p className="text-xs text-ink/55">Region codes: {meta.data?.regions.map((r) => `${r.code} = ${r.name}`).join(' · ')}. Synthetic demonstration data is included unless excluded above. {regionName(meta.data, null) && ''}</p>
        </div>
      )}
    </div>
  )
}
