import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Bar, BarChart, CartesianGrid, Legend, Tooltip, XAxis, YAxis } from 'recharts'
import { Button, DaysLeft, Empty, ErrorBox, Loading, Notice, PageHeader, Panel, Select, Status, Table, Tabs, fmtDate, fmtDateTime, useToast } from '../components/ui'
import { useMeta } from '../hooks/useMeta'
import { api, qs } from '../services/api'
import { useAuth } from '../services/auth'
import { ChartBox } from './Overview'

export function Forecast() {
  const meta = useMeta()
  const { can } = useAuth()
  const qc = useQueryClient()
  const toast = useToast()
  const [tab, setTab] = useState('risk')
  const [f, setF] = useState<Record<string, string>>({ level: 'HIGH' })
  const [page, setPage] = useState(1)
  const q = useQuery({ queryKey: ['forecast', f, page], queryFn: () => api(`/api/forecast${qs({ ...f, page })}`), enabled: tab === 'risk' })
  const cap = useQuery({ queryKey: ['capacity', f.region_id], queryFn: () => api(`/api/capacity${qs({ region_id: f.region_id })}`), enabled: tab === 'capacity' })
  const re = useMutation({ mutationFn: () => api('/api/forecast/recompute', { method: 'POST' }), onSuccess: (r: any) => { qc.invalidateQueries({ queryKey: ['forecast'] }); toast.ok(`Scored ${r.scored} open obligations from ${r.history_samples} historical completions.`) }, onError: toast.fail })
  const nudge = useMutation({ mutationFn: (id: number) => api(`/api/ledger/${id}/do/nudge`, { body: {} }), onSuccess: (r: any) => toast.ok(`Nudge queued: ${r.result.notifications_created} notification(s).`), onError: toast.fail })
  return (
    <div>
      <PageHeader title="Breach forecast" sub="Miss probability from empirical completion-time distributions of similar closed obligations (type, Region, institution tier), with explicit adjustments."
        actions={<Button variant="secondary" loading={re.isPending} onClick={() => re.mutate()}>Recalculate now</Button>} />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'risk', label: 'At-risk obligations' }, { id: 'capacity', label: 'Capacity — next 4 weeks' }]} />
      <div className="mb-3 flex flex-wrap gap-2">
        {tab === 'risk' && <Select aria-label="Risk level" className="max-w-[180px]" value={f.level || ''} onChange={(e) => { setF({ ...f, level: e.target.value }); setPage(1) }}>
          <option value="">All levels</option>{['HIGH', 'MEDIUM', 'LOW', 'INSUFFICIENT_DATA'].map((l) => <option key={l} value={l}>{l.replace('_', ' ').toLowerCase()}</option>)}</Select>}
        <Select aria-label="Region" className="max-w-[180px]" value={f.region_id || ''} onChange={(e) => setF({ ...f, region_id: e.target.value })}><option value="">All Regions</option>{meta.data?.regions.map((r) => <option key={r.id} value={r.id}>{r.code}</option>)}</Select>
        {tab === 'risk' && <Select aria-label="Type" className="max-w-[260px]" value={f.obligation_type || ''} onChange={(e) => setF({ ...f, obligation_type: e.target.value })}><option value="">All types</option>
          {Object.entries(meta.data?.obligation_types || {}).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select>}
        {q.data?.levels && tab === 'risk' && <span className="self-center text-xs text-ink/60">{Object.entries(q.data.levels).map(([k, v]) => `${k.toLowerCase()} ${v}`).join(' · ')}</span>}
      </div>
      {tab === 'risk' && <>
        <ErrorBox error={q.error} />
        {q.isLoading ? <Loading /> : q.data?.items.length ? (
          <div className="space-y-2">
            {q.data.items.map((o: any) => (
              <article key={o.id} className="grid gap-3 rounded-lg border border-rule bg-white p-3 md:grid-cols-[1fr_300px]">
                <div>
                  <Link className="font-medium text-ledger hover:underline" to={`/ledger/${o.id}`}>{o.title}</Link>
                  <div className="text-[12.5px] text-ink/65">{o.institution} · {o.type_label} · due {fmtDate(o.due_date)} · <DaysLeft days={o.days_remaining} state={o.state} /></div>
                  <ol className="mt-1.5 list-decimal pl-5 text-[12.5px]">{o.risk.reasons.map((r: any, i: number) => <li key={i}>{r.reason}</li>)}</ol>
                </div>
                <div className="flex flex-col items-start gap-1.5 md:items-end">
                  <div className="flex items-center gap-2"><Status value={o.risk.level} />{o.risk.probability != null && <span className="text-xl font-semibold tabular-nums">{Math.round(o.risk.probability * 100)}%</span>}</div>
                  <div className="text-[11.5px] text-ink/55">n={o.risk.sample_size} · {o.risk.segment}</div>
                  <div className="text-[11.5px] text-ink/55">Suggested early reminder {fmtDate(o.risk.suggested_reminder)} · scored {fmtDateTime(o.risk.computed_at)}</div>
                  {can('notification.nudge') && <Button size="sm" onClick={() => nudge.mutate(o.id)}>Nudge now</Button>}
                </div>
              </article>))}
            <div className="flex justify-between text-xs text-ink/60"><Button size="sm" variant="secondary" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</Button>
              <span>{q.data.total} scored · page {page}</span><Button size="sm" variant="secondary" disabled={page * 50 >= q.data.total} onClick={() => setPage(page + 1)}>Next</Button></div>
          </div>
        ) : <Empty>No scored obligations for this filter. Run “Recalculate now”.</Empty>}
      </>}
      {tab === 'capacity' && (cap.isLoading ? <Loading /> : cap.data && <div className="space-y-4">
        <ChartBox title="Projected AICTE-side due load per officer (top 12)" h={300}>
          <BarChart data={cap.data.officers.slice(0, 12).map((o: any) => ({ name: o.officer, w1: o.weeks[0], w2: o.weeks[1], w3: o.weeks[2], w4: o.weeks[3] }))}>
            <CartesianGrid vertical={false} stroke="#E4E9F0" /><XAxis dataKey="name" tick={{ fontSize: 9.5 }} interval={0} angle={-25} textAnchor="end" height={80} /><YAxis tick={{ fontSize: 11 }} /><Tooltip /><Legend />
            <Bar dataKey="w1" stackId="a" name="Week 1" fill="#14233C" /><Bar dataKey="w2" stackId="a" name="Week 2" fill="#1F5AA6" /><Bar dataKey="w3" stackId="a" name="Week 3" fill="#6E98CF" /><Bar dataKey="w4" stackId="a" name="Week 4" fill="#B9CDE8" />
          </BarChart>
        </ChartBox>
        <Panel title="Suggested reassignments">
          <Notice tone="amber">Suggestions only. Statutory responsibilities are never reassigned automatically; an authorised officer reassigns individual items from the ledger.</Notice>
          {cap.data.suggestions.length ? <Table head={['From', 'To', 'Items', 'Reason']}>{cap.data.suggestions.map((s: any, i: number) => <tr key={i}><td>{s.from_officer}</td><td>{s.to_officer}</td><td>{s.items}</td><td className="text-xs">{s.reason}</td></tr>)}</Table>
            : <p className="mt-2 text-sm text-ink/65">Load is balanced within each Region (median {cap.data.median_4w_load} items in 4 weeks).</p>}
        </Panel>
        <Panel title="EVC committee members — visits in the next 4 weeks" pad={false}>
          {cap.data.committees.length ? <Table head={['Expert', 'Monthly cap', 'W1', 'W2', 'W3', 'W4']}>{cap.data.committees.map((c: any) => <tr key={c.expert_id}><td>{c.name}</td><td>{c.cap}</td>{c.weeks.map((w: number, i: number) => <td key={i}>{w}</td>)}</tr>)}</Table> : <div className="p-4"><Empty /></div>}
        </Panel>
      </div>)}
      {toast.node}
    </div>
  )
}
