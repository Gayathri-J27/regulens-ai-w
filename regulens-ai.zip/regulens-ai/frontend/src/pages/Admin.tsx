import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Badge, Button, Dialog, Empty, ErrorBox, Field, Input, Loading, Notice, PageHeader, Pager, Panel, Select, Status, Table, Tabs, Textarea,
  fmtDate, fmtDateTime, label, useToast } from '../components/ui'
import { useMeta } from '../hooks/useMeta'
import { api, qs } from '../services/api'
import { useAuth } from '../services/auth'

export function Admin() {
  const { can } = useAuth()
  const tabs = [
    { id: 'rules', label: 'Rules and configuration', show: can('rule.view') },
    { id: 'routes', label: 'Route templates', show: can('rule.view') },
    { id: 'calendars', label: 'Holiday calendars', show: true },
    { id: 'org', label: 'Posts and delegations', show: can('rule.view') },
    { id: 'users', label: 'Users', show: can('user.manage') },
    { id: 'roles', label: 'Roles and permissions', show: can('rule.view') },
    { id: 'templates', label: 'Notification templates', show: can('rule.view') },
    { id: 'imports', label: 'Integration and imports', show: can('import.run') },
    { id: 'data', label: 'Synthetic data and benchmark', show: can('benchmark.run') },
  ].filter((t) => t.show)
  const [tab, setTab] = useState(tabs[0]?.id || 'calendars')
  return (
    <div>
      <PageHeader title="Administration" sub="Configuration is versioned: draft → impact preview → second-person approval → effective date. Live cases keep the configuration version they started with." />
      <Tabs value={tab} onChange={setTab} tabs={tabs} />
      {tab === 'rules' && <Rules />}{tab === 'routes' && <Routes />}{tab === 'calendars' && <Calendars />}{tab === 'org' && <Org />}
      {tab === 'users' && <Users />}{tab === 'roles' && <Roles />}{tab === 'templates' && <Templates />}{tab === 'imports' && <Imports />}{tab === 'data' && <DataTab />}
    </div>
  )
}

function Rules() {
  const { can, me } = useAuth()
  const qc = useQueryClient()
  const toast = useToast()
  const q = useQuery({ queryKey: ['rules-all'], queryFn: () => api('/api/admin/rules') })
  const cv = useQuery({ queryKey: ['config-versions'], queryFn: () => api('/api/admin/config-versions') })
  const [edit, setEdit] = useState<any>(null)
  const done = (m: string) => { qc.invalidateQueries({ queryKey: ['rules-all'] }); qc.invalidateQueries({ queryKey: ['config-versions'] }); toast.ok(m) }
  const save = useMutation({ mutationFn: (b: any) => api('/api/admin/rules', { body: b }), onSuccess: () => { setEdit(null); done('Draft created. Run an impact preview next.') }, onError: toast.fail })
  const prev = useMutation({ mutationFn: (id: number) => api(`/api/admin/rules/${id}/preview`, { method: 'POST' }), onSuccess: () => done('Impact preview recorded.'), onError: toast.fail })
  const appr = useMutation({ mutationFn: (id: number) => api(`/api/admin/rules/${id}/approve`, { body: { note: 'approved' } }), onSuccess: () => done('Approved.'), onError: toast.fail })
  const act = useMutation({ mutationFn: ({ id, active }: any) => api(`/api/admin/rules/${id}/active`, { body: { active, reason: 'administrator action' } }), onSuccess: () => done('Updated.'), onError: toast.fail })
  if (q.isLoading) return <Loading />
  const keys = [...new Set(q.data.map((r: any) => r.rule_key))] as string[]
  return (
    <div className="space-y-3">
      <Notice>All values are <b>configurable parameters</b>: their APH clause and page have not been verified in this prototype, so none is labelled handbook-confirmed. A rule can be marked HANDBOOK_CONFIRMED only with edition, section and page.</Notice>
      <Panel pad={false}>
        <Table head={['Rule', 'Version', 'Parameters', 'Source', 'Effective', 'Status', '']}>
          {keys.map((k) => q.data.filter((r: any) => r.rule_key === k).map((r: any, i: number) => (
            <tr key={r.id} className={i ? 'bg-mist/40 text-ink/70' : ''}>
              <td>{i === 0 ? <><b>{k}</b><div className="text-xs text-ink/60">{r.name}</div></> : ''}</td><td>v{r.version}</td>
              <td className="max-w-[340px] font-mono text-[11px]">{JSON.stringify(r.params)}</td><td className="text-xs">{label(r.source_type)}{r.citation && <div className="text-ink/55">{r.citation}</div>}</td>
              <td className="text-xs">{fmtDate(r.effective_from)}{r.effective_to && ` → ${fmtDate(r.effective_to)}`}</td>
              <td><Status value={r.status} />{r.impact_preview && <div className="text-[11px] text-ink/55">preview: {r.impact_preview.obligations_affected ?? 0} affected</div>}</td>
              <td className="whitespace-nowrap">
                {i === 0 && can('rule.edit') && <Button size="sm" variant="ghost" onClick={() => setEdit({ ...r, params: JSON.stringify(r.params, null, 2), effective_from: '' })}>New version</Button>}
                {['DRAFT'].includes(r.status) && can('rule.edit') && <Button size="sm" variant="secondary" onClick={() => prev.mutate(r.id)}>Preview impact</Button>}
                {r.status === 'PREVIEWED' && can('rule.approve') && <Button size="sm" disabled={r.created_by === me?.id} title={r.created_by === me?.id ? 'A second person must approve' : ''} onClick={() => appr.mutate(r.id)}>Approve</Button>}
                {r.status === 'EFFECTIVE' && can('rule.approve') && i === 0 && <Button size="sm" variant="quiet" onClick={() => act.mutate({ id: r.id, active: false })}>Deactivate</Button>}
                {r.status === 'RETIRED' && can('rule.approve') && <Button size="sm" variant="quiet" onClick={() => act.mutate({ id: r.id, active: true })}>Reactivate</Button>}
              </td></tr>)))}
        </Table>
      </Panel>
      <Panel title="Configuration versions" pad={false}>
        <Table head={['Version', 'Created', 'Reason', 'Rules']} dense>{cv.data?.slice(0, 10).map((c: any) => <tr key={c.id}><td>v{c.id}</td><td>{fmtDateTime(c.created_at)}</td><td>{c.reason}</td><td>{c.rules}</td></tr>)}</Table>
      </Panel>
      <Dialog open={!!edit} onClose={() => setEdit(null)} title={`New version of ${edit?.rule_key}`} wide>
        {edit && <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Parameters (JSON)" className="sm:col-span-2"><textarea className="h-36 w-full rounded-md border border-rule p-2 font-mono text-[12px]" value={edit.params} onChange={(e) => setEdit({ ...edit, params: e.target.value })} /></Field>
          <Field label="Effective from" hint="Empty = today once approved"><Input type="date" value={edit.effective_from} onChange={(e) => setEdit({ ...edit, effective_from: e.target.value })} /></Field>
          <Field label="Source type"><Select value={edit.source_type} onChange={(e) => setEdit({ ...edit, source_type: e.target.value })}><option value="CONFIGURABLE_PARAMETER">Configurable parameter</option><option value="HANDBOOK_CONFIRMED">Handbook confirmed (verified)</option></Select></Field>
          {edit.source_type === 'HANDBOOK_CONFIRMED' && <>
            <Field label="APH edition"><Input value={edit.aph_edition || ''} onChange={(e) => setEdit({ ...edit, aph_edition: e.target.value })} /></Field>
            <Field label="Section"><Input value={edit.section || ''} onChange={(e) => setEdit({ ...edit, section: e.target.value })} /></Field>
            <Field label="Page"><Input value={edit.page || ''} onChange={(e) => setEdit({ ...edit, page: e.target.value })} /></Field></>}
          <Field label="Citation / note" className="sm:col-span-2"><Textarea value={edit.citation || ''} onChange={(e) => setEdit({ ...edit, citation: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Button onClick={() => { let p; try { p = JSON.parse(edit.params) } catch { return toast.fail('Parameters must be valid JSON') }
            save.mutate({ rule_key: edit.rule_key, params: p, effective_from: edit.effective_from || null, source_type: edit.source_type, aph_edition: edit.aph_edition, section: edit.section, page: edit.page, citation: edit.citation }) }}>Save draft</Button></div>
        </div>}
      </Dialog>
      {toast.node}
    </div>
  )
}

function Routes() {
  const q = useQuery({ queryKey: ['routes'], queryFn: () => api('/api/admin/routes') })
  const qc = useQueryClient()
  const toast = useToast()
  const [edit, setEdit] = useState<any>(null)
  const pub = useMutation({ mutationFn: (b: any) => api('/api/admin/routes', { body: b }), onSuccess: (r: any) => { setEdit(null); qc.invalidateQueries({ queryKey: ['routes'] }); toast.ok(`Published v${r.version}. Existing applications keep their version.`) }, onError: toast.fail })
  if (q.isLoading) return <Loading />
  return (
    <Panel pad={false}>
      <Table head={['Route', 'Version', 'Stages', 'Revert policy', 'Active', '']}>
        {q.data.map((r: any) => <tr key={r.id}><td><b>{r.name}</b><div className="text-xs text-ink/55">{r.code}</div></td><td>v{r.version}</td>
          <td className="text-xs">{r.definition.stages.map((s: any) => `${s.code}(${s.budget_days})`).join(' → ')}</td><td>{r.definition.revert_policy}</td><td>{r.is_active ? 'yes' : 'no'}</td>
          <td>{r.is_active && <Button size="sm" variant="ghost" onClick={() => setEdit({ code: r.code, name: r.name, definition: JSON.stringify(r.definition, null, 2) })}>New version</Button>}</td></tr>)}
      </Table>
      <Dialog open={!!edit} onClose={() => setEdit(null)} title={`New version of ${edit?.code}`} wide>
        {edit && <div className="space-y-3"><Field label="State-machine definition (JSON)"><textarea className="h-96 w-full rounded-md border border-rule p-2 font-mono text-[11.5px]" value={edit.definition} onChange={(e) => setEdit({ ...edit, definition: e.target.value })} /></Field>
          <p className="text-xs text-ink/60">Validated on save: unique stage codes, a human decision stage, known resubmit/revert targets and a valid revert policy.</p>
          <Button onClick={() => { try { pub.mutate({ code: edit.code, name: edit.name, definition: JSON.parse(edit.definition) }) } catch { toast.fail('Invalid JSON') } }}>Publish version</Button></div>}
      </Dialog>
      {toast.node}
    </Panel>
  )
}

function Calendars() {
  const { can } = useAuth()
  const q = useQuery({ queryKey: ['calendars'], queryFn: () => api('/api/admin/calendars') })
  const qc = useQueryClient()
  const toast = useToast()
  const [sel, setSel] = useState<number | null>(null)
  const [h, setH] = useState({ day: '', name: '', reason: '' })
  const add = useMutation({ mutationFn: () => api(`/api/admin/calendars/${sel}/holidays`, { body: h }),
    onSuccess: (r: any) => { qc.invalidateQueries({ queryKey: ['calendars'] }); setH({ day: '', name: '', reason: '' }); toast.ok(`Holiday added. ${r.clocks_checked} clocks recomputed; ${r.due_dates_changed} due dates moved.`) }, onError: toast.fail })
  const del = useMutation({ mutationFn: (hid: number) => api(`/api/admin/calendars/${sel}/holidays/${hid}`, { method: 'DELETE' }),
    onSuccess: (r: any) => { qc.invalidateQueries({ queryKey: ['calendars'] }); toast.ok(`Removed. ${r.due_dates_changed} due dates moved.`) }, onError: toast.fail })
  if (q.isLoading) return <Loading />
  const cal = q.data.find((c: any) => c.id === sel)
  return (
    <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
      <Panel title="Calendars" pad={false}><ul className="divide-y divide-rule text-[13px]">{q.data.map((c: any) => <li key={c.id}>
        <button className={`w-full px-3 py-2 text-left hover:bg-mist ${sel === c.id ? 'bg-ledger-50' : ''}`} onClick={() => setSel(c.id)}><b>{c.name}</b><div className="text-xs text-ink/55">{label(c.scope)} · v{c.version} · {c.holidays.length} holidays</div></button></li>)}</ul></Panel>
      {cal ? <Panel title={cal.name}>
        <Notice tone="amber">Illustrative dates for the prototype — replace with the official AICTE / State gazette lists. Changing a calendar recomputes every running clock that uses it.</Notice>
        {can('calendar.edit') && <div className="my-3 flex flex-wrap items-end gap-2">
          <Field label="Date"><Input type="date" value={h.day} onChange={(e) => setH({ ...h, day: e.target.value })} /></Field>
          <Field label="Name"><Input value={h.name} onChange={(e) => setH({ ...h, name: e.target.value })} /></Field>
          <Field label="Reason"><Input value={h.reason} onChange={(e) => setH({ ...h, reason: e.target.value })} /></Field>
          <Button disabled={!h.day || !h.name} onClick={() => add.mutate()}>Add holiday</Button></div>}
        <Table head={['Date', 'Holiday', '']} dense>{cal.holidays.map((x: any) => <tr key={x.id}><td>{fmtDate(x.day)}</td><td>{x.name}</td><td>{can('calendar.edit') && <Button size="sm" variant="quiet" onClick={() => del.mutate(x.id)}>Remove</Button>}</td></tr>)}</Table>
      </Panel> : <Empty>Select a calendar.</Empty>}
      {toast.node}
    </div>
  )
}

function Org() {
  const meta = useMeta()
  const { can } = useAuth()
  const qc = useQueryClient()
  const toast = useToast()
  const [reg, setReg] = useState('')
  const q = useQuery({ queryKey: ['posts', reg], queryFn: () => api(`/api/admin/posts${qs({ region_id: reg })}`) })
  const [res, setRes] = useState<any>(null)
  const [d, setD] = useState<any>(null)
  const resolve = useMutation({ mutationFn: (pid: number) => api(`/api/admin/resolve-escalation/${pid}`), onSuccess: setRes })
  const del = useMutation({ mutationFn: () => api('/api/admin/delegations', { body: { ...d, post_id: Number(d.post_id), delegate_user_id: Number(d.delegate_user_id) } }),
    onSuccess: () => { setD(null); qc.invalidateQueries({ queryKey: ['posts'] }); toast.ok('Delegation recorded.') }, onError: toast.fail })
  const vac = useMutation({ mutationFn: (pid: number) => api(`/api/admin/posts/${pid}/vacate`, { body: { reason: 'transfer/vacancy (demo)' } }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['posts'] }); toast.ok('Post vacated; escalations will fall back.') }, onError: toast.fail })
  return (
    <div className="space-y-3">
      <div className="flex gap-2"><Select className="max-w-[240px]" value={reg} onChange={(e) => setReg(e.target.value)}><option value="">All Regions + HQ</option>{meta.data?.regions.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</Select></div>
      {res && <Notice>Escalation to this post today resolves to <b>{res.recipient || 'nobody — administrator alert'}</b> via {res.via}: {res.path.map((p: any) => `${p.post ?? ''} ${p.result}`).join(' → ')}</Notice>}
      <Panel pad={false}>{q.isLoading ? <Loading /> : <Table head={['Post', 'Level', 'Holder', 'Delegations', '']}>
        {q.data.map((p: any) => <tr key={p.id}><td><b>{p.code}</b><div className="text-xs text-ink/55">{p.title}</div></td><td>{p.level}</td><td>{p.vacant ? <Badge tone="amber">vacant</Badge> : p.holder}</td>
          <td className="text-xs">{p.delegations.map((x: any) => <div key={x.id}>{x.starts_on} → {x.ends_on} {x.active_now && <Badge tone="blue">active</Badge>} {x.reason}</div>)}</td>
          <td className="whitespace-nowrap"><Button size="sm" variant="ghost" onClick={() => resolve.mutate(p.id)}>Who receives escalations?</Button>
            {can('delegation.manage') && <Button size="sm" variant="quiet" onClick={() => setD({ post_id: p.id, delegate_user_id: '', starts_on: '', ends_on: '', reason: 'Leave' })}>Delegate</Button>}
            {can('post.manage') && !p.vacant && <Button size="sm" variant="quiet" onClick={() => vac.mutate(p.id)}>Vacate</Button>}</td></tr>)}
      </Table>}</Panel>
      <Dialog open={!!d} onClose={() => setD(null)} title="Leave delegation">
        {d && <div className="space-y-3">
          <Field label="Delegate"><Select value={d.delegate_user_id} onChange={(e) => setD({ ...d, delegate_user_id: e.target.value })}><option value="">Select…</option>{meta.data?.officers.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</Select></Field>
          <div className="grid grid-cols-2 gap-2"><Field label="From"><Input type="date" value={d.starts_on} onChange={(e) => setD({ ...d, starts_on: e.target.value })} /></Field>
            <Field label="To"><Input type="date" value={d.ends_on} onChange={(e) => setD({ ...d, ends_on: e.target.value })} /></Field></div>
          <Field label="Reason"><Input value={d.reason} onChange={(e) => setD({ ...d, reason: e.target.value })} /></Field>
          <Button onClick={() => del.mutate()}>Save delegation</Button></div>}
      </Dialog>
      {toast.node}
    </div>
  )
}

function Users() {
  const [qq, setQq] = useState('')
  const [page, setPage] = useState(1)
  const [syn, setSyn] = useState('0')
  const qc = useQueryClient()
  const toast = useToast()
  const meta = useMeta()
  const q = useQuery({ queryKey: ['users', qq, page, syn], queryFn: () => api(`/api/admin/users${qs({ q: qq, page, page_size: 25, synthetic: syn })}`) })
  const [n, setN] = useState<any>(null)
  const patch = useMutation({ mutationFn: ({ id, body }: any) => api(`/api/admin/users/${id}`, { method: 'PATCH', body }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['users'] }); toast.ok('Saved.') }, onError: toast.fail })
  const create = useMutation({ mutationFn: () => api('/api/admin/users', { body: { ...n, region_id: n.region_id ? Number(n.region_id) : null, institution_id: n.institution_id ? Number(n.institution_id) : null } }),
    onSuccess: () => { setN(null); qc.invalidateQueries({ queryKey: ['users'] }); toast.ok('User created.') }, onError: toast.fail })
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2"><Input className="max-w-xs" placeholder="Search" value={qq} onChange={(e) => setQq(e.target.value)} />
        <Select className="max-w-[200px]" value={syn} onChange={(e) => setSyn(e.target.value)}><option value="0">Demo / real accounts</option><option value="">Include synthetic officers</option></Select>
        <Button onClick={() => setN({ role: 'REGIONAL_OFFICER', email: '', full_name: '', password: '' })}>Add user</Button></div>
      <Panel pad={false}>{q.isLoading ? <Loading /> : <><Table head={['Name', 'Email', 'Role', 'Region', 'MFA', 'State', '']}>
        {q.data.items.map((u: any) => <tr key={u.id}><td>{u.full_name}</td><td className="text-xs">{u.email}</td><td>{label(u.role)}</td><td>{meta.data?.regions.find((r) => r.id === u.region_id)?.code || '—'}</td>
          <td>{u.totp_enabled ? 'TOTP' : '—'}</td><td>{u.is_active ? (u.locked ? <Badge tone="red">locked</Badge> : 'active') : <Badge>disabled</Badge>}</td>
          <td className="whitespace-nowrap">{u.locked && <Button size="sm" variant="ghost" onClick={() => patch.mutate({ id: u.id, body: { unlock: true } })}>Unlock</Button>}
            <Button size="sm" variant="quiet" onClick={() => patch.mutate({ id: u.id, body: { is_active: !u.is_active } })}>{u.is_active ? 'Disable' : 'Enable'}</Button></td></tr>)}
      </Table><Pager page={page} pages={q.data.pages} total={q.data.total} onPage={setPage} /></>}</Panel>
      <Dialog open={!!n} onClose={() => setN(null)} title="Add user">
        {n && <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Name"><Input value={n.full_name} onChange={(e) => setN({ ...n, full_name: e.target.value })} /></Field>
          <Field label="Email"><Input value={n.email} onChange={(e) => setN({ ...n, email: e.target.value })} /></Field>
          <Field label="Role"><Select value={n.role} onChange={(e) => setN({ ...n, role: e.target.value })}>{['SUPER_ADMIN', 'AICTE_ADMIN', 'REGIONAL_OFFICER', 'BUREAU_OFFICER', 'COMMITTEE_MEMBER', 'COMPETENT_AUTHORITY', 'INSTITUTION_PRINCIPAL', 'INSTITUTION_COMPLIANCE', 'AUDIT_OFFICER'].map((r) => <option key={r} value={r}>{label(r)}</option>)}</Select></Field>
          <Field label="Region"><Select value={n.region_id || ''} onChange={(e) => setN({ ...n, region_id: e.target.value })}><option value="">National</option>{meta.data?.regions.map((r) => <option key={r.id} value={r.id}>{r.code}</option>)}</Select></Field>
          {n.role.startsWith('INSTITUTION') && <Field label="Institution ID"><Input value={n.institution_id || ''} onChange={(e) => setN({ ...n, institution_id: e.target.value })} /></Field>}
          <Field label="Initial password"><Input type="password" value={n.password} onChange={(e) => setN({ ...n, password: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Button onClick={() => create.mutate()}>Create user</Button></div></div>}
      </Dialog>
      {toast.node}
    </div>
  )
}

function Roles() {
  const q = useQuery({ queryKey: ['roles'], queryFn: () => api('/api/admin/roles') })
  if (q.isLoading) return <Loading />
  const roles = Object.keys(q.data.roles)
  return (
    <Panel title="Permission matrix (enforced by the API on every request)" pad={false}>
      <div className="overflow-x-auto"><table className="text-[11.5px]"><thead><tr className="bg-mist"><th className="p-1.5 text-left">Permission</th>{roles.map((r) => <th key={r} className="p-1.5 font-medium">{q.data.roles[r].split(' ')[0]}<br />{q.data.roles[r].split(' ').slice(1).join(' ')}</th>)}</tr></thead>
        <tbody>{Object.entries(q.data.matrix).map(([p, rs]: any) => <tr key={p} className="border-t border-rule"><td className="p-1.5 font-mono">{p}</td>{roles.map((r) => <td key={r} className="p-1.5 text-center">{rs.includes(r) ? <span aria-label="allowed" className="text-ok">●</span> : <span aria-label="denied" className="text-ink/20">·</span>}</td>)}</tr>)}</tbody></table></div>
    </Panel>
  )
}

function Templates() {
  const { can } = useAuth()
  const q = useQuery({ queryKey: ['templates'], queryFn: () => api('/api/admin/templates') })
  const qc = useQueryClient()
  const toast = useToast()
  const [e, setE] = useState<any>(null)
  const save = useMutation({ mutationFn: () => api('/api/admin/templates', { body: e }), onSuccess: (r: any) => { setE(null); qc.invalidateQueries({ queryKey: ['templates'] }); toast.ok(`Saved as v${r.version}.`) }, onError: toast.fail })
  const [key, setKey] = useState('deadline_upcoming')
  if (q.isLoading) return <Loading />
  const keys = [...new Set(q.data.map((t: any) => t.key))] as string[]
  return (
    <div className="space-y-3">
      <Notice tone="amber">Translations are stored versioned and never machine-translated at send time. Hindi, Marathi and Tamil texts are drafts flagged for native-speaker review.</Notice>
      <Select className="max-w-xs" value={key} onChange={(x) => setKey(x.target.value)}>{keys.map((k) => <option key={k}>{k}</option>)}</Select>
      <div className="grid gap-3 md:grid-cols-2">{q.data.filter((t: any) => t.key === key && t.is_active).map((t: any) => <Panel key={t.id} title={`${t.language} · v${t.version}`} actions={can('template.edit') && <Button size="sm" variant="ghost" onClick={() => setE({ key: t.key, language: t.language, subject: t.subject, body: t.body, translation_source: 'HUMAN_AUTHORED' })}>Edit</Button>}>
        <p className="font-medium">{t.subject}</p><p className="mt-1 text-[13px]">{t.body}</p><p className="mt-2 text-[11px] text-ink/55">{label(t.translation_source)}</p></Panel>)}</div>
      <Dialog open={!!e} onClose={() => setE(null)} title={`Edit ${e?.key} (${e?.language})`}>
        {e && <div className="space-y-3"><Field label="Subject"><Input value={e.subject} onChange={(x) => setE({ ...e, subject: x.target.value })} /></Field>
          <Field label="Body" hint="Placeholders like {title}, {due}, {obl_no} are filled when sending."><Textarea rows={5} value={e.body} onChange={(x) => setE({ ...e, body: x.target.value })} /></Field>
          <Field label="Translation source"><Select value={e.translation_source} onChange={(x) => setE({ ...e, translation_source: x.target.value })}><option value="HUMAN_AUTHORED">Human authored / reviewed</option><option value="DRAFT_REQUIRES_HUMAN_REVIEW">Draft — needs review</option></Select></Field>
          <Button onClick={() => save.mutate()}>Save new version</Button></div>}
      </Dialog>
      {toast.node}
    </div>
  )
}

function Imports() {
  const qc = useQueryClient()
  const toast = useToast()
  const [entity, setEntity] = useState('undertaking')
  const [file, setFile] = useState<File | null>(null)
  const hist = useQuery({ queryKey: ['imports'], queryFn: () => api('/api/admin/imports') })
  const [res, setRes] = useState<any>(null)
  const up = useMutation({ mutationFn: () => { const fd = new FormData(); fd.append('entity', entity); fd.append('file', file!); return api('/api/admin/imports/csv', { form: fd }) },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['imports'] }), onError: toast.fail })
  const commit = useMutation({ mutationFn: ({ id, dry }: any) => api(`/api/admin/imports/${id}/commit`, { body: { dry_run: dry } }),
    onSuccess: (r) => { setRes(r); qc.invalidateQueries({ queryKey: ['imports'] }) }, onError: toast.fail })
  return (
    <div className="space-y-4">
      <Notice>ReguLens is integration-ready but <b>not connected to AICTE production systems</b>. The CSV adapter and the synthetic adapter are functional; the API adapter is a documented, testable stub (<button className="text-ledger underline" onClick={() => import('../services/api').then((m) => m.download('/api/admin/integration/openapi.json', 'regulens-import-openapi.json'))}>download the OpenAPI contract</button>). The AICTE portal remains authoritative for statutory decisions.</Notice>
      <Panel title="CSV import — preview, validate, stage">
        <div className="flex flex-wrap items-end gap-2">
          <Field label="Entity"><Select value={entity} onChange={(e) => setEntity(e.target.value)}>{['institution', 'application', 'undertaking', 'document', 'evc_visit'].map((x) => <option key={x}>{x}</option>)}</Select></Field>
          <Field label="CSV file"><Input type="file" accept=".csv" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
          <Button disabled={!file} onClick={() => up.mutate()}>Validate and stage</Button>
          <a className="text-sm text-ledger hover:underline" href={`/api/admin/imports/template/${entity}`} onClick={async (ev) => { ev.preventDefault(); const { download } = await import('../services/api'); download(`/api/admin/imports/template/${entity}`, `${entity}-template.csv`) }}>Download template</a>
        </div>
      </Panel>
      {res && <Notice tone="green">{res.dry_run ? 'Cutover simulation (rolled back)' : 'Committed'}: {res.created} record(s). {res.clock_reconstruction?.length ? `Reconstructed clocks: ${res.clock_reconstruction.slice(0, 5).map((c: any) => `${c.title} → ${c.reconstructed_due} (${c.state})`).join('; ')}` : ''}</Notice>}
      <Panel title="Import history" pad={false}>
        {hist.data?.length ? <Table head={['Batch', 'Adapter', 'Entity', 'File', 'Valid / errors / duplicates', 'Status', '']}>
          {hist.data.map((b: any) => <tr key={b.id}><td>#{b.id}</td><td>{b.adapter}</td><td>{b.entity}</td><td className="text-xs">{b.filename}</td>
            <td>{b.counts.valid} / {b.counts.errors} / {b.counts.duplicates}{(b.errors.length > 0 || b.duplicates.length > 0) && <details className="text-xs"><summary className="cursor-pointer text-ledger">report</summary>
              {b.errors.map((e: any, i: number) => <div key={i} className="text-late">row {e.row}: {e.error}</div>)}{b.duplicates.map((e: any, i: number) => <div key={i} className="text-warn">row {e.row}: {e.reason}</div>)}</details>}</td>
            <td><Status value={b.status} /></td>
            <td className="whitespace-nowrap">{b.status === 'STAGED' && <><Button size="sm" variant="secondary" onClick={() => commit.mutate({ id: b.id, dry: true })}>Simulate cutover</Button> <Button size="sm" onClick={() => commit.mutate({ id: b.id, dry: false })}>Commit</Button></>}</td></tr>)}
        </Table> : <div className="p-4"><Empty>No imports yet.</Empty></div>}
      </Panel>
      {toast.node}
    </div>
  )
}

function DataTab() {
  const { can } = useAuth()
  const toast = useToast()
  const st = useQuery({ queryKey: ['synthetic-status'], queryFn: () => api('/api/admin/synthetic/status'), enabled: can('synthetic.manage') })
  const runs = useQuery({ queryKey: ['bench-runs'], queryFn: () => api('/api/admin/benchmark/runs') })
  const [confirm, setConfirm] = useState('')
  const regen = useMutation({ mutationFn: () => api('/api/admin/synthetic/regenerate', { body: { confirm } }), onSuccess: () => { st.refetch(); toast.ok('Synthetic data regenerated.') }, onError: toast.fail })
  const bench = useMutation({ mutationFn: () => api('/api/admin/benchmark/run', { method: 'POST' }), onSuccess: () => runs.refetch(), onError: toast.fail })
  const last = bench.data || runs.data?.[0]?.scorecard
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {can('synthetic.manage') && <Panel title="Synthetic data (fixed seed)">
        {st.data && <ul className="text-sm">{Object.entries(st.data).filter(([k]) => k !== 'planted').map(([k, v]: any) => <li key={k}>{label(k)}: <b>{v.toLocaleString()}</b></li>)}
          <li className="mt-1">Planted faults: {Object.entries(st.data.planted).map(([k, v]: any) => `${label(k)} ${v}`).join(' · ')}</li></ul>}
        <p className="mt-3 text-xs text-ink/60">Regeneration removes only bulk synthetic records (SYN-* institutions, synthetic officers and experts) and rebuilds them from seed 20261030. Real and demo records are kept.</p>
        <div className="mt-2 flex gap-2"><Input placeholder="Type: REGENERATE SYNTHETIC DATA" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          <Button variant="danger" disabled={confirm !== 'REGENERATE SYNTHETIC DATA'} loading={regen.isPending} onClick={() => regen.mutate()}>Regenerate</Button></div>
      </Panel>}
      <Panel title="Benchmark" actions={<Button loading={bench.isPending} onClick={() => bench.mutate()}>Run benchmark</Button>}>
        {bench.isPending && <Loading label="Running the six criteria, crash recovery and permission probes…" />}
        {last ? <div className="space-y-1 text-[13px]">
          <p className="text-xs text-ink/60">Run {fmtDateTime(last.ran_at)} · {last.duration_s} s · {last.environment}</p>
          <p>Workflow accuracy: route rule {Math.round(last.workflow_accuracy.route_assignment_accuracy * 100)}%, misroute recall {Math.round(last.workflow_accuracy.misroute_recall * 100)}% of {last.workflow_accuracy.planted_misroutes} planted</p>
          <p>Alert timeliness: p50 {last.alert_timeliness.p50_due_to_delivered_s}s, p95 {last.alert_timeliness.p95_due_to_delivered_s}s ({last.alert_timeliness.delivered} delivered)</p>
          <p>Deadline reliability: engine agreement {Math.round(last.deadline_reliability.engine_vs_reference_agreement * 100)}% of {last.deadline_reliability.clocks_sampled} clocks; missed alerts {last.deadline_reliability.missed_per_100k}/100k</p>
          <p>Crash recovery: {last.scheduler_crash_recovery.crashed_mid_run} crashed, {last.scheduler_crash_recovery.missed_after_recovery} missed, {last.scheduler_crash_recovery.duplicate_notifications} duplicates</p>
          <p>Visibility: top-10 in {last.pending_case_visibility.top10_query_ms} ms; planted late flagged {Math.round(last.pending_case_visibility.planted_late_flagged_overdue * 100)}%</p>
          <p>Audit: coverage {Math.round(last.audit_completeness.obligation_audit_coverage * 100)}%, chain ok {String(last.audit_completeness.chain_ok)}, tamper detected {String(last.audit_completeness.tamper_detected)}</p>
          <p>Permissions: {last.permission_matrix.probes} probes, {last.permission_matrix.unauthorised_data_leaks} leaks</p>
          <div className="pt-1">{Object.entries(last.targets).map(([k, v]: any) => <Badge key={k} tone={v ? 'green' : 'red'}>{v ? '✓' : '✕'} {label(k)}</Badge>)}</div>
        </div> : <Empty>No benchmark run yet.</Empty>}
      </Panel>
      {toast.node}
    </div>
  )
}
