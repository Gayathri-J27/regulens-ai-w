import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import '../services/i18n'
import { AuthProvider } from '../services/auth'
import { Login } from './Login'

function setup() {
  globalThis.fetch = vi.fn(async (url: any) => {
    if (String(url).includes('demo-accounts')) return new Response(JSON.stringify([{ email: 'ro.south@regulens.demo', name: 'Karthik', role: 'REGIONAL_OFFICER', role_label: 'Regional Officer' }]), { headers: { 'content-type': 'application/json' } })
    if (String(url).includes('/api/auth/login')) return new Response(JSON.stringify({ detail: 'Invalid email or password.' }), { status: 401, headers: { 'content-type': 'application/json' } })
    return new Response('{}', { status: 401, headers: { 'content-type': 'application/json' } })
  }) as any
  render(<QueryClientProvider client={new QueryClient()}><AuthProvider><MemoryRouter><Login /></MemoryRouter></AuthProvider></QueryClientProvider>)
}

describe('Login', () => {
  it('validates input before calling the API', async () => {
    setup()
    await userEvent.click(await screen.findByRole('button', { name: 'Sign in' }))
    expect(await screen.findByText('Enter a valid email address')).toBeInTheDocument()
  })
  it('fills demo credentials and shows the server error message', async () => {
    setup()
    await userEvent.click(await screen.findByText('Karthik'))
    await userEvent.click(screen.getByRole('button', { name: 'Sign in' }))
    expect(await screen.findByRole('alert')).toHaveTextContent('Invalid email or password.')
  })
})
