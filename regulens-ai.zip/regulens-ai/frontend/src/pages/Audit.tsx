import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Badge, Button, Dialog, Empty, ErrorBox, Input, Loading, Notice, PageHeader, Pager, Panel, Table, fmtDate, fmtDateTime, label, useToast } from '../components/ui'
import { api, qs } from '../services/api'
import { useAuth } from '../services/auth'

export function Audit() {
  const { can } = useAuth()
  const qc = useQueryClient()
  const toast = useToast()
  const [f, setF] = useState<Record<string, string>>({})
  const [page, setPage] = useState(1)
  const [open, setOpen] = useState<any>(null)
  const q = useQuery({ queryKey: ['audit', f, page], queryFn: () => api(`/api/admin/audit${qs({ ...f, page, page_size: 30 })}`) })
  const verify = useMutation({ mutationFn: () => api('/api/admin/audit/verify', { method: 'POST' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['audit'] }), onError: toast.fail })
  const demo = useMutation({ mutationFn: () => api('/api/admin/audit/tamper-demo', { method: 'POST' }), onError: toast.fail })
  const block = useMutation({ mutationFn: (id: number) => api(`/api/admin/audit/try-modify/${id}`, { method: 'POST' }), onError: toast.fail })
  const seal = useMutation({ mutationFn: () => api('/api/admin/audit/seal', { method: 'POST' }), onSuccess: (r: any) => { qc.invalidateQueries({ queryKey: ['audit'] }); toast.ok(r.sealed ? `Sealed ${r.day}: ${r.entries} entries.` : 'Nothing new to seal for yesterday.') } })
  const d = q.data
  const v = verify.data || (d?.last_verification && { ok: d.last_verification.ok, checked: d.last_verification.checked, first_broken_id: d.last_verification.first_broken_id })
  return (
    <div>
      <PageHeader title="Audit trail" sub="Append-only and hash-chained: hash = SHA-256(previous hash + canonical JSON of the entry). The database rejects updates and deletes; daily heads are signed and copied to a separate append-only store."
        actions={can('audit.verify') && <><Button loading={verify.isPending} onClick={() => verify.mutate()}>Verify chain</Button><Button variant="secondary" onClick={() => seal.mutate()}>Seal yesterday</Button></>} />
      <div className="mb-4 grid gap-4 lg:grid-cols-2">
        <Panel title="Chain verification">
          {v ? <div className={`rounded-md border p-3 ${v.ok ? 'border-ok/30 bg-ok-50' : 'border-late/30 bg-late-50'}`}>
            <div className="text-lg font-semibold">{v.ok ? '✓ Chain intact' : '✕ Chain broken'}</div>
            <div className="text-sm">{v.checked?.toLocaleString()} entries checked{verify.data?.seals_checked != null && `, ${verify.data.seals_checked} signed daily heads checked`}{verify.data?.duration_ms && ` in ${verify.data.duration_ms} ms`}.
              {!v.ok && <> First broken link at entry <b>#{v.first_broken_id}</b>{verify.data?.detail && `: ${verify.data.detail}`}.</>}</div>
            {d?.last_verification && !verify.data && <div className="mt-1 text-xs text-ink/60">Last run {fmtDateTime(d.last_verification.ran_at)} ({label(d.last_verification.trigger)}). An hourly job also verifies.</div>}
          </div> : <Empty>Not verified yet.</Empty>}
        </Panel>
        <Panel title="Tamper demonstration (isolated)">
          <p className="text-[13px] text-ink/75">Builds a separate 20-entry demo chain in <code>audit_demo_log</code>, verifies it, silently alters one entry and verifies again. Production records are never touched.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {can('audit.tamper_demo') && <Button variant="secondary" loading={demo.isPending} onClick={() => demo.mutate()}>Run tamper demonstration</Button>}
            {can('audit.tamper_demo') && d?.items?.[0] && <Button variant="quiet" onClick={() => block.mutate(d.items[0].id)}>Try to edit a production entry</Button>}
          </div>
          {demo.data && <div className="mt-3 space-y-1 text-[13px]">
            <div>Before alteration: <Badge tone="green">✓ intact ({demo.data.verification_before.checked} entries)</Badge></div>
            <div>After altering entry #{demo.data.altered_entry}: <Badge tone="red">✕ broken at #{demo.data.verification_after.first_broken_id}</Badge> — {demo.data.verification_after.detail}</div>
            <div className="font-medium">{demo.data.detected ? 'Alteration detected at exactly the modified entry.' : 'Not detected.'}</div></div>}
          {block.data && <div className="mt-2"><Notice tone={block.data.blocked ? 'green' : 'red'}>{block.data.blocked ? `Blocked by the database: ${block.data.database_said}` : 'The update was not blocked!'}</Notice></div>}
        </Panel>
      </div>
      {d?.seals?.length > 0 && <Panel title="Signed daily heads" className="mb-4" pad={false}>
        <Table head={['Day', 'Last entry', 'Entries', 'Head hash', 'Signature', 'Anchored']} dense>{d.seals.map((s: any) => <tr key={s.day}><td>{fmtDate(s.day)}</td><td>#{s.last_audit_id}</td><td>{s.entries}</td>
          <td className="text-[11px]">{s.head_hash.slice(0, 24)}…</td><td className="text-[11px]">{s.signature}</td><td>{s.anchored ? 'yes' : 'no'}</td></tr>)}</Table></Panel>}
      <div className="mb-3 flex flex-wrap gap-2">
        <Input aria-label="Action" className="max-w-[200px]" placeholder="Action contains…" value={f.action || ''} onChange={(e) => setF({ ...f, action: e.target.value })} />
        <Input aria-label="Entity type" className="max-w-[160px]" placeholder="Entity type" value={f.entity_type || ''} onChange={(e) => setF({ ...f, entity_type: e.target.value })} />
        <Input aria-label="Entity ID" className="max-w-[120px]" placeholder="Entity ID" value={f.entity_id || ''} onChange={(e) => setF({ ...f, entity_id: e.target.value })} />
      </div>
      <Panel pad={false}>
        <ErrorBox error={q.error} />
        {q.isLoading ? <Loading /> : d?.items.length ? <>
          <Table head={['#', 'When', 'Actor', 'Action', 'Entity', 'Reason', 'Previous hash', 'Hash']} dense>
            {d.items.map((a: any) => <tr key={a.id} className="cursor-pointer" onClick={() => setOpen(a)}>
              <td>{a.id}</td><td className="whitespace-nowrap">{fmtDateTime(a.ts)}</td><td className="text-xs">{a.actor}<div className="text-ink/50">{label(a.actor_role)}</div></td>
              <td>{label(a.action)}</td><td className="text-xs">{a.entity_type} {a.entity_id}</td><td className="max-w-[220px] truncate text-xs">{a.reason}</td>
              <td className="text-[11px] text-ink/55">{a.prev_hash.slice(0, 12)}…</td><td className="text-[11px]">{a.hash.slice(0, 12)}…</td></tr>)}
          </Table>
          <Pager page={page} pages={d.pages} total={d.total} onPage={setPage} /></> : <div className="p-4"><Empty /></div>}
      </Panel>
      <Dialog open={!!open} onClose={() => setOpen(null)} title={`Audit entry #${open?.id}`} wide>
        {open && <div className="space-y-2 text-[13px]">
          <p><b>{label(open.action)}</b> on {open.entity_type} {open.entity_id} by {open.actor} ({open.actor_role}) at {fmtDateTime(open.ts)}</p>
          {open.reason && <p>Reason: {open.reason}</p>}
          <p className="break-all text-xs">Previous hash: {open.prev_hash}<br />Hash: {open.hash}<br />Correlation ID: {open.correlation_id || '—'}</p>
          <div className="grid gap-2 md:grid-cols-2">
            <div><h3 className="font-semibold">Before</h3><pre className="max-h-72 overflow-auto rounded bg-mist p-2 text-[11px]">{JSON.stringify(open.before, null, 2)}</pre></div>
            <div><h3 className="font-semibold">After</h3><pre className="max-h-72 overflow-auto rounded bg-mist p-2 text-[11px]">{JSON.stringify(open.after, null, 2)}</pre></div>
          </div>
        </div>}
      </Dialog>
      {toast.node}
    </div>
  )
}
