import { useQuery } from '@tanstack/react-query'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { DaysLeft, Empty, ErrorBox, Loading, PageHeader, Pager, Panel, Status, Synthetic, Table, fmtDate, label } from '../components/ui'
import { api, qs } from '../services/api'

export function Workflow() {
  const routes = useQuery({ queryKey: ['routes'], queryFn: () => api('/api/admin/routes') })
  const dash = useQuery({ queryKey: ['dashboard', {}], queryFn: () => api('/api/dashboard') })
  const [stage, setStage] = useState('SCRUTINY')
  const [page, setPage] = useState(1)
  const queue = useQuery({ queryKey: ['stage-queue', stage, page], queryFn: () => api(`/api/ledger${qs({ view: 'mine', page, page_size: 20 })}`) })
  const apps = useQuery({ queryKey: ['apps-stage', stage, page], queryFn: () => api(`/api/applications${qs({ stage, status: stage === 'DECISION' ? 'AWAITING_DECISION' : '', page, page_size: 20 })}`) })
  return (
    <div>
      <PageHeader title="Workflow management" sub="Routes are configurable state machines. Pick a stage to work its queue; each row opens the application with its allowed transitions." />
      <div className="mb-4 flex flex-wrap gap-2" role="tablist" aria-label="Stage queues">
        {['SCRUTINY', 'RESCRUTINY', 'EVC', 'SAC_SHC', 'DECISION'].map((s) => {
          const n = dash.data?.stage_pendency.find((x: any) => x.stage === s)?.count ?? 0
          return <button key={s} role="tab" aria-selected={stage === s} onClick={() => { setStage(s); setPage(1) }}
            className={`rounded-md border px-3 py-2 text-left text-sm ${stage === s ? 'border-ledger bg-ledger-50' : 'border-rule bg-white hover:bg-mist'}`}>
            <div className="font-medium">{label(s)}</div><div className="text-xs tabular-nums text-ink/60">{n} pending</div></button>
        })}
      </div>
      <Panel title={`${label(stage)} queue`} pad={false}>
        <ErrorBox error={apps.error} />
        {apps.isLoading ? <Loading /> : apps.data?.items.length ? <>
          <Table head={['Application', 'Institution', 'Route', 'Status', 'In stage since', 'Age']}>
            {apps.data.items.map((a: any) => <tr key={a.id}>
              <td><Link className="text-ledger hover:underline" to={`/applications/${a.id}`}>{a.app_no}</Link> <Synthetic on={a.is_synthetic} /></td>
              <td>{a.institution}</td><td className="text-xs">{label(a.route_code)}</td><td><Status value={a.status} /></td><td>{fmtDate(a.stage_entered_at)}</td><td>{a.age_days} d</td></tr>)}
          </Table>
          <Pager page={page} pages={apps.data.pages} total={apps.data.total} onPage={setPage} /></> : <div className="p-4"><Empty>No applications at this stage.</Empty></div>}
      </Panel>
      <h2 className="mb-2 mt-6 text-[15px] font-semibold">Route definitions</h2>
      {routes.isLoading ? <Loading /> : (
        <div className="grid gap-3 md:grid-cols-2">
          {routes.data?.filter((r: any) => r.is_active).map((r: any) => (
            <Panel key={r.id} title={<>{r.name} <span className="font-normal text-ink/55">· {r.code} v{r.version}</span></>}>
              <div className="flex flex-wrap items-center gap-1 text-[12.5px]">
                {r.definition.stages.filter((s: any) => !s.entry_only_via_resubmit).map((s: any, i: number, arr: any[]) => (
                  <span key={s.code} className="flex items-center gap-1"><span className="rounded border border-rule px-2 py-0.5">{s.name} · {s.budget_days}{s.day_mode === 'WORKING' ? ' wd' : ' d'}</span>{i < arr.length - 1 && <span className="text-ink/30">→</span>}</span>
                ))}
              </div>
              <div className="mt-2 text-xs text-ink/60">
                Revert policy {r.definition.revert_policy}. Returns allowed from: {r.definition.stages.filter((s: any) => s.returnable).map((s: any) => s.name).join(', ') || 'none'}.
                Reverts: {Object.entries(r.definition.revert_targets || {}).map(([k, v]: any) => `${k}→${v.join('/')}`).join('; ') || 'none'}. {label(r.source_type)}.
              </div>
            </Panel>
          ))}
        </div>
      )}
      {queue.data && <p className="mt-4 text-xs text-ink/55">You have {queue.data.total} open obligations assigned — see <Link className="text-ledger underline" to="/today">Today's 10</Link>.</p>}
    </div>
  )
}
