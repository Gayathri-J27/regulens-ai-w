import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Badge, Button, DaysLeft, Empty, ErrorBox, Loading, PageHeader, Panel, Synthetic, fmtDate, useToast } from '../components/ui'
import { api } from '../services/api'
import { useAuth } from '../services/auth'

export function Today() {
  const { can } = useAuth()
  const qc = useQueryClient()
  const toast = useToast()
  const q = useQuery({ queryKey: ['today'], queryFn: () => api('/api/today') })
  const nudge = useMutation({ mutationFn: (id: number) => api(`/api/ledger/${id}/do/nudge`, { body: {} }),
    onSuccess: (r: any) => toast.ok(`Nudge queued: ${r.result.notifications_created} notification(s).`), onError: toast.fail })
  const d = q.data
  return (
    <div>
      <PageHeader title="Today's 10" sub={d ? <>The ten most important actions for you right now, out of {d.total_candidates} open items assigned or escalated to you.</> : undefined}
        actions={<Button variant="secondary" onClick={() => qc.invalidateQueries({ queryKey: ['today'] })}>Refresh</Button>} />
      <ErrorBox error={q.error} />
      {q.isLoading ? <Loading /> : !d?.items.length ? <Empty>Nothing is waiting on you. New assignments and escalations will appear here.</Empty> : (
        <ol className="space-y-2">
          {d.items.map((it: any, i: number) => (
            <li key={it.obligation_id} className="grid grid-cols-[2.25rem_1fr] gap-3 rounded-lg border border-rule bg-white p-3 sm:grid-cols-[2.25rem_1fr_auto]">
              <div className="font-serif text-2xl font-semibold tabular-nums text-ink/35">{i + 1}</div>
              <div className="min-w-0">
                <Link to={`/ledger/${it.obligation_id}`} className="font-medium text-ledger hover:underline">{it.task}</Link>
                {it.escalated_to_me && <Badge tone="red">escalated to you</Badge>} <Synthetic on={it.is_synthetic} />
                <div className="mt-0.5 text-[12.5px] text-ink/70">{it.institution} (tier {it.institution_tier}){it.application && <> · <Link className="hover:underline" to={`/applications/${it.application_id}`}>{it.application}</Link></>}</div>
                <div className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-[12.5px]">
                  <span>Due {fmtDate(it.deadline)} — <DaysLeft days={it.days_remaining} state={it.state} /></span>
                  <span className="text-ink/75">Why: {it.why}</span>
                  <span className="font-medium">Next: {it.next_action}</span>
                </div>
              </div>
              <div className="col-span-2 flex items-center gap-3 sm:col-span-1 sm:flex-col sm:items-end">
                <div className="text-right" title={`urgency ${it.components.urgency} + tier ${it.components.tier} + statutory ${it.components.statutory} + ageing ${it.components.ageing}`}>
                  <div className="text-lg font-semibold tabular-nums">{it.priority.toFixed(1)}</div>
                  <div className="text-[11px] text-ink/55">{it.overridden ? `override: ${it.override_reason}` : 'priority score'}</div>
                </div>
                {can('notification.nudge') && <Button size="sm" variant="secondary" onClick={() => nudge.mutate(it.obligation_id)}>Nudge now</Button>}
              </div>
            </li>
          ))}
        </ol>
      )}
      {d && (
        <Panel title="How the order is computed" className="mt-5">
          <p className="text-sm"><code className="rounded bg-mist px-1">{d.formula}</code> with w1={d.weights.w1}, w2={d.weights.w2}, w3={d.weights.w3}, w4={d.weights.w4}.</p>
          <p className="mt-1 text-xs text-ink/65">Urgency: {d.urgency_rule}. Weights are set by administrators (rule priority.weights); officers can override an item's priority with a recorded reason from its ledger page.</p>
        </Panel>
      )}
      {toast.node}
    </div>
  )
}
