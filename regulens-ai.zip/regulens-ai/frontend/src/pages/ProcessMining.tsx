import { useQuery } from '@tanstack/react-query'
import { useState } from 'react'
import { Bar, BarChart, CartesianGrid, Tooltip, XAxis, YAxis } from 'recharts'
import { Badge, Empty, ErrorBox, Loading, Notice, PageHeader, Panel, Select, Table, label } from '../components/ui'
import { useMeta } from '../hooks/useMeta'
import { api, qs } from '../services/api'
import { ChartBox } from './Overview'

const axis = { fontSize: 11, fill: '#14233CB0' }

export function ProcessMining() {
  const meta = useMeta()
  const [f, setF] = useState<Record<string, string>>({})
  const q = useQuery({ queryKey: ['pm', f], queryFn: () => api(`/api/process-mining${qs(f)}`) })
  const d = q.data
  const stages = ['SCRUTINY', 'RESCRUTINY', 'EVC', 'SAC_SHC', 'DECISION', 'INSTITUTION']
  const heat = (a: string, b: string) => d?.loop_heatmap.find((x: any) => x.from === a && x.to === b)?.count || 0
  const maxHeat = Math.max(1, ...(d?.loop_heatmap || []).map((x: any) => x.count))
  const regions = [...new Set((d?.region_bottlenecks || []).map((r: any) => r.region))] as string[]
  const durStages = [...new Set((d?.region_bottlenecks || []).map((r: any) => r.stage))] as string[]
  const cell = (reg: string, st: string) => d?.region_bottlenecks.find((x: any) => x.region === reg && x.stage === st)
  return (
    <div>
      <PageHeader title="Process mining" sub="Built from recorded application events: how cases actually moved, where they looped back and where time was lost." />
      <div className="mb-4 flex flex-wrap gap-2">
        <Select aria-label="Region" className="max-w-[200px]" value={f.region_id || ''} onChange={(e) => setF({ ...f, region_id: e.target.value })}><option value="">All Regions</option>{meta.data?.regions.map((r) => <option key={r.id} value={r.id}>{r.code}</option>)}</Select>
        <Select aria-label="Route" className="max-w-[240px]" value={f.route_code || ''} onChange={(e) => setF({ ...f, route_code: e.target.value })}><option value="">All routes</option>{meta.data?.routes.map((r) => <option key={r.code} value={r.code}>{r.name}</option>)}</Select>
        <Select aria-label="Data" className="max-w-[200px]" value={f.synthetic || ''} onChange={(e) => setF({ ...f, synthetic: e.target.value })}><option value="">Incl. synthetic</option><option value="0">Exclude synthetic</option></Select>
      </div>
      <ErrorBox error={q.error} />
      {q.isLoading ? <Loading label="Mining event log…" /> : d?.empty ? <Empty>No events for this selection.</Empty> : d && (
        <div className="space-y-4">
          <Notice tone={d.synthetic_share > 0 ? 'amber' : 'blue'}>{d.data_label}: {d.applications.toLocaleString()} applications ({Math.round(d.synthetic_share * 100)}% synthetic). Conformance with prescribed routes: {d.conformance.conforming || 0} conforming, {d.conformance.deviating || 0} deviating.</Notice>
          <Panel title="Findings from the data">
            <ul className="list-disc space-y-1 pl-5 text-[14px]">{d.insights.map((s: string, i: number) => <li key={i}>{s}</li>)}</ul>
            <p className="mt-2 text-[11.5px] text-ink/55">Each sentence is filled in from SQL aggregates of the event log; none is written by a language model.</p>
          </Panel>
          <div className="grid gap-4 lg:grid-cols-2">
            <Panel title="Loop-back heat map (returns, reverts, resubmissions)">
              <div className="overflow-x-auto"><table className="text-[12px]"><thead><tr><th className="p-1 text-left text-ink/60">from ↓ to →</th>{stages.map((s) => <th key={s} className="p-1 font-medium">{label(s)}</th>)}</tr></thead>
                <tbody>{stages.map((a) => <tr key={a}><th className="p-1 text-left font-medium">{label(a)}</th>{stages.map((b) => { const n = heat(a, b); return <td key={b} className="p-0.5">
                  <div className="flex h-9 w-16 items-center justify-center rounded tabular-nums" style={{ background: n ? `rgba(31,90,166,${0.12 + 0.8 * n / maxHeat})` : '#F4F6F9', color: n / maxHeat > 0.5 ? '#fff' : '#14233C' }}>{n || ''}</div></td> })}</tr>)}</tbody></table></div>
            </Panel>
            <ChartBox title="Most common deficiency reasons">
              <BarChart data={d.deficiency_reasons} layout="vertical" margin={{ left: 60 }}><CartesianGrid horizontal={false} stroke="#E4E9F0" /><XAxis type="number" tick={axis} />
                <YAxis type="category" dataKey="reason" tick={{ ...axis, fontSize: 10 }} width={150} tickFormatter={label} /><Tooltip /><Bar dataKey="count" fill="#1F5AA6" /></BarChart>
            </ChartBox>
            <Panel title="Stage durations (calendar days)" pad={false}>
              <Table head={['Stage', 'n', 'Mean', 'Median', 'P90']}>{d.stage_durations.map((s: any) => <tr key={s.stage}><td>{label(s.stage)}</td><td>{s.n}</td><td>{s.mean_days}</td><td className="font-medium">{s.median_days}</td><td>{s.p90_days}</td></tr>)}</Table>
            </Panel>
            <ChartBox title="Delay contribution — time beyond stage budget">
              <BarChart data={d.delay_contribution}><CartesianGrid vertical={false} stroke="#E4E9F0" /><XAxis dataKey="stage" tick={axis} tickFormatter={label} /><YAxis tick={axis} />
                <Tooltip formatter={(v: any, n: any, p: any) => [`${v} days (${Math.round(p.payload.share * 100)}%)`, 'Excess']} /><Bar dataKey="excess_days" fill="#B54708" /></BarChart>
            </ChartBox>
          </div>
          <Panel title="Region-wise median stage duration (bottlenecks)" pad={false}>
            <Table head={['Region', ...durStages.map(label)]}>{regions.map((r) => <tr key={r}><td className="font-medium">{r}</td>{durStages.map((s) => {
              const c = cell(r, s); const vals = (d.region_bottlenecks.filter((x: any) => x.stage === s).map((x: any) => x.median_days) as number[]).sort((a, b) => a - b)
              const med = vals[Math.floor(vals.length / 2)] || 1
              return <td key={s} className="tabular-nums">{c ? <>{c.median_days} {c.median_days > 1.3 * med && <Badge tone="red">bottleneck</Badge>}</> : '—'}</td> })}</tr>)}</Table>
          </Panel>
          <Panel title="Prescribed route vs actual variants" pad={false}>
            <Table head={['Route', 'Actual sequence', 'Cases', 'Conforms']}>{d.variants.map((v: any, i: number) => <tr key={i}><td className="text-xs">{label(v.route)}</td>
              <td className="text-[12.5px]">{v.variant}<div className="text-[11px] text-ink/50">prescribed: {v.prescribed}</div></td><td className="tabular-nums">{v.count}</td>
              <td>{v.conforms ? <Badge tone="green">yes</Badge> : <Badge tone="amber">deviates</Badge>}</td></tr>)}</Table>
          </Panel>
        </div>
      )}
    </div>
  )
}
