import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Link, useParams, useSearchParams } from 'react-router-dom'
import { ClockStrip } from '../components/ClockStrip'
import { Badge, Button, DaysLeft, Dialog, Empty, ErrorBox, Field, Input, Loading, Notice, PageHeader, Pager, Panel, Select, Status, Synthetic,
  Table, Tabs, Textarea, fmtDate, fmtDateTime, label, useToast } from '../components/ui'
import { regionName, useMeta } from '../hooks/useMeta'
import { api, download, qs } from '../services/api'
import { isInstitution, useAuth } from '../services/auth'

const VIEWS = [['all', 'All'], ['mine', 'My obligations'], ['institution', 'Institution obligations'], ['upcoming', 'Upcoming (30 d)'], ['overdue', 'Overdue'],
  ['verification', 'Needs verification'], ['paused', 'Paused'], ['completed', 'Completed']]

export function Ledger() {
  const [sp, setSp] = useSearchParams()
  const meta = useMeta()
  const { can } = useAuth()
  const f = Object.fromEntries(sp.entries())
  const view = f.view || 'all'
  const page = Number(f.page || 1)
  const [create, setCreate] = useState(false)
  const q = useQuery({ queryKey: ['ledger', f], queryFn: () => api(`/api/ledger${qs({ ...f, view, page_size: 25 })}`) })
  const set = (k: string, v: string) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); if (k !== 'page') n.delete('page'); setSp(n) }
  return (
    <div>
      <PageHeader title="Promise Ledger" sub="The single record of every time-bound action — stage deadlines, undertakings, renewals and compliance — with its live clock."
        actions={<>
          {can('ledger.export') && <Button variant="secondary" onClick={() => download(`/api/ledger/export${qs({ view, region_id: f.region_id, obligation_type: f.obligation_type })}`, `ledger-${view}.csv`)}>Export CSV</Button>}
          {can('ledger.create') && <Button onClick={() => setCreate(true)}>New obligation</Button>}
        </>} />
      <Tabs value={view} onChange={(v) => set('view', v)} tabs={VIEWS.map(([id, l]) => ({ id, label: l }))} />
      <div className="mb-3 grid grid-cols-2 gap-2 md:grid-cols-6">
        <Input aria-label="Search" placeholder="Title, number or institution" defaultValue={f.q} onKeyDown={(e) => e.key === 'Enter' && set('q', (e.target as HTMLInputElement).value)} />
        <Select aria-label="Type" value={f.obligation_type || ''} onChange={(e) => set('obligation_type', e.target.value)}><option value="">All types</option>
          {Object.entries(meta.data?.obligation_types || {}).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</Select>
        <Select aria-label="Region" value={f.region_id || ''} onChange={(e) => set('region_id', e.target.value)}><option value="">All Regions</option>
          {meta.data?.regions.map((r) => <option key={r.id} value={r.id}>{r.code}</option>)}</Select>
        <Select aria-label="Officer" value={f.officer_id || ''} onChange={(e) => set('officer_id', e.target.value)}><option value="">Any officer</option>
          {meta.data?.officers.slice(0, 200).map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</Select>
        <Input aria-label="Due from" type="date" value={f.due_from || ''} onChange={(e) => set('due_from', e.target.value)} />
        <Input aria-label="Due to" type="date" value={f.due_to || ''} onChange={(e) => set('due_to', e.target.value)} />
      </div>
      <Panel pad={false}>
        <ErrorBox error={q.error} />
        {q.isLoading ? <Loading /> : q.data?.items.length ? <>
          <Table head={['Obligation', 'Institution', 'Region', 'Type', 'Party', 'Due', 'Remaining', 'State', 'Esc.']}>
            {q.data.items.map((o: any) => <tr key={o.id}>
              <td className="max-w-[300px]"><Link className="font-medium text-ledger hover:underline" to={`/ledger/${o.id}`}>{o.title}</Link><div className="text-[11px] text-ink/55">{o.obl_no} {o.statutory && '· statutory'}</div></td>
              <td className="max-w-[220px] text-[12.5px]">{o.institution} <Synthetic on={o.institution_synthetic} /></td>
              <td>{regionName(meta.data, o.region_id)}</td><td className="text-xs">{o.type_label}</td><td className="text-xs">{label(o.responsible_party)}</td>
              <td className="whitespace-nowrap">{fmtDate(o.due_date)}</td><td className="whitespace-nowrap"><DaysLeft days={o.days_remaining} state={o.state} /></td>
              <td><Status value={o.display_state} /></td><td>{o.escalation_level > 0 && <Badge tone="red">L{o.escalation_level}</Badge>}</td></tr>)}
          </Table>
          <Pager page={page} pages={q.data.pages} total={q.data.total} onPage={(p) => set('page', String(p))} /></> : <div className="p-4"><Empty>No obligations in this view.</Empty></div>}
      </Panel>
      <CreateObligation open={create} onClose={() => setCreate(false)} />
    </div>
  )
}

function CreateObligation({ open, onClose }: { open: boolean; onClose: () => void }) {
  const meta = useMeta()
  const qc = useQueryClient()
  const [v, setV] = useState<Record<string, string>>({ obligation_type: 'ADMIN_TASK' })
  const [instQ, setInstQ] = useState('')
  const insts = useQuery({ queryKey: ['inst-search', instQ], queryFn: () => api(`/api/institutions${qs({ q: instQ, page_size: 20 })}`), enabled: open })
  const set = (k: string, x: string) => setV((p) => ({ ...p, [k]: x }))
  const m = useMutation({
    mutationFn: () => api('/api/ledger', { body: { institution_id: Number(v.institution_id), obligation_type: v.obligation_type, title: v.title || '', description: v.description || '',
      due_date: v.due_date || null, start_date: v.start_date || null, budget_days: v.budget_days ? Number(v.budget_days) : null,
      evidence_requirements: v.evidence ? [v.evidence] : [] } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['ledger'] }); onClose() },
  })
  return (
    <Dialog open={open} onClose={onClose} title="New obligation">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Find institution" className="sm:col-span-2"><Input value={instQ} onChange={(e) => setInstQ(e.target.value)} placeholder="Name or AICTE ID" /></Field>
        <Field label="Institution" className="sm:col-span-2"><Select value={v.institution_id || ''} onChange={(e) => set('institution_id', e.target.value)}><option value="">Select…</option>
          {insts.data?.items.map((i: any) => <option key={i.id} value={i.id}>{i.name}</option>)}</Select></Field>
        <Field label="Type"><Select value={v.obligation_type} onChange={(e) => set('obligation_type', e.target.value)}>
          {Object.entries(meta.data?.obligation_types || {}).map(([k, x]) => <option key={k} value={k}>{x}</option>)}</Select></Field>
        <Field label="Title"><Input value={v.title || ''} onChange={(e) => set('title', e.target.value)} /></Field>
        <Field label="Due date" hint="Or give a budget instead"><Input type="date" value={v.due_date || ''} onChange={(e) => set('due_date', e.target.value)} /></Field>
        <Field label="Budget (days)" hint="Empty = rule default"><Input type="number" value={v.budget_days || ''} onChange={(e) => set('budget_days', e.target.value)} /></Field>
        <Field label="Start date" hint="Back-date for imported/backfilled obligations"><Input type="date" value={v.start_date || ''} onChange={(e) => set('start_date', e.target.value)} /></Field>
        <Field label="Evidence required"><Input value={v.evidence || ''} onChange={(e) => set('evidence', e.target.value)} /></Field>
        <Field label="Description" className="sm:col-span-2"><Textarea value={v.description || ''} onChange={(e) => set('description', e.target.value)} /></Field>
        <div className="sm:col-span-2"><ErrorBox error={m.error} /></div>
        <div className="sm:col-span-2"><Button loading={m.isPending} disabled={!v.institution_id} onClick={() => m.mutate()}>Create obligation</Button></div>
      </div>
    </Dialog>
  )
}

export function ObligationDetail() {
  const { id } = useParams()
  const { me } = useAuth()
  const meta = useMeta()
  const qc = useQueryClient()
  const toast = useToast()
  const [dlg, setDlg] = useState<string | null>(null)
  const [v, setV] = useState<Record<string, string>>({})
  const q = useQuery({ queryKey: ['obl', id], queryFn: () => api(`/api/ledger/${id}`) })
  const o = q.data
  const act = useMutation({
    mutationFn: ({ action, body }: { action: string; body: any }) => api(`/api/ledger/${id}/do/${action}`, { body }),
    onSuccess: (r: any, x) => { setDlg(null); setV({}); qc.invalidateQueries({ queryKey: ['obl', id] });
      toast.ok(x.action === 'nudge' ? `Nudge sent: ${r.result.notifications_created} notification(s) queued.` : x.action === 'magic-link' ? 'Secure link issued and sent to the institution.' : 'Done — recorded in the audit trail.')
      if (x.action === 'magic-link') setV({ link: r.result.link }) },
    onError: (e) => toast.fail(e),
  })
  const review = useMutation({
    mutationFn: ({ eid, accept, reason }: any) => api(`/api/evidence/${eid}/review`, { body: { accept, reason } }),
    onSuccess: () => { setDlg(null); qc.invalidateQueries({ queryKey: ['obl', id] }); toast.ok('Evidence decision recorded.') }, onError: (e) => toast.fail(e),
  })
  const [file, setFile] = useState<File | null>(null)
  const upload = useMutation({
    mutationFn: async () => {
      const fd = new FormData(); fd.append('file', file!); fd.append('note', v.note || '')
      if (dlg === 'assisted') { fd.append('kind', v.kind || 'OFFLINE_EVIDENCE'); return api(`/api/ledger/${id}/assisted`, { form: fd }) }
      return api(`/api/ledger/${id}/evidence`, { form: fd })
    },
    onSuccess: (r: any) => { setDlg(null); qc.invalidateQueries({ queryKey: ['obl', id] }); toast.ok(r.receipt_no ? `Receipt ${r.receipt_no} issued.` : 'Recorded.') }, onError: (e) => toast.fail(e),
  })
  const assisted = useMutation({
    mutationFn: () => { const fd = new FormData(); fd.append('kind', v.kind); fd.append('note', v.note || ''); if (file) fd.append('file', file); return api(`/api/ledger/${id}/assisted`, { form: fd }) },
    onSuccess: () => { setDlg(null); qc.invalidateQueries({ queryKey: ['obl', id] }); toast.ok('Assisted handling recorded.') }, onError: (e) => toast.fail(e),
  })
  if (q.isLoading) return <Loading />
  if (q.error) return <ErrorBox error={q.error} />
  const c = o.can
  const open = ['OPEN', 'ACKNOWLEDGED', 'SUBMITTED'].includes(o.state)
  const closed = ['MET', 'WAIVED', 'CANCELLED', 'MERGED'].includes(o.state)
  const ex = o.clock
  return (
    <div>
      <PageHeader title={o.title} sub={<>{o.obl_no} · {o.type_label} · {o.institution} <Synthetic on={o.institution_synthetic} /></>}
        actions={<>
          {c['institution.acknowledge'] && o.state === 'OPEN' && <Button onClick={() => act.mutate({ action: 'acknowledge', body: {} })}>Acknowledge</Button>}
          {c['evidence.submit'] && ['OPEN', 'ACKNOWLEDGED'].includes(o.state) && o.responsible_party === 'INSTITUTION' && <Button onClick={() => setDlg('evidence')}>Upload evidence</Button>}
          {c['notification.nudge'] && open && <Button variant="secondary" onClick={() => act.mutate({ action: 'nudge', body: {} })}>Nudge now</Button>}
          {c['ledger.extend'] && (open || o.state === 'PAUSED') && <Button variant="secondary" onClick={() => setDlg('extend')}>Extend</Button>}
          {c['ledger.pause'] && open && <Button variant="secondary" onClick={() => setDlg('pause')}>Pause clock</Button>}
          {c['ledger.pause'] && o.state === 'PAUSED' && <Button variant="secondary" onClick={() => setDlg('resume')}>Resume clock</Button>}
          {c['ledger.assign'] && !closed && <Button variant="quiet" onClick={() => setDlg('assign')}>Reassign</Button>}
          {c['ledger.priority_override'] && !closed && <Button variant="quiet" onClick={() => setDlg('priority')}>Priority</Button>}
          {c['magiclink.issue'] && open && o.responsible_party === 'INSTITUTION' && <Button variant="quiet" onClick={() => act.mutate({ action: 'magic-link', body: {} })}>Send secure link</Button>}
          {c['ledger.assisted'] && open && o.responsible_party === 'INSTITUTION' && <Button variant="quiet" onClick={() => setDlg('assisted')}>Assisted handling</Button>}
          {c['ledger.close'] && !closed && <Button variant="quiet" onClick={() => setDlg('close')}>Close</Button>}
          {c['ledger.reopen'] && closed && <Button variant="quiet" onClick={() => setDlg('reopen')}>Reopen</Button>}
        </>} />
      {v.link && <div className="mb-3"><Notice tone="green">Single-use link (7 days) sent to the institution's contacts: <a className="break-all text-ledger underline" href={v.link.replace(/^https?:\/\/[^/]+/, '')}>{v.link}</a></Notice></div>}
      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          {ex && (
            <Panel title="Deadline clock" actions={<span className="flex items-center gap-2 text-sm"><Status value={o.display_state === 'OVERDUE' ? 'OVERDUE' : ex.state} /><DaysLeft days={o.days_remaining} state={o.state} /></span>}>
              <ClockStrip ex={ex} />
              <div className="mt-4 rounded-md bg-mist/70 p-3">
                <h3 className="text-sm font-semibold">Why this date?</h3>
                <ul className="mt-1.5 space-y-1 text-[13.5px] leading-relaxed">{ex.lines.map((l: string, i: number) => <li key={i}>{l}</li>)}</ul>
                <p className="mt-2 text-[11.5px] text-ink/55">Generated deterministically from {ex.history.length} recorded clock event(s) and calendar “{ex.calendar}”. No AI is used for deadline arithmetic.</p>
              </div>
              <details className="mt-3 text-sm"><summary className="cursor-pointer text-ledger">Clock history ({ex.history.length} events)</summary>
                <Table head={['#', 'Event', 'When', 'Detail', 'Reason']} dense>
                  {ex.history.map((h: any) => <tr key={h.seq}><td>{h.seq}</td><td>{label(h.kind)}</td><td>{fmtDateTime(h.at)}</td>
                    <td className="text-xs">{[h.pause_kind && label(h.pause_kind), h.days && `${h.days} d`, h.policy].filter(Boolean).join(' · ')}</td><td className="text-xs">{h.reason}</td></tr>)}
                </Table></details>
            </Panel>
          )}
          <Panel title="Evidence and verification" pad={false}>
            {o.evidence.length ? <Table head={['Receipt', 'Channel', 'Submitted', 'Status', 'OCR', '']}>
              {o.evidence.map((e: any) => <tr key={e.id}>
                <td className="font-medium">{e.receipt_no}{e.note && <div className="text-xs text-ink/60">{e.note}</div>}</td><td>{label(e.channel)}</td><td>{fmtDateTime(e.submitted_at)}</td>
                <td><Status value={e.status === 'RECEIVED_PENDING_VERIFICATION' ? 'PENDING_VERIFICATION' : e.status} />{e.review_reason && <div className="text-xs text-late">{e.review_reason}</div>}</td>
                <td className="text-xs">{label(e.ocr_status)}</td>
                <td className="whitespace-nowrap">{e.download && <a className="text-ledger hover:underline" href={e.download} target="_blank" rel="noreferrer">View</a>}
                  {c['ledger.verify'] && e.status === 'RECEIVED_PENDING_VERIFICATION' && <> <Button size="sm" onClick={() => review.mutate({ eid: e.id, accept: true })}>Verify</Button>
                    <Button size="sm" variant="secondary" onClick={() => { setV({ eid: String(e.id) }); setDlg('reject') }}>Reject</Button></>}</td></tr>)}
            </Table> : <div className="p-4"><Empty>{o.responsible_party === 'INSTITUTION' ? 'No evidence submitted yet.' : 'AICTE-side obligation: closed by completing the workflow step.'}</Empty></div>}
          </Panel>
          <Panel title="Audit history" pad={false}>
            <Table head={['When', 'Action', 'By', 'Reason', 'Hash']} dense>
              {o.history.map((h: any) => <tr key={h.id}><td className="whitespace-nowrap">{fmtDateTime(h.ts)}</td><td>{label(h.action)}</td><td className="text-xs">{label(h.actor_role)}</td>
                <td className="text-xs">{h.reason}</td><td className="text-[11px] text-ink/55">{h.hash}…</td></tr>)}
            </Table>
          </Panel>
        </div>
        <div className="space-y-4">
          <Panel title="Record">
            <dl className="grid grid-cols-[120px_1fr] gap-x-3 gap-y-1.5 text-[13px]">
              {[['State', <Status value={o.display_state} />], ['Due', fmtDate(o.due_date)], ['Started', fmtDate(o.start_date)], ['Party', label(o.responsible_party)],
                ['Responsible role', label(o.responsible_role)], ['Assigned', o.assigned_user || '—'], ['Verification', label(o.verification_status)],
                ['Priority', <>{o.priority}{o.priority_override != null && <Badge tone="blue" title={o.priority_override_reason}>override {o.priority_override}</Badge>}</>],
                ['Statutory', o.statutory ? 'Yes' : 'No'], ['Escalation', o.escalation_level ? `Level ${o.escalation_level}` : 'None'], ['Source event', o.source_event],
                ['Application', o.application_id ? <Link className="text-ledger hover:underline" to={`/applications/${o.application_id}`}>Open</Link> : '—'],
                ['Created', fmtDateTime(o.created_at)], ['Closed', o.completed_at ? `${fmtDateTime(o.completed_at)} — ${o.closure_note || ''}` : '—']].map(([k, val]: any) => (
                [<dt key={k + 'k'} className="text-ink/60">{k}</dt>, <dd key={k + 'v'}>{val}</dd>]))}
            </dl>
            {o.description && <p className="mt-3 border-t border-rule pt-3 text-[13px]">{o.description}</p>}
            {o.evidence_requirements?.length > 0 && <div className="mt-3 text-[13px]"><div className="font-medium">Evidence required</div><ul className="ml-4 list-disc">{o.evidence_requirements.map((e: string) => <li key={e}>{e}</li>)}</ul></div>}
          </Panel>
          {(o.source_text || o.source_rule) && <Panel title="Source">
            {o.source_text && <blockquote className="border-l-2 border-ledger pl-3 text-[13px] italic">{o.source_text}</blockquote>}
            {o.source_document_url && <a className="mt-2 inline-block text-sm text-ledger hover:underline" href={o.source_document_url} target="_blank" rel="noreferrer">Open source document</a>}
            {o.source_rule && <div className="mt-2 text-xs text-ink/70">Rule <b>{o.source_rule.rule_key}</b> v{o.source_rule.version} — {label(o.source_rule.source_type)}. {o.source_rule.citation}</div>}
          </Panel>}
          {o.risk && <Panel title="Breach forecast">
            <div className="flex items-center gap-2"><Status value={o.risk.level} />{o.risk.probability != null && <span className="text-sm">{Math.round(o.risk.probability * 100)}% estimated miss probability</span>}</div>
            <ul className="mt-2 list-disc pl-4 text-[12.5px]">{o.risk.reasons.map((r: any, i: number) => <li key={i}>{r.reason}</li>)}</ul>
            <p className="mt-1 text-[11px] text-ink/55">n={o.risk.sample_size} · {o.risk.segment} · {fmtDateTime(o.risk.computed_at)}</p>
          </Panel>}
          {o.escalations.length > 0 && <Panel title="Escalations">
            {o.escalations.map((e: any) => <div key={e.id} className="mb-2 text-[13px]"><Badge tone="red">L{e.level}</Badge> {fmtDate(e.triggered_at)} · <Status value={e.status} />
              <div className="text-xs text-ink/60">{e.path.map((p: any) => p.result).join(' → ')}</div></div>)}
          </Panel>}
        </div>
      </div>

      <Dialog open={!!dlg} onClose={() => setDlg(null)} title={{ extend: 'Approve extension', pause: 'Pause clock', resume: 'Resume clock', close: 'Close obligation', reopen: 'Reopen obligation',
        assign: 'Reassign', priority: 'Override priority', evidence: 'Upload evidence', reject: 'Reject evidence', assisted: 'Assisted handling (Tier 3)' }[dlg || ''] || ''}>
        <div className="space-y-3">
          {dlg === 'extend' && <Field label="Extra days"><Input type="number" min={1} value={v.days || ''} onChange={(e) => setV({ ...v, days: e.target.value })} /></Field>}
          {dlg === 'pause' && <Field label="Pause reason category"><Select value={v.kind || 'AICTE'} onChange={(e) => setV({ ...v, kind: e.target.value })}>
            <option value="AICTE">AICTE-side pause</option><option value="INSTITUTION">Waiting on institution</option><option value="SOURCE">Source system unavailable</option></Select></Field>}
          {dlg === 'close' && <Field label="Outcome"><Select value={v.outcome || 'MET'} onChange={(e) => setV({ ...v, outcome: e.target.value })}><option value="MET">Met</option><option value="WAIVED">Waived</option><option value="CANCELLED">Cancelled</option></Select></Field>}
          {dlg === 'reopen' && <Field label="New budget (days)"><Input type="number" value={v.days || ''} onChange={(e) => setV({ ...v, days: e.target.value })} /></Field>}
          {dlg === 'assign' && <Field label="Officer"><Select value={v.user_id || ''} onChange={(e) => setV({ ...v, user_id: e.target.value })}><option value="">Select…</option>
            {meta.data?.officers.filter((x) => x.region_id === o.region_id).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</Select></Field>}
          {dlg === 'priority' && <Field label="Priority score" hint="Empty clears the override."><Input type="number" step="0.1" value={v.value || ''} onChange={(e) => setV({ ...v, value: e.target.value })} /></Field>}
          {(dlg === 'evidence' || dlg === 'assisted') && <>
            {dlg === 'assisted' && <Field label="What happened"><Select value={v.kind || 'OFFLINE_EVIDENCE'} onChange={(e) => setV({ ...v, kind: e.target.value })}>
              <option value="OFFLINE_EVIDENCE">Evidence received offline</option><option value="ASSISTED_SUBMISSION">Submitted on the institution's behalf</option>
              <option value="NON_RESPONSE">Institution not responding</option><option value="CONTACT_FAILURE">Contact details failed</option></Select></Field>}
            <Field label="File (PDF/JPG/PNG, max 15 MB)" hint="Validated by signature, checksummed and malware-scanned."><Input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
            <Field label="Note"><Textarea value={v.note || ''} onChange={(e) => setV({ ...v, note: e.target.value })} /></Field>
          </>}
          {!['evidence', 'assisted'].includes(dlg || '') && <Field label={dlg === 'priority' || dlg === 'assign' ? 'Reason (required)' : dlg === 'close' ? 'Closure note (required)' : 'Reason'}>
            <Textarea value={v.reason || ''} onChange={(e) => setV({ ...v, reason: e.target.value })} /></Field>}
          <ErrorBox error={act.error || upload.error || assisted.error || review.error} />
          <Button loading={act.isPending || upload.isPending || assisted.isPending || review.isPending} onClick={() => {
            if (dlg === 'evidence') return upload.mutate()
            if (dlg === 'assisted') return ['NON_RESPONSE', 'CONTACT_FAILURE'].includes(v.kind) ? assisted.mutate() : (file ? upload.mutate() : assisted.mutate())
            if (dlg === 'reject') return review.mutate({ eid: v.eid, accept: false, reason: v.reason })
            const body: any = { reason: v.reason || '' }
            if (dlg === 'extend' || dlg === 'reopen') body.days = Number(v.days)
            if (dlg === 'pause') body.kind = v.kind || 'AICTE'
            if (dlg === 'close') body.outcome = v.outcome || 'MET'
            if (dlg === 'assign') body.user_id = Number(v.user_id)
            if (dlg === 'priority') body.value = v.value ? Number(v.value) : null
            act.mutate({ action: dlg!, body })
          }}>Confirm</Button>
        </div>
      </Dialog>
      {toast.node}
      {isInstitution(me?.role) && <p className="mt-6 text-xs text-ink/55">Questions about this requirement? Your Regional office officer can see everything shown here.</p>}
    </div>
  )
}
