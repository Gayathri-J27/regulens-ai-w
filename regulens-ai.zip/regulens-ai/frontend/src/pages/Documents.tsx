import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { Button, DaysLeft, Empty, ErrorBox, Field, Input, Loading, Notice, PageHeader, Pager, Panel, Select, Status, Synthetic, Table, Tabs,
  Textarea, fmtDate, fmtDateTime, label, useToast } from '../components/ui'
import { api, qs } from '../services/api'
import { isInstitution, useAuth } from '../services/auth'

const DOC_TYPES = ['LEASE_DEED', 'FIRE_SAFETY_NOC', 'BUILDING_STABILITY', 'LAND_USE_CERTIFICATE', 'AFFILIATION_LETTER', 'OTHER_PRESCRIBED']

export function UploadDocument({ institutionId, previousId, onDone }: { institutionId?: number | null; previousId?: number; onDone: (d: any) => void }) {
  const { me } = useAuth()
  const [instQ, setInstQ] = useState('')
  const [inst, setInst] = useState<string>(institutionId ? String(institutionId) : '')
  const [type, setType] = useState('LEASE_DEED')
  const [file, setFile] = useState<File | null>(null)
  const insts = useQuery({ queryKey: ['inst-search', instQ], queryFn: () => api(`/api/institutions${qs({ q: instQ, page_size: 20 })}`), enabled: !institutionId && !isInstitution(me?.role) })
  const m = useMutation({ mutationFn: () => { const fd = new FormData(); fd.append('file', file!); fd.append('doc_type', type); fd.append('institution_id', inst || String(me?.institution_id))
    if (previousId) fd.append('previous_document_id', String(previousId)); return api('/api/documents', { form: fd }) }, onSuccess: onDone })
  return (
    <div className="space-y-3">
      {!institutionId && !isInstitution(me?.role) && <>
        <Field label="Find institution"><Input value={instQ} onChange={(e) => setInstQ(e.target.value)} /></Field>
        <Field label="Institution"><Select value={inst} onChange={(e) => setInst(e.target.value)}><option value="">Select…</option>{insts.data?.items.map((i: any) => <option key={i.id} value={i.id}>{i.name}</option>)}</Select></Field>
      </>}
      <Field label="Document type"><Select value={type} onChange={(e) => setType(e.target.value)}>{DOC_TYPES.map((t) => <option key={t} value={t}>{label(t)}</option>)}</Select></Field>
      <Field label="Scan or PDF" hint="Pages are deskewed and denoised before OCR; the expiry date is proposed, never treated as verified."><Input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
      <ErrorBox error={m.error} />
      <Button loading={m.isPending} disabled={!file || !(inst || me?.institution_id)} onClick={() => m.mutate()}>Upload and read dates</Button>
    </div>
  )
}

export function Documents() {
  const [sp, setSp] = useSearchParams()
  const nav = useNavigate()
  const validity = sp.get('validity') || 'PENDING'
  const page = Number(sp.get('page') || 1)
  const q = useQuery({ queryKey: ['documents', validity, page], queryFn: () => api(`/api/documents${qs({ validity, page, page_size: 25 })}`) })
  return (
    <div>
      <PageHeader title="Document validity" sub="Lease deeds and prescribed certificates: OCR reads the dates, an official confirms them, and the confirmed expiry becomes a renewal obligation with advance reminders." />
      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        <div>
          <Tabs value={validity} onChange={(v) => setSp({ validity: v })} tabs={[{ id: 'PENDING', label: 'Awaiting confirmation' }, { id: 'EXPIRING', label: 'Expiring in 90 days' },
            { id: 'EXPIRED', label: 'Expired' }, { id: 'ALL', label: 'All' }]} />
          <Panel pad={false}>
            <ErrorBox error={q.error} />
            {q.isLoading ? <Loading /> : q.data?.items.length ? <>
              <Table head={['Document', 'Institution', 'Expiry', 'Validity', 'OCR', 'Verification']}>
                {q.data.items.map((d: any) => <tr key={d.id}><td><Link className="text-ledger hover:underline" to={`/documents/${d.id}`}>{label(d.doc_type)} #{d.id}</Link> <Synthetic on={d.is_synthetic} /></td>
                  <td>{d.institution}</td><td>{fmtDate(d.expiry_date)} {d.days_to_expiry != null && <DaysLeft days={d.days_to_expiry} state="OPEN" />}</td>
                  <td><Status value={d.validity} /></td><td className="text-xs">{label(d.ocr_status)}{d.extraction_confidence != null && ` · ${Math.round(d.extraction_confidence * 100)}%`}</td>
                  <td><Status value={d.verification_status} /></td></tr>)}
              </Table>
              <Pager page={page} pages={q.data.pages} total={q.data.total} onPage={(p) => setSp({ validity, page: String(p) })} /></> : <div className="p-4"><Empty>No documents in this view.</Empty></div>}
          </Panel>
        </div>
        <Panel title="Upload a document"><UploadDocument onDone={(d) => nav(`/documents/${d.id}`)} /></Panel>
      </div>
    </div>
  )
}

export function DocumentDetail() {
  const { id } = useParams()
  const { can } = useAuth()
  const qc = useQueryClient()
  const toast = useToast()
  const nav = useNavigate()
  const q = useQuery({ queryKey: ['document', id], queryFn: () => api(`/api/documents/${id}`) })
  const [exp, setExp] = useState('')
  const [iss, setIss] = useState('')
  const [note, setNote] = useState('')
  const [renew, setRenew] = useState(false)
  const conf = useMutation({ mutationFn: (reject: boolean) => api(`/api/documents/${id}/confirm`, { body: { expiry_date: exp || q.data.ocr_result?.expiry, issue_date: iss || null, note, reject } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['document', id] }); toast.ok('Decision recorded.') }, onError: toast.fail })
  if (q.isLoading) return <Loading />
  if (q.error) return <ErrorBox error={q.error} />
  const d = q.data
  const o = d.ocr_result || {}
  const isImg = d.file_url && !String(o.engine || '').includes('pdf')
  return (
    <div>
      <PageHeader title={`${label(d.doc_type)} — ${d.institution}`} sub={<>Uploaded document #{d.id} · OCR {label(d.ocr_status)} · verification <Status value={d.verification_status} /></>} />
      <div className="grid gap-4 lg:grid-cols-[1fr_380px]">
        <Panel title="Scan with detected date highlighted">
          {d.file_url && <div className="relative inline-block w-full">
            <img src={d.file_url} alt="Uploaded document scan" className="w-full rounded border border-rule" onError={(e) => ((e.target as HTMLImageElement).style.display = 'none')} />
            {(o.highlights || []).filter((h: any) => h.page === 0).map((h: any, i: number) => (
              <div key={i} className="absolute border-2 border-warn bg-warn/15" title={`${h.text} (${Math.round(h.conf * 100)}%)`}
                style={{ left: `${h.x * 100}%`, top: `${h.y * 100}%`, width: `${h.w * 100}%`, height: `${h.h * 100}%` }} />))}
          </div>}
          {!isImg && <a className="text-sm text-ledger hover:underline" href={d.file_url} target="_blank" rel="noreferrer">Open file</a>}
          <details className="mt-3 text-sm"><summary className="cursor-pointer text-ledger">OCR text</summary><pre className="mt-2 whitespace-pre-wrap text-xs">{d.ocr_text}</pre></details>
        </Panel>
        <div className="space-y-4">
          <Panel title="What OCR proposed">
            <dl className="grid grid-cols-[130px_1fr] gap-y-1 text-[13px]">
              <dt className="text-ink/60">Expiry</dt><dd className="font-semibold">{o.expiry ? fmtDate(o.expiry) : 'not found'}</dd>
              <dt className="text-ink/60">Issue / start</dt><dd>{fmtDate(o.issue)}</dd>
              <dt className="text-ink/60">Why</dt><dd>{o.reason}</dd>
              <dt className="text-ink/60">Confidence</dt><dd>{o.confidence != null ? `${Math.round(o.confidence * 100)}%` : '—'} (page {Math.round((o.page_confidence || 0) * 100)}%)</dd>
              <dt className="text-ink/60">Engine</dt><dd>{o.engine}</dd>
              <dt className="text-ink/60">Agreement</dt><dd>{o.agreement ? 'yes' : 'no'} — second read via {o.agreement_source}{o.secondary_expiry && ` (${o.secondary_expiry})`}</dd>
              <dt className="text-ink/60">Pre-processing</dt><dd>{(o.preprocessing || []).map((p: any) => `deskew ${p.deskew_angle}°`).join(', ')}, denoised</dd>
            </dl>
            <p className="mt-2 text-[11.5px] text-ink/60">≥90% with agreement → pending confirmation; 60–90% → manual review; below 60% → unreadable. All outcomes need an official.</p>
          </Panel>
          {d.verification_status === 'PENDING' && can('document.verify') ? (
            <Panel title="Official confirmation">
              <div className="space-y-3">
                <Field label="Expiry date" hint="Pre-filled with the OCR proposal; correct it if the document says otherwise."><Input type="date" defaultValue={o.expiry || ''} onChange={(e) => setExp(e.target.value)} /></Field>
                <Field label="Issue / start date"><Input type="date" defaultValue={o.issue || ''} onChange={(e) => setIss(e.target.value)} /></Field>
                <Field label="Note"><Textarea value={note} onChange={(e) => setNote(e.target.value)} /></Field>
                <div className="flex gap-2"><Button onClick={() => conf.mutate(false)} disabled={!(exp || o.expiry)}>Confirm and create renewal obligation</Button>
                  <Button variant="secondary" disabled={!note} onClick={() => conf.mutate(true)}>Reject document</Button></div>
              </div>
            </Panel>
          ) : (
            <Panel title="Status">
              <p className="text-sm">Confirmed expiry: <b>{fmtDate(d.expiry_date)}</b> <Status value={d.validity} /></p>
              {d.verified_at && <p className="text-xs text-ink/60">Verified {fmtDateTime(d.verified_at)}</p>}
              {d.obligation_id && <Link className="mt-2 inline-block text-sm text-ledger hover:underline" to={`/ledger/${d.obligation_id}`}>Renewal obligation</Link>}
              {d.is_current && d.verification_status !== 'REJECTED' && <div className="mt-3"><Button variant="secondary" size="sm" onClick={() => setRenew(!renew)}>Submit renewed document</Button></div>}
              {renew && <div className="mt-3 border-t border-rule pt-3"><UploadDocument institutionId={d.institution_id} previousId={d.id} onDone={(x) => nav(`/documents/${x.id}`)} /></div>}
            </Panel>
          )}
          {d.renewal_history?.length > 0 && <Panel title="Renewal history"><ul className="text-[13px]">{d.renewal_history.map((h: any) => <li key={h.id}><Link className="text-ledger hover:underline" to={`/documents/${h.id}`}>#{h.id}</Link> expired {fmtDate(h.expiry_date)} · {label(h.verification_status)}</li>)}</ul></Panel>}
          {d.verification_status === 'PENDING' && !can('document.verify') && <Notice>Uploaded. An AICTE official will confirm the dates; you will be notified.</Notice>}
        </div>
      </div>
      {toast.node}
    </div>
  )
}
