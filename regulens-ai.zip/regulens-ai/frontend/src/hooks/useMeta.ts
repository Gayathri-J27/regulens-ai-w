import { useQuery } from '@tanstack/react-query'
import { api } from '../services/api'

export type Meta = {
  regions: { id: number; code: string; name: string; states: string[] }[]
  routes: { code: string; name: string; version: number }[]
  application_types: string[]
  obligation_types: Record<string, string>
  reason_codes: string[]
  stages: string[]
  officers: { id: number; name: string; role: string; region_id: number | null }[]
}

export function useMeta() {
  return useQuery<Meta>({ queryKey: ['meta'], queryFn: () => api('/api/meta'), staleTime: 300000 })
}

export const regionName = (m: Meta | undefined, id?: number | null) => m?.regions.find((r) => r.id === id)?.code || '—'
