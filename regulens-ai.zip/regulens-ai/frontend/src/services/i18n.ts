import i18n from 'i18next'
import { initReactI18next } from 'react-i18next'
import en from '../locales/en.json'
import hi from '../locales/hi.json'
import mr from '../locales/mr.json'
import ta from '../locales/ta.json'

const saved = (() => { try { return localStorage.getItem('regulens.lang') || 'en' } catch { return 'en' } })()

i18n.use(initReactI18next).init({
  resources: { en: { translation: en }, hi: { translation: hi }, mr: { translation: mr }, ta: { translation: ta } },
  lng: saved, fallbackLng: 'en', interpolation: { escapeValue: false },
})

export function setLanguage(l: string) {
  i18n.changeLanguage(l)
  try { localStorage.setItem('regulens.lang', l) } catch { /* ignore */ }
  document.documentElement.lang = l
}

export const LANGS = [{ code: 'en', label: 'English' }, { code: 'hi', label: 'हिन्दी' }, { code: 'mr', label: 'मराठी' }, { code: 'ta', label: 'தமிழ்' }]
export default i18n
