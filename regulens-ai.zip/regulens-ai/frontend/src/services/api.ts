// Thin fetch wrapper for the ReguLens API. Token is kept in sessionStorage (cleared when the tab closes).
const KEY = 'regulens.token'

export class ApiError extends Error {
  status: number
  detail: unknown
  constructor(status: number, detail: unknown) {
    super(typeof detail === 'string' ? detail : Array.isArray(detail) ? detail.map((d: any) => d.msg).join('; ') : `Request failed (${status})`)
    this.status = status
    this.detail = detail
  }
}

export const token = {
  get: () => { try { return sessionStorage.getItem(KEY) } catch { return null } },
  set: (t: string | null) => { try { t ? sessionStorage.setItem(KEY, t) : sessionStorage.removeItem(KEY) } catch { /* storage unavailable */ } },
}

let onUnauthorized: (() => void) | null = null
export const setUnauthorizedHandler = (fn: () => void) => { onUnauthorized = fn }

export async function api<T = any>(path: string, opts: { method?: string; body?: unknown; form?: FormData; raw?: boolean } = {}): Promise<T> {
  const headers: Record<string, string> = {}
  const t = token.get()
  if (t) headers.Authorization = `Bearer ${t}`
  let body: BodyInit | undefined
  if (opts.form) body = opts.form
  else if (opts.body !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.body) }
  const r = await fetch(path, { method: opts.method || (body ? 'POST' : 'GET'), headers, body })
  if (r.status === 401 && !path.startsWith('/api/auth/login')) onUnauthorized?.()
  if (!r.ok) {
    let detail: unknown = r.statusText
    try { detail = (await r.json()).detail } catch { /* not json */ }
    throw new ApiError(r.status, detail)
  }
  if (opts.raw) return r as unknown as T
  const ct = r.headers.get('content-type') || ''
  return (ct.includes('json') ? r.json() : r.text()) as Promise<T>
}

export function qs(params: Record<string, unknown>): string {
  const p = new URLSearchParams()
  Object.entries(params).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') p.set(k, String(v)) })
  const s = p.toString()
  return s ? `?${s}` : ''
}

/** Authenticated file download (exports): fetches with the bearer token and saves via an object URL. */
export async function download(path: string, filename: string) {
  const r = await api<Response>(path, { raw: true })
  const blob = await r.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename; a.click()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}
