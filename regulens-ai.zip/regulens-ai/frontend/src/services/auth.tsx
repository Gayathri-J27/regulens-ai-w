import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import { api, setUnauthorizedHandler, token } from './api'

export type Me = {
  id: number; email: string; full_name: string; role: string; role_label: string; region_id: number | null; region: string | null
  institution_id: number | null; institution: string | null; preferred_language: string; totp_enabled: boolean
  permissions: string[]; modules: string[]
}

type Ctx = { me: Me | null; loading: boolean; can: (p: string) => boolean; refresh: () => Promise<void>; logout: () => Promise<void>; setMe: (m: Me | null) => void }
const AuthCtx = createContext<Ctx>(null as unknown as Ctx)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null)
  const [loading, setLoading] = useState(true)
  const refresh = useCallback(async () => {
    if (!token.get()) { setMe(null); setLoading(false); return }
    try { setMe(await api<Me>('/api/auth/me')) } catch { token.set(null); setMe(null) } finally { setLoading(false) }
  }, [])
  useEffect(() => { setUnauthorizedHandler(() => { token.set(null); setMe(null) }); refresh() }, [refresh])
  const logout = async () => { try { await api('/api/auth/logout', { method: 'POST' }) } catch { /* already gone */ } token.set(null); setMe(null) }
  const can = (p: string) => !!me?.permissions.includes(p)
  return <AuthCtx.Provider value={{ me, loading, can, refresh, logout, setMe }}>{children}</AuthCtx.Provider>
}

export const useAuth = () => useContext(AuthCtx)
export const isInstitution = (role?: string) => role === 'INSTITUTION_PRINCIPAL' || role === 'INSTITUTION_COMPLIANCE'
