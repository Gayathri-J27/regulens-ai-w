// The deadline clock strip: one bar from start to due date showing whose time each day was.
// Segments are derived from the clock history returned by /api/clocks/{id}/explain — never computed in the browser.
import { cx, fmtDate } from './ui'

type Explain = {
  start_date: string | null; due_date: string | null; state: string; day_mode: string; original_budget: number; effective_budget: number
  remaining: number; pause_intervals: { kind: string; start: string; end: string | null; calendar_days: number; countable_days: number }[]
  extensions: { days: number; on: string; actor?: string }[]; reverts: { policy: string; on: string }[]; holidays_excluded: { date: string; name: string }[]
  result: { projected_due_if_resumed_today?: string | null; stopped_on?: string | null; as_of?: string | null }
}

const d = (s: string) => new Date(s + 'T00:00:00').getTime()
const PAUSE_TONE: Record<string, string> = { INSTITUTION: 'bg-warn/70', AICTE: 'bg-ink-300', LEGAL_HOLD: 'bg-ink-600', SOURCE: 'bg-ink-300' }
const PAUSE_LABEL: Record<string, string> = { INSTITUTION: 'Waiting on institution', AICTE: 'Paused by AICTE', LEGAL_HOLD: 'Legal hold', SOURCE: 'Source unavailable' }

export function ClockStrip({ ex }: { ex: Explain }) {
  if (!ex.start_date) return null
  const today = ex.result.as_of || new Date().toISOString().slice(0, 10)
  const end = ex.due_date || ex.result.projected_due_if_resumed_today || today
  const stop = ex.result.stopped_on
  const lo = d(ex.start_date)
  const hi = Math.max(d(end), d(today), stop ? d(stop) : 0) + 86400000
  const pos = (s: string) => `${Math.min(100, Math.max(0, ((d(s) - lo) / (hi - lo)) * 100))}%`
  const width = (a: string, b: string) => `${Math.max(0.6, ((d(b) - d(a)) / (hi - lo)) * 100)}%`
  const overdue = ex.due_date && !stop && d(today) > d(ex.due_date)
  return (
    <figure aria-label="Deadline clock history" className="w-full">
      <div className="relative h-9 overflow-hidden rounded border border-rule bg-ledger-50">
        {/* running time = base; overdue beyond due date */}
        {ex.due_date && overdue && <div className="absolute inset-y-0 bg-late/25" style={{ left: pos(ex.due_date), width: width(ex.due_date, today) }} />}
        {ex.pause_intervals.map((p, i) => (
          <div key={i} title={`${PAUSE_LABEL[p.kind] || p.kind}: ${p.start} → ${p.end || 'now'} (${p.calendar_days} days, not counted)`}
            className={cx('absolute inset-y-0 bg-[repeating-linear-gradient(135deg,transparent_0_5px,rgba(255,255,255,.35)_5px_9px)]', PAUSE_TONE[p.kind] || 'bg-ink-300')}
            style={{ left: pos(p.start), width: width(p.start, p.end || today) }} />
        ))}
        {stop && <div className="absolute inset-y-0 right-0 bg-white/70" style={{ left: pos(stop) }} />}
        <div className="absolute inset-y-0 w-0.5 bg-ink" style={{ left: pos(today) }} title={`Today ${today}`} />
        {ex.due_date && <div className="absolute inset-y-0 w-[3px] bg-late" style={{ left: pos(ex.due_date) }} title={`Due ${ex.due_date}`} />}
        {ex.extensions.map((x, i) => <div key={i} className="absolute top-0 h-2 w-2 -translate-x-1 rotate-45 bg-ok" style={{ left: pos(x.on) }} title={`Extension +${x.days} on ${x.on}`} />)}
      </div>
      <figcaption className="mt-1.5 flex flex-wrap justify-between gap-x-4 gap-y-1 text-[11.5px] text-ink/70">
        <span>Started {fmtDate(ex.start_date)}</span>
        <span className="flex flex-wrap gap-x-3">
          <span><i className="mr-1 inline-block h-2 w-3 bg-ledger-50 ring-1 ring-rule" />time counting</span>
          <span><i className="mr-1 inline-block h-2 w-3 bg-warn/70" />waiting on institution</span>
          {ex.pause_intervals.some((p) => p.kind === 'LEGAL_HOLD') && <span><i className="mr-1 inline-block h-2 w-3 bg-ink-600" />legal hold</span>}
          <span><i className="mr-1 inline-block h-2 w-0.5 bg-ink" /> today</span>
          {ex.extensions.length > 0 && <span><i className="mr-1 inline-block h-2 w-2 rotate-45 bg-ok" />extension</span>}
        </span>
        <span className={overdue ? 'font-semibold text-late' : 'font-semibold text-ink'}>
          {ex.due_date ? `Due ${fmtDate(ex.due_date)}` : `Paused — would be due ${fmtDate(ex.result.projected_due_if_resumed_today)}`}
        </span>
      </figcaption>
    </figure>
  )
}
