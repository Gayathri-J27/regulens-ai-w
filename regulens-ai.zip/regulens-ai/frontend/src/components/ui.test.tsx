import { render, screen } from '@testing-library/react'
import '../services/i18n'
import { ClockStrip } from './ClockStrip'
import { DaysLeft, Status, label } from './ui'

describe('status badges', () => {
  it('carry text and a glyph so meaning does not depend on colour', () => {
    render(<Status value="OVERDUE" />)
    const el = screen.getByText('overdue')
    expect(el.textContent).toContain('!')
  })
  it('render a dash for empty values', () => {
    render(<Status value={null} />)
    expect(screen.getByText('—')).toBeInTheDocument()
  })
})

describe('label', () => {
  it('keeps regulatory acronyms', () => {
    expect(label('EVC')).toBe('EVC')
    expect(label('SAC_SHC')).toBe('SAC/SHC')
    expect(label('RESCRUTINY')).toBe('Re-scrutiny')
    expect(label('AWAITING_DECISION')).toBe('Awaiting decision')
  })
})

describe('DaysLeft', () => {
  it('handles overdue, due today, paused and closed', () => {
    const { rerender } = render(<DaysLeft days={-3} state="OPEN" />)
    expect(screen.getByText('3d overdue')).toBeInTheDocument()
    rerender(<DaysLeft days={0} state="OPEN" />)
    expect(screen.getByText('due today')).toBeInTheDocument()
    rerender(<DaysLeft days={null} state="PAUSED" />)
    expect(screen.getByText('paused')).toBeInTheDocument()
    rerender(<DaysLeft days={4} state="MET" />)
    expect(screen.getByText('closed')).toBeInTheDocument()
  })
})

describe('ClockStrip', () => {
  const ex = { start_date: '2026-10-01', due_date: '2026-11-05', state: 'RUNNING', day_mode: 'WORKING', original_budget: 20, effective_budget: 25, remaining: 10,
    pause_intervals: [{ kind: 'INSTITUTION', start: '2026-10-05', end: '2026-10-12', calendar_days: 7, countable_days: 5 }],
    extensions: [{ days: 5, on: '2026-10-20' }], reverts: [], holidays_excluded: [], result: { as_of: '2026-10-25' } }
  it('shows pause segments, extension marker and due date from server history', () => {
    render(<ClockStrip ex={ex as any} />)
    expect(screen.getByTitle(/Waiting on institution: 2026-10-05 → 2026-10-12/)).toBeInTheDocument()
    expect(screen.getByTitle('Extension +5 on 2026-10-20')).toBeInTheDocument()
    expect(screen.getByText(/Due 05 Nov 2026/)).toBeInTheDocument()
  })
  it('explains a paused clock without inventing a due date', () => {
    render(<ClockStrip ex={{ ...ex, due_date: null, result: { as_of: '2026-10-25', projected_due_if_resumed_today: '2026-11-20' } } as any} />)
    expect(screen.getByText(/Paused — would be due 20 Nov 2026/)).toBeInTheDocument()
  })
})
