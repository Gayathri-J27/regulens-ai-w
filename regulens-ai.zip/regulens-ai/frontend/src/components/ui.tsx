// Component primitives in the shadcn/ui style (hand-authored, Tailwind-based, no external UI runtime).
import clsx from 'clsx'
import { useEffect, useRef, useState, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes,
  type TextareaHTMLAttributes } from 'react'
import { useTranslation } from 'react-i18next'
import { ApiError } from '../services/api'

export const cx = clsx

type BtnVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'quiet'
export function Button({ variant = 'primary', size = 'md', loading, className, children, ...p }:
  ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; size?: 'sm' | 'md'; loading?: boolean }) {
  return (
    <button {...p} disabled={p.disabled || loading}
      className={cx('inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed',
        'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ledger',
        size === 'sm' ? 'h-8 px-2.5 text-[13px]' : 'h-10 px-4 text-sm min-w-[2.75rem]',
        variant === 'primary' && 'bg-ledger text-white hover:bg-ledger-600',
        variant === 'secondary' && 'border border-rule bg-white text-ink hover:bg-mist',
        variant === 'ghost' && 'text-ledger hover:bg-ledger-50',
        variant === 'quiet' && 'text-ink/70 hover:text-ink hover:bg-mist',
        variant === 'danger' && 'bg-late text-white hover:bg-late/90', className)}>
      {loading && <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" aria-hidden />}
      {children}
    </button>
  )
}

export function Field({ label, hint, error, children, className }: { label: string; hint?: string; error?: string; children: ReactNode; className?: string }) {
  return (
    <label className={cx('block text-sm', className)}>
      <span className="mb-1 block font-medium text-ink">{label}</span>
      {children}
      {hint && !error && <span className="mt-1 block text-xs text-ink/60">{hint}</span>}
      {error && <span role="alert" className="mt-1 block text-xs text-late">{error}</span>}
    </label>
  )
}

const inputCls = 'w-full rounded-md border border-rule bg-white px-3 py-2 text-sm text-ink placeholder:text-ink/40 focus:border-ledger focus:outline-none focus:ring-2 focus:ring-ledger/25'
export const Input = (p: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={cx(inputCls, 'h-10', p.className)} />
export const Textarea = (p: TextareaHTMLAttributes<HTMLTextAreaElement>) => <textarea rows={3} {...p} className={cx(inputCls, p.className)} />
export const Select = ({ children, ...p }: SelectHTMLAttributes<HTMLSelectElement>) =>
  <select {...p} className={cx(inputCls, 'h-10 pr-8', p.className)}>{children}</select>

export function Panel({ title, actions, children, className, pad = true }: { title?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string; pad?: boolean }) {
  return (
    <section className={cx('rounded-lg border border-rule bg-white', className)}>
      {(title || actions) && (
        <header className="flex flex-wrap items-center justify-between gap-2 border-b border-rule px-4 py-3">
          {title && <h2 className="text-[15px] font-semibold text-ink">{title}</h2>}
          {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
        </header>
      )}
      <div className={pad ? 'p-4' : ''}>{children}</div>
    </section>
  )
}

export function PageHeader({ title, sub, actions }: { title: string; sub?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-serif text-[26px] font-semibold leading-tight text-ink">{title}</h1>
        {sub && <p className="mt-1 max-w-3xl text-sm text-ink/70">{sub}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  )
}

const TONES: Record<string, string> = {
  red: 'bg-late-50 text-late ring-late/25', amber: 'bg-warn-50 text-warn ring-warn/25', green: 'bg-ok-50 text-ok ring-ok/25',
  blue: 'bg-ledger-50 text-ledger ring-ledger/25', grey: 'bg-mist text-ink/75 ring-ink/10', navy: 'bg-ink text-white ring-ink',
}
// Status badges always carry a text label + a glyph so meaning never depends on colour alone.
const STATUS: Record<string, [string, string]> = {
  OVERDUE: ['red', '!'], BREACHED: ['red', '!'], HIGH: ['red', '▲'], REJECTED: ['red', '✕'], BOUNCED: ['red', '✕'], FAILED: ['red', '✕'],
  INFECTED: ['red', '✕'], UNROUTABLE: ['red', '!'], EXPIRED: ['red', '!'], DELAYED: ['amber', '!'],
  MEDIUM: ['amber', '◆'], PAUSED: ['amber', 'Ⅱ'], PAUSED_INSTITUTION: ['amber', 'Ⅱ'], PAUSED_AICTE: ['amber', 'Ⅱ'], PAUSED_LEGAL_HOLD: ['amber', 'Ⅱ'],
  PAUSED_SOURCE: ['amber', 'Ⅱ'], RETURNED: ['amber', '↩'], SUBMITTED: ['blue', '⇪'], PENDING_VERIFICATION: ['blue', '⇪'], EXPIRING_SOON: ['amber', '◷'],
  EXPIRING: ['amber', '◷'], MANUAL_REVIEW: ['amber', '?'], MANUAL_REVIEW_UNREADABLE: ['red', '?'], ON_HOLD: ['amber', 'Ⅱ'], AWAITING_DECISION: ['blue', '⚖'],
  QUEUED: ['grey', '…'], SENT: ['blue', '→'], OPEN: ['blue', '○'], ACKNOWLEDGED: ['blue', '✓'], IN_PROGRESS: ['blue', '○'], RUNNING: ['blue', '▶'],
  SCHEDULED: ['blue', '◷'], PANEL_PROPOSED: ['blue', '○'], REPORT_PENDING: ['amber', '…'], PROPOSED: ['blue', '○'], PENDING: ['grey', '…'],
  MET: ['green', '✓'], VERIFIED: ['green', '✓'], DELIVERED: ['green', '✓'], APPROVED: ['green', '✓'], CLOSED: ['grey', '■'], LOW: ['green', '▼'],
  STOPPED_MET: ['green', '✓'], STOPPED_WAIVED: ['grey', '■'], WAIVED: ['grey', '■'], CANCELLED: ['grey', '■'], MERGED: ['grey', '⇢'], CONFIRMED: ['green', '✓'],
  CORRECTED: ['green', '✓'], VALID: ['green', '✓'], ACCEPTED: ['green', '✓'], EFFECTIVE: ['green', '✓'], DRAFT: ['grey', '✎'], PREVIEWED: ['blue', '◐'],
  SUPERSEDED: ['grey', '■'], RETIRED: ['grey', '■'], WITHDRAWN: ['grey', '■'], VISITED: ['blue', '✓'], REPORT_RECEIVED: ['green', '✓'],
  VERIFIED_PENDING_CONFIRMATION: ['blue', '◐'], INSUFFICIENT_DATA: ['grey', '?'], UNVERIFIED: ['grey', '?'], STAGED: ['blue', '◐'], COMMITTED: ['green', '✓'],
}
export function Badge({ children, tone, title }: { children: ReactNode; tone?: keyof typeof TONES; title?: string }) {
  return <span title={title} className={cx('inline-flex items-center gap-1 whitespace-nowrap rounded px-1.5 py-0.5 text-[11.5px] font-medium ring-1 ring-inset', TONES[tone || 'grey'])}>{children}</span>
}
export function Status({ value }: { value?: string | null }) {
  if (!value) return <span className="text-ink/40">—</span>
  const [tone, glyph] = STATUS[value] || ['grey', '•']
  return <Badge tone={tone as any}><span aria-hidden>{glyph}</span>{value.replace(/_/g, ' ').toLowerCase()}</Badge>
}
export function Synthetic({ on }: { on?: boolean }) {
  return on ? <Badge tone="grey" title="Fictional record generated for demonstration">synthetic</Badge> : null
}

export function Stat({ label, value, tone, sub, to }: { label: string; value: ReactNode; tone?: 'red' | 'amber' | 'green'; sub?: string; to?: string }) {
  const body = (
    <div className={cx('h-full border-l-[3px] bg-white px-3 py-2.5', tone === 'red' ? 'border-late' : tone === 'amber' ? 'border-warn' : tone === 'green' ? 'border-ok' : 'border-ledger')}>
      <div className="text-xs text-ink/65">{label}</div>
      <div className="mt-0.5 text-2xl font-semibold tabular-nums text-ink">{value}</div>
      {sub && <div className="text-[11.5px] text-ink/55">{sub}</div>}
    </div>
  )
  return to ? <a href={to} className="block hover:bg-mist focus-visible:outline focus-visible:outline-2 focus-visible:outline-ledger">{body}</a> : body
}

export function Loading({ label }: { label?: string }) {
  const { t } = useTranslation()
  return <div role="status" className="flex items-center gap-2 py-8 text-sm text-ink/60"><span className="h-4 w-4 animate-spin rounded-full border-2 border-ledger border-t-transparent" />{label || t('common.loading')}</div>
}
export function Empty({ children }: { children?: ReactNode }) {
  const { t } = useTranslation()
  return <div className="rounded-md border border-dashed border-rule px-4 py-8 text-center text-sm text-ink/60">{children || t('common.empty')}</div>
}
export function ErrorBox({ error }: { error: unknown }) {
  if (!error) return null
  const msg = error instanceof ApiError ? error.message : error instanceof Error ? error.message : String(error)
  const status = error instanceof ApiError ? error.status : null
  return (
    <div role="alert" className="rounded-md border border-late/30 bg-late-50 px-3 py-2 text-sm text-late">
      {status === 403 ? 'Not permitted: ' : status === 404 ? 'Not found: ' : ''}{msg}
    </div>
  )
}
export function Notice({ tone = 'blue', children }: { tone?: 'blue' | 'amber' | 'green' | 'red'; children: ReactNode }) {
  const c = { blue: 'border-ledger/25 bg-ledger-50 text-ink', amber: 'border-warn/30 bg-warn-50 text-ink', green: 'border-ok/30 bg-ok-50 text-ink', red: 'border-late/30 bg-late-50 text-late' }[tone]
  return <div className={cx('rounded-md border px-3 py-2 text-sm', c)}>{children}</div>
}

export function Table({ head, children, dense }: { head: ReactNode[]; children: ReactNode; dense?: boolean }) {
  return (
    <div className="overflow-x-auto">
      <table className={cx('w-full border-collapse text-left text-[13px]', dense && 'text-[12.5px]')}>
        <thead><tr className="border-b border-rule bg-mist/70 text-[12px] text-ink/70">{head.map((h, i) => <th key={i} scope="col" className="whitespace-nowrap px-3 py-2 font-semibold">{h}</th>)}</tr></thead>
        <tbody className="[&>tr]:border-b [&>tr]:border-rule/70 [&>tr:hover]:bg-mist/40 [&_td]:px-3 [&_td]:py-2 [&_td]:align-top">{children}</tbody>
      </table>
    </div>
  )
}

export function Pager({ page, pages, total, onPage }: { page: number; pages: number; total: number; onPage: (p: number) => void }) {
  const { t } = useTranslation()
  if (!total) return null
  return (
    <nav aria-label="Pagination" className="flex items-center justify-between gap-2 px-3 py-2 text-xs text-ink/65">
      <span>{total.toLocaleString()} records</span>
      <span className="flex items-center gap-1">
        <Button size="sm" variant="secondary" disabled={page <= 1} onClick={() => onPage(page - 1)}>{t('common.previous')}</Button>
        <span className="px-2">{t('common.page')} {page} {t('common.of')} {Math.max(pages, 1)}</span>
        <Button size="sm" variant="secondary" disabled={page >= pages} onClick={() => onPage(page + 1)}>{t('common.next')}</Button>
      </span>
    </nav>
  )
}

export function Tabs({ tabs, value, onChange }: { tabs: { id: string; label: ReactNode }[]; value: string; onChange: (v: string) => void }) {
  return (
    <div role="tablist" className="mb-4 flex flex-wrap gap-1 border-b border-rule">
      {tabs.map((t) => (
        <button key={t.id} role="tab" aria-selected={value === t.id} onClick={() => onChange(t.id)}
          className={cx('-mb-px border-b-2 px-3 py-2 text-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-ledger',
            value === t.id ? 'border-ledger font-semibold text-ink' : 'border-transparent text-ink/65 hover:text-ink')}>{t.label}</button>
      ))}
    </div>
  )
}

export function Dialog({ open, title, onClose, children, wide }: { open: boolean; title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDialogElement>(null)
  useEffect(() => { const d = ref.current; if (!d) return; if (open && !d.open) d.showModal(); if (!open && d.open) d.close() }, [open])
  return (
    <dialog ref={ref} onClose={onClose} aria-label={title}
      className={cx('w-[calc(100%-2rem)] rounded-lg border border-rule p-0 backdrop:bg-ink/40', wide ? 'max-w-3xl' : 'max-w-lg')}>
      {open && (
        <div>
          <header className="flex items-center justify-between border-b border-rule px-4 py-3">
            <h2 className="font-semibold text-ink">{title}</h2>
            <button onClick={onClose} aria-label="Close" className="rounded px-2 text-xl leading-none text-ink/60 hover:bg-mist">×</button>
          </header>
          <div className="max-h-[75vh] overflow-y-auto p-4">{children}</div>
        </div>
      )}
    </dialog>
  )
}

export function useToast() {
  const [msg, setMsg] = useState<{ text: string; tone: 'green' | 'red' } | null>(null)
  useEffect(() => { if (!msg) return; const t = setTimeout(() => setMsg(null), 4500); return () => clearTimeout(t) }, [msg])
  const node = msg ? (
    <div role="status" aria-live="polite" className={cx('fixed bottom-4 right-4 z-50 max-w-sm rounded-md px-4 py-3 text-sm text-white shadow-lg', msg.tone === 'green' ? 'bg-ok' : 'bg-late')}>{msg.text}</div>
  ) : null
  return { ok: (text: string) => setMsg({ text, tone: 'green' }), fail: (e: unknown) => setMsg({ text: e instanceof Error ? e.message : String(e), tone: 'red' }), node }
}

export const fmtDate = (s?: string | null) => (s ? new Date(s.length === 10 ? s + 'T00:00:00' : s).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—')
export const fmtDateTime = (s?: string | null) => (s ? new Date(s).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—')
const ACR: Record<string, string> = { evc: 'EVC', 'sac shc': 'SAC/SHC', aicte: 'AICTE', sms: 'SMS', ocr: 'OCR', noc: 'NOC', pdf: 'PDF', rescrutiny: 'Re-scrutiny',
  aph: 'APH', ro: 'RO', in_app: 'In-app', 'in app': 'In-app', csv: 'CSV', api: 'API', totp: 'TOTP' }
export const label = (s?: string | null) => {
  if (!s) return '—'
  let t = s.replace(/_/g, ' ').toLowerCase()
  for (const [k, v] of Object.entries(ACR)) t = t.replace(new RegExp(`\\b${k}\\b`, 'g'), v)
  return t.replace(/^[a-z]/, (c) => c.toUpperCase())
}

export function DaysLeft({ days, state }: { days: number | null | undefined; state?: string }) {
  if (days === null || days === undefined) return <span className="text-ink/50">{state === 'PAUSED' ? 'paused' : '—'}</span>
  if (['MET', 'WAIVED', 'CANCELLED', 'MERGED'].includes(state || '')) return <span className="text-ink/50">closed</span>
  if (days < 0) return <span className="font-semibold text-late">{-days}d overdue</span>
  if (days <= 3) return <span className="font-semibold text-warn">{days === 0 ? 'due today' : `${days}d left`}</span>
  return <span className="tabular-nums text-ink/80">{days}d left</span>
}
