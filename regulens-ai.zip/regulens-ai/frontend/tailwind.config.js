/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: '#14233C', 700: '#1C3050', 600: '#29406A', 300: '#8FA3C2' },
        ledger: { DEFAULT: '#1F5AA6', 600: '#18498A', 50: '#EAF1FA' },
        mist: '#EEF2F7', rule: '#D3DBE6', paper: '#FFFFFF',
        late: { DEFAULT: '#B42318', 50: '#FEF3F2' }, warn: { DEFAULT: '#B54708', 50: '#FFFAEB' }, ok: { DEFAULT: '#067647', 50: '#ECFDF3' },
      },
      fontFamily: {
        sans: ['"Noto Sans"', '"Noto Sans Devanagari"', '"Noto Sans Tamil"', 'system-ui', 'sans-serif'],
        serif: ['"Noto Serif"', '"Noto Serif Devanagari"', 'Georgia', 'serif'],
      },
    },
  },
  plugins: [],
}
