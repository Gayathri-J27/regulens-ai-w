#!/usr/bin/env bash
# Start/stop the API for local development. Usage: scripts/devserver.sh start|stop|restart [--scheduler]
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RUN="${REGULENS_RUN_DIR:-$ROOT/.run}"
mkdir -p "$RUN"
PIDF="$RUN/api.pid"
stop() {
  if [ -f "$PIDF" ]; then kill "$(cat "$PIDF")" 2>/dev/null; rm -f "$PIDF"; sleep 1; fi
}
start() {
  local sched=0
  [ "${1:-}" = "--scheduler" ] && sched=1
  cd "$ROOT/backend"
  RUN_SCHEDULER=$sched nohup uvicorn app.main:app --host 0.0.0.0 --port "${API_PORT:-8000}" > "$RUN/api.log" 2>&1 &
  echo $! > "$PIDF"
  for _ in $(seq 1 30); do curl -sf "localhost:${API_PORT:-8000}/api/health" >/dev/null && { echo "API up (pid $(cat "$PIDF"), scheduler=$sched)"; return 0; }; sleep 1; done
  echo "API failed to start; see $RUN/api.log"; return 1
}
case "${1:-}" in
  start) start "${2:-}";;
  stop) stop;;
  restart) stop; start "${2:-}";;
  *) echo "usage: $0 start|stop|restart [--scheduler]";;
esac
