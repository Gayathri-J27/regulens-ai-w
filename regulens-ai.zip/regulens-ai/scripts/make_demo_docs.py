"""Generate FICTIONAL demo documents for the end-to-end scenario.

* approval_letter_demo.pdf        — digitally generated letter (text layer)
* approval_letter_scanned.pdf     — same letter rasterised, skewed and noisy (no text layer -> OCR path)
* lease_deed_scan.png             — skewed/noisy lease deed scan with an expiry date (OCR + highlight)
* lease_deed_renewal.png          — renewed lease (renewal submission)
* evidence_fire_noc.pdf           — sample evidence file
None of these are real AICTE documents; every page is watermarked SYNTHETIC DEMO.
"""
from __future__ import annotations

import sys
from datetime import date, timedelta
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

OUT = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "demo_docs")
OUT.mkdir(parents=True, exist_ok=True)
TODAY = date.today()
LETTER_DATE = TODAY - timedelta(days=2)
FIXED_DUE = TODAY + timedelta(days=150)
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

CLAUSES = [
    f"Ref: F.No. SYNTH/SR/2026/0001 dated {LETTER_DATE:%d.%m.%Y}",
    "To: The Principal, Kaveri Institute of Technology (SYNTHETIC DEMO), Chengalpattu, Tamil Nadu.",
    "Subject: Extension of Approval for the academic year 2026-27 — conditions of approval (FICTIONAL DOCUMENT FOR DEMONSTRATION).",
    "With reference to the application submitted by the institution, the competent authority has conveyed approval subject to the following conditions.",
    "1. The institution shall submit a valid Fire Safety No Objection Certificate issued by the State Fire Service within 30 days from the date of this letter.",
    "2. The Trust shall submit the registered lease deed extension for the land parcel on or before " + f"{FIXED_DUE:%d.%m.%Y}" + ".",
    "3. The institution must upload the audited statement of accounts for the financial year 2025-26 within 60 days of the date of this letter.",
    "4. The Principal is required to ensure that faculty vacancies are filled and furnish the updated faculty list within 90 days.",
    "5. The institution undertakes to maintain the student-teacher ratio as prescribed and to display the approval letter on its website.",
    "This letter is issued with the approval of the competent authority. ReguLens demo text: no statutory effect.",
]


def letter_pdf(path: Path):
    ss = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(path), pagesize=A4, title="SYNTHETIC approval letter")
    els = [Paragraph("ALL INDIA COUNCIL FOR TECHNICAL EDUCATION — SYNTHETIC DEMO DOCUMENT", ss["Title"]),
           Paragraph("This is a fictional document generated for the ReguLens AI prototype. It is not an AICTE letter.", ss["Italic"]),
           Spacer(1, 12)]
    for c in CLAUSES:
        els += [Paragraph(c, ss["BodyText"]), Spacer(1, 6)]
    doc.build(els)


def render_text_image(lines: list[str], w=1700, h=2200, size=30) -> np.ndarray:
    img = Image.new("L", (w, h), 255)
    d = ImageDraw.Draw(img)
    f = ImageFont.truetype(FONT, size)
    y = 120
    for line in lines:
        words, cur = line.split(), ""
        for word in words:
            t = (cur + " " + word).strip()
            if d.textlength(t, font=f) > w - 240:
                d.text((120, y), cur, fill=0, font=f)
                y += int(size * 1.6)
                cur = word
            else:
                cur = t
        d.text((120, y), cur, fill=0, font=f)
        y += int(size * 2.2)
    d.text((w - 560, h - 120), "SYNTHETIC DEMO — NOT A REAL DOCUMENT", fill=110, font=ImageFont.truetype(FONT, 22))
    return np.array(img)


def degrade(a: np.ndarray, angle: float, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    h, w = a.shape
    m = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
    a = cv2.warpAffine(a, m, (w, h), borderValue=255)
    noise = rng.normal(0, 18, a.shape)
    a = np.clip(a.astype(float) + noise, 0, 255).astype(np.uint8)
    return cv2.GaussianBlur(a, (3, 3), 0)


def scanned_pdf(path: Path):
    a = degrade(render_text_image(["AICTE — SYNTHETIC DEMO (scanned copy)"] + CLAUSES, size=28), 1.6, 7)
    Image.fromarray(a).convert("RGB").save(path, "PDF", resolution=200)


def lease(path: Path, start: date, years: int, expiry: date, angle: float, seed: int, title="LEASE DEED (SYNTHETIC DEMO)"):
    lines = [title,
             f"This Deed of Lease is executed on {start:%d.%m.%Y} between Sri Venkateswara Land Holdings (fictional) as Lessor and",
             "Kaveri Educational Trust (fictional) as Lessee for 10.5 acres in Survey No. 214, Chengalpattu District.",
             f"The lease is for a period of {years} years commencing from {start:%d.%m.%Y}.",
             f"This lease shall expire on {expiry:%d %B %Y} unless renewed by mutual consent.",
             "Registered at Sub-Registrar Office (fictional). Stamp duty paid. For demonstration only."]
    a = degrade(render_text_image(lines, w=1700, h=1300, size=34), angle, seed)
    cv2.imwrite(str(path), a)


def evidence(path: Path):
    ss = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(path), pagesize=A4)
    doc.build([Paragraph("Fire Safety No Objection Certificate — SYNTHETIC DEMO", ss["Title"]),
               Paragraph(f"Issued to Kaveri Institute of Technology (fictional) on {TODAY:%d.%m.%Y}. Valid till {TODAY.replace(year=TODAY.year + 1):%d.%m.%Y}.",
                         ss["BodyText"])])


if __name__ == "__main__":
    letter_pdf(OUT / "approval_letter_demo.pdf")
    scanned_pdf(OUT / "approval_letter_scanned.pdf")
    start = TODAY.replace(year=TODAY.year - 9) + timedelta(days=45)
    lease(OUT / "lease_deed_scan.png", start, 9, start.replace(year=start.year + 9) - timedelta(days=1), -2.2, 3)
    nstart = start.replace(year=start.year + 9)
    lease(OUT / "lease_deed_renewal.png", nstart, 15, nstart.replace(year=nstart.year + 15) - timedelta(days=1), 1.1, 5,
          "LEASE DEED — RENEWAL (SYNTHETIC DEMO)")
    evidence(OUT / "evidence_fire_noc.pdf")
    print("wrote", sorted(p.name for p in OUT.iterdir()))
