"""Load test: dashboards, ledger, Today's 10 and file uploads.

locust -f scripts/locustfile.py --headless -u 50 -r 10 -t 60s --host http://localhost:8000 --csv .run/load
"""
import random
from pathlib import Path

from locust import HttpUser, between, task

PDF = (Path(__file__).resolve().parents[1] / "demo_docs" / "evidence_fire_noc.pdf").read_bytes()
USERS = ["ro.south@regulens.demo", "ro.west@regulens.demo", "admin@regulens.demo", "bureau@regulens.demo", "authority@regulens.demo"]


class Officer(HttpUser):
    wait_time = between(0.5, 2)

    def on_start(self):
        r = self.client.post("/api/auth/login", json={"email": random.choice(USERS), "password": "Demo@1234"}, name="login")
        self.client.headers["Authorization"] = f"Bearer {r.json()['token']}"

    @task(6)
    def dashboard(self):
        self.client.get("/api/dashboard", name="dashboard (aggregate)")

    @task(2)
    def dashboard_filtered(self):
        self.client.get(f"/api/dashboard?status=IN_PROGRESS&priority={random.choice(['NORMAL', 'HIGH'])}", name="dashboard (filtered)")

    @task(4)
    def ledger(self):
        self.client.get(f"/api/ledger?view={random.choice(['all', 'overdue', 'upcoming'])}&page_size=25", name="ledger list")

    @task(2)
    def today(self):
        self.client.get("/api/today", name="today10")

    @task(1)
    def upload(self):
        self.client.post("/api/files", files={"file": ("load.pdf", PDF, "application/pdf")}, data={"purpose": "loadtest"}, name="upload (validate+scan+store)")
